//! What Copy Image puts on the clipboard: a picture's first frame, which
//! arboard offers as a PNG.
//!
//! On Linux the clipboard holds a picture only while the app that copied it
//! answers for it, so a thread does that until something else is copied.

use std::borrow::Cow;

use anyhow::{Context, ensure};
use yapfast_core::chat::CopiedPicture;

#[cfg(all(windows, feature = "discord"))]
pub fn discord_token(token: &str) -> Result<(), arboard::Error> {
    use arboard::SetExtWindows;

    arboard::Clipboard::new()?
        .set()
        .exclude_from_monitoring()
        .text(token)
}

/// Puts the original picture or its displayed preview on the clipboard.
pub fn picture(
    picture: CopiedPicture,
    failed: impl FnOnce() + Send + 'static,
) -> std::io::Result<()> {
    std::thread::Builder::new()
        .name("copy-picture".into())
        .spawn(move || {
            if let Err(error) = copy(&picture) {
                tracing::warn!(%error, "could not copy a picture");
                failed();
            }
        })
        .map(drop)
}

fn decoded(file: &[u8]) -> anyhow::Result<arboard::ImageData<'static>> {
    let mut reader = image::ImageReader::new(std::io::Cursor::new(file)).with_guessed_format()?;
    let mut limits = image::Limits::default();
    limits.max_image_width = Some(8192);
    limits.max_image_height = Some(8192);
    limits.max_alloc = Some(256 * 1024 * 1024);
    reader.limits(limits);
    let picture = reader.decode()?.into_rgba8();
    Ok(arboard::ImageData {
        width: picture.width() as usize,
        height: picture.height() as usize,
        bytes: Cow::Owned(picture.into_raw()),
    })
}

fn pixels(picture: &CopiedPicture) -> anyhow::Result<arboard::ImageData<'_>> {
    if let Some(file) = &picture.encoded
        && let Ok(image) = decoded(file)
    {
        return Ok(image);
    }
    let preview = picture
        .preview
        .as_ref()
        .context("the picture could not be decoded")?;
    let (width, height) = (preview.width as usize, preview.height as usize);
    ensure!(
        width > 0
            && height > 0
            && width
                .checked_mul(height)
                .and_then(|pixels| pixels.checked_mul(4))
                == Some(preview.rgba.len()),
        "the picture's pixels are incomplete"
    );
    Ok(arboard::ImageData {
        width,
        height,
        bytes: Cow::Borrowed(&preview.rgba),
    })
}

fn copy(picture: &CopiedPicture) -> anyhow::Result<()> {
    let image = pixels(picture)?;
    let mut clipboard = arboard::Clipboard::new()?;
    #[cfg(windows)]
    {
        // A clipboard manager or the previous copy may hold it briefly.
        let mut write = || {
            clipboard.set_image(arboard::ImageData {
                width: image.width,
                height: image.height,
                bytes: Cow::Borrowed(image.bytes.as_ref()),
            })
        };
        let mut result = write();
        for _ in 0..5 {
            if !matches!(result, Err(arboard::Error::ClipboardOccupied)) {
                break;
            }
            std::thread::sleep(std::time::Duration::from_millis(20));
            result = write();
        }
        result.map_err(Into::into)
    }
    #[cfg(not(windows))]
    {
        let set = clipboard.set();
        #[cfg(target_os = "linux")]
        let set = {
            use arboard::SetExtLinux;
            // Answers for the picture until another copy takes its place.
            set.wait()
        };
        set.image(image)?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Arc;
    use yapfast_core::chat::{Picture, Pixels};

    #[test]
    fn copying_an_image_uses_visible_pixels_when_the_original_cannot_decode() {
        let bytes = vec![15, 70, 123, 180, 200, 150, 100, 50];
        let picture = CopiedPicture {
            encoded: Some(b"unusable original".to_vec()),
            preview: Some(Arc::new(Picture {
                width: 2,
                height: 1,
                rgba: Pixels::new(2, 1, bytes.clone()),
                animation: None,
            })),
        };
        let copied = pixels(&picture).unwrap();
        assert_eq!((copied.width, copied.height), (2, 1));
        assert_eq!(copied.bytes.as_ref(), bytes);
    }

    #[test]
    fn copying_an_image_preserves_a_decodable_original() {
        let mut png = std::io::Cursor::new(Vec::new());
        image::RgbaImage::from_pixel(2, 1, image::Rgba([255, 128, 0, 255]))
            .write_to(&mut png, image::ImageFormat::Png)
            .unwrap();
        let picture = CopiedPicture {
            encoded: Some(png.into_inner()),
            preview: Some(Arc::new(Picture {
                width: 1,
                height: 1,
                rgba: Pixels::new(1, 1, vec![0, 0, 0, 255]),
                animation: None,
            })),
        };
        let copied = pixels(&picture).unwrap();
        assert_eq!((copied.width, copied.height), (2, 1));
        assert_eq!(&copied.bytes[..4], &[255, 128, 0, 255]);
    }

    /// Copies a picture to the desktop's clipboard, for checking by hand:
    /// paste it elsewhere while the test waits.
    #[test]
    #[ignore = "writes the desktop clipboard"]
    fn copies_a_picture_to_the_desktop_clipboard() {
        let mut png = std::io::Cursor::new(Vec::new());
        image::RgbaImage::from_pixel(64, 48, image::Rgba([255, 128, 0, 255]))
            .write_to(&mut png, image::ImageFormat::Png)
            .unwrap();
        copy(&CopiedPicture {
            encoded: Some(png.into_inner()),
            preview: None,
        })
        .unwrap();
    }
}
