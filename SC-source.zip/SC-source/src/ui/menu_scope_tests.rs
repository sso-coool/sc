//! Menu callbacks use the same server scope as the permission-checked action.
#![cfg(feature = "discord")]

use super::*;
use yapfast_core::chat::{ServerSettingsPage, SettingsSection};

fn fixture() -> (tempfile::TempDir, YapfastWindow, Rc<RefCell<Adapter>>) {
    i_slint_backend_testing::init_no_event_loop();
    let directory = tempfile::tempdir().unwrap();
    let window = YapfastWindow::new().unwrap();
    let adapter = Adapter::new(
        Arc::new(BackgroundRuntime::new().unwrap()),
        directory.path().into(),
        &window,
    )
    .unwrap();
    bind_callbacks(&window, &adapter);
    let mut app = yapfast_core::application::member_server(&["30"]);
    yapfast_core::application::with_clubs(&mut app);
    adapter.borrow_mut().app = app;
    (directory, window, adapter)
}

fn roles(window: &YapfastWindow, target: &str) -> Vec<(String, bool, bool)> {
    window.invoke_prepare_menu(target.into(), true);
    let at = window
        .get_menu_rows()
        .iter()
        .position(|row| row.text == "Roles")
        .expect("member menu offers Roles");
    window
        .get_menu_submenus()
        .row_data(at)
        .unwrap()
        .iter()
        .map(|row| (row.text.to_string(), row.checked, row.disabled))
        .collect()
}

fn expected() -> Vec<(String, bool, bool)> {
    vec![
        ("Crew".into(), true, false),
        ("Wardens".into(), false, false),
    ]
}

#[test]
fn menu_role_scope_follows_members_settings_with_no_or_other_selected_room() {
    let (_directory, window, adapter) = fixture();
    {
        let mut adapter = adapter.borrow_mut();
        // Dispatch only; no transport is attached or effects executed.
        adapter
            .app
            .dispatch(Action::OpenServerSettings("discord:10".into()));
        adapter
            .app
            .dispatch(Action::ServerSettingsSection(SettingsSection::Members));
        adapter.app.apply(Event::ServerSettingsLoaded {
            server: "discord:10".into(),
            section: SettingsSection::Members,
            result: Ok(ServerSettingsPage::Members {
                members: vec![],
                total: Some(0),
            }),
        });
        assert_eq!(adapter.app.member_place("4"), Some("discord:10"));
    }
    for selected in [None, Some("discord:@me:999"), Some("discord:50:52")] {
        adapter.borrow_mut().app.state.selected = selected.map(str::to_owned);
        assert_eq!(
            roles(&window, "4"),
            expected(),
            "settings determines roles even with {selected:?} selected"
        );
        assert_eq!(adapter.borrow().app.state.selected.as_deref(), selected);
    }
}

#[test]
fn menu_role_scope_follows_explicit_voice_room_over_another_server() {
    let (_directory, window, adapter) = fixture();
    adapter.borrow_mut().app.state.selected = Some("discord:50:52".into());
    assert!(
        adapter
            .borrow()
            .app
            .role_choices("discord:50:52", "4")
            .iter()
            .all(|choice| !choice.grantable)
    );
    assert_eq!(roles(&window, "in-voice:discord:10:12/4"), expected());
    assert_eq!(
        adapter.borrow().app.state.selected.as_deref(),
        Some("discord:50:52")
    );
    // Unknown voice destinations retain the core's permission gate.
    window.invoke_prepare_menu("in-voice:discord:999:100/4".into(), true);
    assert!(!window.get_menu_rows().iter().any(|row| row.text == "Roles"));
}
