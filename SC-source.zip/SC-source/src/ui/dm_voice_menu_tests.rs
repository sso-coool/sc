//! Real menu callbacks for active DM calls; no account, clipboard or media traffic.
#![cfg(feature = "discord")]
use super::*;
use yapfast_core::yapfast_discord::service::{Conversation, Snapshot, Status};

const DM: &str = "discord:@me:30";
const OTHER: &str = "discord:@me:32";
const USER: &str = "2718281";
const TARGET: &str = "in-voice:discord:@me:30/2718281";

fn fixture() -> (tempfile::TempDir, YapfastWindow, Rc<RefCell<Adapter>>) {
    i_slint_backend_testing::init_no_event_loop();
    let directory = tempfile::tempdir().unwrap();
    let window = YapfastWindow::new().unwrap();
    let adapter = Adapter::new(
        Arc::new(BackgroundRuntime::new().unwrap()),
        directory.path().into(),
        &window,
    )
    .unwrap();
    bind_callbacks(&window, &adapter);
    let mut app = Application::default();
    app.apply(Event::Discord(Arc::new(Snapshot {
        status: Status::Online,
        user_id: Some("1".into()),
        conversations: vec![
            Arc::new(Conversation {
                id: "30".into(),
                name: "Annie".into(),
                person: Some(USER.into()),
                people: 2,
                ..Default::default()
            }),
            Arc::new(Conversation {
                id: "32".into(),
                name: "Other".into(),
                person: Some("3".into()),
                people: 2,
                ..Default::default()
            }),
        ],
        ..Default::default()
    })));
    app.state.selected = Some(OTHER.into());
    app.state.voice.phase = voice::Phase::Connected;
    app.state.voice.room = Some(DM.into());
    app.state.voice.participants = vec![voice::Participant {
        id: USER.into(),
        user: "Annie".into(),
        person: USER.into(),
        local: false,
        muted: false,
        deafened: false,
        server_muted: false,
        server_deafened: false,
        speaking: false,
        connected: true,
        problem: None,
        streaming: true,
        video: None,
        avatar: None,
    }];
    {
        let mut adapter = adapter.borrow_mut();
        adapter.app = app;
        adapter.layout.developer_mode = true;
        adapter.sync_dm_pins();
    }
    (directory, window, adapter)
}

#[test]
fn dm_voice_menu_callbacks_keep_person_and_channel_ids_separate() {
    let (_directory, window, adapter) = fixture();
    let copied = || i_slint_core::window::WindowInner::from_pub(window.window()).context().platform()
        .clipboard_text(i_slint_core::platform::Clipboard::DefaultClipboard);
    window.invoke_prepare_menu(TARGET.into(), true);
    for label in [
        "Profile",
        "Add note",
        "Close DM",
        "Mute",
        "Mute Soundboard",
        "Disable Video",
        "Show Non-Video Participants",
        "Copy User ID",
        "Copy Channel ID",
    ] {
        assert!(
            window.get_menu_rows().iter().any(|row| row.text == label),
            "missing {label}"
        );
    }
    window.invoke_choose_menu(TARGET.into(), true, "copy-id".into());
    assert_eq!(copied().as_deref(), Some(USER));
    window.invoke_choose_menu(TARGET.into(), true, "copy-channel-id".into());
    assert_eq!(copied().as_deref(), Some("30"));
    window.invoke_choose_menu(TARGET.into(), true, "pin".into());
    assert!(
        adapter
            .borrow()
            .app
            .state
            .pinned
            .iter()
            .any(|room| room == DM)
    );
    assert!(
        !adapter
            .borrow()
            .app
            .state
            .pinned
            .iter()
            .any(|room| room == OTHER)
    );
    assert_eq!(adapter.borrow().app.state.selected.as_deref(), Some(OTHER));
    // The sidebar exposes the same participant's volume, while unrelated DMs do not.
    assert_eq!(
        menus::volume_for_menu(&adapter.borrow(), DM, false),
        Some((USER.into(), "Annie".into(), true))
    );
    assert_eq!(
        menus::volume_for_menu(&adapter.borrow(), OTHER, false),
        None
    );
    window.invoke_prepare_menu(DM.into(), false);
    window.invoke_choose_menu(DM.into(), false, "copy-user-id".into());
    assert_eq!(copied().as_deref(), Some(USER));
    window.invoke_choose_menu(DM.into(), false, "copy-id".into());
    assert_eq!(copied().as_deref(), Some("30"));
    // A stale call tile cannot keep acting after the participant leaves.
    adapter.borrow_mut().app.state.voice.participants.clear();
    window.invoke_choose_menu(TARGET.into(), true, "unpin".into());
    assert!(
        adapter
            .borrow()
            .app
            .state
            .pinned
            .iter()
            .any(|room| room == DM)
    );
    assert_eq!(menus::volume_for_menu(&adapter.borrow(), DM, false), None);
}

#[test]
fn dm_voice_menu_sidebar_local_audio_uses_the_person_key() {
    let (directory, window, adapter) = fixture();
    // Restore process-global volume state even if an assertion panics.
    struct Reset;
    impl Drop for Reset {
        fn drop(&mut self) {
            yapfast_core::volume::mute(USER, false);
            yapfast_core::volume::mute_soundboard(USER, false);
        }
    }
    let _reset = Reset;
    yapfast_core::volume::mute(USER, false);
    yapfast_core::volume::mute_soundboard(USER, false);
    window.invoke_prepare_menu(DM.into(), false);
    window.invoke_choose_menu(DM.into(), false, "local-mute".into());
    window.invoke_choose_menu(DM.into(), false, "soundboard-mute".into());
    assert!(yapfast_core::volume::muted(USER));
    assert!(yapfast_core::volume::soundboard_muted(USER));
    let saved = Layout::read(directory.path());
    assert!(saved.muted_people.contains(USER));
    assert!(saved.soundboard_muted_people.contains(USER));
    assert!(!saved.muted_people.contains(DM));
    window.invoke_prepare_menu(TARGET.into(), true);
    for id in ["local-mute", "soundboard-mute"] {
        assert!(
            window
                .get_menu_rows()
                .iter()
                .any(|row| row.id == id && row.checked)
        );
        window.invoke_choose_menu(TARGET.into(), true, id.into());
    }
    assert!(!yapfast_core::volume::muted(USER));
    assert!(!yapfast_core::volume::soundboard_muted(USER));
    assert_eq!(adapter.borrow().app.state.selected.as_deref(), Some(OTHER));
}
