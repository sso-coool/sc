//! Real menu callbacks for active DM calls; no account, clipboard or media traffic.
#![cfg(feature = "discord")]
use super::*;
use yapfast_core::yapfast_discord::service::{Conversation, Snapshot, Status};

const DM: &str = "discord:@me:30";
const OTHER: &str = "discord:@me:32";
const USER: &str = "2718281";
const TARGET: &str = "in-voice:discord:@me:30/2718281";

fn fixture() -> (tempfile::TempDir, YapfastWindow, Rc<RefCell<Adapter>>) {
    i_slint_backend_testing::init_no_event_loop();
    let directory = tempfile::tempdir().unwrap();
    let window = YapfastWindow::new().unwrap();
    let adapter = Adapter::new(
        Arc::new(BackgroundRuntime::new().unwrap()),
        directory.path().into(),
        &window,
    )
    .unwrap();
    bind_callbacks(&window, &adapter);
    let mut app = Application::default();
    app.apply(Event::Discord(Arc::new(Snapshot {
        status: Status::Online,
        user_id: Some("1".into()),
        conversations: vec![
            Arc::new(Conversation {
                id: "30".into(),
                name: "Annie".into(),
                person: Some(USER.into()),
                people: 2,
                ..Default::default()
            }),
            Arc::new(Conversation {
                id: "32".into(),
                name: "Other".into(),
                person: Some("3".into()),
                people: 2,
                ..Default::default()
            }),
        ],
        ..Default::default()
    })));
    app.state.selected = Some(OTHER.into());
    app.state.voice.phase = voice::Phase::Connected;
    app.state.voice.room = Some(DM.into());
    app.state.voice.participants = vec![voice::Participant {
        id: USER.into(),
        user: "Annie".into(),
        person: USER.into(),
        local: false,
        muted: false,
        deafened: false,
        server_muted: false,
        server_deafened: false,
        speaking: false,
        connected: true,
        problem: None,
        streaming: true,
        video: None,
        avatar: None,
    }];
    {
        let mut adapter = adapter.borrow_mut();
        adapter.app = app;
        adapter.layout.developer_mode = true;
        adapter.sync_dm_pins();
    }
    (directory, window, adapter)
}

#[test]
fn one_to_one_audio_call_keeps_both_tiles_when_no_video_is_active() {
    let (_directory, window, adapter) = fixture();
    {
        let mut adapter = adapter.borrow_mut();
        adapter.layout.hide_non_video_participants = true;
        adapter.app.state.selected = Some(DM.into());
        let people = &mut adapter.app.state.voice.participants;
        people[0].streaming = false;
        let mut local = people[0].clone();
        local.id = "1".into();
        local.person.clone_from(&local.id);
        local.user = "Me".into();
        local.local = true;
        people.insert(0, local);
        adapter.refresh(&window);
    }
    assert!(window.get_call_shown() && window.get_voice_here());
    let names: Vec<_> = window
        .get_participants()
        .iter()
        .map(|row| row.name)
        .collect();
    assert_eq!(
        names,
        [SharedString::from("Me"), SharedString::from("Annie")]
    );

    let mut adapter = adapter.borrow_mut();
    adapter.app.state.voice.participants[1].streaming = true;
    adapter.refresh(&window);
    let rows = window.get_participants();
    assert_eq!(rows.row_count(), 1);
    assert!(rows.row_data(0).unwrap().live);
    assert!(adapter.layout.hide_non_video_participants);
}

#[test]
fn returning_to_an_active_call_dm_opens_chat_until_the_call_is_requested() {
    let (_directory, window, adapter) = fixture();
    let commands = Rc::new(RefCell::new(Vec::new()));
    {
        let mut adapter = adapter.borrow_mut();
        adapter.app.state.account = Some("@me:example.test".into());
        adapter.app.state.navigation = Navigation::DirectMessages;
        adapter.backend_commands = Some(commands.clone());
        adapter.refresh(&window);
    }
    window.show().unwrap();
    window
        .window()
        .set_size(slint::LogicalSize::new(800., 560.));

    for phase in [
        voice::Phase::Joining,
        voice::Phase::Connected,
        voice::Phase::Reconnecting,
    ] {
        adapter.borrow_mut().app.state.voice.phase = phase;
        window.invoke_select_room(DM.into());
        assert_eq!(window.get_room_id().as_str(), DM);
        assert!(window.get_call_shown() && window.get_voice_here());
        assert!(
            !window.get_grid_shown(),
            "ordinary DM navigation keeps chat first"
        );
        assert!(!window.window().is_fullscreen());

        window.invoke_open_call();
        assert_eq!(window.get_room_id().as_str(), DM);
        assert!(
            window.get_grid_shown(),
            "the dock opens the call while this DM is selected"
        );
        window.invoke_select_room(DM.into());
        assert!(
            !window.get_grid_shown(),
            "reselecting the DM takes you back to chat"
        );

        window.invoke_open_call();
        window.invoke_select_room(OTHER.into());
        assert_eq!(window.get_room_id().as_str(), OTHER);
        assert!(!window.get_grid_shown());
        assert!(window.get_voice_active());
        assert_eq!(window.get_voice_channel().as_str(), DM);
    }
    window.invoke_open_call();
    assert_eq!(window.get_room_id().as_str(), DM);
    assert!(
        window.get_grid_shown(),
        "the dock still opens a call in another DM"
    );
    assert!(commands.borrow().iter().all(|command| !matches!(
        command,
        Command::Voice(voice::Command::Join(_) | voice::Command::Leave)
    )));
    window.hide().unwrap();
}

#[test]
fn starting_a_call_in_the_open_dm_reveals_it_when_the_backend_joins() {
    let (_directory, window, adapter) = fixture();
    let commands = Rc::new(RefCell::new(Vec::new()));
    {
        let mut adapter = adapter.borrow_mut();
        adapter.app.state.navigation = Navigation::DirectMessages;
        adapter.app.state.voice = voice::State::default();
        adapter.backend_commands = Some(commands.clone());
    }
    window.invoke_select_room(DM.into());
    window.invoke_start_call();
    assert!(commands.borrow().iter().any(|command| matches!(
        command,
        Command::Voice(voice::Command::Join(room)) if room == DM
    )));
    assert_eq!(window.get_dm_call_expanded_room().as_str(), DM);
    assert!(!window.get_grid_shown());
    {
        let mut adapter = adapter.borrow_mut();
        adapter.app.state.voice.room = Some(DM.into());
        adapter.app.state.voice.phase = voice::Phase::Joining;
        adapter.refresh(&window);
    }
    assert!(window.get_voice_here() && window.get_grid_shown());
    {
        let mut adapter = adapter.borrow_mut();
        adapter.app.state.voice = voice::State::default();
        adapter.refresh(&window);
    }
    assert!(!window.get_grid_shown());
}

#[test]
fn dm_voice_menu_callbacks_keep_person_and_channel_ids_separate() {
    let (_directory, window, adapter) = fixture();
    let copied = || {
        i_slint_core::window::WindowInner::from_pub(window.window())
            .context()
            .platform()
            .clipboard_text(i_slint_core::platform::Clipboard::DefaultClipboard)
    };
    window.invoke_prepare_menu(TARGET.into(), true);
    for label in [
        "Profile",
        "Add note",
        "Close DM",
        "Mute",
        "Mute Soundboard",
        "Disable Video",
        "Show Non-Video Participants",
        "Copy User ID",
        "Copy Channel ID",
    ] {
        assert!(
            window.get_menu_rows().iter().any(|row| row.text == label),
            "missing {label}"
        );
    }
    window.invoke_choose_menu(TARGET.into(), true, "copy-id".into());
    assert_eq!(copied().as_deref(), Some(USER));
    window.invoke_choose_menu(TARGET.into(), true, "copy-channel-id".into());
    assert_eq!(copied().as_deref(), Some("30"));
    window.invoke_choose_menu(TARGET.into(), true, "pin".into());
    assert!(
        adapter
            .borrow()
            .app
            .state
            .pinned
            .iter()
            .any(|room| room == DM)
    );
    assert!(
        !adapter
            .borrow()
            .app
            .state
            .pinned
            .iter()
            .any(|room| room == OTHER)
    );
    assert_eq!(adapter.borrow().app.state.selected.as_deref(), Some(OTHER));
    // The sidebar exposes the same participant's volume, while unrelated DMs do not.
    assert_eq!(
        menus::volume_for_menu(&adapter.borrow(), DM, false),
        Some((USER.into(), "Annie".into(), true))
    );
    assert_eq!(
        menus::volume_for_menu(&adapter.borrow(), OTHER, false),
        None
    );
    window.invoke_prepare_menu(DM.into(), false);
    window.invoke_choose_menu(DM.into(), false, "copy-user-id".into());
    assert_eq!(copied().as_deref(), Some(USER));
    window.invoke_choose_menu(DM.into(), false, "copy-id".into());
    assert_eq!(copied().as_deref(), Some("30"));
    // A stale call tile cannot keep acting after the participant leaves.
    adapter.borrow_mut().app.state.voice.participants.clear();
    window.invoke_choose_menu(TARGET.into(), true, "unpin".into());
    assert!(
        adapter
            .borrow()
            .app
            .state
            .pinned
            .iter()
            .any(|room| room == DM)
    );
    assert_eq!(menus::volume_for_menu(&adapter.borrow(), DM, false), None);
}

#[test]
fn dm_voice_menu_sidebar_local_audio_uses_the_person_key() {
    let (directory, window, adapter) = fixture();
    // Restore process-global volume state even if an assertion panics.
    struct Reset;
    impl Drop for Reset {
        fn drop(&mut self) {
            yapfast_core::volume::mute(USER, false);
            yapfast_core::volume::mute_soundboard(USER, false);
        }
    }
    let _reset = Reset;
    yapfast_core::volume::mute(USER, false);
    yapfast_core::volume::mute_soundboard(USER, false);
    window.invoke_prepare_menu(DM.into(), false);
    window.invoke_choose_menu(DM.into(), false, "local-mute".into());
    window.invoke_choose_menu(DM.into(), false, "soundboard-mute".into());
    assert!(yapfast_core::volume::muted(USER));
    assert!(yapfast_core::volume::soundboard_muted(USER));
    let saved = Layout::read(directory.path());
    assert!(saved.muted_people.contains(USER));
    assert!(saved.soundboard_muted_people.contains(USER));
    assert!(!saved.muted_people.contains(DM));
    window.invoke_prepare_menu(TARGET.into(), true);
    for id in ["local-mute", "soundboard-mute"] {
        assert!(
            window
                .get_menu_rows()
                .iter()
                .any(|row| row.id == id && row.checked)
        );
        window.invoke_choose_menu(TARGET.into(), true, id.into());
    }
    assert!(!yapfast_core::volume::muted(USER));
    assert!(!yapfast_core::volume::soundboard_muted(USER));
    assert_eq!(adapter.borrow().app.state.selected.as_deref(), Some(OTHER));
}
