//! An explicitly packaged Windows companion. Ordinary builds have no pins and
//! offer no launcher. Package verification and startup run off the UI thread.
use super::*;

pub(super) fn bind(window: &YapfastWindow) {
    #[cfg(not(windows))]
    let _ = window;
    #[cfg(windows)]
    {
        let Some(package) = windows::Package::beside_executable() else {
            return;
        };
        window.global::<ClientStyle>().set_companion_available(true);
        let weak = window.as_weak();
        window.on_launch_vencord_companion(move || {
            let Some(window) = weak.upgrade() else { return };
            let style = window.global::<ClientStyle>();
            if style.get_companion_starting() {
                return;
            }
            style.set_companion_starting(true);
            style.set_companion_status("".into());
            let return_to = window.as_weak();
            let package = package.clone();
            let work = std::thread::Builder::new()
                .name("sc-vencord-package".into())
                .spawn(move || {
                    let result = package.start();
                    let _ = return_to.upgrade_in_event_loop(move |window| {
                        let style = window.global::<ClientStyle>();
                        style.set_companion_starting(false);
                        style.set_companion_status(
                            match result {
                                Ok(()) => "Vencord companion opened.",
                                Err(reason) => reason,
                            }
                            .into(),
                        );
                    });
                });
            if work.is_err() {
                style.set_companion_starting(false);
                style.set_companion_status("Could not start package verification.".into());
            }
        });
    }
}

#[cfg(windows)]
mod windows {
    use sha2::{Digest, Sha256};
    use std::{
        fs::{File, OpenOptions},
        io::Read,
        os::windows::{
            fs::{MetadataExt, OpenOptionsExt},
            process::CommandExt,
        },
        path::{Path, PathBuf},
        process::{Command, Stdio},
    };

    const MANIFEST: &str = "companion-manifest.json";
    const LAUNCHER: &str = "launch.ps1";
    const REPARSE_POINT: u32 = 0x400;
    const SHARE_READ: u32 = 1;
    const CREATE_NO_WINDOW: u32 = 0x0800_0000;

    #[derive(Clone)]
    pub(super) struct Package {
        root: PathBuf,
        manifest: &'static str,
        launcher: &'static str,
    }

    impl Package {
        pub(super) fn beside_executable() -> Option<Self> {
            let manifest =
                option_env!("SC_VENCORD_MANIFEST_SHA256").filter(|value| digest(value))?;
            let launcher =
                option_env!("SC_VENCORD_LAUNCHER_SHA256").filter(|value| digest(value))?;
            let program = std::env::current_exe().ok()?;
            let root = program.parent()?.join("vencord-companion");
            (root.is_dir() && root.join(MANIFEST).is_file() && root.join(LAUNCHER).is_file())
                .then_some(Self {
                    root,
                    manifest,
                    launcher,
                })
        }

        pub(super) fn start(&self) -> Result<(), &'static str> {
            for path in self.root.ancestors() {
                plain(path).ok_or("The companion package is in an unsupported location.")?;
            }
            let install = self.root.parent().ok_or("The S;C folder was not found.")?;
            let parent = install.parent().ok_or("The S;C folder was not found.")?;
            let mut lock_name = std::ffi::OsString::from(".");
            lock_name.push(install.file_name().ok_or("The S;C folder was not found.")?);
            lock_name.push(".update.lock");
            let lock_path = parent.join(lock_name);
            if lock_path.exists() && !plain(&lock_path).is_some_and(|info| info.is_file()) {
                return Err("The update lock is in an unsupported location.");
            }
            const OPEN_REPARSE_POINT: u32 = 0x0020_0000;
            let update_lock = OpenOptions::new()
                .read(true)
                .write(true)
                .create(true)
                .truncate(false)
                .share_mode(0)
                .custom_flags(OPEN_REPARSE_POINT)
                .open(lock_path)
                .map_err(|_| "The companion can't start while an S;C update is running.")?;
            if !update_lock
                .metadata()
                .is_ok_and(|info| info.is_file() && info.file_attributes() & REPARSE_POINT == 0)
            {
                return Err("The update lock is in an unsupported location.");
            }
            let launcher = self.root.join(LAUNCHER);
            let manifest = self.root.join(MANIFEST);
            // Keep the verified files open with only read-sharing for the
            // lifetime of the launcher. Its own inventory check covers the rest.
            let _manifest = verified(&manifest, self.manifest, 2 * 1024 * 1024)
                .ok_or("The companion package does not match this build.")?;
            let _launcher = verified(&launcher, self.launcher, 64 * 1024)
                .ok_or("The companion launcher does not match this build.")?;
            let system = std::env::var_os("SystemRoot")
                .map(PathBuf::from)
                .filter(|path| path.is_absolute())
                .ok_or("Windows PowerShell is unavailable.")?;
            let powershell = system.join("System32/WindowsPowerShell/v1.0/powershell.exe");
            let mut child = Command::new(powershell);
            child.current_dir(&self.root).env_clear();
            for name in [
                "SystemRoot",
                "WINDIR",
                "COMSPEC",
                "APPDATA",
                "LOCALAPPDATA",
                "USERPROFILE",
                "HOMEDRIVE",
                "HOMEPATH",
                "TEMP",
                "TMP",
                "PROCESSOR_ARCHITECTURE",
                "NUMBER_OF_PROCESSORS",
            ] {
                if let Some(value) = std::env::var_os(name) {
                    child.env(name, value);
                }
            }
            let report = child
                .env("PATH", system.join("System32"))
                .arg("-NoProfile")
                .arg("-NonInteractive")
                .arg("-ExecutionPolicy")
                // The embedded digest authenticates this package script even
                // when Explorer marks files extracted from a downloaded ZIP.
                .arg("Bypass")
                .arg("-File")
                .arg(launcher)
                .arg("-ExpectedManifestSha256")
                .arg(self.manifest)
                .arg("-Launch")
                .stdin(Stdio::null())
                .stderr(Stdio::null())
                .creation_flags(CREATE_NO_WINDOW)
                .output()
                .map_err(|_| "The companion could not start.")?;
            let started = serde_json::from_slice::<serde_json::Value>(&report.stdout)
                .is_ok_and(|reply| reply["launched"] == true);
            if report.status.success() && started {
                Ok(())
            } else {
                Err("The companion package or profile could not be verified.")
            }
        }
    }

    fn digest(value: &str) -> bool {
        value.len() == 64 && value.bytes().all(|byte| byte.is_ascii_hexdigit())
    }

    fn plain(path: &Path) -> Option<std::fs::Metadata> {
        let metadata = std::fs::symlink_metadata(path).ok()?;
        (metadata.file_attributes() & REPARSE_POINT == 0).then_some(metadata)
    }

    fn verified(path: &Path, expected: &str, limit: u64) -> Option<File> {
        let metadata = plain(path)?;
        if !metadata.is_file() || metadata.len() > limit {
            return None;
        }
        let mut file = OpenOptions::new()
            .read(true)
            .share_mode(SHARE_READ)
            .open(path)
            .ok()?;
        let mut bytes = Vec::new();
        (&mut file).take(limit + 1).read_to_end(&mut bytes).ok()?;
        let actual = format!("{:x}", Sha256::digest(&bytes));
        (bytes.len() as u64 <= limit && expected.eq_ignore_ascii_case(&actual)).then_some(file)
    }
}
