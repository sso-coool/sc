//! Native clipboard adapter regression. Only the OS read is replaced: the
//! background file write, stale-target check, Stage action and thumbnail decode
//! all run normally. No system clipboard, account or transport is opened.
use super::*;
use std::{io::Cursor, time::Instant};
use yapfast_core::{
    chat::CommandIndex,
    yapfast_discord::{
        marked::MarkedServer,
        ready::{Channel, Server},
        service::{Snapshot, Status},
    },
};

const ROOM: &str = "discord:10:21";

fn until(ready: impl Fn() -> bool + 'static) {
    let done = Rc::new(Cell::new(false));
    let result = done.clone();
    let deadline = Instant::now() + Duration::from_secs(10);
    let timer = slint::Timer::default();
    timer.start(
        slint::TimerMode::Repeated,
        Duration::from_millis(5),
        move || {
            let ready = ready();
            if ready || Instant::now() >= deadline {
                result.set(ready);
                slint::quit_event_loop().unwrap();
            }
        },
    );
    slint::run_event_loop().unwrap();
    timer.stop();
    assert!(done.get(), "native clipboard pipeline did not finish");
}

#[test]
fn native_clipboard_picture_fills_slash_attachment_and_preserves_ordinary_files() {
    // One event-loop test owns this backend; no actual desktop window exists.
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: false,
            threading: true,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let directory = tempfile::tempdir().unwrap();
    let window = YapfastWindow::new().unwrap();
    let adapter = Adapter::new(
        Arc::new(BackgroundRuntime::new().unwrap()),
        directory.path().into(),
        &window,
    )
    .unwrap();
    bind_callbacks(&window, &adapter);
    window.global::<PictureStore>().on_request(|_| {});
    let pixels = image::RgbaImage::from_pixel(3, 2, image::Rgba([240, 40, 120, 255]));
    let mut png = Cursor::new(Vec::new());
    pixels.write_to(&mut png, image::ImageFormat::Png).unwrap();
    let png = png.into_inner();
    let ordinary = directory.path().join("before-command.png");
    std::fs::write(&ordinary, &png).unwrap();
    {
        let mut adapter = adapter.borrow_mut();
        // Apply synthetic data directly: never execute connection/fetch effects.
        adapter.app.apply(Event::Discord(Arc::new(Snapshot {
            status: Status::Online,
            user_id: Some("1".into()),
            servers: vec![MarkedServer::from(Server {
                id: "10".into(),
                name: "Clipboard fixture".into(),
                owner_id: Some("1".into()),
                text_channels: vec![Channel {
                    id: "21".into(),
                    name: "clipboard".into(),
                    ..Default::default()
                }],
                ..Default::default()
            })],
            ..Default::default()
        })));
        adapter
            .app
            .dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
        adapter.app.dispatch(Action::SelectRoom(ROOM.into()));
        adapter.app.apply(Event::Timeline {
            room: ROOM.into(),
            messages: vec![],
        });
        assert_eq!(adapter.app.state.selected.as_deref(), Some(ROOM));
        assert!(
            adapter
                .app
                .dispatch(Action::Stage(vec![ordinary.clone()]))
                .is_empty()
        );
        adapter.app.dispatch(Action::SetDraft("/".into()));
        adapter.app.apply(Event::CommandIndex {
            room: ROOM.into(),
            index: Ok(Arc::new(CommandIndex::parse(&serde_json::json!({
                "applications": [{"id":"500", "name":"Image fixture"}],
                "application_commands": [{"id":"501", "application_id":"500", "version":"1", "type":1,
                    "name":"olosnap", "description":"Read image", "default_member_permissions":null,
                    "options":[
                        {"type":11, "name":"image", "description":"Screenshot", "required":true},
                        {"type":3, "name":"note", "description":"Optional note"}
                    ]}]
            }), false))),
        });
        adapter.app.dispatch(Action::SetDraft("/olosnap ".into()));
        assert!(
            adapter.app.state.command_draft().unwrap().options[0]
                .file
                .is_none()
        );
        assert!(
            adapter.app.state.staged().is_empty(),
            "old files are not implicitly command arguments"
        );
        adapter.pasted = Some(tempfile::tempdir_in(directory.path()).unwrap());
        adapter.refresh(&window);
    }
    assert_eq!(window.get_command_options().row_data(0).unwrap().value, "");
    assert_eq!(window.get_staged().row_count(), 0);

    let screenshot = png.clone();
    adapter.borrow_mut().paste_with(false, move || {
        crate::paste::Clipboard::Picture(screenshot, "png")
    });
    let weak = window.as_weak();
    until(move || {
        weak.upgrade().is_some_and(|window| {
            window
                .get_staged()
                .row_data(0)
                .is_some_and(|file| file.has_picture)
        })
    });
    let path = {
        let adapter = adapter.borrow();
        assert!(adapter.backend.is_none(), "no transport was started");
        let command = adapter.app.state.command_draft().unwrap();
        assert_eq!(command.options[0].shown(), "image.png");
        let path = command.options[0].file.clone().unwrap();
        assert!(path.starts_with(directory.path()));
        assert_eq!(adapter.app.state.staged().len(), 1);
        path
    };
    assert_eq!(std::fs::read(&path).unwrap(), png);
    assert_eq!(image::open(&path).unwrap().to_rgba8(), pixels);
    let option = window.get_command_options().row_data(0).unwrap();
    assert!(option.file && option.required && option.error.is_empty());
    assert_eq!(option.value, "image.png");
    let preview = window.get_staged().row_data(0).unwrap();
    assert_eq!(preview.name, "image.png");
    assert!(preview.has_picture && preview.picture.size().width > 0);

    // Delay only the injected read, then focus another option before completion.
    // Its result must not overwrite the successful image or land in ordinary files.
    let (release, blocked) = std::sync::mpsc::channel();
    adapter.borrow_mut().paste_with(false, move || {
        blocked.recv_timeout(Duration::from_secs(10)).unwrap();
        crate::paste::Clipboard::Picture(png, "png")
    });
    adapter
        .borrow_mut()
        .action(&window, Action::FocusCommandOption(1));
    release.send(()).unwrap();
    let weak = Rc::downgrade(&adapter);
    until(move || {
        weak.upgrade().is_some_and(|adapter| {
            adapter
                .borrow()
                .app
                .state
                .notice
                .as_deref()
                .is_some_and(|notice| notice.contains("command changed"))
        })
    });
    assert_eq!(
        adapter.borrow().app.state.command_draft().unwrap().options[0]
            .file
            .as_ref(),
        Some(&path)
    );
    adapter
        .borrow_mut()
        .action(&window, Action::CloseCommand(false));
    assert_eq!(window.get_command_name(), "");
    assert_eq!(
        window.get_staged().row_data(0).unwrap().name,
        "before-command.png"
    );
    assert_eq!(adapter.borrow().app.state.staged()[0].path, ordinary);
    assert_eq!(adapter.borrow().app.state.staged().len(), 1);
    assert!(adapter.borrow().backend.is_none());
}
