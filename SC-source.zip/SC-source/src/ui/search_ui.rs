//! Bridge between the header search helper, its filter form and message search.
use super::{
    Action, Adapter, AppState, ComponentHandle, Model, ModelRc, Network, SearchAssistRow,
    SearchFilterField, SharedString, VecModel, YapfastWindow, pictures,
    search_assist::{self, FilterValue, SuggestionAction, SuggestionGroup},
};
use std::{cell::RefCell, rc::Rc};
use yapfast_core::application::split_search_filters;

struct Field {
    key: &'static str,
    label: &'static str,
    detail: &'static str,
    placeholder: &'static str,
    multiple: bool,
    icon: i32,
}

const FIELDS: &[Field] = &[
    Field {
        key: "from",
        label: "From",
        detail: "Sent by any of the selected users",
        placeholder: "Search for a user",
        multiple: true,
        icon: 3,
    },
    Field {
        key: "in",
        label: "In",
        detail: "Sent in any of the selected channels",
        placeholder: "Search for a channel",
        multiple: true,
        icon: 4,
    },
    Field {
        key: "has",
        label: "Has",
        detail: "Includes any of the selected types of data",
        placeholder: "Any content",
        multiple: true,
        icon: 6,
    },
    Field {
        key: "mentions",
        label: "Mentions",
        detail: "Mentions any of the selected users",
        placeholder: "Search for a user",
        multiple: true,
        icon: 5,
    },
    Field {
        key: "after",
        label: "After",
        detail: "Sent after this date",
        placeholder: "YYYY-MM-DD",
        multiple: false,
        icon: 7,
    },
    Field {
        key: "before",
        label: "Before",
        detail: "Sent before this date",
        placeholder: "YYYY-MM-DD",
        multiple: false,
        icon: 7,
    },
    Field {
        key: "during",
        label: "On",
        detail: "Sent on this date",
        placeholder: "YYYY-MM-DD",
        multiple: false,
        icon: 7,
    },
    Field {
        key: "author",
        label: "Author type",
        detail: "Sent by any of the selected author types",
        placeholder: "Any author",
        multiple: true,
        icon: 3,
    },
    Field {
        key: "pinned",
        label: "Pinned",
        detail: "Whether messages were pinned",
        placeholder: "Any message",
        multiple: false,
        icon: 2,
    },
];

#[derive(Clone)]
struct Atom {
    key: String,
    value: String,
    label: String,
}

impl Atom {
    fn parse(raw: &str) -> Option<Self> {
        let (key, value) = raw.split_once(':')?;
        let key = match key.to_ascii_lowercase().as_str() {
            "author-type" | "author_type" => "author".into(),
            other => other.to_owned(),
        };
        let value = canonical_value(&key, value.trim());
        Some(Self {
            key,
            label: value.trim_matches('"').to_owned(),
            value,
        })
    }
}

fn canonical_value(key: &str, raw: &str) -> String {
    let value = raw.trim_matches('"');
    if matches!(key, "from" | "mentions" | "in") {
        let symbol = if key == "in" { '#' } else { '@' };
        let bare = value
            .strip_prefix('<')
            .and_then(|value| value.strip_suffix('>'))
            .unwrap_or(value);
        let id = bare.trim_start_matches(symbol);
        let id = if symbol == '@' {
            id.trim_start_matches('!')
        } else {
            id
        };
        if !id.starts_with('0')
            && id.bytes().all(|byte| byte.is_ascii_digit())
            && id.parse::<u64>().is_ok()
        {
            return format!("<{symbol}{id}>");
        }
    }
    match (key, value.to_ascii_lowercase().as_str()) {
        ("has", "snapshot") => "forward".into(),
        ("has", "-snapshot") => "-forward".into(),
        ("pinned", "yes") => "true".into(),
        ("pinned", "no") => "false".into(),
        ("sort", "most-relevant") => "relevance".into(),
        _ => raw.to_owned(),
    }
}

#[derive(Default)]
struct Form {
    content: String,
    atoms: Vec<Atom>,
}

impl Form {
    fn from_query(query: &str) -> Self {
        let (content, atoms) = split_search_filters(query);
        Self {
            content,
            atoms: atoms.iter().filter_map(|atom| Atom::parse(atom)).collect(),
        }
    }

    fn query(&self) -> String {
        if self.content.is_empty() && self.atoms.iter().all(|atom| atom.key == "sort") {
            return String::new();
        }
        std::iter::once(self.content.clone())
            .filter(|part| !part.is_empty())
            .chain(
                self.atoms
                    .iter()
                    .map(|atom| format!("{}:{}", atom.key, atom.value)),
            )
            .collect::<Vec<_>>()
            .join(" ")
    }

    fn selected(&self, key: &str, value: &str) -> bool {
        self.atoms
            .iter()
            .any(|atom| atom.key == key && atom.value.eq_ignore_ascii_case(value))
    }

    fn choose(&mut self, field: &Field, value: FilterValue) {
        let selected = self.selected(field.key, &value.value);
        self.atoms.retain(|atom| {
            atom.key != field.key
                || (field.multiple && !atom.value.eq_ignore_ascii_case(&value.value))
        });
        if !selected {
            self.insert(field.key, value.value, value.label);
        }
    }

    fn replace(&mut self, key: &str, value: &str) {
        self.atoms.retain(|atom| atom.key != key);
        if !value.is_empty() {
            self.insert(key, value.to_owned(), value.to_owned());
        }
    }

    fn insert(&mut self, key: &str, value: String, label: String) {
        self.atoms.push(Atom {
            key: key.to_owned(),
            value,
            label,
        });
    }

    fn field_value(&self, key: &str) -> String {
        self.atoms
            .iter()
            .filter(|atom| atom.key == key)
            .map(|atom| atom.label.as_str())
            .collect::<Vec<_>>()
            .join(", ")
    }
}

#[derive(Default)]
pub(super) struct State {
    scope: Option<String>,
    text: String,
    epoch: u64,
    choices: Vec<(String, SuggestionAction)>,
    form: Option<Form>,
    form_origin: String,
    field: String,
    field_text: String,
    fields: Rc<VecModel<SearchFilterField>>,
    field_options: Vec<(String, FilterValue)>,
    shown_query: Option<String>,
}

fn group(group: SuggestionGroup) -> (&'static str, i32) {
    match group {
        SuggestionGroup::Actions => ("", 1),
        SuggestionGroup::Filters => ("Filters", 2),
        SuggestionGroup::From => ("From User", 3),
        SuggestionGroup::In => ("In Channel", 4),
        SuggestionGroup::Has => ("Has", 6),
        SuggestionGroup::Mentions => ("Mentions User", 5),
        SuggestionGroup::Before => ("Before", 7),
        SuggestionGroup::After => ("After", 7),
        SuggestionGroup::During => ("On", 7),
        SuggestionGroup::Author => ("Author Type", 3),
        SuggestionGroup::Pinned => ("Pinned", 2),
        SuggestionGroup::Sort => ("Sort", 2),
    }
}

fn row_picture(url: Option<&str>) -> slint::Image {
    url.map(pictures::avatar_picture).unwrap_or_default()
}

fn rows<T: Clone + 'static>(rows: Vec<T>) -> ModelRc<T> {
    ModelRc::new(VecModel::from(rows))
}

impl State {
    fn next_id(&mut self) -> String {
        self.epoch = self.epoch.wrapping_add(1);
        format!("choice:{}", self.epoch)
    }

    fn show_suggestions(&mut self, window: &YapfastWindow, app: &AppState, text: &str, caret: i32) {
        if self.scope.is_none() {
            return;
        }
        let mut rows_out = Vec::new();
        let mut last = "";
        let mut first = None;
        self.text.clear();
        self.text.push_str(text);
        self.choices.clear();
        let caret = usize::try_from(caret).unwrap_or(text.len());
        for choice in search_assist::suggestions(app, text, caret) {
            let (heading, icon) = group(choice.group);
            if heading != last && !heading.is_empty() {
                rows_out.push(SearchAssistRow {
                    label: heading.into(),
                    kind: 1,
                    ..Default::default()
                });
            }
            last = heading;
            first.get_or_insert((
                rows_out.len(),
                !matches!(
                    choice.group,
                    SuggestionGroup::Actions | SuggestionGroup::Filters
                ),
            ));
            let row_icon = match &choice.action {
                SuggestionAction::OpenFilters => 2,
                SuggestionAction::Replace { replacement, .. }
                    if matches!(choice.group, SuggestionGroup::Filters) =>
                {
                    match replacement.split_once(':').map(|(key, _)| key) {
                        Some("from") => 3,
                        Some("in") => 4,
                        Some("mentions") => 5,
                        Some("has") => 6,
                        _ => icon,
                    }
                }
                _ => icon,
            };
            let id = match &choice.action {
                SuggestionAction::OpenFilters => "@filters".to_owned(),
                SuggestionAction::Submit => "@search".to_owned(),
                _ => self.next_id(),
            };
            self.choices.push((id.clone(), choice.action));
            rows_out.push(SearchAssistRow {
                id: id.into(),
                label: choice.title.into(),
                detail: choice.subtitle.into(),
                icon: row_icon,
                picture: row_picture(choice.avatar.as_deref()),
                ..Default::default()
            });
        }
        window.set_search_suggestion_index(
            first
                .filter(|(_, active_filter)| *active_filter)
                .map_or(-1, |(index, _)| index as i32),
        );
        window.set_search_suggestions(rows(rows_out));
    }

    fn show_fields(&self, window: &YapfastWindow, app: &AppState) {
        let fields = FIELDS
            .iter()
            .filter(|field| {
                field.key != "in"
                    || app
                        .search_place()
                        .is_some_and(|place| super::discord::parse_server(&place).is_some())
            })
            .map(|field| SearchFilterField {
                key: field.key.into(),
                label: field.label.into(),
                detail: field.detail.into(),
                placeholder: field.placeholder.into(),
                value: self
                    .form
                    .as_ref()
                    .map(|form| form.field_value(field.key))
                    .unwrap_or_default()
                    .into(),
            })
            .collect();
        super::update_model(&self.fields, fields);
        window.set_search_filters_can_apply(
            self.form
                .as_ref()
                .is_some_and(|form| form.query() != self.form_origin),
        );
    }

    fn edit_field(&mut self, window: &YapfastWindow, app: &AppState, key: &str, input: &str) {
        let Some(field) = FIELDS.iter().find(|field| field.key == key) else {
            return;
        };
        if self.form.is_none() {
            return;
        }
        self.field.clear();
        self.field.push_str(key);
        self.field_text.clear();
        self.field_text.push_str(input);
        self.field_options.clear();
        let values = search_assist::values(app, key, input);
        let mut display = Vec::new();
        for value in values {
            let id = self.next_id();
            display.push(SearchAssistRow {
                id: id.as_str().into(),
                label: value.label.as_str().into(),
                detail: value.detail.as_str().into(),
                icon: field.icon,
                picture: row_picture(value.avatar.as_deref()),
                selected: self
                    .form
                    .as_ref()
                    .is_some_and(|form| form.selected(key, &value.value)),
                ..Default::default()
            });
            self.field_options.push((id, value));
        }
        window.set_search_filter_options(rows(display));
    }

    fn open_form(&mut self, window: &YapfastWindow, app: &AppState) {
        if self.scope.is_none() || self.form.is_some() {
            return;
        }
        let mut form = Form::from_query(window.get_search_text().as_str());
        for atom in form.atoms.iter_mut().take(32) {
            if let Some(found) = search_assist::values(app, &atom.key, &atom.value)
                .into_iter()
                .find(|value| value.value.eq_ignore_ascii_case(&atom.value))
            {
                atom.label = found.label;
            }
        }
        self.form_origin = form.query();
        self.form = Some(form);
        self.field.clear();
        self.field_text.clear();
        self.field_options.clear();
        window.set_search_filter_active(SharedString::default());
        window.set_search_filter_options(ModelRc::default());
        window.set_search_filter_fields(ModelRc::from(self.fields.clone()));
        self.show_fields(window, app);
        window.set_search_filters_open(true);
    }

    fn close_form(&mut self, window: &YapfastWindow) {
        self.form = None;
        self.form_origin.clear();
        self.field.clear();
        self.field_text.clear();
        self.field_options.clear();
        window.set_search_filters_open(false);
        window.set_search_filters_can_apply(false);
        window.set_search_filter_active(SharedString::default());
        window.set_search_filter_options(ModelRc::default());
    }
}

pub(super) fn refresh_scope(
    state: &mut State,
    window: &YapfastWindow,
    app: &AppState,
    hidden: bool,
) {
    let scope = (!hidden)
        .then(|| app.search_place())
        .flatten()
        .filter(|place| Network::of(place) == Network::Discord);
    window.set_search_assist_enabled(scope.is_some());
    if state.scope != scope {
        state.scope = scope;
        state.choices.clear();
        state.text.clear();
        state.close_form(window);
        window.set_search_suggestions(ModelRc::default());
        window.set_search_suggestion_index(-1);
    }
    let query = app.search_shown().map(|search| search.query.as_str());
    if state.shown_query.as_deref() != query {
        state.shown_query = query.map(str::to_owned);
        let sort = query
            .map(Form::from_query)
            .and_then(|form| form.atoms.into_iter().rev().find(|atom| atom.key == "sort"))
            .map(|atom| atom.value)
            .unwrap_or_else(|| "newest".into());
        window.set_search_sort(sort.into());
    }
}

pub(super) fn bind(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_search_assist_changed(move |text, caret| {
        if let Some(window) = weak.upgrade() {
            if let Ok(mut adapter) = state.try_borrow_mut() {
                let Adapter { app, search_ui, .. } = &mut *adapter;
                search_ui.show_suggestions(&window, &app.state, text.as_str(), caret);
            }
        }
    });
    let weak = window.as_weak();
    window.on_search_suggestion_step(move |direction| {
        if let Some(window) = weak.upgrade() {
            let rows = window.get_search_suggestions();
            let options: Vec<_> = rows
                .iter()
                .enumerate()
                .filter_map(|(i, row)| (row.kind == 0 && !row.id.is_empty()).then_some(i as i32))
                .collect();
            if options.is_empty() {
                return;
            }
            let current = options
                .iter()
                .position(|i| *i == window.get_search_suggestion_index());
            let next = match (current, direction < 0) {
                (None, false) => 0,
                (None, true) => options.len() - 1,
                (Some(i), false) => (i + 1) % options.len(),
                (Some(i), true) => (i + options.len() - 1) % options.len(),
            };
            window.set_search_suggestion_index(options[next]);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_search_assist_choose(move |id| {
        let Some(window) = weak.upgrade() else {
            return;
        };
        let mut adapter = state.borrow_mut();
        if window.get_search_filters_open() {
            let Adapter { app, search_ui, .. } = &mut *adapter;
            let Some(field) = FIELDS.iter().find(|field| field.key == search_ui.field) else {
                return;
            };
            if let Some((_, value)) = search_ui
                .field_options
                .iter()
                .find(|(key, _)| key == id.as_str())
                && let Some(form) = search_ui.form.as_mut()
            {
                form.choose(field, value.clone());
                search_ui.show_fields(&window, &app.state);
                let input = search_ui.field_text.clone();
                search_ui.edit_field(&window, &app.state, field.key, &input);
            }
            return;
        }
        if adapter.search_ui.text != window.get_search_text().as_str() {
            return;
        }
        let Some(action) = adapter
            .search_ui
            .choices
            .iter()
            .find(|(key, _)| key == id.as_str())
            .map(|(_, action)| action.clone())
        else {
            return;
        };
        match action {
            SuggestionAction::Submit => {
                adapter.action(
                    &window,
                    Action::Search(window.get_search_text().to_string()),
                );
            }
            SuggestionAction::OpenFilters => {
                let Adapter { app, search_ui, .. } = &mut *adapter;
                search_ui.open_form(&window, &app.state);
            }
            SuggestionAction::Replace { range, replacement } => {
                let mut text = window.get_search_text().to_string();
                if text.get(range.clone()).is_none() {
                    return;
                }
                let caret = range.start + replacement.len();
                text.replace_range(range, &replacement);
                window.set_search_text(text.as_str().into());
                window.set_search_caret_request(caret as i32);
                let Adapter { app, search_ui, .. } = &mut *adapter;
                search_ui.show_suggestions(&window, &app.state, &text, caret as i32);
                drop(adapter);
                window.invoke_refocus_search();
            }
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_search_filters_shown(move || {
        if let Some(window) = weak.upgrade() {
            if let Ok(mut adapter) = state.try_borrow_mut() {
                let Adapter { app, search_ui, .. } = &mut *adapter;
                search_ui.open_form(&window, &app.state);
            }
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_search_filter_edit(move |key, input| {
        if let Some(window) = weak.upgrade() {
            let mut adapter = state.borrow_mut();
            let Adapter { app, search_ui, .. } = &mut *adapter;
            if matches!(key.as_str(), "before" | "after" | "during")
                && input.len() == 10
                && let Some(form) = search_ui.form.as_mut()
                && !split_search_filters(&format!("{}:{}", key, input))
                    .1
                    .is_empty()
            {
                form.replace(key.as_str(), input.as_str());
                search_ui.show_fields(&window, &app.state);
            }
            search_ui.edit_field(&window, &app.state, key.as_str(), input.as_str());
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_search_filters_clear(move || {
        if let Some(window) = weak.upgrade() {
            let mut adapter = state.borrow_mut();
            let Adapter { app, search_ui, .. } = &mut *adapter;
            if let Some(form) = search_ui.form.as_mut() {
                form.atoms.retain(|atom| atom.key == "sort");
            }
            search_ui.show_fields(&window, &app.state);
            search_ui.field.clear();
            search_ui.field_text.clear();
            search_ui.field_options.clear();
            window.set_search_filter_active(SharedString::default());
            window.set_search_filter_options(ModelRc::default());
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_search_filters_cancel(move || {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().search_ui.close_form(&window);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_search_filters_apply(move || {
        if let Some(window) = weak.upgrade() {
            let mut adapter = state.borrow_mut();
            if let Some(form) = adapter.search_ui.form.take() {
                let query = form.query();
                let changed = query != adapter.search_ui.form_origin;
                adapter.search_ui.close_form(&window);
                if changed {
                    window.set_search_text(query.as_str().into());
                    adapter.action(&window, Action::Search(query));
                }
            }
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_sort_search(move |sort| {
        if let Some(window) = weak.upgrade() {
            let mut adapter = state.borrow_mut();
            if matches!(sort.as_str(), "newest" | "oldest" | "relevance")
                && let Some(search) = adapter.app.state.search_shown()
            {
                let mut form = Form::from_query(&search.query);
                form.replace(
                    "sort",
                    if sort.as_str() == "newest" {
                        ""
                    } else {
                        sort.as_str()
                    },
                );
                let query = form.query();
                window.set_search_text(query.as_str().into());
                adapter.action(&window, Action::Search(query));
            }
        }
    });
}

#[cfg(all(test, feature = "discord"))]
mod tests {
    use super::super::{
        Application, BackgroundRuntime, Command, Event, Navigation, bind_callbacks,
    };
    use super::*;
    use std::sync::Arc;
    use yapfast_core::chat::DiscordCommand;
    use yapfast_core::yapfast_discord::service::{Conversation, Snapshot, Status};

    #[test]
    fn search_filter_form_keeps_text_and_multiple_selected_values() {
        let mut form = Form::from_query("open orders from:<@12> has:file sort:oldest");
        let field = FIELDS.iter().find(|field| field.key == "has").unwrap();
        form.choose(
            field,
            FilterValue {
                value: "link".into(),
                label: "Link".into(),
                detail: String::new(),
                avatar: None,
            },
        );
        assert_eq!(
            form.query(),
            "open orders from:<@12> has:file sort:oldest has:link"
        );
        form.choose(
            field,
            FilterValue {
                value: "file".into(),
                label: "File".into(),
                detail: String::new(),
                avatar: None,
            },
        );
        form.replace("sort", "relevance");
        assert_eq!(
            form.query(),
            "open orders from:<@12> has:link sort:relevance"
        );
    }

    #[test]
    fn search_filter_form_canonicalizes_ids_and_clears_sorted_filter_only_searches() {
        let mut form = Form::from_query("from:12 mentions:<@!23> in:#34 has:snapshot sort:oldest");
        assert!(form.selected("from", "<@12>"));
        assert!(form.selected("mentions", "<@23>"));
        assert!(form.selected("in", "<#34>"));
        let field = FIELDS.iter().find(|field| field.key == "has").unwrap();
        let forwarded = FilterValue {
            value: "forward".into(),
            label: "Forwarded message".into(),
            detail: String::new(),
            avatar: None,
        };
        assert!(form.selected(field.key, &forwarded.value));
        form.choose(field, forwarded);
        assert!(!form.query().contains("has:"));
        form.atoms.retain(|atom| atom.key == "sort");
        assert_eq!(form.query(), "");
        form.content = "receipt".into();
        assert_eq!(form.query(), "receipt sort:oldest");
    }

    #[test]
    fn search_assist_filters_and_sort_dispatch_only_on_apply() {
        i_slint_backend_testing::init_no_event_loop();
        let directory = tempfile::tempdir().unwrap();
        let window = YapfastWindow::new().unwrap();
        let adapter = Adapter::new(
            Arc::new(BackgroundRuntime::new().unwrap()),
            directory.path().into(),
            &window,
        )
        .unwrap();
        bind_callbacks(&window, &adapter);
        let mut app = Application::default();
        app.apply(Event::Discord(Arc::new(Snapshot {
            status: Status::Online,
            user_id: Some("1".into()),
            conversations: vec![Arc::new(Conversation {
                id: "30".into(),
                name: "Friend".into(),
                person: Some("2".into()),
                people: 2,
                ..Default::default()
            })],
            ..Default::default()
        })));
        app.state.selected = Some("discord:@me:30".into());
        app.state.navigation = Navigation::DirectMessages;
        let commands = Rc::new(RefCell::new(Vec::new()));
        {
            let mut adapter = adapter.borrow_mut();
            adapter.app = app;
            adapter.backend_commands = Some(commands.clone());
            adapter.refresh(&window);
        }
        assert!(window.get_search_assist_enabled());
        window.set_search_text("receipt".into());
        window.invoke_search_assist_changed("receipt".into(), 7);
        assert!(
            window
                .get_search_suggestions()
                .iter()
                .any(|row| row.id == "@search")
        );
        window.invoke_search_suggestion_step(1);
        assert!(window.get_search_suggestion_index() >= 0);
        let pick_link = || {
            window.invoke_search_filters_shown();
            assert!(!window.get_search_filters_can_apply());
            assert!(
                !window
                    .get_search_filter_fields()
                    .iter()
                    .any(|field| field.key == "in")
            );
            window.invoke_search_filter_edit("has".into(), "link".into());
            let choice = window
                .get_search_filter_options()
                .iter()
                .find(|row| row.label.to_lowercase().starts_with("link"))
                .unwrap();
            window.invoke_search_assist_choose(choice.id);
            assert!(window.get_search_filters_can_apply());
        };
        pick_link();
        assert_eq!(window.get_search_text().as_str(), "receipt");
        window.invoke_search_filters_cancel();
        assert!(!window.get_search_filters_open());
        assert!(adapter.borrow().app.state.search_shown().is_none());
        pick_link();
        window.invoke_search_filters_apply();
        assert_eq!(window.get_search_text().as_str(), "receipt has:link");
        window.invoke_sort_search("oldest".into());
        assert_eq!(
            window.get_search_text().as_str(),
            "receipt has:link sort:oldest"
        );
        assert_eq!(window.get_search_sort().as_str(), "oldest");
        let queries: Vec<_> = commands
            .borrow()
            .iter()
            .filter_map(|command| match command {
                Command::Discord(DiscordCommand::Search {
                    place,
                    query,
                    offset: 0,
                }) => Some((place.clone(), query.clone())),
                _ => None,
            })
            .collect();
        assert_eq!(
            queries,
            [
                ("discord:@me:30".into(), "receipt has:link".into()),
                (
                    "discord:@me:30".into(),
                    "receipt has:link sort:oldest".into()
                ),
            ]
        );
    }
}
