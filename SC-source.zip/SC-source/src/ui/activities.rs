//! Honest handoff for Discord's iframe-based Activities, scoped to a known room.
use super::*;

#[derive(Default)]
pub(super) struct State {
    pending: Option<Target>,
}

struct Target {
    account: String,
    room: String,
    call: bool,
}

fn snowflake(value: &str) -> bool {
    !value.is_empty()
        && value.len() <= 20
        && value.bytes().all(|byte| byte.is_ascii_digit())
        && value.parse::<u64>().is_ok_and(|id| id != 0)
}

/// Only canonical IDs from currently readable Discord rooms become links.
fn channel_parts<'a>(state: &AppState, id: &'a str) -> Option<(&'a str, &'a str)> {
    if state.preview || !state.discord_user.as_deref().is_some_and(snowflake) {
        return None;
    }
    let room = state.rooms.iter().find(|room| room.id == id)?;
    if room.network != Network::Discord || room.locked || room.request || room.forum {
        return None;
    }
    let (guild, channel) = discord::parse_room(id)?;
    if !(guild == discord::DM_GUILD || snowflake(guild)) || !snowflake(channel) {
        return None;
    }
    Some((guild, channel))
}

fn context(state: &AppState, call: bool) -> Option<&str> {
    if call {
        state
            .voice
            .active()
            .then_some(state.voice.room.as_deref())
            .flatten()
    } else {
        state.selected.as_deref()
    }
}

fn valid(state: &AppState, target: &Target) -> bool {
    if state.discord_user.as_deref() != Some(target.account.as_str())
        || context(state, target.call) != Some(target.room.as_str())
    {
        return false;
    }
    channel_parts(state, &target.room).is_some()
}

pub(super) fn sync(adapter: &mut Adapter, window: &YapfastWindow) {
    let launcher = window.global::<ActivityLauncher>();
    let state = &adapter.app.state;
    launcher.set_chat_available(
        context(state, false)
            .and_then(|room| channel_parts(state, room))
            .is_some(),
    );
    launcher.set_call_available(
        context(state, true)
            .and_then(|room| channel_parts(state, room))
            .is_some(),
    );
    if window.get_settings_open()
        || adapter
            .activities
            .pending
            .as_ref()
            .is_some_and(|target| !valid(state, target))
    {
        adapter.activities.pending = None;
        launcher.set_open(false);
        launcher.set_place(SharedString::default());
    }
}

pub(super) fn bind(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    bind_with(window, adapter, Rc::new(browser::open));
}

fn bind_with(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>, open_web: Rc<dyn Fn(&str)>) {
    let weak = window.as_weak();
    let state = adapter.clone();
    window.global::<ActivityLauncher>().on_show(move |call| {
        let Some(window) = weak.upgrade() else {
            return;
        };
        let mut adapter = state.borrow_mut();
        let state = &adapter.app.state;
        let Some(room) = context(state, call).filter(|room| channel_parts(state, room).is_some())
        else {
            return;
        };
        let name = state
            .rooms
            .iter()
            .find(|known| known.id == room)
            .map(|room| room.name.as_str())
            .unwrap_or("this channel");
        let launcher = window.global::<ActivityLauncher>();
        launcher.set_place(name.into());
        launcher.set_call(call);
        adapter.activities.pending = Some(Target {
            account: state.discord_user.clone().unwrap(),
            room: room.to_owned(),
            call,
        });
        launcher.set_open(true);
    });
    let weak = window.as_weak();
    let state = adapter.clone();
    window.global::<ActivityLauncher>().on_close(move || {
        state.borrow_mut().activities.pending = None;
        if let Some(window) = weak.upgrade() {
            let launcher = window.global::<ActivityLauncher>();
            launcher.set_open(false);
            launcher.set_place(SharedString::default());
        }
    });
    let weak = window.as_weak();
    let state = adapter.clone();
    window.global::<ActivityLauncher>().on_open_web(move || {
        let Some(window) = weak.upgrade() else {
            return;
        };
        // Take before launch so double activation cannot open two browser tabs.
        let url = {
            let mut adapter = state.borrow_mut();
            adapter
                .activities
                .pending
                .take()
                .filter(|target| valid(&adapter.app.state, target))
                .and_then(|target| {
                    let (guild, channel) = channel_parts(&adapter.app.state, &target.room)?;
                    Some(format!("https://discord.com/channels/{guild}/{channel}"))
                })
        };
        let launcher = window.global::<ActivityLauncher>();
        launcher.set_open(false);
        launcher.set_place(SharedString::default());
        // Bypass the native Discord-link router intentionally: this exact
        // destination needs Discord's web runtime, with its own browser login.
        if let Some(url) = url {
            open_web(&url);
        }
    });
}

#[cfg(all(test, feature = "discord"))]
mod tests {
    use super::*;
    use yapfast_core::yapfast_discord::service::{Conversation, Snapshot, Status};

    const CHAT: &str = "discord:@me:30";
    const CALL: &str = "discord:10:12";

    fn fixture() -> (
        tempfile::TempDir,
        YapfastWindow,
        Rc<RefCell<Adapter>>,
        Rc<RefCell<Vec<String>>>,
    ) {
        i_slint_backend_testing::init_no_event_loop();
        let folder = tempfile::tempdir().unwrap();
        let window = YapfastWindow::new().unwrap();
        let adapter = Adapter::new(
            Arc::new(BackgroundRuntime::new().unwrap()),
            folder.path().into(),
            &window,
        )
        .unwrap();
        let mut app = Application::default();
        app.apply(Event::Discord(Arc::new(Snapshot {
            status: Status::Online,
            user_id: Some("1".into()),
            conversations: vec![Arc::new(Conversation {
                id: "30".into(),
                name: "Friends".into(),
                person: Some("2".into()),
                people: 2,
                ..Default::default()
            })],
            ..Default::default()
        })));
        // A different, readable voice room is the call context, independent of selection.
        let mut call = (*app.state.rooms[0]).clone();
        call.id = CALL.into();
        call.name = "Lounge".into();
        call.direct = false;
        call.person = None;
        call.voice = true;
        app.state.rooms.push(Arc::new(call));
        app.state.selected = Some(CHAT.into());
        app.state.voice.room = Some(CALL.into());
        app.state.voice.phase = voice::Phase::Connected;
        adapter.borrow_mut().app = app;
        let opened = Rc::new(RefCell::new(Vec::new()));
        let captured = opened.clone();
        bind_with(
            &window,
            &adapter,
            Rc::new(move |url| captured.borrow_mut().push(url.to_owned())),
        );
        sync(&mut adapter.borrow_mut(), &window);
        (folder, window, adapter, opened)
    }

    #[test]
    fn activities_web_callbacks_preserve_call_and_target_the_chosen_context() {
        let (_folder, window, adapter, opened) = fixture();
        let launcher = window.global::<ActivityLauncher>();
        assert!(launcher.get_chat_available() && launcher.get_call_available());
        launcher.invoke_show(true);
        assert!(launcher.get_open());
        assert_eq!(launcher.get_place(), "Lounge");
        assert!(
            opened.borrow().is_empty(),
            "showing the dialog does not open a browser"
        );
        launcher.invoke_open_web();
        launcher.invoke_open_web();
        assert_eq!(*opened.borrow(), ["https://discord.com/channels/10/12"]);
        assert!(!launcher.get_open());
        assert_eq!(adapter.borrow().app.state.voice.room.as_deref(), Some(CALL));
        assert_eq!(
            adapter.borrow().app.state.voice.phase,
            voice::Phase::Connected
        );
        assert_eq!(adapter.borrow().app.state.selected.as_deref(), Some(CHAT));
        launcher.invoke_show(false);
        assert_eq!(launcher.get_place(), "Friends");
        launcher.invoke_open_web();
        assert_eq!(opened.borrow()[1], "https://discord.com/channels/@me/30");
        launcher.invoke_show(false);
        launcher.invoke_close();
        launcher.invoke_open_web();
        assert_eq!(opened.borrow().len(), 2);
    }

    #[test]
    fn activities_web_revalidates_accounts_rooms_permissions_and_calls() {
        let (_folder, window, adapter, opened) = fixture();
        let launcher = window.global::<ActivityLauncher>();
        launcher.invoke_show(false);
        adapter.borrow_mut().app.state.discord_user = Some("2".into());
        launcher.invoke_open_web();
        assert!(opened.borrow().is_empty());
        adapter.borrow_mut().app.state.discord_user = Some("1".into());
        launcher.invoke_show(false);
        adapter.borrow_mut().app.state.selected = Some(CALL.into());
        launcher.invoke_open_web();
        assert!(opened.borrow().is_empty());
        launcher.invoke_show(true);
        adapter.borrow_mut().app.state.voice.phase = voice::Phase::Disconnected;
        sync(&mut adapter.borrow_mut(), &window);
        assert!(!launcher.get_open() && !launcher.get_call_available());
        adapter.borrow_mut().app.state.selected = Some(CHAT.into());
        launcher.invoke_show(false);
        Arc::make_mut(&mut adapter.borrow_mut().app.state.rooms[0]).locked = true;
        launcher.invoke_open_web();
        assert!(opened.borrow().is_empty());
        sync(&mut adapter.borrow_mut(), &window);
        assert!(!launcher.get_chat_available());
    }

    #[test]
    fn activities_web_rejects_unknown_and_noncanonical_destinations() {
        let (_folder, _window, adapter, _opened) = fixture();
        let mut adapter = adapter.borrow_mut();
        let state = &mut adapter.app.state;
        for id in [
            "https://example.test",
            "discord:@me:0",
            "discord:10:12?x=1",
            "discord:10:12/99",
            "discord:../x:30",
            "discord:10:18446744073709551616",
        ] {
            Arc::make_mut(&mut state.rooms[0]).id = id.into();
            assert!(channel_parts(state, id).is_none(), "reject {id}");
        }
        Arc::make_mut(&mut state.rooms[0]).id = CHAT.into();
        state.preview = true;
        assert!(channel_parts(state, CHAT).is_none());
        state.preview = false;
        Arc::make_mut(&mut state.rooms[0]).request = true;
        assert!(channel_parts(state, CHAT).is_none());
    }

    #[test]
    #[ignore = "native offscreen review artifact"]
    fn activities_web_native_snapshot() {
        use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
        use std::ops::ControlFlow;
        slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
            i_slint_backend_testing::TestingBackendOptions {
                mock_time: true,
                threading: false,
                renderer_name: Some("skia".into()),
            },
        )))
        .unwrap();
        let window = yapfast::window().unwrap();
        Layout::default().apply_appearance(&window);
        window.global::<ActivityLauncher>().set_open(true);
        window
            .global::<ActivityLauncher>()
            .set_place("Lounge · a channel with a long but readable name".into());
        window.show().unwrap();
        let output = std::env::var_os("SC_REVIEW_DIR")
            .map(PathBuf::from)
            .expect("SC_REVIEW_DIR");
        std::fs::create_dir_all(&output).unwrap();
        for (width, height, call) in [(800, 600, true), (1120, 760, false)] {
            window
                .window()
                .set_size(slint::LogicalSize::new(width as f32, height as f32));
            window.global::<ActivityLauncher>().set_call(call);
            let frame = window.window().take_snapshot().unwrap();
            let inner = i_slint_core::window::WindowInner::from_pub(window.window());
            let root = ItemRc::new_root(inner.component());
            for label in ["Close Activities", "Cancel Activities", "Open Discord web"] {
                let item = root
                    .visit_descendants(|item| {
                        if item.is_visible()
                            && item
                                .accessible_string_property(AccessibleStringProperty::Label)
                                .as_deref()
                                == Some(label)
                        {
                            ControlFlow::Break(item.clone())
                        } else {
                            ControlFlow::Continue(())
                        }
                    })
                    .unwrap_or_else(|| panic!("missing {label}"));
                let geometry = item.geometry();
                let point = item.map_to_window(geometry.origin);
                assert!(
                    point.x >= 0. && point.x + geometry.width() <= width as f32,
                    "{label} clipped"
                );
                assert!(
                    point.y >= 0. && point.y + geometry.height() <= height as f32,
                    "{label} clipped"
                );
            }
            image::save_buffer(
                output.join(format!("activities-web-{width}.png")),
                frame.as_bytes(),
                width,
                height,
                image::ColorType::Rgba8,
            )
            .unwrap();
        }
        window.hide().unwrap();
    }
}
