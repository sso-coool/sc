use super::*;

#[test]
fn appearance_options_survive_saved_layout_and_window_recreation() {
    i_slint_backend_testing::init_no_event_loop();
    let window = YapfastWindow::new().unwrap();
    let presentation = window.global::<ClientStyle>();
    presentation.set_density(0);
    presentation.set_enhanced_surfaces(false);
    presentation.set_interface_motion(false);
    presentation.set_inline_slash_input(false);
    presentation.set_auto_resize(false);
    window.global::<Looks>().set_animate_name_styles(false);
    let mut layout = Layout::default();
    layout.read_cosmetics(&window);
    let saved = serde_json::to_string(&layout).unwrap();
    let restored: Layout = serde_json::from_str(&saved).unwrap();
    let recreated = YapfastWindow::new().unwrap();
    restored.show_cosmetics(&recreated);
    let shown = recreated.global::<ClientStyle>();
    assert_eq!(shown.get_density(), 0);
    assert!(!shown.get_enhanced_surfaces());
    assert!(!shown.get_interface_motion());
    assert!(!shown.get_inline_slash_input());
    assert!(!shown.get_auto_resize());
    assert!(!recreated.global::<Looks>().get_animate_name_styles());
    assert_eq!(recreated.global::<Theme>().get_quick(), 0);
}

#[test]
fn appearance_density_falls_back_and_clamps_without_touching_saved_pane_widths() {
    i_slint_backend_testing::init_no_event_loop();
    let window = YapfastWindow::new().unwrap();
    let mut layout = Layout::default();
    layout.show_cosmetics(&window);
    assert_eq!(window.global::<ClientStyle>().get_density(), 1);
    assert!(window.global::<ClientStyle>().get_inline_slash_input());
    assert!(window.global::<ClientStyle>().get_auto_resize());
    layout.interface_density = Some(999);
    layout.show_cosmetics(&window);
    assert_eq!(window.global::<ClientStyle>().get_density(), 2);
    layout.interface_density = Some(-5);
    layout.show_cosmetics(&window);
    assert_eq!(window.global::<ClientStyle>().get_density(), 0);
}
