use super::*;

#[test]
fn appearance_ultra_optimized_pauses_visuals_and_restores_preferences() {
    i_slint_backend_testing::init_no_event_loop();
    let window = YapfastWindow::new().unwrap();
    let mut saved = Layout {
        animate: Animate::Always,
        profile_effects: Some(true),
        moving_cosmetics: Some(true),
        interface_motion: Some(true),
        animate_name_styles: Some(true),
        ultra_optimized: true,
        ..Default::default()
    };
    saved.show_cosmetics(&window);
    let previous = ANIMATE.replace(saved.animate);
    show_motion(&window);
    assert!(window.global::<Motion>().get_never());
    assert!(!window.global::<Motion>().get_playing());
    assert!(!window.global::<ClientStyle>().get_transitions());
    assert!(!saved.effective_cosmetics().effects);
    assert!(!saved.effective_cosmetics().moving);
    saved.read_cosmetics(&window);
    let mut restored: Layout =
        serde_json::from_str(&serde_json::to_string(&saved).unwrap()).unwrap();
    assert!(restored.ultra_optimized);
    restored.ultra_optimized = false;
    restored.show_cosmetics(&window);
    show_motion(&window);
    assert!(window.global::<Motion>().get_playing());
    assert!(window.global::<ClientStyle>().get_transitions());
    assert!(window.global::<Looks>().get_animate_name_styles());
    assert!(restored.effective_cosmetics().effects && restored.effective_cosmetics().moving);
    ANIMATE.set(previous);
}

#[test]
fn appearance_options_survive_saved_layout_and_window_recreation() {
    i_slint_backend_testing::init_no_event_loop();
    let window = YapfastWindow::new().unwrap();
    let presentation = window.global::<ClientStyle>();
    presentation.set_density(0);
    presentation.set_enhanced_surfaces(false);
    presentation.set_interface_motion(false);
    presentation.set_inline_slash_input(false);
    presentation.set_auto_resize(false);
    presentation.set_discord_extras(false);
    window.global::<Looks>().set_animate_name_styles(false);
    let mut layout = Layout::default();
    layout.read_cosmetics(&window);
    let saved = serde_json::to_string(&layout).unwrap();
    let restored: Layout = serde_json::from_str(&saved).unwrap();
    let recreated = YapfastWindow::new().unwrap();
    restored.show_cosmetics(&recreated);
    let shown = recreated.global::<ClientStyle>();
    assert_eq!(shown.get_density(), 0);
    assert!(!shown.get_enhanced_surfaces());
    assert!(!shown.get_interface_motion());
    assert!(!shown.get_inline_slash_input());
    assert!(!shown.get_auto_resize());
    assert!(!shown.get_discord_extras());
    assert!(!recreated.global::<Looks>().get_animate_name_styles());
    assert_eq!(recreated.global::<Theme>().get_quick(), 0);
}

#[test]
fn appearance_density_falls_back_and_clamps_without_touching_saved_pane_widths() {
    i_slint_backend_testing::init_no_event_loop();
    let window = YapfastWindow::new().unwrap();
    let mut layout = Layout::default();
    layout.show_cosmetics(&window);
    assert_eq!(window.global::<ClientStyle>().get_density(), 1);
    assert!(window.global::<ClientStyle>().get_inline_slash_input());
    assert!(window.global::<ClientStyle>().get_auto_resize());
    assert!(window.global::<ClientStyle>().get_discord_extras());
    layout.interface_density = Some(999);
    layout.show_cosmetics(&window);
    assert_eq!(window.global::<ClientStyle>().get_density(), 2);
    layout.interface_density = Some(-5);
    layout.show_cosmetics(&window);
    assert_eq!(window.global::<ClientStyle>().get_density(), 0);
}

#[test]
fn appearance_discord_extras_switch_controls_real_sidebar_links_and_persists() {
    use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
    use slint::platform::{PointerEventButton, WindowEvent};
    use std::ops::ControlFlow;

    fn named(window: &YapfastWindow, label: &str) -> Option<ItemRc> {
        let inner = i_slint_core::window::WindowInner::from_pub(window.window());
        ItemRc::new_root(inner.component()).visit_descendants(|item| {
            if item.is_visible()
                && item
                    .accessible_string_property(AccessibleStringProperty::Label)
                    .as_deref()
                    == Some(label)
            {
                ControlFlow::Break(item.clone())
            } else {
                ControlFlow::Continue(())
            }
        })
    }
    fn click(window: &YapfastWindow, label: &str) {
        let item = named(window, label).unwrap_or_else(|| panic!("missing control: {label}"));
        let point = item.map_to_window(item.geometry().center());
        let size = window
            .window()
            .size()
            .to_logical(window.window().scale_factor());
        assert!(
            point.x >= 0. && point.x < size.width,
            "{label} fits horizontally"
        );
        assert!(
            point.y >= 0. && point.y < size.height,
            "{label} fits vertically"
        );
        let position = slint::LogicalPosition::new(point.x, point.y);
        window
            .window()
            .dispatch_event(WindowEvent::PointerMoved { position });
        window.window().dispatch_event(WindowEvent::PointerPressed {
            position,
            button: PointerEventButton::Left,
        });
        window
            .window()
            .dispatch_event(WindowEvent::PointerReleased {
                position,
                button: PointerEventButton::Left,
            });
    }
    fn show_dms(window: &YapfastWindow) {
        window.set_workspace(true);
        window.set_trusted(true);
        window.set_discord_linked(true);
        window.set_dms_selected(true);
        window.set_preview(false);
        window.set_settings_open(false);
    }

    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let directory = tempfile::tempdir().unwrap();
    let window = yapfast::window().unwrap();
    let adapter = Adapter::new(
        Arc::new(BackgroundRuntime::new().unwrap()),
        directory.path().into(),
        &window,
    )
    .unwrap();
    bind_callbacks(&window, &adapter);
    window.global::<PictureStore>().on_request(|_| {});
    window.global::<ClientStyle>().set_interface_motion(false);
    let opened = Rc::new(RefCell::new(Vec::<String>::new()));
    let links = opened.clone();
    window.on_open_link(move |link| links.borrow_mut().push(link.to_string()));
    let friends = Rc::new(Cell::new(0));
    let hits = friends.clone();
    window.on_open_friends(move || hits.set(hits.get() + 1));
    let requests = Rc::new(Cell::new(0));
    let hits = requests.clone();
    window.on_open_requests(move || hits.set(hits.get() + 1));
    show_dms(&window);
    window.show().unwrap();
    window
        .window()
        .set_size(slint::LogicalSize::new(800., 600.));
    let shortcuts = [
        ("Nitro overview", "https://discord.com/nitro"),
        ("Shop overview", "https://discord.com/shop"),
        ("Quests overview", "https://discord.com/discovery/quests"),
    ];
    // The empty list and virtualized first-DM row have separate render paths.
    for populated in [false, true] {
        window.set_rooms(ModelRc::new(VecModel::from(if populated {
            vec![RoomRow {
                id: "discord:@me:100".into(),
                name: "A conversation".into(),
                direct: true,
                ..Default::default()
            }]
        } else {
            vec![]
        })));
        let frame = window.window().take_snapshot().unwrap();
        if populated && let Some(directory) = std::env::var_os("SC_REVIEW_DIR") {
            let directory = std::path::Path::new(&directory);
            std::fs::create_dir_all(directory).unwrap();
            image::save_buffer(
                directory.join("dm-extras800.png"),
                frame.as_bytes(),
                frame.width(),
                frame.height(),
                image::ColorType::Rgba8,
            )
            .unwrap();
        }
        for (label, destination) in shortcuts {
            let before = opened.borrow().len();
            click(&window, label);
            assert_eq!(
                opened.borrow().len(),
                before,
                "overview does not launch a browser"
            );
            assert!(window.global::<DiscordExtras>().get_page() > 0);
            let frame = window.window().take_snapshot().unwrap();
            if populated && let Some(directory) = std::env::var_os("SC_REVIEW_DIR") {
                let name = label.split_whitespace().next().unwrap().to_lowercase();
                image::save_buffer(
                    std::path::Path::new(&directory)
                        .join(format!("discord-{name}-overview800.png")),
                    frame.as_bytes(),
                    frame.width(),
                    frame.height(),
                    image::ColorType::Rgba8,
                )
                .unwrap();
            }
            click(&window, "Open in Discord");
            assert_eq!(window.global::<DiscordExtras>().get_page(), 0);
            assert_eq!(
                opened.borrow().last().map(String::as_str),
                Some(destination)
            );
        }
        click(&window, "Friends");
        click(&window, "Requests");
    }
    assert_eq!(opened.borrow().len(), 6);
    assert_eq!(friends.get(), 2);
    assert_eq!(requests.get(), 2);

    click(&window, "Shop overview");
    click(&window, "Hide these shortcuts");
    assert!(!window.global::<ClientStyle>().get_discord_extras());
    assert_eq!(window.global::<DiscordExtras>().get_page(), 0);
    assert_eq!(Layout::read(directory.path()).discord_extras, Some(false));
    window.global::<ClientStyle>().set_discord_extras(true);
    window.invoke_preferences_changed();
    // Saving refreshes the adapter's preview state; restore this fixture's
    // manually selected DM screen before testing the next visible shortcut.
    show_dms(&window);
    window.window().take_snapshot().unwrap();
    click(&window, "Quests overview");

    window.set_settings_open(true);
    window.set_settings_section(7);
    window
        .window()
        .set_size(slint::LogicalSize::new(1120., 900.));
    i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(1000));
    window.window().take_snapshot().unwrap();
    assert_eq!(
        window.global::<DiscordExtras>().get_page(),
        0,
        "settings closes and resets the overview"
    );
    click(&window, "Show Nitro, Shop and Quests");
    assert!(!window.global::<ClientStyle>().get_discord_extras());
    let restored = Layout::read(directory.path());
    assert_eq!(restored.discord_extras, Some(false));
    let recreated = YapfastWindow::new().unwrap();
    restored.show_cosmetics(&recreated);
    assert!(!recreated.global::<ClientStyle>().get_discord_extras());

    show_dms(&window);
    window
        .window()
        .set_size(slint::LogicalSize::new(800., 600.));
    window.window().take_snapshot().unwrap();
    for (label, _) in shortcuts {
        assert!(
            named(&window, label).is_none(),
            "disabled shortcut is removed: {label}"
        );
    }
    click(&window, "Friends");
    click(&window, "Requests");
    assert_eq!(friends.get(), 3);
    assert_eq!(requests.get(), 3);
    window.global::<ClientStyle>().set_discord_extras(true);
    window.invoke_preferences_changed();
    assert_eq!(Layout::read(directory.path()).discord_extras, Some(true));
    show_dms(&window);
    window.window().take_snapshot().unwrap();
    for (label, _) in shortcuts {
        assert!(named(&window, label).is_some());
    }
    assert_eq!(opened.borrow().len(), 6, "toggling never opens a page");
    window.hide().unwrap();
}
