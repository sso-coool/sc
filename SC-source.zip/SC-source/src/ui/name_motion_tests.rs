//! Native, offscreen checks for opt-in name motion; no service or account.
use super::*;
use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
use slint::platform::{PointerEventButton, WindowEvent};
use std::ops::ControlFlow;

const NAME: &str = "MMMM";

fn fixture() -> YapfastWindow {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let window = yapfast::window().unwrap();
    Layout::default().apply_appearance(&window);
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<Looks>().set_name_styles(true);
    window.global::<Looks>().set_animate_name_styles(true);
    window.global::<Looks>().set_moving(true);
    window.global::<Motion>().set_focused(true);
    window.global::<Motion>().set_playing(true);
    window.global::<Motion>().set_never(false);
    window.set_workspace(true);
    window.set_room_selected(true);
    window.set_room_ready(true);
    window.set_trusted(true);
    window.set_composer_enabled(false);
    window.set_sidebar_title("Offline test".into());
    window.global::<PictureStore>().on_request(|_| {});
    window.show().unwrap();
    window
        .window()
        .set_size(slint::LogicalSize::new(1120., 760.));
    window
}

fn set_effect(window: &YapfastWindow, effect: u8) {
    let message = ChatMessage {
        item: "motion:message".into(),
        sender: "motion:person".into(),
        author: NAME.into(),
        body: "A synthetic name with no remote assets.".into(),
        ..Default::default()
    };
    let mut row = message_row(&message, &HashSet::new());
    row.name_style = name_style::row(
        Some(&yapfast_core::chat::NameStyle::new(
            11,
            effect,
            &[0x96aaff, 0xf19dde, 0x81d8b2],
        )),
        NAME,
    );
    window.set_messages(ModelRc::new(VecModel::from(vec![row])));
}

fn advance(
    window: &YapfastWindow,
    milliseconds: u64,
) -> slint::SharedPixelBuffer<slint::Rgba8Pixel> {
    i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(milliseconds));
    slint::platform::update_timers_and_animations();
    window.window().take_snapshot().unwrap()
}

fn name_item(window: &YapfastWindow) -> ItemRc {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    ItemRc::new_root(inner.component())
        .visit_descendants(|item| {
            if item.is_visible()
                && item
                    .accessible_string_property(AccessibleStringProperty::Label)
                    .as_deref()
                    == Some(NAME)
            {
                ControlFlow::Break(item.clone())
            } else {
                ControlFlow::Continue(())
            }
        })
        .expect("the synthetic author is visible")
}

fn hover(window: &YapfastWindow) -> slint::LogicalPosition {
    let item = name_item(window);
    let at = item.map_to_window(item.geometry().center());
    let position = slint::LogicalPosition::new(at.x, at.y);
    window
        .window()
        .dispatch_event(WindowEvent::PointerMoved { position });
    position
}

fn settle(window: &YapfastWindow) {
    for _ in 0..3 {
        let _ = advance(window, 500);
    }
}

fn name_pixels(
    window: &YapfastWindow,
    frame: &slint::SharedPixelBuffer<slint::Rgba8Pixel>,
) -> Vec<u8> {
    let item = name_item(window);
    let geometry = item.geometry();
    let at = item.map_to_window(geometry.origin);
    let left = (at.x - 8.).max(0.) as usize;
    let right = (at.x + geometry.width() + 8.).min(frame.width() as f32) as usize;
    let top = (at.y - 12.).max(0.) as usize;
    let bottom = (at.y + geometry.height() + 12.).min(frame.height() as f32) as usize;
    let stride = frame.width() as usize * 4;
    (top..bottom)
        .flat_map(|y| {
            frame.as_bytes()[y * stride + left * 4..y * stride + right * 4]
                .iter()
                .copied()
        })
        .collect()
}

#[test]
fn name_motion_only_runs_for_a_hovered_focused_name_and_obeys_switches() {
    let window = fixture();
    set_effect(&window, 7);
    settle(&window);
    assert!(
        !window.window().has_active_animations(),
        "resting names do not tick"
    );
    hover(&window);
    settle(&window);
    assert!(
        window.window().has_active_animations(),
        "hover starts the shared clock"
    );
    for gate in 0..6 {
        match gate {
            0 => window.global::<Motion>().set_focused(false),
            1 => window.global::<Motion>().set_playing(false),
            2 => window.global::<Motion>().set_never(true),
            3 => window.global::<Looks>().set_moving(false),
            4 => window.global::<Looks>().set_animate_name_styles(false),
            _ => window.global::<Looks>().set_name_styles(false),
        }
        settle(&window);
        assert!(
            !window.window().has_active_animations(),
            "disabled gate {gate} stops redraws"
        );
        window.global::<Motion>().set_focused(true);
        window.global::<Motion>().set_playing(true);
        window.global::<Motion>().set_never(false);
        window.global::<Looks>().set_moving(true);
        window.global::<Looks>().set_animate_name_styles(true);
        window.global::<Looks>().set_name_styles(true);
        settle(&window);
        assert!(
            window.window().has_active_animations(),
            "gate {gate} resumes on hover"
        );
    }
    window.window().dispatch_event(WindowEvent::PointerExited);
    settle(&window);
    assert!(
        !window.window().has_active_animations(),
        "leaving the name releases the clock"
    );
    // A model can retain a styled name while its whole chat surface is hidden.
    hover(&window);
    window.set_workspace(false);
    settle(&window);
    assert!(
        !window.window().has_active_animations(),
        "hidden chat does not keep a name clock alive"
    );
    window.hide().unwrap();
}

#[test]
fn name_motion_changes_pixels_without_changing_metrics_or_taking_profile_clicks() {
    let window = fixture();
    for effect in [3, 4, 5, 7, 8] {
        window.window().dispatch_event(WindowEvent::PointerExited);
        set_effect(&window, effect);
        settle(&window);
        let geometry = name_item(&window).geometry();
        hover(&window);
        settle(&window);
        assert!(
            window.window().has_active_animations(),
            "effect {effect} activates the shared clock"
        );
        let first = name_pixels(&window, &advance(&window, 50));
        let mut changed = false;
        for _ in 0..32 {
            let next = advance(&window, 100);
            changed |= first != name_pixels(&window, &next);
            assert_eq!(
                name_item(&window).geometry(),
                geometry,
                "effect {effect} must not relayout the name"
            );
        }
        assert!(changed, "effect {effect} visibly animates");
        window.window().dispatch_event(WindowEvent::PointerExited);
        settle(&window);
        assert!(
            !window.window().has_active_animations(),
            "effect {effect} returns to rest"
        );
    }
    let opened = Rc::new(Cell::new(false));
    let observed = opened.clone();
    window.on_show_profile(move |person| {
        assert_eq!(person, "motion:person");
        observed.set(true);
    });
    let position = hover(&window);
    let button = PointerEventButton::Left;
    window
        .window()
        .dispatch_event(WindowEvent::PointerPressed { position, button });
    window
        .window()
        .dispatch_event(WindowEvent::PointerReleased { position, button });
    assert!(
        opened.get(),
        "the existing author click still opens the profile"
    );
    window.hide().unwrap();
}
