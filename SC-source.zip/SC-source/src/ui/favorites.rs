//! A bounded, account-isolated collection of channel shortcuts on this device.
//! Discord's incoming Favorites have a separate live read-only view and can
//! be copied into the local collection; no settings are sent back.
use super::*;
use std::{io::Write, path::Path};
use yapfast_ui::{ChannelFavorites, FavoriteChannelRow};

const FILE: &str = "channel-favorites.json";
const MAX_ITEMS: usize = 200;
const MAX_ACCOUNTS: usize = 8;
const MAX_FILE: u64 = 4 * 1024 * 1024;
pub(super) const MENU_TOGGLE: &str = "sc:channel-favorite";

fn yes() -> bool {
    true
}

#[derive(Clone, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(default)]
struct Entry {
    id: String,
    name: String,
    category: bool,
    parent: String,
    collapsed: bool,
}

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(default)]
struct Collection {
    account: String,
    #[serde(default = "yes")]
    enabled: bool,
    visibility_set: bool,
    imported: bool,
    entries: Vec<Entry>,
}

impl Default for Collection {
    fn default() -> Self {
        Self {
            account: String::new(),
            enabled: true,
            visibility_set: false,
            imported: false,
            entries: Vec::new(),
        }
    }
}

#[derive(Default, serde::Serialize, serde::Deserialize)]
#[serde(default)]
struct Saved {
    accounts: Vec<Collection>,
}

fn account_valid(account: &str) -> bool {
    !account.is_empty() && account.len() <= 20 && account.bytes().all(|byte| byte.is_ascii_digit())
}

fn label(text: &str) -> String {
    text.trim()
        .chars()
        .filter(|ch| !ch.is_control())
        .take(128)
        .collect()
}

fn key(room: &str) -> Option<String> {
    if room.is_empty() || room.len() > 256 || room.chars().any(char::is_control) {
        return None;
    }
    if room.starts_with("discord:") {
        let id = room.rsplit(':').next()?;
        if id.is_empty() || id.len() > 20 || !id.bytes().all(|byte| byte.is_ascii_digit()) {
            return None;
        }
        return Some(format!("discord:{id}"));
    }
    Some(room.to_owned())
}

impl Collection {
    fn tidy(&mut self) {
        let mut seen = HashSet::new();
        self.entries.retain_mut(|entry| {
            if seen.len() >= MAX_ITEMS
                || entry.id.is_empty()
                || entry.id.len() > 256
                || entry.id.chars().any(char::is_control)
                || !seen.insert(entry.id.clone())
            {
                return false;
            }
            entry.name = label(&entry.name);
            if entry.category {
                entry.parent.clear();
                if entry.name.is_empty() {
                    entry.name = "Category".into();
                }
            }
            true
        });
        let categories: HashSet<_> = self
            .entries
            .iter()
            .filter(|entry| entry.category)
            .map(|entry| entry.id.clone())
            .collect();
        for entry in &mut self.entries {
            if !categories.contains(&entry.parent) {
                entry.parent.clear();
            }
        }
    }

    fn contains(&self, id: &str) -> bool {
        self.entries
            .iter()
            .any(|entry| !entry.category && entry.id == id)
    }

    fn remove(&mut self, id: &str) {
        self.entries.retain(|entry| entry.id != id);
        // Removing a heading never removes the conversations under it.
        for entry in &mut self.entries {
            if entry.parent == id {
                entry.parent.clear();
            }
        }
    }

    fn add(&mut self, id: String) -> Result<(), &'static str> {
        if self.contains(&id) {
            return Ok(());
        }
        if self.entries.len() >= MAX_ITEMS {
            return Err("Favorites can contain 200 channels and categories. Remove one first.");
        }
        self.entries.push(Entry {
            id,
            ..Entry::default()
        });
        Ok(())
    }

    fn category(&mut self, id: &str, name: &str) -> Result<(), &'static str> {
        let name = label(name);
        if name.is_empty() {
            return Err("Give the category a name.");
        }
        if !id.is_empty() {
            if let Some(entry) = self
                .entries
                .iter_mut()
                .find(|entry| entry.category && entry.id == id)
            {
                entry.name = name;
            }
            return Ok(());
        }
        if self.entries.len() >= MAX_ITEMS {
            return Err("Favorites can contain 200 channels and categories. Remove one first.");
        }
        let id = (1..=MAX_ITEMS + 1)
            .map(|number| format!("category:local:{number}"))
            .find(|id| !self.entries.iter().any(|entry| &entry.id == id))
            .unwrap();
        self.entries.push(Entry {
            id,
            name,
            category: true,
            ..Entry::default()
        });
        Ok(())
    }

    fn move_to(&mut self, id: &str, parent: &str) {
        if !parent.is_empty()
            && !self
                .entries
                .iter()
                .any(|entry| entry.category && entry.id == parent)
        {
            return;
        }
        if let Some(entry) = self
            .entries
            .iter_mut()
            .find(|entry| !entry.category && entry.id == id)
        {
            entry.parent = parent.to_owned();
        }
    }

    fn reorder(&mut self, id: &str, direction: i32) {
        let Some(index) = self.entries.iter().position(|entry| entry.id == id) else {
            return;
        };
        let entry = &self.entries[index];
        let peers: Vec<_> = self
            .entries
            .iter()
            .enumerate()
            .filter(|(_, other)| other.category == entry.category && other.parent == entry.parent)
            .map(|(at, _)| at)
            .collect();
        let Some(at) = peers.iter().position(|other| *other == index) else {
            return;
        };
        let next = at as isize + direction.signum() as isize;
        if next >= 0 && (next as usize) < peers.len() {
            self.entries.swap(index, peers[next as usize]);
        }
    }

    #[cfg(feature = "discord")]
    fn import(&mut self, cloud: &yapfast_core::yapfast_discord::favorites::Favorites) -> usize {
        use yapfast_core::yapfast_discord::favorites::FavoriteKind;
        let mut incoming: Vec<_> = cloud.channels.iter().collect();
        incoming.sort_by_key(|entry| entry.position);
        let before = self.entries.len();
        // Categories first so a partial merge at the cap cannot orphan a child.
        for category in [true, false] {
            for item in incoming
                .iter()
                .filter(|item| (item.kind == FavoriteKind::Category) == category)
            {
                let id = if category {
                    format!("category:discord:{}", item.id)
                } else {
                    format!("discord:{}", item.id)
                };
                if self.entries.len() >= MAX_ITEMS {
                    break;
                }
                if self.entries.iter().any(|entry| entry.id == id) {
                    continue;
                }
                self.entries.push(Entry {
                    id,
                    name: label(&item.nickname),
                    category,
                    parent: if item.parent.is_empty() || item.parent == "0" {
                        String::new()
                    } else {
                        format!("category:discord:{}", item.parent)
                    },
                    collapsed: item.collapsed,
                });
            }
        }
        if !self.imported && !self.visibility_set {
            if let Some(visible) = cloud.visible {
                self.enabled = visible;
            }
        }
        self.imported = true;
        self.tidy();
        self.entries.len().saturating_sub(before)
    }
}

impl Saved {
    fn tidy(&mut self) {
        let mut seen = HashSet::new();
        self.accounts.reverse();
        self.accounts.retain_mut(|collection| {
            if seen.len() >= MAX_ACCOUNTS
                || !account_valid(&collection.account)
                || !seen.insert(collection.account.clone())
            {
                return false;
            }
            collection.tidy();
            true
        });
        self.accounts.reverse();
    }

    fn read(root: &Path) -> Self {
        let path = root.join(FILE);
        let mut saved = std::fs::metadata(&path)
            .ok()
            .filter(|metadata| metadata.len() <= MAX_FILE)
            .and_then(|_| std::fs::read(path).ok())
            .and_then(|bytes| serde_json::from_slice::<Self>(&bytes).ok())
            .unwrap_or_default();
        saved.tidy();
        saved
    }

    fn write(&self, root: &Path) -> std::io::Result<()> {
        std::fs::create_dir_all(root)?;
        let mut file = tempfile::NamedTempFile::new_in(root)?;
        serde_json::to_writer(&mut file, self)?;
        file.flush()?;
        file.as_file().sync_all()?;
        file.persist(root.join(FILE)).map_err(|error| error.error)?;
        Ok(())
    }
}

#[derive(Default)]
pub(super) struct Favorites {
    loaded: bool,
    saved: Saved,
    account: Option<String>,
    preview: Collection,
    // View-only expansion choices; never written to either settings store.
    cloud_collapsed: HashMap<String, bool>,
}

impl Favorites {
    fn activate(&mut self, state: &AppState, root: &Path) -> bool {
        if !self.loaded {
            self.saved = Saved::read(root);
            self.loaded = true;
        }
        let account = if state.preview {
            Some("preview".to_owned())
        } else {
            state
                .discord_user
                .as_deref()
                .filter(|id| account_valid(id))
                .map(str::to_owned)
        };
        if self.account == account {
            return false;
        }
        self.account = account;
        self.cloud_collapsed.clear();
        if let Some(account) = self.account.as_ref().filter(|id| id.as_str() != "preview") {
            if !self
                .saved
                .accounts
                .iter()
                .any(|collection| &collection.account == account)
            {
                if self.saved.accounts.len() >= MAX_ACCOUNTS {
                    self.saved.accounts.remove(0);
                }
                self.saved.accounts.push(Collection {
                    account: account.clone(),
                    ..Collection::default()
                });
            }
        }
        true
    }

    fn current(&self) -> Option<&Collection> {
        let account = self.account.as_deref()?;
        if account == "preview" {
            Some(&self.preview)
        } else {
            self.saved
                .accounts
                .iter()
                .find(|collection| collection.account == account)
        }
    }

    fn current_mut(&mut self) -> Option<&mut Collection> {
        let account = self.account.as_deref()?;
        if account == "preview" {
            Some(&mut self.preview)
        } else {
            self.saved
                .accounts
                .iter_mut()
                .find(|collection| collection.account == account)
        }
    }

    fn write(&self, root: &Path) -> Result<(), &'static str> {
        if self.account.as_deref() == Some("preview") {
            return Ok(());
        }
        self.saved.write(root).map_err(|error| {
            tracing::warn!(%error, "could not save channel favorites");
            "Favorites could not be saved on this device."
        })
    }
}

fn eligible(room: &yapfast_core::chat::ChatRoom) -> bool {
    !room.locked
}

fn resolve<'a>(state: &'a AppState, id: &str) -> Option<&'a yapfast_core::chat::ChatRoom> {
    state
        .rooms
        .iter()
        .find(|room| key(&room.id).as_deref() == Some(id) && eligible(room))
        .map(|room| &**room)
}

impl Adapter {
    /// Identity changes clear the pane before drawing any incoming account.
    pub(super) fn sync_channel_favorites(&mut self, window: &YapfastWindow) {
        let changed = self.favorites.activate(&self.app.state, &self.root);
        let favorites = window.global::<ChannelFavorites>();
        if changed {
            favorites.set_showing(false);
            favorites.set_status(SharedString::default());
            favorites.set_category_editing(false);
            favorites.set_category_key(SharedString::default());
            favorites.set_category_name(SharedString::default());
            favorites.set_menu(ModelRc::default());
            favorites.set_count(0);
            favorites.set_imported(false);
            favorites.set_cloud_view(false);
        }
        #[cfg(feature = "discord")]
        if !self.app.state.preview
            && let Some(cloud) = self.app.state.discord_channel_favorites.as_ref()
            && self
                .favorites
                .current()
                .is_some_and(|collection| !collection.imported)
        {
            self.favorites.current_mut().unwrap().import(cloud);
            if let Err(message) = self.favorites.write(&self.root) {
                favorites.set_status(message.into());
            }
        }
        self.show_channel_favorites(window);
    }

    fn show_channel_favorites(&self, window: &YapfastWindow) {
        let favorites = window.global::<ChannelFavorites>();
        let local = self.favorites.current();
        favorites.set_active(local.is_some());
        favorites.set_enabled(local.is_some_and(|collection| collection.enabled));
        #[cfg(feature = "discord")]
        favorites.set_has_cloud(
            !self.app.state.preview && self.app.state.discord_channel_favorites.is_some(),
        );
        #[cfg(not(feature = "discord"))]
        favorites.set_has_cloud(false);
        if !favorites.get_enabled() {
            favorites.set_showing(false);
        }
        if !favorites.get_showing() {
            favorites.set_rows(ModelRc::default());
            return;
        }
        // This view is rebuilt from the already received bounded snapshot.
        // Deletions, renames and ordering changes therefore appear immediately,
        // without guessing how to merge them into an independently edited list.
        #[cfg(feature = "discord")]
        let cloud = favorites
            .get_cloud_view()
            .then(|| {
                self.app
                    .state
                    .discord_channel_favorites
                    .as_ref()
                    .map(|source| {
                        let mut collection = Collection::default();
                        collection.import(source);
                        for entry in &mut collection.entries {
                            if entry.category
                                && let Some(collapsed) =
                                    self.favorites.cloud_collapsed.get(&entry.id)
                            {
                                entry.collapsed = *collapsed;
                            }
                        }
                        collection
                    })
            })
            .flatten();
        #[cfg(not(feature = "discord"))]
        let cloud: Option<Collection> = None;
        let collection = if favorites.get_cloud_view() {
            cloud.as_ref()
        } else {
            local
        };
        let Some(collection) = collection else {
            favorites.set_rows(ModelRc::default());
            favorites.set_count(0);
            return;
        };
        let state = &self.app.state;
        // Only the at-most-200 requested rooms are indexed, never copied room histories.
        let wanted: HashSet<_> = collection
            .entries
            .iter()
            .filter(|entry| !entry.category)
            .map(|entry| entry.id.as_str())
            .collect();
        let rooms: HashMap<_, _> = state
            .rooms
            .iter()
            .filter(|room| eligible(room))
            .filter_map(|room| {
                let id = key(&room.id)?;
                wanted.contains(id.as_str()).then_some((id, &**room))
            })
            .collect();
        let row = |entry: &Entry| {
            let room = rooms.get(&entry.id).copied();
            let available = room.is_some();
            let title = if entry.category {
                entry.name.as_str()
            } else if !available {
                "Unavailable channel"
            } else if !entry.name.is_empty() {
                &entry.name
            } else {
                &room.unwrap().name
            };
            let subtitle = room.map_or("You may no longer have access", |room| {
                if room.direct {
                    if room.person.is_some() {
                        "Direct message"
                    } else {
                        "Group DM"
                    }
                } else {
                    room.id
                        .rsplit_once(':')
                        .and_then(|(id, _)| state.servers.iter().find(|server| server.id == id))
                        .map_or("Channel", |server| server.name.as_str())
                }
            });
            FavoriteChannelRow {
                key: entry.id.as_str().into(),
                title: title.into(),
                subtitle: if entry.category {
                    String::new().into()
                } else {
                    subtitle.into()
                },
                category: entry.category,
                collapsed: entry.collapsed,
                available,
                selected: room
                    .is_some_and(|room| state.selected.as_deref() == Some(room.id.as_str())),
                direct: room.is_some_and(|room| room.direct),
                voice: room.is_some_and(|room| room.voice),
                forum: room.is_some_and(|room| room.forum),
                initial: initial(title),
                picture_url: room
                    .filter(|room| room.direct)
                    .and_then(|room| room.avatar.as_deref())
                    .unwrap_or_default()
                    .into(),
                unread: room.is_some_and(|room| room.unread > 0),
                badge: room.map_or_else(SharedString::default, |room| count_badge(room.mentions)),
            }
        };
        let mut rows = Vec::with_capacity(collection.entries.len());
        rows.extend(
            collection
                .entries
                .iter()
                .filter(|entry| !entry.category && entry.parent.is_empty())
                .map(row),
        );
        for category in collection.entries.iter().filter(|entry| entry.category) {
            rows.push(row(category));
            if !category.collapsed {
                rows.extend(
                    collection
                        .entries
                        .iter()
                        .filter(|entry| !entry.category && entry.parent == category.id)
                        .map(row),
                );
            }
        }
        favorites.set_count(collection.entries.len() as i32);
        favorites.set_imported(collection.imported);
        let existing = favorites.get_rows();
        if existing.row_count() != rows.len() || existing.iter().zip(&rows).any(|(a, b)| &a != b) {
            favorites.set_rows(ModelRc::new(VecModel::from(rows)));
        }
    }

    pub(super) fn channel_favorite_menu(&self, room: &str) -> Option<MenuRow> {
        let collection = self.favorites.current()?;
        let room = self
            .app
            .state
            .rooms
            .iter()
            .find(|found| found.id == room && eligible(found))?;
        let id = key(&room.id)?;
        Some(MenuRow {
            id: MENU_TOGGLE.into(),
            text: if collection.contains(&id) {
                "Remove from Favorites"
            } else {
                "Add to Favorites"
            }
            .into(),
            plain: true,
            ..Default::default()
        })
    }

    pub(super) fn toggle_channel_favorite(&mut self, window: &YapfastWindow, room: &str) {
        self.favorites.activate(&self.app.state, &self.root);
        let Some(room) = self
            .app
            .state
            .rooms
            .iter()
            .find(|found| found.id == room && eligible(found))
        else {
            return;
        };
        let Some(id) = key(&room.id) else { return };
        let Some(collection) = self.favorites.current_mut() else {
            return;
        };
        let result = if collection.contains(&id) {
            collection.remove(&id);
            Ok(())
        } else {
            collection.add(id)
        };
        self.favorite_result(window, result);
    }

    fn favorite_result(&self, window: &YapfastWindow, result: Result<(), &'static str>) {
        let result = result.and_then(|()| self.favorites.write(&self.root));
        window
            .global::<ChannelFavorites>()
            .set_status(result.err().unwrap_or("").into());
        if let Err(message) = result {
            window.set_notice(message.into());
        }
        self.show_channel_favorites(window);
    }

    fn favorite_menu(&self, window: &YapfastWindow, key: &str) {
        let Some(collection) = self.favorites.current() else {
            return;
        };
        let Some(entry) = collection.entries.iter().find(|entry| entry.id == key) else {
            return;
        };
        let menu = |id: String, text: String| MenuRow {
            id: id.into(),
            text: text.into(),
            plain: true,
            ..Default::default()
        };
        let mut rows = vec![
            menu(
                "remove".into(),
                if entry.category {
                    "Remove category (keep channels)"
                } else {
                    "Remove from Favorites"
                }
                .into(),
            ),
            menu("up".into(), "Move up".into()),
            menu("down".into(), "Move down".into()),
        ];
        if entry.category {
            rows.push(menu("rename".into(), "Rename category".into()));
        } else {
            rows.push(menu("move:".into(), "Move to Uncategorized".into()));
            rows.extend(
                collection
                    .entries
                    .iter()
                    .filter(|entry| entry.category)
                    .map(|category| {
                        menu(
                            format!("move:{}", category.id),
                            format!("Move to {}", category.name),
                        )
                    }),
            );
        }
        window
            .global::<ChannelFavorites>()
            .set_menu(ModelRc::new(VecModel::from(rows)));
    }
}

pub(super) fn bind(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    macro_rules! bind {
        ($method:ident, |$state:ident, $window:ident $(, $arg:ident)*| $body:block) => {{
            let adapter = Rc::downgrade(adapter);
            let weak = window.as_weak();
            window.global::<ChannelFavorites>().$method(move |$($arg),*| {
                let (Some(adapter), Some($window)) = (adapter.upgrade(), weak.upgrade()) else { return };
                let mut $state = adapter.borrow_mut();
                $body
            });
        }};
    }
    bind!(on_open, |state, window| {
        state.sync_channel_favorites(&window);
        if window.global::<ChannelFavorites>().get_enabled() {
            window.global::<ChannelFavorites>().set_showing(true);
        }
        state.show_channel_favorites(&window);
    });
    bind!(on_close, |state, window| {
        window.global::<ChannelFavorites>().set_showing(false);
        state.show_channel_favorites(&window);
    });
    bind!(on_set_cloud_view, |state, window, from_discord| {
        state.sync_channel_favorites(&window);
        let favorites = window.global::<ChannelFavorites>();
        favorites.set_cloud_view(from_discord && favorites.get_has_cloud());
        favorites.set_status(SharedString::default());
        favorites.set_category_editing(false);
        favorites.set_category_key(SharedString::default());
        favorites.set_category_name(SharedString::default());
        favorites.set_menu(ModelRc::default());
        state.show_channel_favorites(&window);
    });
    bind!(on_set_enabled, |state, window, enabled| {
        state.sync_channel_favorites(&window);
        if let Some(collection) = state.favorites.current_mut() {
            collection.enabled = enabled;
            collection.visibility_set = true;
        }
        state.favorite_result(&window, Ok(()));
    });
    bind!(on_select, |state, window, id| {
        if let Some(room) = resolve(&state.app.state, &id).map(|room| room.id.clone()) {
            state.action(&window, Action::SelectRoom(room));
        } else {
            window
                .global::<ChannelFavorites>()
                .set_status("This channel is no longer available.".into());
        }
    });
    bind!(on_collapse, |state, window, id| {
        if window.global::<ChannelFavorites>().get_cloud_view() {
            #[cfg(feature = "discord")]
            if let Some(initially_collapsed) = state
                .app
                .state
                .discord_channel_favorites
                .as_ref()
                .and_then(|cloud| {
                    cloud.channels.iter().find(|entry| {
                        entry.kind
                            == yapfast_core::yapfast_discord::favorites::FavoriteKind::Category
                            && format!("category:discord:{}", entry.id) == id.as_str()
                    })
                })
                .map(|entry| entry.collapsed)
            {
                let overrides = &mut state.favorites.cloud_collapsed;
                let collapsed = overrides
                    .get(id.as_str())
                    .copied()
                    .unwrap_or(initially_collapsed);
                if overrides.len() >= MAX_ITEMS && !overrides.contains_key(id.as_str()) {
                    overrides.clear();
                }
                overrides.insert(id.to_string(), !collapsed);
            }
            state.show_channel_favorites(&window);
            return;
        }
        if let Some(collection) = state.favorites.current_mut()
            && let Some(entry) = collection
                .entries
                .iter_mut()
                .find(|entry| entry.category && entry.id == id.as_str())
        {
            entry.collapsed = !entry.collapsed;
        }
        state.favorite_result(&window, Ok(()));
    });
    bind!(on_prepare_menu, |state, window, id| {
        if window.global::<ChannelFavorites>().get_cloud_view() {
            return;
        }
        state.favorite_menu(&window, &id);
    });
    bind!(on_menu_choice, |state, window, id, action| {
        if window.global::<ChannelFavorites>().get_cloud_view() {
            return;
        }
        if action == "rename" {
            if let Some(entry) = state.favorites.current().and_then(|collection| {
                collection
                    .entries
                    .iter()
                    .find(|entry| entry.id == id.as_str())
            }) {
                let favorites = window.global::<ChannelFavorites>();
                favorites.set_category_key(id);
                favorites.set_category_name(entry.name.as_str().into());
                favorites.set_category_editing(true);
            }
            return;
        }
        if let Some(collection) = state.favorites.current_mut() {
            if action == "remove" {
                collection.remove(&id);
            } else if action == "up" {
                collection.reorder(&id, -1);
            } else if action == "down" {
                collection.reorder(&id, 1);
            } else if let Some(parent) = action.strip_prefix("move:") {
                collection.move_to(&id, parent);
            }
        }
        state.favorite_result(&window, Ok(()));
    });
    bind!(on_save_category, |state, window, id, name| {
        if window.global::<ChannelFavorites>().get_cloud_view() {
            return;
        }
        let result = state
            .favorites
            .current_mut()
            .map_or(Err("Sign in to keep Favorites."), |collection| {
                collection.category(&id, &name)
            });
        if result.is_ok() {
            window
                .global::<ChannelFavorites>()
                .set_category_editing(false);
        }
        state.favorite_result(&window, result);
    });
    bind!(on_import_cloud, |state, window| {
        #[cfg(feature = "discord")]
        if let Some(cloud) = state.app.state.discord_channel_favorites.clone()
            && let Some(collection) = state.favorites.current_mut()
        {
            let count = collection.import(&cloud);
            window.global::<ChannelFavorites>().set_cloud_view(false);
            state.favorite_result(&window, Ok(()));
            if window.global::<ChannelFavorites>().get_status().is_empty() {
                window.global::<ChannelFavorites>().set_status(
                    format!("Copied {count} new items to this device. Existing local names and categories were kept.").into(),
                );
            }
        }
    });
}

#[cfg(test)]
mod tests {
    use super::*;
    use yapfast_core::chat::ChatRoom;

    #[cfg(feature = "discord")]
    #[test]
    fn channel_favorites_live_discord_view_updates_without_changing_local_edits() {
        use yapfast_core::yapfast_discord::favorites::{
            FavoriteChannel, FavoriteKind, Favorites as Cloud,
        };
        i_slint_backend_testing::init_no_event_loop();
        let directory = tempfile::tempdir().unwrap();
        let window = YapfastWindow::new().unwrap();
        let adapter = Adapter::new(
            Arc::new(BackgroundRuntime::new().unwrap()),
            directory.path().into(),
            &window,
        )
        .unwrap();
        bind(&window, &adapter);
        let favorites = window.global::<ChannelFavorites>();
        let cloud = |id: &str, nickname: &str| {
            Arc::new(Cloud {
                channels: vec![
                    FavoriteChannel {
                        id: "50".into(),
                        nickname: "Remote category".into(),
                        kind: FavoriteKind::Category,
                        position: 0,
                        parent: String::new(),
                        channel_type: None,
                        collapsed: true,
                    },
                    FavoriteChannel {
                        id: id.into(),
                        nickname: nickname.into(),
                        kind: FavoriteKind::Reference,
                        position: 1,
                        parent: "50".into(),
                        channel_type: Some(0),
                        collapsed: false,
                    },
                ],
                ..Default::default()
            })
        };
        {
            let mut state = adapter.borrow_mut();
            state.app.state.discord_user = Some("1".into());
            state.app.state.rooms = ["21", "22"]
                .into_iter()
                .map(|id| {
                    Arc::new(ChatRoom {
                        id: format!("discord:10:{id}"),
                        name: format!("Room {id}"),
                        ..room_fixture()
                    })
                })
                .collect();
            state.sync_channel_favorites(&window);
            let local = state.favorites.current_mut().unwrap();
            local.imported = true;
            local.add("discord:21".into()).unwrap();
            local.entries[0].name = "My local alias".into();
            state.favorites.write(directory.path()).unwrap();
            state.app.state.discord_channel_favorites = Some(cloud("22", "Remote first"));
            state.sync_channel_favorites(&window);
        }
        let original_file = std::fs::read(directory.path().join(FILE)).unwrap();
        favorites.invoke_open();
        favorites.invoke_set_cloud_view(true);
        assert!(favorites.get_cloud_view());
        assert_eq!(
            favorites.get_rows().row_count(),
            1,
            "remote collapsed category is respected"
        );
        favorites.invoke_collapse("category:discord:50".into());
        assert_eq!(
            favorites.get_rows().row_data(1).unwrap().title,
            "Remote first"
        );
        favorites.invoke_menu_choice("discord:21".into(), "remove".into());
        favorites.invoke_save_category("".into(), "Not allowed in read-only view".into());
        {
            let mut state = adapter.borrow_mut();
            state.app.state.discord_channel_favorites = Some(cloud("21", "Remote changed"));
            state.sync_channel_favorites(&window);
        }
        assert_eq!(
            favorites.get_rows().row_data(1).unwrap().title,
            "Remote changed"
        );
        assert!(
            !favorites
                .get_rows()
                .iter()
                .any(|row| row.key == "discord:22")
        );
        assert_eq!(
            std::fs::read(directory.path().join(FILE)).unwrap(),
            original_file,
            "read sync and view expansion never write local preferences"
        );
        {
            let mut state = adapter.borrow_mut();
            state.app.state.discord_channel_favorites = Some(Arc::new(Cloud::default()));
            state.sync_channel_favorites(&window);
        }
        assert_eq!(
            favorites.get_rows().row_count(),
            0,
            "an explicit empty Discord snapshot clears only its live view"
        );
        favorites.invoke_set_cloud_view(false);
        assert_eq!(
            favorites.get_rows().row_data(0).unwrap().title,
            "My local alias"
        );
        {
            let mut state = adapter.borrow_mut();
            state.app.state.discord_channel_favorites = Some(cloud("22", "Remote copied"));
            state.sync_channel_favorites(&window);
        }
        favorites.invoke_set_cloud_view(true);
        favorites.invoke_import_cloud();
        assert!(
            !favorites.get_cloud_view(),
            "explicit copy returns to editable local collection"
        );
        assert_eq!(
            adapter.borrow().favorites.current().unwrap().entries[0].name,
            "My local alias"
        );
        assert!(
            adapter
                .borrow()
                .favorites
                .current()
                .unwrap()
                .contains("discord:22")
        );
        favorites.invoke_set_cloud_view(true);
        {
            let mut state = adapter.borrow_mut();
            state.app.state.discord_user = Some("2".into());
            state.app.state.discord_channel_favorites = None;
            state.sync_channel_favorites(&window);
            assert!(state.favorites.cloud_collapsed.is_empty());
        }
        assert!(!favorites.get_cloud_view());
        assert!(!favorites.get_showing());
        assert_eq!(favorites.get_rows().row_count(), 0);
        favorites.invoke_open();
        assert_eq!(
            favorites.get_rows().row_count(),
            0,
            "another account cannot inherit either view"
        );
    }

    fn room_fixture() -> ChatRoom {
        let mut app = Application::default();
        // Dispatch creates synthetic data; effects are deliberately not executed.
        app.dispatch(Action::Preview);
        (*app.state.rooms[0]).clone()
    }

    #[test]
    fn channel_favorites_accounts_restart_preview_and_sign_out_are_isolated() {
        let directory = tempfile::tempdir().unwrap();
        let mut favorites = Favorites::default();
        let mut state = AppState::default();
        state.discord_user = Some("1".into());
        assert!(favorites.activate(&state, directory.path()));
        favorites
            .current_mut()
            .unwrap()
            .add("discord:11".into())
            .unwrap();
        favorites.current_mut().unwrap().enabled = false;
        favorites.write(directory.path()).unwrap();
        state.discord_user = Some("2".into());
        favorites.activate(&state, directory.path());
        assert!(favorites.current().unwrap().entries.is_empty());
        assert!(favorites.current().unwrap().enabled);
        favorites
            .current_mut()
            .unwrap()
            .add("discord:22".into())
            .unwrap();
        favorites.write(directory.path()).unwrap();
        state.preview = true;
        favorites.activate(&state, directory.path());
        assert!(favorites.current().unwrap().entries.is_empty());
        favorites
            .current_mut()
            .unwrap()
            .add("preview-room".into())
            .unwrap();
        favorites.write(directory.path()).unwrap();
        let saved = std::fs::read_to_string(directory.path().join(FILE)).unwrap();
        assert!(!saved.contains("preview-room"));
        state.preview = false;
        state.discord_user = None;
        favorites.activate(&state, directory.path());
        assert!(favorites.current().is_none());
        state.discord_user = Some("1".into());
        let mut restarted = Favorites::default();
        restarted.activate(&state, directory.path());
        let kept = restarted.current().unwrap();
        assert!(kept.contains("discord:11"));
        assert!(!kept.contains("discord:22"));
        assert!(!kept.enabled);
    }

    #[test]
    fn channel_favorites_bound_records_accounts_and_category_operations() {
        let mut collection = Collection::default();
        collection.category("", "  Work\n ").unwrap();
        let category = collection.entries[0].id.clone();
        for id in 1..MAX_ITEMS {
            collection.add(format!("discord:{id}")).unwrap();
        }
        assert!(collection.add("discord:9999".into()).is_err());
        assert!(collection.category("", "Overflow").is_err());
        collection.add("discord:1".into()).unwrap();
        assert_eq!(collection.entries.len(), MAX_ITEMS);
        collection.move_to("discord:1", &category);
        collection.move_to("discord:2", &category);
        collection.reorder("discord:2", -1);
        let children: Vec<_> = collection
            .entries
            .iter()
            .filter(|entry| entry.parent == category)
            .map(|entry| entry.id.as_str())
            .collect();
        assert_eq!(children, ["discord:2", "discord:1"]);
        collection.remove(&category);
        assert!(collection.contains("discord:1"));
        assert!(
            collection
                .entries
                .iter()
                .all(|entry| entry.parent.is_empty())
        );
        let mut saved = Saved {
            accounts: (1..=12)
                .map(|id| Collection {
                    account: id.to_string(),
                    entries: collection.entries.clone(),
                    ..Default::default()
                })
                .collect(),
        };
        saved.accounts.push(Collection {
            account: "not-an-account".into(),
            ..Default::default()
        });
        saved.tidy();
        assert_eq!(saved.accounts.len(), MAX_ACCOUNTS);
        assert_eq!(saved.accounts[0].account, "5");
        assert_eq!(saved.accounts.last().unwrap().account, "12");
        let directory = tempfile::tempdir().unwrap();
        saved.write(directory.path()).unwrap();
        assert_eq!(Saved::read(directory.path()).accounts.len(), MAX_ACCOUNTS);
        std::fs::write(directory.path().join(FILE), b"{broken").unwrap();
        assert!(Saved::read(directory.path()).accounts.is_empty());
        let file = std::fs::File::create(directory.path().join(FILE)).unwrap();
        file.set_len(MAX_FILE + 1).unwrap();
        assert!(Saved::read(directory.path()).accounts.is_empty());
    }

    #[cfg(feature = "discord")]
    #[test]
    fn channel_favorites_import_merges_categories_without_overwriting_local_edits() {
        use yapfast_discord::favorites::{FavoriteChannel, FavoriteKind, Favorites as Cloud};
        let item = |id: &str, nickname: &str, kind, parent: &str, position| FavoriteChannel {
            id: id.into(),
            nickname: nickname.into(),
            kind,
            parent: parent.into(),
            position,
            channel_type: None,
            collapsed: false,
        };
        let mut cloud = Cloud {
            channels: vec![
                item("21", "general", FavoriteKind::Reference, "50", 1),
                item("50", "Work", FavoriteKind::Category, "0", 0),
                item("22", "DM", FavoriteKind::Reference, "0", 2),
            ],
            visible: Some(false),
            muted: false,
        };
        let mut collection = Collection::default();
        collection.add(key("discord:10:21").unwrap()).unwrap();
        assert_eq!(collection.import(&cloud), 2);
        assert_eq!(collection.entries.len(), 3);
        assert!(!collection.enabled);
        collection
            .category("category:discord:50", "My category")
            .unwrap();
        collection.move_to("discord:22", "category:discord:50");
        collection.enabled = true;
        assert_eq!(collection.import(&cloud), 0);
        assert!(
            collection.enabled,
            "re-import must not reset local visibility"
        );
        assert_eq!(
            collection
                .entries
                .iter()
                .find(|entry| entry.category)
                .unwrap()
                .name,
            "My category"
        );
        assert_eq!(
            collection
                .entries
                .iter()
                .find(|entry| entry.id == "discord:22")
                .unwrap()
                .parent,
            "category:discord:50"
        );
        cloud
            .channels
            .push(item("23", "new", FavoriteKind::Reference, "50", 3));
        assert_eq!(
            collection.import(&cloud),
            1,
            "new cloud entries remain importable later"
        );
        assert_eq!(
            collection
                .entries
                .iter()
                .find(|entry| entry.id == "discord:23")
                .unwrap()
                .parent,
            "category:discord:50"
        );
        assert_eq!(collection.import(&Cloud::default()), 0);
        assert!(
            collection.contains("discord:23"),
            "empty cloud import must not delete local edits"
        );
        for id in 100..400 {
            cloud.channels.push(item(
                &id.to_string(),
                "bounded",
                FavoriteKind::Reference,
                "0",
                id,
            ));
        }
        collection.import(&cloud);
        assert_eq!(collection.entries.len(), MAX_ITEMS);
    }

    #[test]
    fn channel_favorites_current_permissions_control_resolution() {
        let mut state = AppState::default();
        state.rooms = vec![
            Arc::new(ChatRoom {
                id: "discord:10:21".into(),
                name: "visible".into(),
                ..room_fixture()
            }),
            Arc::new(ChatRoom {
                id: "discord:10:22".into(),
                locked: true,
                ..room_fixture()
            }),
            Arc::new(ChatRoom {
                id: "discord:10:23".into(),
                parent: Some("discord:10:21".into()),
                ..room_fixture()
            }),
        ];
        assert_eq!(resolve(&state, "discord:21").unwrap().id, "discord:10:21");
        assert!(resolve(&state, "discord:22").is_none());
        assert_eq!(resolve(&state, "discord:23").unwrap().id, "discord:10:23");
        assert!(resolve(&state, "discord:24").is_none());
        Arc::make_mut(&mut state.rooms[0]).locked = true;
        assert!(
            resolve(&state, "discord:21").is_none(),
            "saved shortcut never grants access"
        );
        assert!(key("discord:10:not-a-channel").is_none());
    }

    #[test]
    fn channel_favorites_threads_follow_current_access_and_keep_local_removal() {
        let mut state = AppState::default();
        state.rooms = vec![Arc::new(ChatRoom {
            id: "discord:10:30".into(),
            parent: Some("discord:10:21".into()),
            ..room_fixture()
        })];
        let mut collection = Collection::default();
        collection.add(key(&state.rooms[0].id).unwrap()).unwrap();
        assert!(collection.contains("discord:30"));
        assert!(resolve(&state, "discord:30").is_some());
        Arc::make_mut(&mut state.rooms[0]).locked = true;
        assert!(
            resolve(&state, "discord:30").is_none(),
            "favorite never grants private-thread access"
        );
        Arc::make_mut(&mut state.rooms[0]).locked = false;
        collection.remove("discord:30");
        assert!(!collection.contains("discord:30"));
        state.rooms.clear();
        assert!(
            resolve(&state, "discord:30").is_none(),
            "unknown or deleted thread stays unresolved"
        );
    }

    #[test]
    fn channel_favorites_callbacks_hide_stale_account_editor_and_preserve_hidden_items() {
        i_slint_backend_testing::init_no_event_loop();
        let directory = tempfile::tempdir().unwrap();
        let window = YapfastWindow::new().unwrap();
        let adapter = Adapter::new(
            Arc::new(BackgroundRuntime::new().unwrap()),
            directory.path().into(),
            &window,
        )
        .unwrap();
        bind(&window, &adapter);
        let favorites = window.global::<ChannelFavorites>();
        {
            let mut state = adapter.borrow_mut();
            state.app.state.discord_user = Some("1".into());
            state.app.state.rooms = vec![Arc::new(ChatRoom {
                id: "discord:10:21".into(),
                name: "Private project".into(),
                ..room_fixture()
            })];
            state.sync_channel_favorites(&window);
            let (rows, submenus) = super::super::menus::menu(&state, "discord:10:21", false);
            assert!(
                rows.iter()
                    .any(|row| row.id == MENU_TOGGLE && row.text == "Add to Favorites")
            );
            assert!(submenus.is_empty() || rows.len() == submenus.len());
            super::super::menus::choose(
                &mut state,
                &window,
                "discord:10:21".into(),
                false,
                MENU_TOGGLE,
            );
            assert!(
                super::super::menus::menu(&state, "discord:10:21", false)
                    .0
                    .iter()
                    .any(|row| row.id == MENU_TOGGLE && row.text == "Remove from Favorites")
            );
        }
        favorites.invoke_open();
        assert_eq!(favorites.get_rows().row_count(), 1);
        assert_eq!(
            favorites.get_rows().row_data(0).unwrap().title,
            "Private project"
        );
        favorites.invoke_set_enabled(false);
        assert!(!favorites.get_showing());
        assert_eq!(favorites.get_rows().row_count(), 0);
        favorites.invoke_set_enabled(true);
        favorites.invoke_open();
        assert_eq!(
            favorites.get_rows().row_count(),
            1,
            "hide preserves shortcuts"
        );
        favorites.invoke_save_category("".into(), "Account A category".into());
        let category = adapter
            .borrow()
            .favorites
            .current()
            .unwrap()
            .entries
            .iter()
            .find(|entry| entry.category)
            .unwrap()
            .id
            .clone();
        favorites.invoke_menu_choice(category.into(), "rename".into());
        assert!(favorites.get_category_editing());
        {
            let mut state = adapter.borrow_mut();
            state.app.state.discord_user = Some("2".into());
            state.app.state.rooms.clear();
            state.sync_channel_favorites(&window);
        }
        assert!(!favorites.get_showing());
        assert!(!favorites.get_category_editing());
        assert!(
            favorites.get_category_key().is_empty() && favorites.get_category_name().is_empty()
        );
        assert_eq!(favorites.get_menu().row_count(), 0);
        assert_eq!(favorites.get_count(), 0);
        favorites.invoke_open();
        assert_eq!(favorites.get_rows().row_count(), 0);
        assert!(
            !std::fs::read_to_string(directory.path().join(FILE))
                .unwrap()
                .contains("Private project"),
            "ordinary channel names are never persisted"
        );
        {
            let mut state = adapter.borrow_mut();
            state.app.state.discord_user = Some("1".into());
            state.app.state.rooms = vec![Arc::new(ChatRoom {
                id: "discord:10:21".into(),
                name: "Private project".into(),
                locked: true,
                ..room_fixture()
            })];
            state.sync_channel_favorites(&window);
        }
        favorites.invoke_open();
        let unavailable = favorites.get_rows().row_data(0).unwrap();
        assert!(!unavailable.available);
        assert_eq!(unavailable.title, "Unavailable channel");
        favorites.invoke_select("discord:21".into());
        assert!(adapter.borrow().app.state.selected.is_none());
        assert!(favorites.get_status().contains("no longer available"));
        favorites.invoke_close();
        assert_eq!(
            favorites.get_rows().row_count(),
            0,
            "hidden collection holds no rendered rows"
        );
    }
}
