//! The message menu's saved-message actions and the Inbox Bookmarks tab.

use super::*;
use yapfast_core::application::SavedMessageKind;

#[derive(Default)]
pub(super) struct State {
    menu_item: String,
    reminder: Option<Reminder>,
}

struct Reminder {
    account: String,
    target: ReminderTarget,
}

enum ReminderTarget {
    Timeline { room: String, item: String },
    Inbox { channel: String, message: String },
}

pub(super) fn bind(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    let shown = window.global::<MessageSaves>();
    let state = adapter.clone();
    let weak = window.as_weak();
    shown.on_prepare_menu(move |item| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        adapter.message_saves.menu_item = item.to_string();
        let app = &adapter.app.state;
        if app
            .message_save_state(&item)
            .is_some_and(|save| save.eligible)
            && !app.saved_messages().loaded
            && !app.saved_messages().loading
            && app.saved_messages().error.is_none()
        {
            adapter.action(&window, Action::LoadSavedMessages);
        } else {
            show(&mut adapter, &window);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    shown.on_menu_choice(move |item, choice| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        let app = &adapter.app.state;
        let Some(save) = app
            .message_save_state(&item)
            .filter(|save| save.eligible && !save.busy && app.saved_messages().loaded)
        else {
            return;
        };
        let item = item.to_string();
        match (choice, save.kind) {
            (0, None) => adapter.action(&window, Action::BookmarkMessage(item)),
            (0, Some(SavedMessageKind::Bookmark)) | (2, Some(SavedMessageKind::Reminder)) => {
                adapter.action(&window, Action::RemoveSavedMessage(item))
            }
            (1, kind) => {
                let Some(room) = app.room_of(&item).cloned() else {
                    return;
                };
                let target = ReminderTarget::Timeline { room, item };
                open_reminder(
                    &mut adapter,
                    &window,
                    target,
                    kind == Some(SavedMessageKind::Reminder),
                );
            }
            _ => {}
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    shown.on_jump(move |channel, message| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        let Some(entry) = listed(&adapter.app.state, &channel, &message) else {
            return;
        };
        let room = discord::room_id(
            entry.guild.as_deref().unwrap_or(discord::DM_GUILD),
            &channel,
        );
        window.set_inbox_open(false);
        adapter.action(
            &window,
            Action::JumpInRoom {
                room,
                item: format!("d:{message}"),
            },
        );
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    shown.on_choose_reminder(move |channel, message| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        let Some(entry) = listed(&adapter.app.state, &channel, &message) else {
            return;
        };
        let changing = entry.due_at.is_some();
        let target = ReminderTarget::Inbox {
            channel: channel.to_string(),
            message: message.to_string(),
        };
        open_reminder(&mut adapter, &window, target, changing);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    shown.on_remove(move |channel, message| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        if listed(&adapter.app.state, &channel, &message).is_some() {
            adapter.action(
                &window,
                Action::RemoveListedSavedMessage {
                    channel: channel.into(),
                    message: message.into(),
                },
            );
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    shown.on_load(move || {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        let saved = adapter.app.state.saved_messages();
        let action = if saved.loaded && saved.has_more {
            Action::MoreMessageBookmarks
        } else {
            Action::LoadSavedMessages
        };
        adapter.action(&window, action);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    shown.on_more(move || {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::MoreMessageBookmarks);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    shown.on_pick_delay(move |choice| {
        let Some(window) = weak.upgrade() else { return };
        let minutes = match choice.as_str() {
            "30" => 30,
            "60" => 60,
            "240" => 240,
            "1440" => 1_440,
            "10080" => 10_080,
            _ => return,
        };
        let mut adapter = state.borrow_mut();
        let Some(reminder) = adapter.message_saves.reminder.take() else {
            return;
        };
        window.global::<MessageSaves>().set_reminder_open(false);
        if !valid_reminder(&adapter.app.state, &reminder) {
            return;
        }
        let due_at_ms = clock::now_ms().saturating_add(minutes * 60_000);
        let action = match reminder.target {
            ReminderTarget::Timeline { item, .. } => Action::RemindMessage { item, due_at_ms },
            ReminderTarget::Inbox { channel, message } => Action::RemindListedSavedMessage {
                channel,
                message,
                due_at_ms,
            },
        };
        adapter.action(&window, action);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    shown.on_cancel_reminder(move || {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().message_saves.reminder = None;
            window.global::<MessageSaves>().set_reminder_open(false);
        }
    });
}

fn listed<'a>(
    state: &'a AppState,
    channel: &str,
    message: &str,
) -> Option<&'a yapfast_core::application::SavedMessage> {
    let saved = state.saved_messages();
    saved
        .reminders
        .iter()
        .chain(&saved.bookmarks)
        .find(|entry| entry.channel == channel && entry.message == message)
}

fn open_reminder(
    adapter: &mut Adapter,
    window: &YapfastWindow,
    target: ReminderTarget,
    changing: bool,
) {
    let Some(account) = adapter.app.state.discord_user.clone() else {
        return;
    };
    let reminder = Reminder { account, target };
    if valid_reminder(&adapter.app.state, &reminder) {
        adapter.message_saves.reminder = Some(reminder);
        let shown = window.global::<MessageSaves>();
        shown.set_changing_reminder(changing);
        shown.set_reminder_open(true);
    }
}

fn valid_reminder(state: &AppState, reminder: &Reminder) -> bool {
    if !state.discord_online || state.discord_user.as_ref() != Some(&reminder.account) {
        return false;
    }
    match &reminder.target {
        ReminderTarget::Timeline { room, item } => {
            state.room_of(item) == Some(room)
                && state
                    .message_save_state(item)
                    .is_some_and(|save| save.eligible && !save.busy)
        }
        ReminderTarget::Inbox { channel, message } => listed(state, channel, message).is_some(),
    }
}

pub(super) fn inbox_opened(adapter: &mut Adapter, window: &YapfastWindow) {
    let state = &adapter.app.state;
    let saved = state.saved_messages();
    if window.get_inbox_tab() == 2 && state.discord_online && !saved.loaded && !saved.loading {
        adapter.action(window, Action::LoadSavedMessages);
    } else {
        adapter.refresh(window);
    }
}

pub(super) fn show(adapter: &mut Adapter, window: &YapfastWindow) {
    let state = &adapter.app.state;
    let shown = window.global::<MessageSaves>();
    let available = !state.preview && state.discord_user.is_some();
    shown.set_available(available);
    if !available && window.get_inbox_tab() == 2 {
        window.set_inbox_tab(0);
    }
    let saved = state.saved_messages();
    let menu_save = state.message_save_state(&adapter.message_saves.menu_item);
    shown.set_menu_eligible(menu_save.as_ref().is_some_and(|save| save.eligible));
    shown.set_menu_busy(!saved.loaded || menu_save.as_ref().is_some_and(|save| save.busy));
    shown.set_menu_kind(match menu_save.and_then(|save| save.kind) {
        Some(SavedMessageKind::Bookmark) => 1,
        Some(SavedMessageKind::Reminder) => 2,
        None => 0,
    });
    if adapter
        .message_saves
        .reminder
        .as_ref()
        .is_some_and(|reminder| !valid_reminder(state, reminder))
    {
        adapter.message_saves.reminder = None;
        shown.set_reminder_open(false);
    }
    if window.get_inbox_open() && window.get_inbox_tab() == 2 && available {
        shown.set_list_loading(saved.loading);
        shown.set_list_more(saved.has_more);
        shown.set_list_error(saved.error.as_deref().unwrap_or("").into());
        let rows = saved
            .reminders
            .iter()
            .chain(&saved.bookmarks)
            .map(|entry| {
                let due = entry
                    .due_at
                    .and_then(|due| u64::try_from(due.timestamp()).ok())
                    .and_then(|seconds| {
                        let day = clock::date(seconds)?;
                        let time = clock::time_on(seconds, adapter.layout.twelve_hour_clock);
                        Some(format!("Due {} at {time}", day.format("%b %-d")))
                    })
                    .unwrap_or_default();
                SavedMessageRow {
                    channel: entry.channel.as_str().into(),
                    message: entry.message.as_str().into(),
                    author: entry.author.as_str().into(),
                    location: entry.channel_name.as_str().into(),
                    summary: entry.summary.as_str().into(),
                    due: due.into(),
                }
            })
            .collect();
        update_model(&adapter.models.saved_messages, rows);
    } else if adapter.models.saved_messages.row_count() != 0 {
        adapter.models.saved_messages.set_vec(Vec::new());
    }
}
