//! Enabled plugins in the bundled Vencord companion's dedicated profile.

use serde::Deserialize;
use serde_json::{Map, Value};
use std::{
    collections::{BTreeMap, BTreeSet},
    fmt,
    sync::LazyLock,
};

#[derive(Clone, Debug, Default)]
pub(super) struct CompanionSnapshot {
    pub(super) running: bool,
    enabled: BTreeSet<String>,
}

impl CompanionSnapshot {
    pub(super) fn enabled(&self, name: &str) -> bool {
        self.enabled.contains(name)
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) enum ProfileError {
    #[cfg(not(windows))]
    Unsupported,
    Registry,
    InvalidSettings,
    InvalidProfile,
    InUse,
    ProcessStatus,
    Storage,
    UnavailablePlugin,
    RequiredPlugin,
    RequiredBy(String),
}

impl fmt::Display for ProfileError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            #[cfg(not(windows))]
            Self::Unsupported => f.write_str("The bundled Vencord companion requires Windows."),
            Self::Registry => f.write_str("The bundled Vencord plugin list could not be verified."),
            Self::InvalidSettings => {
                f.write_str("The companion's plugin settings could not be read.")
            }
            Self::InvalidProfile => f.write_str("The companion profile could not be verified."),
            Self::InUse => f.write_str("Close the Vencord companion before changing its plugins."),
            Self::ProcessStatus => {
                f.write_str("S;C could not check whether the Vencord companion is running.")
            }
            Self::Storage => f.write_str("S;C could not access the companion's plugin settings."),
            Self::UnavailablePlugin => {
                f.write_str("This plugin can't be changed in the bundled companion.")
            }
            Self::RequiredPlugin => f.write_str("The bundled companion requires this plugin."),
            Self::RequiredBy(plugin) => {
                write!(f, "{plugin} needs this plugin. Disable {plugin} first.")
            }
        }
    }
}

#[derive(Deserialize)]
struct Plugin {
    default_enabled: bool,
    required: bool,
    internal: bool,
    dependencies: Vec<String>,
}

struct Registry {
    plugins: BTreeMap<String, Plugin>,
    optional: BTreeSet<String>,
}

static REGISTRY: LazyLock<Result<Registry, ProfileError>> = LazyLock::new(|| {
    #[derive(Deserialize)]
    struct Manifest {
        schema: u32,
        renderer_sha256: String,
        plugins: BTreeMap<String, Plugin>,
    }
    #[derive(Deserialize)]
    struct Lock {
        plugins: BTreeMap<String, String>,
    }
    let manifest: Manifest = serde_json::from_str(include_str!("vencord_companion_metadata.json"))
        .map_err(|_| ProfileError::Registry)?;
    let lock: Lock = serde_json::from_str(include_str!(
        "../../tools/vencord-companion/upstream-lock.json"
    ))
    .map_err(|_| ProfileError::Registry)?;
    let optional: BTreeSet<_> = lock.plugins.into_values().collect();
    if manifest.schema != 1
        || manifest.renderer_sha256.len() != 64
        || !manifest
            .renderer_sha256
            .bytes()
            .all(|byte| byte.is_ascii_hexdigit())
        || !optional
            .iter()
            .all(|name| manifest.plugins.contains_key(name))
        || !manifest.plugins.values().all(|plugin| {
            plugin
                .dependencies
                .iter()
                .all(|name| manifest.plugins.contains_key(name))
        })
    {
        return Err(ProfileError::Registry);
    }
    Ok(Registry {
        plugins: manifest.plugins,
        optional,
    })
});

fn registry() -> Result<&'static Registry, ProfileError> {
    REGISTRY.as_ref().map_err(Clone::clone)
}

pub(super) fn companion_plugin_toggleable(name: &str) -> bool {
    registry().is_ok_and(|registry| registry.toggleable(name).is_ok())
}

impl Registry {
    fn toggleable(&self, name: &str) -> Result<(), ProfileError> {
        let plugin = self
            .plugins
            .get(name)
            .ok_or(ProfileError::UnavailablePlugin)?;
        if !self.optional.contains(name) || plugin.internal {
            return Err(ProfileError::UnavailablePlugin);
        }
        if plugin.required {
            return Err(ProfileError::RequiredPlugin);
        }
        Ok(())
    }

    fn with_dependencies<'a>(&'a self, name: &'a str) -> BTreeSet<&'a str> {
        let mut resolved = BTreeSet::new();
        let mut pending = vec![name];
        while let Some(name) = pending.pop() {
            if resolved.insert(name) {
                pending.extend(self.plugins[name].dependencies.iter().map(String::as_str));
            }
        }
        resolved
    }

    fn configured<'a>(&'a self, settings: &Value) -> Result<BTreeSet<&'a str>, ProfileError> {
        let plugins = settings.as_object().ok_or(ProfileError::InvalidSettings)?;
        let plugins = match plugins.get("plugins") {
            Some(plugins) => Some(plugins.as_object().ok_or(ProfileError::InvalidSettings)?),
            None => None,
        };
        self.plugins
            .iter()
            .try_fold(BTreeSet::new(), |mut enabled, (name, plugin)| {
                let configured = match plugins.and_then(|plugins| plugins.get(name)) {
                    Some(entry) => match entry
                        .as_object()
                        .ok_or(ProfileError::InvalidSettings)?
                        .get("enabled")
                    {
                        Some(value) => value.as_bool().ok_or(ProfileError::InvalidSettings)?,
                        None => false,
                    },
                    None => plugin.default_enabled,
                };
                if configured || plugin.required {
                    enabled.insert(name.as_str());
                }
                Ok(enabled)
            })
    }

    fn snapshot(&self, settings: &Value, running: bool) -> Result<CompanionSnapshot, ProfileError> {
        let enabled = self
            .configured(settings)?
            .into_iter()
            .flat_map(|name| self.with_dependencies(name))
            .map(str::to_owned)
            .collect();
        Ok(CompanionSnapshot { running, enabled })
    }

    fn set(&self, settings: &mut Value, name: &str, enabled: bool) -> Result<bool, ProfileError> {
        self.toggleable(name)?;
        let configured = self.configured(settings)?;
        if !enabled {
            if let Some(dependent) = configured
                .iter()
                .copied()
                .find(|&other| other != name && self.with_dependencies(other).contains(name))
            {
                return Err(ProfileError::RequiredBy(dependent.to_owned()));
            }
            if !configured.contains(name) {
                return Ok(false);
            }
        }

        let changed = if enabled {
            self.with_dependencies(name)
                .into_iter()
                .filter(|name| !configured.contains(name))
                .collect()
        } else {
            BTreeSet::from([name])
        };
        if changed.is_empty() {
            return Ok(false);
        }
        let plugins = plugins_mut(settings)?;
        for name in changed {
            let entry = plugins
                .entry(name)
                .or_insert_with(|| Value::Object(Map::new()));
            let entry = entry.as_object_mut().ok_or(ProfileError::InvalidSettings)?;
            entry.insert("enabled".into(), Value::Bool(enabled));
        }
        update_sync_version(settings);
        Ok(true)
    }
}

fn update_sync_version(settings: &mut Value) {
    use std::time::{SystemTime, UNIX_EPOCH};

    if let Some(version) = settings
        .get_mut("cloud")
        .and_then(|cloud| cloud.get_mut("settingsSyncVersion"))
        .filter(|version| version.is_number())
        && let Ok(elapsed) = SystemTime::now().duration_since(UNIX_EPOCH)
        && let Ok(millis) = u64::try_from(elapsed.as_millis())
    {
        *version = Value::from(millis);
    }
}

fn plugins_mut(settings: &mut Value) -> Result<&mut Map<String, Value>, ProfileError> {
    settings
        .as_object_mut()
        .ok_or(ProfileError::InvalidSettings)?
        .entry("plugins")
        .or_insert_with(|| Value::Object(Map::new()))
        .as_object_mut()
        .ok_or(ProfileError::InvalidSettings)
}

pub(super) fn companion_snapshot() -> Result<CompanionSnapshot, ProfileError> {
    #[cfg(windows)]
    return filesystem::snapshot();
    #[cfg(not(windows))]
    Err(ProfileError::Unsupported)
}

pub(super) fn set_companion_plugin(
    name: &str,
    enabled: bool,
) -> Result<CompanionSnapshot, ProfileError> {
    #[cfg(windows)]
    return filesystem::set(name, enabled);
    #[cfg(not(windows))]
    {
        let _ = (name, enabled);
        Err(ProfileError::Unsupported)
    }
}

#[cfg(windows)]
mod filesystem {
    use super::*;
    use std::{
        fs::{self, File, OpenOptions},
        io::{self, Read, Write},
        os::windows::fs::{MetadataExt, OpenOptionsExt},
        path::{Path, PathBuf},
    };

    const LOCK: &str = ".sc-profile.lock";
    const MARKER: &str = "sc-companion-profile.json";
    const MARKER_JSON: &[u8] = br#"{"schema":1,"kind":"sc-vencord-companion-profile"}"#;
    const SETTINGS: &str = "settings.json";
    const MAX_SETTINGS: u64 = 8 * 1024 * 1024;
    const REPARSE_POINT: u32 = 0x400;
    const OPEN_REPARSE_POINT: u32 = 0x0020_0000;

    pub(super) fn snapshot() -> Result<CompanionSnapshot, ProfileError> {
        let container = companion_directory(false)?;
        let lock = container.join(LOCK);
        let _lock = checked(&lock, false)?
            .then(|| exclusive(&lock, false))
            .transpose()?;
        let running = companion_running()?;
        let profile = profile_directory(&container)?;
        registry()?.snapshot(&read_settings(&profile)?, running)
    }

    pub(super) fn set(name: &str, enabled: bool) -> Result<CompanionSnapshot, ProfileError> {
        let registry = registry()?;
        registry.toggleable(name)?;
        let container = companion_directory(true)?;
        let _lock = exclusive(&container.join(LOCK), true)?;
        if companion_running()? {
            return Err(ProfileError::InUse);
        }
        let profile = profile_directory(&container)?;
        let mut settings = read_settings(&profile)?;
        if registry.set(&mut settings, name, enabled)? {
            let snapshot = registry.snapshot(&settings, false)?;
            let bytes = serde_json::to_vec(&settings).map_err(|_| ProfileError::InvalidSettings)?;
            if bytes.len() as u64 > MAX_SETTINGS {
                return Err(ProfileError::InvalidSettings);
            }
            ensure_directory(&profile)?;
            let marker = profile.join(MARKER);
            if !checked(&marker, false)? {
                write_atomic(&marker, MARKER_JSON, false)?;
            }
            let folder = profile.join("settings");
            ensure_directory(&folder)?;
            let settings = folder.join(SETTINGS);
            checked(&settings, false)?;
            write_atomic(&settings, &bytes, true)?;
            return Ok(snapshot);
        }
        registry.snapshot(&settings, false)
    }

    fn companion_directory(create: bool) -> Result<PathBuf, ProfileError> {
        let local = std::env::var_os("LOCALAPPDATA")
            .map(PathBuf::from)
            .filter(|path| path.is_absolute())
            .ok_or(ProfileError::InvalidProfile)?;
        for folder in local.ancestors() {
            if !checked(folder, true)? {
                return Err(ProfileError::InvalidProfile);
            }
        }
        let sc = local.join("SC");
        let companion = sc.join("VencordCompanion");
        for path in [&sc, &companion] {
            if create {
                ensure_directory(path)?;
            } else {
                checked(path, true)?;
            }
        }
        Ok(companion)
    }

    fn profile_directory(container: &Path) -> Result<PathBuf, ProfileError> {
        let profile = container.join("profile-v1");
        if !checked(&profile, true)? {
            return Ok(profile);
        }
        match read(&profile.join(MARKER), 1024)? {
            Some(marker) => {
                let value: Value =
                    serde_json::from_slice(&marker).map_err(|_| ProfileError::InvalidProfile)?;
                if value["schema"] != 1 || value["kind"] != "sc-vencord-companion-profile" {
                    return Err(ProfileError::InvalidProfile);
                }
            }
            None => {
                if fs::read_dir(&profile)
                    .map_err(|_| ProfileError::Storage)?
                    .next()
                    .is_some()
                {
                    return Err(ProfileError::InvalidProfile);
                }
            }
        }
        Ok(profile)
    }

    fn read_settings(profile: &Path) -> Result<Value, ProfileError> {
        let folder = profile.join("settings");
        if checked(&folder, true)?
            && let Some(data) = read(&folder.join(SETTINGS), MAX_SETTINGS)?
        {
            return serde_json::from_slice(&data).map_err(|_| ProfileError::InvalidSettings);
        }
        Ok(Value::Object(Map::new()))
    }

    fn checked(path: &Path, directory: bool) -> Result<bool, ProfileError> {
        match fs::symlink_metadata(path) {
            Ok(metadata)
                if metadata.file_attributes() & REPARSE_POINT == 0
                    && if directory {
                        metadata.is_dir()
                    } else {
                        metadata.is_file()
                    } =>
            {
                Ok(true)
            }
            Ok(_) => Err(ProfileError::InvalidProfile),
            Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(false),
            Err(error) if matches!(error.raw_os_error(), Some(32 | 33)) => Err(ProfileError::InUse),
            Err(_) => Err(ProfileError::Storage),
        }
    }

    fn ensure_directory(path: &Path) -> Result<(), ProfileError> {
        if !checked(path, true)? {
            match fs::create_dir(path) {
                Ok(()) => (),
                Err(error) if error.kind() == io::ErrorKind::AlreadyExists => (),
                Err(_) => return Err(ProfileError::Storage),
            }
            if !checked(path, true)? {
                return Err(ProfileError::InvalidProfile);
            }
        }
        Ok(())
    }

    fn exclusive(path: &Path, create: bool) -> Result<File, ProfileError> {
        checked(path, false)?;
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .create(create)
            .truncate(false)
            .share_mode(0)
            .custom_flags(OPEN_REPARSE_POINT)
            .open(path)
            .map_err(|error| {
                if matches!(error.raw_os_error(), Some(32 | 33)) {
                    ProfileError::InUse
                } else {
                    ProfileError::Storage
                }
            })?;
        validate_file(&file)?;
        Ok(file)
    }

    fn validate_file(file: &File) -> Result<(), ProfileError> {
        let metadata = file.metadata().map_err(|_| ProfileError::Storage)?;
        if !metadata.is_file() || metadata.file_attributes() & REPARSE_POINT != 0 {
            return Err(ProfileError::InvalidProfile);
        }
        Ok(())
    }

    fn read(path: &Path, max: u64) -> Result<Option<Vec<u8>>, ProfileError> {
        if !checked(path, false)? {
            return Ok(None);
        }
        let file = OpenOptions::new()
            .read(true)
            .custom_flags(OPEN_REPARSE_POINT)
            .open(path)
            .map_err(|_| ProfileError::Storage)?;
        validate_file(&file)?;
        let mut data = Vec::new();
        file.take(max + 1)
            .read_to_end(&mut data)
            .map_err(|_| ProfileError::Storage)?;
        if data.len() as u64 > max {
            return Err(ProfileError::InvalidSettings);
        }
        Ok(Some(data))
    }

    fn write_atomic(path: &Path, data: &[u8], replace: bool) -> Result<(), ProfileError> {
        let parent = path.parent().ok_or(ProfileError::InvalidProfile)?;
        let mut file =
            tempfile::NamedTempFile::new_in(parent).map_err(|_| ProfileError::Storage)?;
        file.write_all(data).map_err(|_| ProfileError::Storage)?;
        file.as_file()
            .sync_all()
            .map_err(|_| ProfileError::Storage)?;
        if replace {
            file.persist(path)
        } else {
            file.persist_noclobber(path)
        }
        .map(drop)
        .map_err(|_| ProfileError::Storage)
    }

    fn companion_running() -> Result<bool, ProfileError> {
        use windows::{
            Win32::{
                Foundation::{CloseHandle, ERROR_NO_MORE_FILES},
                System::Diagnostics::ToolHelp::{
                    CreateToolhelp32Snapshot, PROCESSENTRY32W, Process32FirstW, Process32NextW,
                    TH32CS_SNAPPROCESS,
                },
            },
            core::HRESULT,
        };

        // A running Electron process has already loaded a settings snapshot
        // and can write it back. The launcher holds the same file lock until
        // this process becomes visible to a system snapshot.
        unsafe {
            let handle = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
                .map_err(|_| ProfileError::ProcessStatus)?;
            let mut entry = PROCESSENTRY32W {
                dwSize: size_of::<PROCESSENTRY32W>() as u32,
                ..Default::default()
            };
            let mut next = Process32FirstW(handle, &mut entry);
            let result = loop {
                match next {
                    Ok(()) => {
                        let length = entry
                            .szExeFile
                            .iter()
                            .position(|&unit| unit == 0)
                            .unwrap_or(entry.szExeFile.len());
                        if String::from_utf16_lossy(&entry.szExeFile[..length])
                            .eq_ignore_ascii_case("SC-Vencord.exe")
                        {
                            break Ok(true);
                        }
                        next = Process32NextW(handle, &mut entry);
                    }
                    Err(error) if error.code() == HRESULT::from_win32(ERROR_NO_MORE_FILES.0) => {
                        break Ok(false);
                    }
                    Err(_) => break Err(ProfileError::ProcessStatus),
                }
            };
            let _ = CloseHandle(handle);
            result
        }
    }

    #[cfg(test)]
    #[test]
    fn vencord_companion_profile_requires_marker_and_serializes_access() {
        let temp = tempfile::tempdir().unwrap();
        let folder = temp.path().join("profile-v1");
        let lock = temp.path().join(LOCK);
        let first = exclusive(&lock, true).unwrap();
        assert_eq!(exclusive(&lock, true).unwrap_err(), ProfileError::InUse);
        drop(first);
        let _locked = exclusive(&lock, false).unwrap();
        assert_eq!(profile_directory(temp.path()).unwrap(), folder);

        ensure_directory(&folder).unwrap();
        let settings = folder.join("settings");
        ensure_directory(&settings).unwrap();
        assert_eq!(
            profile_directory(temp.path()).unwrap_err(),
            ProfileError::InvalidProfile
        );
        write_atomic(&folder.join(MARKER), MARKER_JSON, false).unwrap();
        assert_eq!(profile_directory(temp.path()).unwrap(), folder);

        let file = settings.join(SETTINGS);
        write_atomic(&file, br#"{"keep":true}"#, true).unwrap();
        assert_eq!(read_settings(&folder).unwrap()["keep"], true);
        write_atomic(
            &file,
            br#"{"keep":true,"plugins":{"BetterGifPicker":{"enabled":true}}}"#,
            true,
        )
        .unwrap();
        let prefs = read_settings(&folder).unwrap();
        assert_eq!(prefs["keep"], true);
        assert!(
            registry()
                .unwrap()
                .snapshot(&prefs, false)
                .unwrap()
                .enabled("BetterGifPicker")
        );
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn vencord_companion_profile_applies_pinned_defaults_and_preserves_settings() {
        let registry = registry().unwrap();
        let mut settings = json!({
            "frameless": true,
            "cloud": {"settingsSyncVersion": 0, "settingsSync": false},
            "plugins": {
                "ClearURLs": {"stripAmazon": false},
                "DisableDeepLinks": {"enabled": false},
                "Other": {"favorite": true}
            }
        });
        let initial = registry.snapshot(&settings, true).unwrap();
        assert!(initial.running);
        assert!(initial.enabled("DisableDeepLinks"));
        assert!(!initial.enabled("ClearURLs"));
        assert!(!companion_plugin_toggleable("DisableDeepLinks"));
        assert!(!companion_plugin_toggleable("NoMiddleClickPaste"));
        assert!(!companion_plugin_toggleable("FakeNitro"));
        assert!(companion_plugin_toggleable("ClearURLs"));

        assert_eq!(registry.set(&mut settings, "ClearURLs", true), Ok(true));
        let updated = registry.snapshot(&settings, false).unwrap();
        assert!(updated.enabled("ClearURLs"));
        assert!(updated.enabled("MessageEventsAPI"));
        assert_eq!(settings["frameless"], true);
        assert_eq!(settings["plugins"]["ClearURLs"]["stripAmazon"], false);
        assert_eq!(settings["plugins"]["Other"]["favorite"], true);
        assert_eq!(settings["cloud"]["settingsSync"], false);
        assert!(settings["cloud"]["settingsSyncVersion"].as_u64().unwrap() > 0);
        let previous = settings.clone();
        assert_eq!(registry.set(&mut settings, "ClearURLs", true), Ok(false));
        assert_eq!(settings, previous);
        assert_eq!(
            registry.set(&mut settings, "DisableDeepLinks", false),
            Err(ProfileError::RequiredPlugin)
        );
        assert_eq!(settings, previous);
    }

    #[test]
    fn vencord_companion_profile_protects_transitive_dependencies() {
        let plugins = serde_json::from_value(json!({
            "Starting": {"default_enabled": false, "required": false, "internal": false, "dependencies": ["Middle"]},
            "Middle": {"default_enabled": false, "required": false, "internal": false, "dependencies": ["Ending"]},
            "Ending": {"default_enabled": false, "required": false, "internal": false, "dependencies": []},
        })).unwrap();
        let registry = Registry {
            plugins,
            optional: ["Starting", "Middle", "Ending"].map(str::to_owned).into(),
        };
        let mut settings = json!({"plugins": {"Starting": {"enabled": true}}});
        assert_eq!(
            registry.set(&mut settings, "Ending", false),
            Err(ProfileError::RequiredBy("Starting".into()))
        );
        assert_eq!(registry.set(&mut settings, "Starting", true), Ok(true));
        assert_eq!(settings["plugins"]["Middle"]["enabled"], true);
        assert_eq!(settings["plugins"]["Ending"]["enabled"], true);
        assert_eq!(registry.set(&mut settings, "Starting", false), Ok(true));
        assert_eq!(registry.set(&mut settings, "Middle", false), Ok(true));
        assert_eq!(registry.set(&mut settings, "Ending", false), Ok(true));
        assert!(
            !registry
                .snapshot(&settings, false)
                .unwrap()
                .enabled("Ending")
        );
    }
}
