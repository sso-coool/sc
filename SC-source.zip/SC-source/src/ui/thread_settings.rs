//! Native thread settings and explicit deletion confirmation.
use super::*;
use yapfast_core::application::{SLOWMODES, ThreadInput};

const ARCHIVE_MINUTES: [u16; 4] = [60, 1440, 4320, 10080];

impl Adapter {
    pub(super) fn show_thread_settings(&self, window: &YapfastWindow) {
        let Some(dialog) = self.app.state.thread_dialog.as_ref() else {
            window.set_thread_settings_open(false);
            return;
        };
        if window.get_thread_settings_name() != dialog.name.as_str() {
            window.set_thread_settings_name(dialog.name.as_str().into());
        }
        let mut rows = vec![
            SettingsRow {
                heading: true,
                text: dialog.name.to_uppercase().into(),
                ..Default::default()
            },
            SettingsRow {
                text: "Overview".into(),
                icon: self.icons.edit.clone(),
                ..Default::default()
            },
        ];
        if dialog.can_delete {
            rows.extend([
                SettingsRow {
                    heading: true,
                    ..Default::default()
                },
                SettingsRow {
                    id: 7,
                    text: "Delete Thread".into(),
                    icon: self.icons.delete.clone(),
                    danger: true,
                    ..Default::default()
                },
            ]);
        }
        window.set_thread_settings_prompt(ThreadSettingsPrompt {
            rows: same_list(
                &window.get_thread_settings_prompt().rows,
                ModelRc::new(VecModel::from(rows)),
            ),
            deleting: dialog.deleting,
            slowmode: SLOWMODES
                .iter()
                .position(|value| *value == dialog.slowmode)
                .unwrap_or(0) as i32,
            archive: ARCHIVE_MINUTES
                .iter()
                .position(|value| *value == dialog.archive_minutes)
                .unwrap_or(1) as i32,
            can_slowmode: dialog.can_slowmode,
            can_invite: dialog.invitable.is_some(),
            invitable: dialog.invitable.unwrap_or_default(),
            can_spoiler: dialog.spoiler.is_some(),
            spoiler: dialog.spoiler.unwrap_or_default(),
            changed: dialog.changed(),
            saving: dialog.saving,
            may_save: !dialog.saving
                && self.app.state.discord_online
                && (dialog.deleting
                    || (dialog.changed()
                        && !dialog.name.trim().is_empty()
                        && dialog.name.chars().count() <= 100)),
            error: dialog.error.as_deref().unwrap_or_default().into(),
        });
        window.set_thread_settings_open(true);
    }
}

pub(super) fn bind(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_thread_settings_input(move |what, text, number| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        if what == 7 {
            let room = adapter
                .app
                .state
                .thread_dialog
                .as_ref()
                .filter(|dialog| !dialog.deleting && !dialog.saving && dialog.can_delete)
                .map(|dialog| dialog.room.clone());
            if let Some(room) = room {
                adapter.action(&window, Action::AskDeleteThread(room));
            }
            return;
        }
        let input = match what {
            0 => Some(ThreadInput::Name(text.into())),
            1 => usize::try_from(number)
                .ok()
                .and_then(|index| SLOWMODES.get(index))
                .copied()
                .map(ThreadInput::Slowmode),
            2 => usize::try_from(number)
                .ok()
                .and_then(|index| ARCHIVE_MINUTES.get(index))
                .copied()
                .map(ThreadInput::ArchiveMinutes),
            3 => Some(ThreadInput::Save),
            4 => Some(ThreadInput::Cancel),
            5 => Some(ThreadInput::Invitable(number != 0)),
            6 => Some(ThreadInput::Spoiler(number != 0)),
            8 => Some(ThreadInput::Reset),
            _ => None,
        };
        if let Some(input) = input {
            adapter.action(&window, Action::ThreadSettings(input));
        }
    });
}
