//! Native thread editing and explicit deletion confirmation.
use super::*;
use yapfast_core::application::{SLOWMODES, ThreadInput};

const ARCHIVE_MINUTES: [u16; 4] = [60, 1440, 4320, 10080];

impl Adapter {
    pub(super) fn show_thread_settings(&self, window: &YapfastWindow) {
        let Some(dialog) = self.app.state.thread_dialog.as_ref() else {
            if window.get_thread_settings_open() {
                window.set_thread_settings_open(false);
                window.set_thread_settings_prompt(ThreadSettingsPrompt::default());
                window.set_thread_settings_name(SharedString::default());
            }
            return;
        };
        window.set_thread_settings_open(true);
        if window.get_thread_settings_name() != dialog.name.as_str() {
            window.set_thread_settings_name(dialog.name.as_str().into());
        }
        window.set_thread_settings_prompt(ThreadSettingsPrompt {
            deleting: dialog.deleting,
            slowmode: SLOWMODES
                .iter()
                .position(|value| *value == dialog.slowmode)
                .unwrap_or(0) as i32,
            archive: ARCHIVE_MINUTES
                .iter()
                .position(|value| *value == dialog.archive_minutes)
                .unwrap_or(1) as i32,
            can_slowmode: dialog.can_slowmode,
            saving: dialog.saving,
            may_save: !dialog.saving
                && self.app.state.discord_online
                && (dialog.deleting
                    || (!dialog.name.trim().is_empty() && dialog.name.chars().count() <= 100)),
            error: dialog.error.as_deref().unwrap_or_default().into(),
        });
    }
}

pub(super) fn bind(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_thread_settings_input(move |what, text, number| {
        let Some(window) = weak.upgrade() else { return };
        let input = match what {
            0 => Some(ThreadInput::Name(text.into())),
            1 => usize::try_from(number)
                .ok()
                .and_then(|index| SLOWMODES.get(index))
                .copied()
                .map(ThreadInput::Slowmode),
            2 => usize::try_from(number)
                .ok()
                .and_then(|index| ARCHIVE_MINUTES.get(index))
                .copied()
                .map(ThreadInput::ArchiveMinutes),
            3 => Some(ThreadInput::Save),
            4 => Some(ThreadInput::Cancel),
            _ => None,
        };
        if let Some(input) = input {
            state
                .borrow_mut()
                .action(&window, Action::ThreadSettings(input));
        }
    });
}
