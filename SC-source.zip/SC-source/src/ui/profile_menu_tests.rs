//! A long mini-profile menu is navigated using real offscreen pointer events.
use super::*;
use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
use slint::platform::{PointerEventButton, WindowEvent};
use std::ops::ControlFlow;

fn named(root: &ItemRc, label: &str) -> ItemRc {
    root.visit_descendants(|item| {
        if item.is_visible()
            && item
                .accessible_string_property(AccessibleStringProperty::Label)
                .as_deref()
                == Some(label)
        {
            ControlFlow::Break(item.clone())
        } else {
            ControlFlow::Continue(())
        }
    })
    .unwrap_or_else(|| panic!("missing native menu control {label}"))
}

fn settle(window: &YapfastWindow) {
    for _ in 0..3 {
        window.window().take_snapshot().unwrap();
        i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(120));
        slint::platform::update_timers_and_animations();
    }
}

fn click(window: &YapfastWindow, position: slint::LogicalPosition) {
    window
        .window()
        .dispatch_event(WindowEvent::PointerMoved { position });
    window.window().dispatch_event(WindowEvent::PointerPressed {
        position,
        button: PointerEventButton::Left,
    });
    window
        .window()
        .dispatch_event(WindowEvent::PointerReleased {
            position,
            button: PointerEventButton::Left,
        });
    settle(window);
}

fn window_rect(window: &YapfastWindow, label: &str) -> (f32, f32, f32, f32) {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    let item = named(&ItemRc::new_root(inner.component()), label);
    let geometry = item.geometry();
    let point = item.map_to_window(geometry.origin);
    (point.x, point.y, geometry.width(), geometry.height())
}

fn more(window: &YapfastWindow) {
    let (x, y, w, h) = window_rect(window, "More actions");
    click(window, slint::LogicalPosition::new(x + w / 2., y + h / 2.));
}

fn menu_rect(window: &YapfastWindow, label: &str) -> (f32, f32, f32, f32) {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    let popups = inner.active_popups();
    let popup = popups.last().expect("More opens a native popup");
    let i_slint_core::window::PopupWindowLocation::ChildWindow(place) = popup.location else {
        panic!("testing backend uses embedded popups");
    };
    let item = named(&ItemRc::new_root(popup.component.clone()), label);
    let geometry = item.geometry();
    let point = item.map_to_item_tree(geometry.origin, &popup.component);
    (
        place.x + point.x,
        place.y + point.y,
        geometry.width(),
        geometry.height(),
    )
}

fn assert_contained(window: &YapfastWindow, label: &str, width: f32, height: f32) {
    let (x, y, w, h) = menu_rect(window, label);
    assert!(x >= 7. && x + w <= width - 7., "{label}: {x}+{w}/{width}");
    // The fixture uses the native 32px title bar. It remains accessible.
    assert!(
        y >= 39. && y + h <= height - 7.,
        "{label}: {y}+{h}/{height}"
    );
}

fn click_row(window: &YapfastWindow, label: &str, width: f32, height: f32) {
    assert_contained(window, label, width, height);
    let (x, y, w, h) = menu_rect(window, label);
    click(window, slint::LogicalPosition::new(x + w / 2., y + h / 2.));
}

#[test]
fn profile_more_menu_stays_in_view_and_scrolls_to_every_action() {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let window = yapfast::window().unwrap();
    Layout::default().apply_appearance(&window);
    title_bar::show(&window, Some(false));
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<PictureStore>().on_request(|_| {});
    window.set_workspace(true);
    window.set_trusted(true);
    window.set_profile(ProfileData {
        id: "900".into(),
        name: "Menu fixture".into(),
        initial: "M".into(),
        ..Default::default()
    });
    window.set_profile_open(true);
    window.on_ask_app_commands(|| {});
    let prepared = Rc::new(RefCell::new(Vec::new()));
    let recorded = prepared.clone();
    window.on_prepare_menu(move |id, person| recorded.borrow_mut().push((id.to_string(), person)));
    let chosen = Rc::new(RefCell::new(Vec::new()));
    let recorded = chosen.clone();
    window.on_choose_menu(move |id, person, action| {
        recorded
            .borrow_mut()
            .push((id.to_string(), person, action.to_string()));
    });
    window.show().unwrap();
    window
        .window()
        .set_size(slint::LogicalSize::new(1120., 760.));
    window.set_profile_at_pointer(true);
    window.set_menu_rows(ModelRc::new(VecModel::from(vec![MenuRow {
        id: "short-menu".into(),
        text: "Short menu".into(),
        plain: true,
        ..Default::default()
    }])));
    for (pointer_x, opens_on_right) in [(100., true), (650., false)] {
        window.invoke_anchor_link(pointer_x, 200., 24., 24.);
        settle(&window);
        let before = window_rect(&window, "Menu fixture's profile");
        let ellipsis = window_rect(&window, "More actions");
        more(&window);
        assert_eq!(window_rect(&window, "Menu fixture's profile"), before);
        assert_eq!(window_rect(&window, "More actions"), ellipsis);
        let (x, y, w, _) = menu_rect(&window, "Context menu");
        let gap = if opens_on_right {
            x - before.0 - before.2
        } else {
            before.0 - x - w
        };
        assert!(
            (gap - 4.).abs() <= 1.,
            "menu should sit beside profile, gap={gap}"
        );
        assert!(
            (y - before.1).abs() <= 1.,
            "menu should align with top of profile"
        );
        i_slint_core::window::WindowInner::from_pub(window.window()).close_all_popups();
        settle(&window);
    }
    window.set_profile_at_pointer(false);
    // More than a screenful, including separators and subtitle rows. These are
    // synthetic actions: no relationship/moderation/backend operation executes.
    window.set_menu_rows(ModelRc::new(VecModel::from(
        (0..40)
            .map(|index| MenuRow {
                id: format!("row-{index}").into(),
                text: format!("Action {index:02}").into(),
                subtitle: if index % 5 == 0 {
                    "Extra information".into()
                } else {
                    "".into()
                },
                plain: true,
                separated: index % 4 == 0,
                ..Default::default()
            })
            .collect::<Vec<_>>(),
    )));
    for (width, height) in [(800., 600.), (1120., 760.)] {
        window
            .window()
            .set_size(slint::LogicalSize::new(width, height));
        settle(&window);
        more(&window);
        assert_eq!(
            prepared.borrow().last(),
            Some(&("profile-more:900".into(), true))
        );
        assert_contained(&window, "Context menu", width, height);
        click_row(&window, "Action 00", width, height);
        assert_eq!(chosen.borrow().last().unwrap().2, "row-0");
        more(&window);
        let (x, y, w, h) = menu_rect(&window, "Context menu");
        window
            .window()
            .dispatch_event(WindowEvent::PointerScrolled {
                position: slint::LogicalPosition::new(x + w / 2., y + h / 2.),
                delta_x: 0.,
                delta_y: -10000.,
            });
        settle(&window);
        assert_contained(&window, "Context menu", width, height);
        if let Some(output) = std::env::var_os("SC_REVIEW_DIR") {
            let output = std::path::PathBuf::from(output);
            std::fs::create_dir_all(&output).unwrap();
            let frame = window.window().take_snapshot().unwrap();
            image::save_buffer(
                output.join(format!("profile-more-menu-{width}x{height}.png")),
                frame.as_bytes(),
                frame.width(),
                frame.height(),
                image::ColorType::Rgba8,
            )
            .unwrap();
        }
        click_row(&window, "Action 39", width, height);
        assert_eq!(chosen.borrow().last().unwrap().2, "row-39");
    }
    // Resize with a menu already open. Its viewport, not only its origin,
    // shrinks, and keyboard navigation can still expose the final action.
    more(&window);
    window
        .window()
        .set_size(slint::LogicalSize::new(800., 600.));
    settle(&window);
    for event in [
        WindowEvent::KeyPressed {
            text: slint::platform::Key::End.into(),
        },
        WindowEvent::KeyReleased {
            text: slint::platform::Key::End.into(),
        },
    ] {
        window.window().dispatch_event(event);
    }
    settle(&window);
    assert_contained(&window, "Context menu", 800., 600.);
    click_row(&window, "Action 39", 800., 600.);
    assert_eq!(chosen.borrow().len(), 5);
    assert!(
        chosen
            .borrow()
            .iter()
            .all(|(id, person, _)| id == "profile-more:900" && *person)
    );
    window.hide().unwrap();
}

#[test]
fn quick_reaction_tooltip_uses_the_popup_origin_and_stays_near_its_emoji() {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let window = yapfast::window().unwrap();
    Layout::default().apply_appearance(&window);
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<PictureStore>().on_request(|_| {});
    window.set_workspace(true);
    window.set_trusted(true);
    window.set_new_reactions_enabled(true);
    window.on_prepare_menu(|_, _| {});
    window.on_ask_message_app_commands(|_| {});
    window.set_menu_reactions(ModelRc::new(VecModel::from(
        [
            ("👍", "Thumbs up"),
            ("❤️", "Heart"),
            ("😂", "Joy"),
            ("🎉", "Party popper"),
        ]
        .into_iter()
        .map(|(glyph, name)| EmojiCell {
            key: glyph.into(),
            glyph: glyph.into(),
            name: name.into(),
            usable: true,
            picture: crate::twemoji::picture(glyph, 24., 1.).unwrap(),
        })
        .collect::<Vec<_>>(),
    )));
    let mut row = MessageRow::default();
    row.item = "d:100".into();
    row.can_react = true;
    window.show().unwrap();
    for (width, height, anchor_x, anchor_y, apps) in [
        (800., 600., 760., 380., false),
        (800., 600., 760., 380., true),
        (1120., 760., 80., 500., true),
    ] {
        window
            .window()
            .set_size(slint::LogicalSize::new(width, height));
        window.set_app_menu_commands(ModelRc::new(VecModel::from(if apps {
            vec![CommandChoice {
                id: "review:command".into(),
                name: "Inspect".into(),
                app: "Fixture".into(),
                ..Default::default()
            }]
        } else {
            vec![]
        })));
        // Seed the same shared anchor as a native right click without opening
        // another menu. Only the emoji hover below displays the tooltip.
        window.invoke_open_context_menu("fixture".into(), false, anchor_x, anchor_y);
        window.invoke_open_menu(row.clone());
        settle(&window);
        let (x, y, w, h) = menu_rect(&window, "React with Party popper");
        let position = slint::LogicalPosition::new(x + w / 2., y + h / 2.);
        window
            .window()
            .dispatch_event(WindowEvent::PointerMoved { position });
        settle(&window);
        let inner = i_slint_core::window::WindowInner::from_pub(window.window());
        let tooltip = named(&ItemRc::new_root(inner.component()), "Party popper");
        let bounds = tooltip.geometry();
        let at = tooltip.map_to_window(bounds.origin);
        assert!(at.x >= 7. && at.x + bounds.width() <= width - 7.);
        assert!(at.y >= 7. && at.y + bounds.height() <= height - 7.);
        assert!(
            at.x <= position.x && at.x + bounds.width() >= position.x,
            "tooltip must overlap its emoji horizontally, not jump to the main window's left edge: tooltip {}..{}, emoji {}",
            at.x,
            at.x + bounds.width(),
            position.x,
        );
        assert!(
            (at.y + bounds.height() + 6. - y).abs() <= 1.,
            "tooltip sits just above the hovered emoji"
        );
        if let Some(output) = std::env::var_os("SC_REVIEW_DIR") {
            let output = std::path::PathBuf::from(output);
            std::fs::create_dir_all(&output).unwrap();
            let frame = window.window().take_snapshot().unwrap();
            image::save_buffer(
                output.join(format!("reaction-tip-{width}-{anchor_x}-{apps}.png")),
                frame.as_bytes(),
                frame.width(),
                frame.height(),
                image::ColorType::Rgba8,
            )
            .unwrap();
        }
        window.window().dispatch_event(WindowEvent::PointerExited);
        inner.close_all_popups();
    }
    window.hide().unwrap();
}
