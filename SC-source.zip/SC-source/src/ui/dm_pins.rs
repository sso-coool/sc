//! DM shortcuts, separate from message pins and the Favorites collection.
//! Incoming Discord pins are read-only; local overrides remain account-scoped.
use super::*;

pub(super) const MAX_PINS: usize = 200;
const MAX_ACCOUNTS: usize = 8;

#[derive(Clone, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(default)]
pub(super) struct KeptPins {
    account: String,
    rooms: Vec<String>,
    // Local unpins override incoming pins instead of returning on every refresh.
    removed: Vec<String>,
}

fn valid_id(value: &str) -> bool {
    !value.is_empty() && value.len() <= 20 && value.bytes().all(|byte| byte.is_ascii_digit())
}

fn valid_room(room: &str) -> bool {
    room.len() <= 256
        && !room.chars().any(char::is_control)
        && (room.strip_prefix("discord:@me:").is_some_and(valid_id) || room.starts_with('!'))
}

fn bound(rooms: &mut Vec<String>) {
    let mut seen = HashSet::new();
    rooms.retain(|room| seen.len() < MAX_PINS && valid_room(room) && seen.insert(room.clone()));
}

pub(super) fn tidy(accounts: &mut Vec<KeptPins>) {
    let mut seen = HashSet::new();
    accounts.reverse();
    accounts.retain_mut(|kept| {
        let valid = kept.account.strip_prefix("discord:").is_some_and(valid_id)
            || (kept.account.starts_with("matrix:@")
                && kept.account.len() <= 264
                && !kept.account.chars().any(char::is_control));
        if !valid || seen.len() >= MAX_ACCOUNTS || !seen.insert(kept.account.clone()) {
            return false;
        }
        bound(&mut kept.rooms);
        bound(&mut kept.removed);
        true
    });
    accounts.reverse();
}

fn account(state: &AppState) -> Option<String> {
    if state.preview {
        return None;
    }
    state
        .discord_user
        .as_deref()
        .filter(|id| valid_id(id))
        .map(|id| format!("discord:{id}"))
        .or_else(|| {
            state
                .account
                .as_deref()
                .filter(|id| id.starts_with('@') && id.len() <= 256)
                .map(|id| format!("matrix:{id}"))
        })
}

fn cloud(state: &AppState) -> &[String] {
    #[cfg(feature = "discord")]
    if state.discord_user.is_some() {
        return state.discord_dm_pins.as_deref().unwrap_or_default();
    }
    &[]
}

fn merged(kept: Option<&KeptPins>, incoming: &[String]) -> Vec<String> {
    let mut rooms = kept.map_or_else(Vec::new, |kept| kept.rooms.clone());
    for room in incoming.iter().take(MAX_PINS) {
        if kept.is_some_and(|kept| kept.removed.contains(room)) || rooms.contains(room) {
            continue;
        }
        rooms.push(room.clone());
    }
    bound(&mut rooms);
    rooms
}

#[derive(Default)]
pub(super) struct ActivePins {
    account: Option<String>,
    reset: u64,
    applied: Vec<String>,
    #[cfg(feature = "discord")]
    incoming: Option<Arc<[String]>>,
}

impl ActivePins {
    fn sync(
        &mut self,
        state: &mut AppState,
        accounts: &mut Vec<KeptPins>,
        legacy: &mut Vec<String>,
    ) -> bool {
        let incoming_account = account(state);
        let switched = self.account != incoming_account || self.reset != state.reset_version;
        #[cfg(feature = "discord")]
        let unchanged_cloud = match (&self.incoming, &state.discord_dm_pins) {
            (Some(before), Some(now)) => Arc::ptr_eq(before, now),
            (None, None) => true,
            _ => false,
        };
        #[cfg(not(feature = "discord"))]
        let unchanged_cloud = true;
        if !switched && unchanged_cloud && legacy.is_empty() && state.pinned == self.applied {
            return false;
        }
        #[cfg(feature = "discord")]
        {
            self.incoming = state.discord_dm_pins.clone();
        }
        let mut dirty = false;
        if switched {
            self.account = incoming_account;
            self.reset = state.reset_version;
            self.applied.clear();
        }
        let Some(account) = &self.account else {
            state.pinned.clear();
            self.applied.clear();
            return false;
        };
        let changed = !switched && state.pinned != self.applied;
        let migrates: Vec<_> = legacy
            .iter()
            .take(MAX_PINS)
            .filter(|id| {
                valid_room(id)
                    && state
                        .rooms
                        .iter()
                        .any(|room| room.direct && !room.request && !room.locked && room.id == **id)
            })
            .cloned()
            .collect();
        let at = accounts.iter().position(|kept| &kept.account == account);
        if changed || !migrates.is_empty() {
            let mut kept = at
                .map(|at| accounts.remove(at))
                .unwrap_or_else(|| KeptPins {
                    account: account.clone(),
                    ..Default::default()
                });
            if changed {
                for id in &self.applied {
                    if !state.pinned.contains(id) {
                        kept.rooms.retain(|room| room != id);
                        if !kept.removed.contains(id) {
                            kept.removed.push(id.clone());
                        }
                    }
                }
                for id in &state.pinned {
                    if !self.applied.contains(id) && valid_room(id) {
                        kept.removed.retain(|room| room != id);
                        if !kept.rooms.contains(id) {
                            kept.rooms.push(id.clone());
                        }
                    }
                }
            }
            for id in migrates {
                if !kept.rooms.contains(&id) && !kept.removed.contains(&id) {
                    kept.rooms.push(id.clone());
                }
                legacy.retain(|room| room != &id);
            }
            bound(&mut kept.rooms);
            // The latest explicit unpin wins if a long-lived account reaches
            // the cap after receiving many different cloud pins over time.
            if kept.removed.len() > MAX_PINS {
                kept.removed.drain(..kept.removed.len() - MAX_PINS);
            }
            bound(&mut kept.removed);
            if accounts.len() >= MAX_ACCOUNTS {
                accounts.remove(0);
            }
            accounts.push(kept);
            dirty = true;
        }
        let kept = accounts.iter().find(|kept| &kept.account == account);
        let pins = merged(kept, cloud(state));
        if state.pinned != pins {
            state.pinned = pins.clone();
        }
        self.applied = pins;
        dirty
    }
}

impl Adapter {
    pub(super) fn sync_dm_pins(&mut self) {
        if self.dm_pins.sync(
            &mut self.app.state,
            &mut self.layout.pinned_accounts,
            &mut self.layout.pinned,
        ) {
            self.write_layout_soon();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fixture(id: &str, name: &str) -> Arc<yapfast_core::chat::ChatRoom> {
        let mut app = Application::default();
        app.dispatch(Action::Preview);
        Arc::new(yapfast_core::chat::ChatRoom {
            id: id.into(),
            name: name.into(),
            direct: true,
            request: false,
            locked: false,
            ..(*app.state.rooms[0]).clone()
        })
    }

    #[test]
    fn pinned_dm_accounts_restore_and_legacy_only_claims_current_dms() {
        let mut active = ActivePins::default();
        let mut accounts = Vec::new();
        let mut legacy = vec!["discord:@me:10".into(), "discord:@me:20".into()];
        let mut state = AppState::default();
        state.discord_user = Some("1".into());
        state.rooms = vec![fixture("discord:@me:10", "Alice")];
        assert!(active.sync(&mut state, &mut accounts, &mut legacy));
        assert_eq!(state.pinned, ["discord:@me:10"]);
        assert_eq!(legacy, ["discord:@me:20"]);
        state.discord_user = Some("2".into());
        state.rooms = vec![fixture("discord:@me:20", "Bob")];
        active.sync(&mut state, &mut accounts, &mut legacy);
        assert_eq!(state.pinned, ["discord:@me:20"]);
        assert!(legacy.is_empty());
        state.discord_user = None;
        active.sync(&mut state, &mut accounts, &mut legacy);
        assert!(state.pinned.is_empty());
        state.discord_user = Some("1".into());
        active.sync(&mut state, &mut accounts, &mut legacy);
        assert_eq!(state.pinned, ["discord:@me:10"]);
        state.pinned.clear();
        state.reset_version += 1;
        active.sync(&mut state, &mut accounts, &mut legacy);
        assert_eq!(state.pinned, ["discord:@me:10"]);
    }

    #[cfg(feature = "discord")]
    #[test]
    fn pinned_dm_cloud_merge_respects_local_unpin_and_new_cloud_entries() {
        let mut active = ActivePins::default();
        let mut accounts = Vec::new();
        let mut legacy = Vec::new();
        let mut state = AppState::default();
        state.discord_user = Some("1".into());
        state.discord_dm_pins = Some(Arc::from(vec!["discord:@me:10".into()]));
        active.sync(&mut state, &mut accounts, &mut legacy);
        assert_eq!(state.pinned, ["discord:@me:10"]);
        let applied = active.applied.as_ptr();
        assert!(!active.sync(&mut state, &mut accounts, &mut legacy));
        assert_eq!(
            active.applied.as_ptr(),
            applied,
            "unchanged refresh reuses the pin vector"
        );
        assert!(Arc::ptr_eq(
            active.incoming.as_ref().unwrap(),
            state.discord_dm_pins.as_ref().unwrap()
        ));
        state.pinned.clear();
        assert!(active.sync(&mut state, &mut accounts, &mut legacy));
        assert!(state.pinned.is_empty());
        assert!(!active.sync(&mut state, &mut accounts, &mut legacy));
        state.discord_dm_pins = Some(Arc::from(vec![
            "discord:@me:10".into(),
            "discord:@me:20".into(),
        ]));
        active.sync(&mut state, &mut accounts, &mut legacy);
        assert_eq!(state.pinned, ["discord:@me:20"]);
        state.pinned.push("discord:@me:10".into());
        active.sync(&mut state, &mut accounts, &mut legacy);
        assert_eq!(state.pinned, ["discord:@me:10", "discord:@me:20"]);
        assert!(accounts[0].removed.is_empty());
        accounts[0].removed = (1000..1200).map(|id| format!("discord:@me:{id}")).collect();
        state.pinned.clear();
        active.sync(&mut state, &mut accounts, &mut legacy);
        assert!(
            state.pinned.is_empty(),
            "the latest explicit unpin must win even after 200 older overrides"
        );
        assert!(accounts[0].removed.contains(&"discord:@me:20".into()));
        assert_eq!(accounts[0].removed.len(), MAX_PINS);
    }

    #[test]
    fn pinned_dm_sidebar_menu_callbacks_pin_unpin_order_and_restart() {
        i_slint_backend_testing::init_no_event_loop();
        let directory = tempfile::tempdir().unwrap();
        let window = YapfastWindow::new().unwrap();
        let adapter = Adapter::new(
            Arc::new(BackgroundRuntime::new().unwrap()),
            directory.path().into(),
            &window,
        )
        .unwrap();
        bind_callbacks(&window, &adapter);
        {
            let mut state = adapter.borrow_mut();
            state.app.state.discord_user = Some("1".into());
            state.app.state.rooms = vec![
                fixture("discord:@me:10", "Alice"),
                fixture("discord:@me:20", "Bob"),
            ];
            state.app.state.navigation = Navigation::DirectMessages;
            state.refresh(&window);
        }
        window.invoke_prepare_menu("discord:@me:20".into(), false);
        assert!(window.get_menu_rows().iter().any(|row| row.id == "pin"
            && row.text == "Pin DM"
            && row.subtitle == "On this device"));
        window.invoke_choose_menu("discord:@me:20".into(), false, "pin".into());
        let rows: Vec<_> = window.get_rooms().iter().collect();
        assert_eq!(rows[0].id, "discord:@me:20");
        assert_eq!(rows[0].heading, "Pinned DMs");
        assert!(rows[0].pinned);
        assert_eq!(rows[1].heading, "Direct Messages");
        assert!(!rows[1].pinned);
        let saved = Layout::read(directory.path());
        assert_eq!(saved.pinned_accounts[0].rooms, ["discord:@me:20"]);
        assert!(saved.pinned.is_empty());
        let mut state = AppState::default();
        state.discord_user = Some("1".into());
        let mut restarted = ActivePins::default();
        let mut saved = saved;
        restarted.sync(&mut state, &mut saved.pinned_accounts, &mut saved.pinned);
        assert_eq!(state.pinned, ["discord:@me:20"]);
        window.invoke_prepare_menu("discord:@me:20".into(), false);
        assert!(
            window
                .get_menu_rows()
                .iter()
                .any(|row| row.id == "unpin" && row.text == "Unpin DM")
        );
        window.invoke_choose_menu("discord:@me:20".into(), false, "unpin".into());
        assert!(adapter.borrow().app.state.pinned.is_empty());
        assert!(window.get_rooms().iter().all(|room| !room.pinned));
        assert_eq!(
            window.get_rooms().row_data(0).unwrap().heading,
            "Direct Messages"
        );
    }

    #[test]
    fn pinned_dm_storage_bounds_accounts_ids_and_removals() {
        let mut accounts: Vec<_> = (1..=12)
            .map(|id| KeptPins {
                account: format!("discord:{id}"),
                rooms: (1..=300).map(|id| format!("discord:@me:{id}")).collect(),
                removed: (301..=600).map(|id| format!("discord:@me:{id}")).collect(),
            })
            .collect();
        tidy(&mut accounts);
        assert_eq!(accounts.len(), MAX_ACCOUNTS);
        assert!(
            accounts
                .iter()
                .all(|kept| kept.rooms.len() == MAX_PINS && kept.removed.len() == MAX_PINS)
        );
    }
}
