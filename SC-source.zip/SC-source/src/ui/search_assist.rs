//! Local suggestions for Discord message-search tokens.
use std::{collections::HashSet, ops::Range};

use yapfast_core::{application::AppState, chat::ChatRoom, discord};

const GROUP_LIMIT: usize = 3;
const VALUE_LIMIT: usize = 40;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum SuggestionGroup {
    Actions,
    Filters,
    From,
    In,
    Has,
    Mentions,
    Before,
    After,
    During,
    Author,
    Pinned,
    Sort,
}

use SuggestionGroup::*;

impl SuggestionGroup {
    fn key(self) -> &'static str {
        match self {
            From => "from",
            In => "in",
            Has => "has",
            Mentions => "mentions",
            Before => "before",
            After => "after",
            During => "during",
            Author => "author",
            Pinned => "pinned",
            Sort => "sort",
            Actions | Filters => "",
        }
    }

    fn filter(key: &str) -> Option<Self> {
        if key.eq_ignore_ascii_case("author-type") {
            return Some(Author);
        }
        [
            From, In, Has, Mentions, Before, After, During, Author, Pinned, Sort,
        ]
        .into_iter()
        .find(|group| key.eq_ignore_ascii_case(group.key()))
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) enum SuggestionAction {
    Submit,
    OpenFilters,
    Replace {
        range: Range<usize>,
        replacement: String,
    },
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct Suggestion {
    pub group: SuggestionGroup,
    pub title: String,
    pub subtitle: String,
    pub avatar: Option<String>,
    pub action: SuggestionAction,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct FilterValue {
    /// The wire-safe value after the colon, without the filter name.
    pub value: String,
    pub label: String,
    pub detail: String,
    pub avatar: Option<String>,
}

struct Scope<'a> {
    room: &'a ChatRoom,
    guild: Option<&'a str>,
}

fn scope(state: &AppState) -> Option<Scope<'_>> {
    let room = state.conversation_that(|capabilities| capabilities.search)?;
    let (guild, _) = discord::parse_room(&room.id)?;
    Some(Scope {
        room,
        guild: (!room.direct).then_some(guild),
    })
}

/// A span at the caret includes a trailing suffix so picking a row replaces
/// the whole token being edited. Filters elsewhere in the input retain their
/// spelling and spacing. A whitespace gap immediately after `from:` belongs
/// with the value the user starts typing there.
fn active_token(input: &str, cursor: usize) -> (Range<usize>, Option<SuggestionGroup>) {
    let mut previous = None;
    let mut token = cursor..cursor;
    let mut start = None;
    let mut quote = false;
    let mut escape = false;
    for (at, ch) in input
        .char_indices()
        .chain(std::iter::once((input.len(), ' ')))
    {
        if at == input.len() || (ch.is_whitespace() && !quote) {
            if let Some(begin) = start.take() {
                if (begin..=at).contains(&cursor) {
                    token = begin..at;
                    break;
                }
                if at <= cursor {
                    previous = Some(begin..at);
                }
            }
            if at >= cursor {
                break;
            }
            continue;
        }
        start.get_or_insert(at);
        if quote && !escape && ch == '\\' {
            escape = true;
        } else {
            if ch == '"' && !escape {
                quote = !quote;
            }
            escape = false;
        }
    }
    if let Some(group) = input[token.clone()]
        .split_once(':')
        .and_then(|(key, _)| SuggestionGroup::filter(key))
    {
        return (token, Some(group));
    }
    let preceding = previous.and_then(|range: Range<usize>| {
        let key = input[range.clone()].strip_suffix(':')?;
        Some((range.start, SuggestionGroup::filter(key)?))
    });
    if let Some((begin, group)) = preceding {
        return (begin..token.end, Some(group));
    }
    (token, None)
}

pub(super) fn suggestions(state: &AppState, input: &str, cursor: usize) -> Vec<Suggestion> {
    let Some(scope) = scope(state) else {
        return vec![];
    };
    let mut caret = cursor.min(input.len());
    while !input.is_char_boundary(caret) {
        caret -= 1;
    }
    let (range, filter) = active_token(input, caret);
    let typed = input.get(range.start..caret).unwrap_or_default();
    let mut rows = Vec::new();
    if let Some(group) = filter {
        let value = typed.split_once(':').map_or("", |(_, value)| value.trim());
        for value in ranked_values(state, &scope, group, value, VALUE_LIMIT) {
            rows.push(value_row(group, value, &range, input));
        }
        return rows;
    }
    let query = input.trim();
    if !query.is_empty() {
        rows.push(Suggestion {
            group: Actions,
            title: format!("Search for {query}"),
            subtitle: String::new(),
            avatar: None,
            action: SuggestionAction::Submit,
        });
    }
    if typed.trim().is_empty() {
        for (group, title, subtitle) in [
            (From, "From a specific user", "from: user"),
            (In, "Sent in a specific channel", "in: channel"),
            (
                Has,
                "Includes a specific type of data",
                "has: link, embed or file",
            ),
            (Mentions, "Mentions a specific user", "mentions: user"),
        ] {
            if group == In && scope.guild.is_none() {
                continue;
            }
            rows.push(Suggestion {
                group: Filters,
                title: title.into(),
                subtitle: subtitle.into(),
                avatar: None,
                action: SuggestionAction::Replace {
                    range: range.clone(),
                    replacement: format!("{}:", group.key()),
                },
            });
        }
    }
    rows.push(Suggestion {
        group: if typed.trim().is_empty() {
            Filters
        } else {
            Actions
        },
        title: if query.is_empty() {
            "More filters"
        } else {
            "Add search filters"
        }
        .into(),
        subtitle: if query.is_empty() {
            "Dates, author type, and more".into()
        } else {
            String::new()
        },
        avatar: None,
        action: SuggestionAction::OpenFilters,
    });
    if !typed.trim().is_empty() {
        let from = people(state, &scope, typed, GROUP_LIMIT);
        rows.extend(
            from.iter()
                .cloned()
                .map(|value| value_row(From, value, &range, input)),
        );
        rows.extend(
            channels(state, &scope, typed, GROUP_LIMIT)
                .into_iter()
                .map(|value| value_row(In, value, &range, input)),
        );
        rows.extend(
            from.into_iter()
                .map(|value| value_row(Mentions, value, &range, input)),
        );
    }
    rows
}

fn value_row(
    group: SuggestionGroup,
    value: FilterValue,
    range: &Range<usize>,
    input: &str,
) -> Suggestion {
    let mut replacement = format!("{}:{}", group.key(), value.value);
    if !input[range.end..].starts_with(char::is_whitespace) {
        replacement.push(' ');
    }
    let subtitle = match group {
        From | Mentions => format!(
            "{}: {}",
            group.key(),
            value
                .detail
                .strip_prefix('@')
                .filter(|name| !name.is_empty())
                .unwrap_or(&value.label)
        ),
        In => String::new(),
        _ => value.detail,
    };
    Suggestion {
        group,
        title: value.label,
        subtitle,
        avatar: value.avatar,
        action: SuggestionAction::Replace {
            range: range.clone(),
            replacement,
        },
    }
}

pub(super) fn values(state: &AppState, key: &str, typed: &str) -> Vec<FilterValue> {
    let (Some(scope), Some(group)) = (scope(state), SuggestionGroup::filter(key)) else {
        return vec![];
    };
    ranked_values(state, &scope, group, typed, VALUE_LIMIT)
}

fn ranked_values(
    state: &AppState,
    scope: &Scope<'_>,
    group: SuggestionGroup,
    typed: &str,
    limit: usize,
) -> Vec<FilterValue> {
    let typed = typed
        .trim()
        .trim_matches('"')
        .trim_start_matches(['@', '#']);
    match group {
        From | Mentions => people(state, scope, typed, limit),
        In => channels(state, scope, typed, limit),
        Before | After | During => dates(typed),
        _ => {
            let options: &[(&str, &str)] = match group {
                Has => &[
                    ("link", "Link"),
                    ("embed", "Embed"),
                    ("poll", "Poll"),
                    ("file", "File"),
                    ("video", "Video"),
                    ("image", "Image"),
                    ("sound", "Sound"),
                    ("sticker", "Sticker"),
                    ("forward", "Forwarded message"),
                ],
                Author => &[("user", "User"), ("bot", "Bot"), ("webhook", "Webhook")],
                Pinned => &[("true", "Pinned"), ("false", "Not pinned")],
                Sort => &[
                    ("newest", "Newest"),
                    ("oldest", "Oldest"),
                    ("relevance", "Most relevant"),
                ],
                _ => &[],
            };
            let exclude = matches!(group, Has | Author) && typed.starts_with('-');
            let query = words(typed);
            options
                .iter()
                .filter(|(value, label)| rank(label, Some(value), &query).is_some())
                .map(|(value, label)| FilterValue {
                    value: if exclude {
                        format!("-{value}")
                    } else {
                        (*value).into()
                    },
                    label: if exclude {
                        format!("Exclude {}", label.to_lowercase())
                    } else {
                        (*label).into()
                    },
                    detail: String::new(),
                    avatar: None,
                })
                .collect()
        }
    }
}

fn words(text: &str) -> String {
    text.split(|ch: char| !ch.is_alphanumeric())
        .filter(|word| !word.is_empty())
        .collect::<Vec<_>>()
        .join(" ")
        .to_lowercase()
}

fn rank(label: &str, alias: Option<&str>, query: &str) -> Option<u8> {
    if query.is_empty() {
        return Some(0);
    }
    let label = words(label);
    let alias = alias.map(words).unwrap_or_default();
    if label == query || alias == query {
        Some(0)
    } else if label.starts_with(query) {
        Some(1)
    } else if alias.starts_with(query) {
        Some(2)
    } else if [&label, &alias].into_iter().any(|name| {
        let mut parts = name.split_whitespace();
        query
            .split_whitespace()
            .all(|term| parts.by_ref().any(|part| part.starts_with(term)))
    }) {
        Some(3)
    } else {
        (label.contains(query) || alias.contains(query)).then_some(4)
    }
}

fn snowflake(id: &str) -> Option<u64> {
    (!id.starts_with('0') && id.bytes().all(|byte| byte.is_ascii_digit()))
        .then(|| id.parse().ok())
        .flatten()
}

fn channels(state: &AppState, scope: &Scope<'_>, typed: &str, limit: usize) -> Vec<FilterValue> {
    let Some(guild) = scope.guild else {
        return vec![];
    };
    let query = words(typed);
    let raw = typed.trim().trim_start_matches("<#").trim_end_matches('>');
    let mut rows: Vec<_> = state
        .rooms
        .iter()
        .filter_map(|room| {
            let (server, id) = discord::parse_room(&room.id)?;
            if server != guild
                || room.direct
                || room.locked
                || room.request
                || !room.capabilities.search
                || snowflake(id).is_none()
            {
                return None;
            }
            let score = if raw == id {
                Some(0)
            } else {
                rank(&room.name, None, &query)
            }?;
            Some((score, room, id))
        })
        .collect();
    rows.sort_by_key(|(score, room, _)| (*score, room.id != scope.room.id));
    rows.into_iter()
        .take(limit)
        .map(|(_, room, id)| FilterValue {
            value: format!("<#{id}>"),
            label: room.name.clone(),
            detail: room.category.clone(),
            avatar: None,
        })
        .collect()
}

struct Person<'a> {
    id: u64,
    name: &'a str,
    username: Option<&'a str>,
    avatar: Option<&'a str>,
}

fn people(state: &AppState, scope: &Scope<'_>, typed: &str, limit: usize) -> Vec<FilterValue> {
    #[cfg(feature = "discord")]
    let names = state.discord_names.as_ref().map(|names| names.read());
    let query = words(typed);
    let typed_id = snowflake(typed.trim().trim_start_matches("<@").trim_end_matches('>'));
    let own = state.discord_user.as_deref().and_then(snowflake);
    let mut seen = HashSet::new();
    let mut ranked = Vec::new();
    let mut add = |person @ Person {
                       id, name, username, ..
                   }| {
        if name.is_empty() || !seen.insert(id) {
            return;
        }
        let score = if typed_id == Some(id) || (query == "me" && own == Some(id)) {
            Some(0)
        } else {
            rank(name, username, &query)
        };
        if let Some(score) = score {
            ranked.push((score, person));
        }
    };
    for member in state
        .members
        .iter()
        .flatten()
        .flat_map(|members| members.iter())
        .chain(state.found_members.iter().filter(|_| scope.guild.is_some()))
    {
        if let Some(id) = snowflake(&member.id) {
            add(Person {
                id,
                name: &member.name,
                username: member.username.as_deref(),
                avatar: member.avatar.as_deref(),
            });
        }
    }
    if let Some(id) = own {
        add(Person {
            id,
            name: state
                .account_name
                .as_deref()
                .or(state.account_username.as_deref())
                .unwrap_or("Me"),
            username: state.account_username.as_deref(),
            avatar: state.account_avatar.as_deref(),
        });
    }
    if let Some(person) = scope.room.person.as_deref().filter(|_| scope.room.direct)
        && let Some(id) = snowflake(person)
    {
        #[cfg(feature = "discord")]
        let username = names.as_ref().and_then(|names| names.username(person));
        #[cfg(not(feature = "discord"))]
        let username = None;
        add(Person {
            id,
            name: &scope.room.name,
            username,
            avatar: scope.room.avatar.as_deref(),
        });
    }
    for message in state
        .messages
        .iter()
        .rev()
        .map(|message| message.as_ref())
        .chain(
            state
                .search_shown()
                .into_iter()
                .flat_map(|search| search.results.iter().map(|hit| &hit.message)),
        )
    {
        if let Some(user) = discord::sender_user(&message.sender)
            && let Some(id) = snowflake(user)
        {
            #[cfg(feature = "discord")]
            let username = names.as_ref().and_then(|names| names.username(user));
            #[cfg(not(feature = "discord"))]
            let username = None;
            add(Person {
                id,
                name: &message.author,
                username,
                avatar: message.avatar.as_deref(),
            });
        }
    }
    #[cfg(feature = "discord")]
    if let (Some(names), Some(guild)) = (&names, scope.guild) {
        let mut known: Vec<_> = names.known_guild_members(guild).collect();
        known.sort_unstable_by_key(|(id, ..)| *id);
        for (id, name, username) in known {
            add(Person {
                id,
                name,
                username,
                avatar: None,
            });
        }
    }
    ranked.sort_by_key(|(score, _)| *score);
    ranked
        .into_iter()
        .take(limit)
        .map(|(_, person)| {
            let avatar = person.avatar.map(str::to_owned);
            #[cfg(feature = "discord")]
            let avatar = avatar.or_else(|| {
                names
                    .as_ref()
                    .map(|names| names.avatar(scope.guild, &person.id.to_string()))
            });
            FilterValue {
                value: format!("<@{}>", person.id),
                label: person.name.to_owned(),
                detail: person
                    .username
                    .map(|username| format!("@{username}"))
                    .unwrap_or_default(),
                avatar,
            }
        })
        .collect()
}

fn dates(typed: &str) -> Vec<FilterValue> {
    use chrono::{Days, Local, NaiveDate};
    if let Ok(date) = NaiveDate::parse_from_str(typed, "%Y-%m-%d") {
        let value = date.to_string();
        return vec![FilterValue {
            label: value.clone(),
            value,
            detail: String::new(),
            avatar: None,
        }];
    }
    let today = Local::now().date_naive();
    [(0, "Today"), (1, "Yesterday"), (7, "Seven days ago")]
        .into_iter()
        .filter_map(|(days, label)| {
            let value = today.checked_sub_days(Days::new(days))?.to_string();
            (value.starts_with(typed) || label.to_lowercase().starts_with(&typed.to_lowercase()))
                .then(|| FilterValue {
                    detail: value.clone(),
                    value,
                    label: label.into(),
                    avatar: None,
                })
        })
        .collect()
}

#[cfg(all(test, feature = "discord"))]
mod tests {
    use super::*;
    use std::sync::{Arc, RwLock};
    use yapfast_core::{
        application::{Application, Navigation},
        chat::Event,
        yapfast_discord::{
            message::Names,
            ready::{Channel, Server},
            service::{Conversation, SharedNames, Snapshot, Status},
        },
    };

    fn fixture() -> Application {
        let mut app = Application::default();
        let mut names = Names::default();
        for (guild, user, nick, handle) in [
            ("10", "2", "✨ Head Chef · Solo", "starchel"),
            ("10", "3", "Mew", "ohmew."),
            ("20", "4", "Solo", "elsewhere"),
        ] {
            names.learn_member(
                guild,
                &serde_json::json!({
                    "user": {"id": user, "username": handle}, "nick": nick
                }),
            );
        }
        let server = |id: &str, channels: &[(&str, &str)]| {
            Server {
                id: id.into(),
                name: format!("Server {id}"),
                owner_id: Some("1".into()),
                text_channels: channels
                    .iter()
                    .map(|(id, name)| Channel {
                        id: (*id).into(),
                        name: (*name).into(),
                        ..Default::default()
                    })
                    .collect(),
                ..Default::default()
            }
            .into()
        };
        app.apply(Event::Discord(Arc::new(Snapshot {
            status: Status::Online,
            user_id: Some("1".into()),
            names: SharedNames::new(Arc::new(RwLock::new(names))),
            servers: vec![
                server(
                    "10",
                    &[
                        ("11", "general"),
                        ("12", "🍕・order-here"),
                        ("13", "order-secret"),
                    ],
                ),
                server("20", &[("21", "order-in-another-server")]),
            ],
            conversations: vec![
                Arc::new(Conversation {
                    id: "30".into(),
                    name: "Local person".into(),
                    person: Some("5".into()),
                    ..Default::default()
                }),
                Arc::new(Conversation {
                    id: "31".into(),
                    name: "Unrelated DM".into(),
                    person: Some("6".into()),
                    ..Default::default()
                }),
            ],
            ..Default::default()
        })));
        app.state.navigation = Navigation::Server("discord:10".into());
        app.state.selected = Some("discord:10:11".into());
        for room in &mut app.state.rooms {
            if room.id == "discord:10:13" {
                Arc::make_mut(room).locked = true;
            }
        }
        app
    }

    #[test]
    fn search_assist_uses_scoped_guild_and_dm_values() {
        let mut app = fixture();
        let users = values(&app.state, "from", "chef solo");
        assert_eq!(
            users
                .iter()
                .map(|user| user.value.as_str())
                .collect::<Vec<_>>(),
            ["<@2>"]
        );
        assert_eq!(values(&app.state, "mentions", "ohm")[0].label, "Mew");
        let rooms = values(&app.state, "in", "order");
        assert_eq!(
            rooms
                .iter()
                .map(|room| room.value.as_str())
                .collect::<Vec<_>>(),
            ["<#12>"]
        );
        assert_eq!(
            values(&app.state, "in", "order h")[0].label,
            "🍕・order-here"
        );

        app.state.navigation = Navigation::DirectMessages;
        app.state.selected = Some("discord:@me:30".into());
        assert!(values(&app.state, "in", "").is_empty());
        assert!(values(&app.state, "from", "solo").is_empty());
        assert!(values(&app.state, "from", "unrelated").is_empty());
        assert_eq!(values(&app.state, "from", "local")[0].value, "<@5>");
    }

    #[test]
    fn search_assist_keeps_other_terms_and_replaces_the_active_token() {
        let app = fixture();
        let input = "🧾 in: orD has:file";
        let caret = input.find("rD").unwrap() + 1;
        let rows = suggestions(&app.state, input, caret);
        assert!(rows.iter().all(|row| row.group == In));
        let row = rows
            .into_iter()
            .find(|row| row.title == "🍕・order-here")
            .unwrap();
        let SuggestionAction::Replace { range, replacement } = row.action else {
            panic!()
        };
        let mut updated = input.to_owned();
        updated.replace_range(range, &replacement);
        assert_eq!(updated, "🧾 in:<#12> has:file");

        let input = r#"from:"Head Chef" has:file"#;
        let caret = input.find(" Chef").unwrap();
        assert!(matches!(
            &suggestions(&app.state, input, caret)[0].action,
            SuggestionAction::Replace { range, replacement }
                if &input[range.clone()] == r#"from:"Head Chef""# && replacement == "from:<@2>"
        ));
        assert_eq!(values(&app.state, "has", "-vi")[0].value, "-video");
        assert_eq!(
            values(&app.state, "during", "2026-11-15")[0].value,
            "2026-11-15"
        );
    }

    #[test]
    fn search_assist_shows_quick_filters_or_grouped_matches() {
        let app = fixture();
        let empty = suggestions(&app.state, "", 0);
        assert_eq!(empty.len(), 5);
        assert_eq!(empty[4].action, SuggestionAction::OpenFilters);
        let typed = suggestions(&app.state, "o", 1);
        assert_eq!(typed[0].action, SuggestionAction::Submit);
        assert_eq!(typed[1].action, SuggestionAction::OpenFilters);
        for group in [From, In, Mentions] {
            assert!(typed.iter().any(|row| row.group == group), "{group:?}");
        }
    }
}
