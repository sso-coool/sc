//! Native checks for the switcher grouping and session-takeover banner.
use super::*;

#[test]
fn parity_grouped_switcher_and_voice_banner_render() {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions { mock_time: true, threading: false, renderer_name: Some("skia".into()) },
    ))).unwrap();
    let window = yapfast::window().unwrap();
    Layout::default().apply_appearance(&window);
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<PictureStore>().on_request(|_| {});
    window.set_workspace(true);
    window.set_dms_selected(true);
    window.set_voice_displaced_room("discord:@me:20".into());
    window.set_can_reconnect_voice(true);
    let reconnect = Rc::new(RefCell::new(String::new()));
    let recorded = reconnect.clone();
    window.on_reconnect_voice(move |id| *recorded.borrow_mut() = id.to_string());
    window.window().set_size(slint::LogicalSize::new(800., 600.));
    window.show().unwrap();
    window.window().take_snapshot().unwrap();
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    let root = i_slint_core::item_tree::ItemRc::new_root(inner.component());
    let label = |text: &str| {
        root.visit_descendants(|item| {
            let caption = item.accessible_string_property(i_slint_core::accessibility::AccessibleStringProperty::Label);
            if item.is_visible() && caption.as_deref() == Some(text) {
                std::ops::ControlFlow::Break(item.clone())
            } else {
                std::ops::ControlFlow::Continue(())
            }
        })
    };
    assert!(label("Reconnect").is_some());
    window.set_switcher_places(ModelRc::new(VecModel::from(vec![
        PlaceRow { id: "22".into(), name: "general".into(), group: "Previous Channels".into(), ..Default::default() },
        PlaceRow { id: "20".into(), name: "new mention".into(), badge: "2".into(), group: "Mentions".into(), ..Default::default() },
    ])));
    window.set_switcher_mention_start(1);
    window.set_switcher_open(true);
    i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(350));
    slint::platform::update_timers_and_animations();
    window.window().take_snapshot().unwrap();
    assert!(label("Quick switcher").is_some());
    assert!(label("new mention, , 2 mentions").is_some());
    assert!(reconnect.borrow().is_empty());
    window.hide().unwrap();
}
