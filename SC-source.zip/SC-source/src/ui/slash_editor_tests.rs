//! Native slash input refinements, using synthetic state and real input events.
use super::*;
use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
use slint::platform::{Key, PointerEventButton, WindowEvent};
use std::ops::ControlFlow;

fn named(window: &YapfastWindow, label: &str) -> ItemRc {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    ItemRc::new_root(inner.component())
        .visit_descendants(|item| {
            if item.is_visible()
                && item
                    .accessible_string_property(AccessibleStringProperty::Label)
                    .as_deref()
                    == Some(label)
            {
                ControlFlow::Break(item.clone())
            } else {
                ControlFlow::Continue(())
            }
        })
        .unwrap_or_else(|| panic!("native input control missing: {label}"))
}

fn click(window: &YapfastWindow, label: &str) {
    let item = named(window, label);
    let point = item.map_to_window(item.geometry().center());
    let position = slint::LogicalPosition::new(point.x, point.y);
    window
        .window()
        .dispatch_event(WindowEvent::PointerMoved { position });
    window.window().dispatch_event(WindowEvent::PointerPressed {
        position,
        button: PointerEventButton::Left,
    });
    window
        .window()
        .dispatch_event(WindowEvent::PointerReleased {
            position,
            button: PointerEventButton::Left,
        });
}

fn key(window: &YapfastWindow, key: Key) {
    text(window, key.into());
}
fn text(window: &YapfastWindow, text: SharedString) {
    window
        .window()
        .dispatch_event(WindowEvent::KeyPressed { text: text.clone() });
    window
        .window()
        .dispatch_event(WindowEvent::KeyReleased { text });
}

fn model(values: Vec<CommandOptionPill>) -> ModelRc<CommandOptionPill> {
    ModelRc::new(VecModel::from(values))
}

fn options(
    window: &YapfastWindow,
    values: &[CommandOptionPill],
    focused: usize,
    replace_text: bool,
) {
    window.set_command_options(model(values.to_vec()));
    window.set_command_before(model(values.iter().take(focused).cloned().collect()));
    window.set_command_after(model(
        values
            .iter()
            .skip(focused.saturating_add(1))
            .cloned()
            .collect(),
    ));
    window.set_command_focus(focused as i32);
    window.set_command_other_values(values.iter().skip(1).any(|option| !option.value.is_empty()));
    if replace_text {
        window.set_draft(
            values
                .get(focused)
                .filter(|option| !option.file)
                .map_or_else(SharedString::default, |option| option.value.clone()),
        );
    }
    window.set_command_text_bytes(window.get_draft().len() as i32);
}

fn fixture(values: Vec<CommandOptionPill>) -> (YapfastWindow, Rc<RefCell<Vec<CommandOptionPill>>>) {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let window = yapfast::window().unwrap();
    Layout::default().apply_appearance(&window);
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<PictureStore>().on_request(|_| {});
    window.set_workspace(true);
    window.set_room_selected(true);
    window.set_room_ready(true);
    window.set_trusted(true);
    window.set_composer_enabled(true);
    window.set_command_name("claim".into());
    window
        .window()
        .set_size(slint::LogicalSize::new(1120., 760.));
    let values = Rc::new(RefCell::new(values));
    options(&window, &values.borrow(), 0, true);
    let (state, weak) = (values.clone(), window.as_weak());
    window.on_focus_command_option(move |index| {
        if let Some(window) = weak.upgrade() {
            options(&window, &state.borrow(), index.max(0) as usize, true);
            window.invoke_place_composer_caret(1_000_000);
        }
    });
    let (state, weak) = (values.clone(), window.as_weak());
    window.on_draft_edited(move |value| {
        if let Some(window) = weak.upgrade() {
            let focus = window.get_command_focus() as usize;
            if let Some(option) = state.borrow_mut().get_mut(focus) {
                option.value = value;
            }
            options(&window, &state.borrow(), focus, false);
        }
    });
    let (state, weak) = (values.clone(), window.as_weak());
    window.on_deselect_command_option(move |index| {
        if let Some(window) = weak.upgrade() {
            let mut values = state.borrow_mut();
            if let Some(option) = values
                .get_mut(index.max(0) as usize)
                .filter(|option| !option.required)
            {
                option.value = "".into();
            }
            options(&window, &values, values.len(), true);
        }
    });
    window.show().unwrap();
    window.window().take_snapshot().unwrap();
    window.invoke_focus_composer();
    (window, values)
}

fn option(name: &str, value: &str, required: bool, file: bool) -> CommandOptionPill {
    CommandOptionPill {
        name: name.into(),
        value: value.into(),
        required,
        file,
        description: format!("Describe {name}").into(),
        ..Default::default()
    }
}

#[test]
fn slash_editor_modes_keep_values_caret_and_optional_deselection() {
    let (window, values) = fixture(vec![
        option("link", "abcd", true, false),
        option("chef", "Mika", false, false),
    ]);
    let sent = Rc::new(Cell::new(0));
    let count = sent.clone();
    window.on_send(move || count.set(count.get() + 1));
    let edits = Rc::new(Cell::new(0));
    let count = edits.clone();
    window.on_edit_last(move || count.set(count.get() + 1));
    for inline in [true, false] {
        window
            .global::<ClientStyle>()
            .set_inline_slash_input(inline);
        window.invoke_focus_command_option(0);
        window.invoke_focus_composer();
        window.invoke_place_composer_caret(2);
        window
            .global::<ClientStyle>()
            .set_inline_slash_input(!inline);
        window.window().take_snapshot().unwrap();
        text(&window, "X".into());
        assert_eq!(
            window.get_draft(),
            "abXcd",
            "mode switch keeps the same editor/caret"
        );
        values.borrow_mut()[0].value = "abcd".into();
        window
            .global::<ClientStyle>()
            .set_inline_slash_input(inline);
        window.invoke_focus_command_option(1);
        window.window().take_snapshot().unwrap();
        click(&window, "Remove optional chef");
        assert_eq!(window.get_command_focus(), 2);
        assert!(values.borrow()[1].value.is_empty());
        assert_eq!(values.borrow()[0].value, "abcd");
        key(&window, Key::UpArrow);
        assert_eq!(
            edits.get(),
            0,
            "neutral slash input must not edit the last ordinary message"
        );
        key(&window, Key::Return);
        assert_eq!(sent.get(), if inline { 1 } else { 2 });
        key(&window, Key::Tab);
        assert_eq!(
            window.get_command_focus(),
            0,
            "Tab from neutral chooses the first field"
        );
        key(&window, Key::Tab);
        assert_eq!(window.get_command_focus(), 1);
        text(&window, "Mika".into());
        assert_eq!(values.borrow()[1].value, "Mika");
    }
    window.hide().unwrap();
}

#[test]
fn slash_editor_boundary_keys_preserve_unicode_selection_and_file_paste_focus() {
    let (window, values) = fixture(vec![
        option("text", "é🙂Z", true, false),
        option("chef", "", false, false),
        option("image", "", false, true),
    ]);
    window.invoke_place_composer_caret(2);
    key(&window, Key::RightArrow);
    assert_eq!(
        window.get_command_focus(),
        0,
        "a UTF-8 caret inside the value stays there"
    );
    window.invoke_place_composer_caret(1_000_000);
    key(&window, Key::RightArrow);
    assert_eq!(window.get_command_focus(), 1);
    key(&window, Key::Backspace);
    assert_eq!(
        window.get_command_focus(),
        0,
        "empty backspace returns to previous value"
    );
    assert_eq!(values.borrow()[0].value, "é🙂Z");
    window.window().dispatch_event(WindowEvent::KeyPressed {
        text: Key::Control.into(),
    });
    text(&window, "a".into());
    window.window().dispatch_event(WindowEvent::KeyReleased {
        text: Key::Control.into(),
    });
    text(&window, "replacement".into());
    assert_eq!(
        window.get_draft(),
        "replacement",
        "normal selection editing still replaces only the active value"
    );
    assert!(values.borrow()[1].value.is_empty());
    // Pointer selection targets the attachment without opening a dialog.
    let files = Rc::new(Cell::new(0));
    let count = files.clone();
    window.on_command_file(move |_| count.set(count.get() + 1));
    let pasted = Rc::new(Cell::new(-1));
    let seen = pasted.clone();
    let weak = window.as_weak();
    window.on_paste_into_composer(move || {
        if let Some(window) = weak.upgrade() {
            seen.set(window.get_command_focus());
        }
    });
    window.window().take_snapshot().unwrap();
    click(&window, "Edit image, optional");
    assert_eq!(window.get_command_focus(), 2);
    assert_eq!(files.get(), 0);
    window.window().dispatch_event(WindowEvent::KeyPressed {
        text: Key::Control.into(),
    });
    text(&window, "v".into());
    window.window().dispatch_event(WindowEvent::KeyReleased {
        text: Key::Control.into(),
    });
    assert_eq!(
        pasted.get(),
        2,
        "paste uses the attachment that was actually selected"
    );
    window.window().take_snapshot().unwrap();
    click(&window, "Choose file for image");
    assert_eq!(files.get(), 1);
    values.borrow_mut()[2].value = "pasted-image.png".into();
    for inline in [true, false] {
        window
            .global::<ClientStyle>()
            .set_inline_slash_input(inline);
        window.invoke_focus_command_option(2);
        window.window().take_snapshot().unwrap();
        let filename = named(&window, "Attached file for image: pasted-image.png");
        let at = filename.map_to_window(filename.geometry().center());
        assert!(at.x > 0. && at.x < 1120. && at.y > 0. && at.y < 760.);
        assert!(
            window.get_draft().is_empty(),
            "the filename is a file indication, not argument text"
        );
    }
    window.hide().unwrap();
}

#[test]
fn slash_editor_many_options_and_long_values_stay_inside_narrow_window() {
    let mut entries: Vec<_> = (0..25)
        .map(|index| {
            option(
                &format!("argument_{index}_with_a_long_name"),
                "",
                index < 2,
                false,
            )
        })
        .collect();
    entries[24].value =
        "A long multiline value with emoji 🙂 and text that should wrap naturally.\n"
            .repeat(16)
            .into();
    let (window, _values) = fixture(entries);
    window
        .window()
        .set_size(slint::LogicalSize::new(800., 600.));
    for inline in [true, false] {
        window
            .global::<ClientStyle>()
            .set_inline_slash_input(inline);
        window.invoke_focus_command_option(24);
        window.invoke_focus_composer();
        window.invoke_place_composer_caret(1_000_000);
        window.window().take_snapshot().unwrap();
        let input = named(&window, "Value for argument_24_with_a_long_name");
        let geometry = input.geometry();
        let point = input.map_to_window(geometry.origin);
        assert!(
            point.x >= 0. && point.x + geometry.width() <= 801.,
            "active input fits horizontally: inline={inline}, origin={point:?}, size={:?}, window={:?}",
            geometry.size,
            window.window().size(),
        );
        // The text item may be taller than its own scroll viewport; its top
        // can scroll out, but its caret's editor remains in the composer.
        let remove = named(&window, "Remove optional argument_24_with_a_long_name");
        let at = remove.map_to_window(remove.geometry().center());
        assert!(
            at.x >= 0. && at.x <= 800. && at.y >= 200. && at.y <= 600.,
            "focused argument and remove control remain reachable: {at:?}"
        );
    }
    // Normal message editing still wraps and retains its exact contents.
    window.set_command_name("".into());
    window.set_command_before(model(vec![]));
    window.set_command_after(model(vec![]));
    window.set_draft("First line\nSecond line 🙂".into());
    window.invoke_focus_composer();
    window.invoke_place_composer_caret(1_000_000);
    text(&window, "!".into());
    assert_eq!(window.get_draft(), "First line\nSecond line 🙂!");
    window.window().take_snapshot().unwrap();
    window.hide().unwrap();
}
