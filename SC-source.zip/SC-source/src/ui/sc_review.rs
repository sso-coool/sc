//! Opt-in native snapshots, using only the testing backend and synthetic data.
use super::*;
use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
use std::{ops::ControlFlow, path::Path};

fn picture(width: u32, height: u32) -> slint::Image {
    let mut pixels = slint::SharedPixelBuffer::<slint::Rgba8Pixel>::new(width, height);
    for (index, pixel) in pixels.make_mut_slice().iter_mut().enumerate() {
        let x = index as u32 % width;
        let y = index as u32 / width;
        *pixel = slint::Rgba8Pixel::new(
            (70 + x * 90 / width) as u8,
            (85 + y * 70 / height) as u8,
            205,
            255,
        );
    }
    slint::Image::from_rgba8(pixels)
}

fn named(window: &YapfastWindow, label: &str) -> ItemRc {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    named_in(&ItemRc::new_root(inner.component()), label)
}

fn named_in(root: &ItemRc, label: &str) -> ItemRc {
    root.visit_descendants(|item| {
        if item.is_visible()
            && item
                .accessible_string_property(AccessibleStringProperty::Label)
                .as_deref()
                == Some(label)
        {
            ControlFlow::Break(item.clone())
        } else {
            ControlFlow::Continue(())
        }
    })
    .unwrap_or_else(|| panic!("visible native control missing: {label}"))
}

fn horizontal_bounds(item: &ItemRc) -> (f32, f32) {
    let geometry = item.geometry();
    let at = item.map_to_window(geometry.origin);
    (at.x, at.x + geometry.width())
}

fn profile_action_bounds(window: &YapfastWindow, name: &str, label: &str) {
    let card = named(window, &format!("{name}'s profile"));
    let (card_left, card_right) = horizontal_bounds(&card);
    let button = named_in(&card, label);
    let (button_left, button_right) = horizontal_bounds(&button);
    let text = button
        .visit_descendants(|item| {
            let matches = item
                .downcast::<i_slint_core::items::SimpleText>()
                .is_some_and(|text| text.as_pin_ref().text() == label)
                || item
                    .downcast::<i_slint_core::items::ComplexText>()
                    .is_some_and(|text| text.as_pin_ref().text() == label);
            if matches && item.is_visible() {
                ControlFlow::Break(item.clone())
            } else {
                ControlFlow::Continue(())
            }
        })
        .unwrap_or_else(|| panic!("rendered friendship label missing: {label}"));
    let (text_left, text_right) = horizontal_bounds(&text);
    assert!(
        text_left >= button_left + 11. && text_right <= button_right - 11.,
        "{label} needs real padding inside its button: text {text_left}..{text_right}, button {button_left}..{button_right}"
    );
    let center = button.map_to_window(button.geometry().center()).y;
    let text_center = text.map_to_window(text.geometry().center()).y;
    assert!(
        (text_center - center).abs() <= 1.,
        "{label} is vertically centered"
    );
    let mut previous_right = button_right;
    for action in [format!("Message {name}"), "More actions".into()] {
        let item = named_in(&card, &action);
        let (left, right) = horizontal_bounds(&item);
        assert!(
            left >= previous_right + 7.,
            "profile actions must not overlap"
        );
        assert!(
            (item.map_to_window(item.geometry().center()).y - center).abs() <= 1.,
            "profile actions share a vertical center"
        );
        assert!(
            right <= card_right - 15.,
            "{action} leaves the profile card's inset"
        );
        previous_right = right;
    }
    assert!(button_left >= card_left + 15. && button_right <= card_right - 15.);
}

#[test]
fn profile_friendship_labels_keep_padding_and_fit_minimum_window() {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let window = yapfast::window().unwrap();
    Layout::default().apply_appearance(&window);
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<PictureStore>().on_request(|_| {});
    window.on_profile_tab_opened(|_| {});
    window.set_workspace(true);
    window.set_trusted(true);
    window.set_profile_large(true);
    window.set_profile_open(true);
    window.show().unwrap();
    for width in [800., 1120., 1600.] {
        window
            .window()
            .set_size(slint::LogicalSize::new(width, 760.));
        for (friend, label) in [
            (1, "Add Friend"),
            (2, "Friend Request Sent"),
            (3, "Accept Friend Request"),
            (4, "Friends"),
        ] {
            window.set_profile(ProfileData {
                id: "review-profile".into(),
                name: "Profile bounds".into(),
                handle: "profile.bounds".into(),
                initial: "P".into(),
                friend,
                can_message: true,
                ..Default::default()
            });
            window.window().take_snapshot().unwrap();
            profile_action_bounds(&window, "Profile bounds", label);
        }
    }
    window.hide().unwrap();
}

#[test]
fn forum_filters_controls_fit_and_dispatch_native_actions() {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let window = yapfast::window().unwrap();
    Layout::default().apply_appearance(&window);
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<PictureStore>().on_request(|_| {});
    window.set_workspace(true);
    window.set_trusted(true);
    window.set_room_selected(true);
    window.set_room_forum(true);
    window.set_posts_searchable(true);
    window.set_posts_searching(true);
    window.set_posts_more(true);
    window.set_post_rows(ModelRc::new(VecModel::from(vec![PostRow {
        room: "discord:10:40".into(),
        name: "A filtered forum post".into(),
        text: "A synthetic first message".into(),
        ..Default::default()
    }])));
    window.set_posts_filter_tags(ModelRc::new(VecModel::from(vec![
        PostTagChoice {
            id: "7".into(),
            tag: PostTag {
                name: "Bug".into(),
                ..Default::default()
            },
            chosen: true,
        },
        PostTagChoice {
            id: "8".into(),
            tag: PostTag {
                name: "Feature request".into(),
                ..Default::default()
            },
            chosen: false,
        },
    ])));
    let calls = Rc::new(RefCell::new(Vec::<String>::new()));
    let capture = calls.clone();
    window.on_filter_posts(move |tag| capture.borrow_mut().push(format!("tag:{tag}")));
    let capture = calls.clone();
    window.on_sort_posts(move |creation| capture.borrow_mut().push(format!("sort:{creation}")));
    let capture = calls.clone();
    window.on_more_posts(move || capture.borrow_mut().push("more".into()));
    window.show().unwrap();
    for width in [800., 1120., 1600.] {
        window
            .window()
            .set_size(slint::LogicalSize::new(width, 760.));
        window.window().take_snapshot().unwrap();
        let (left, right) = horizontal_bounds(&named(&window, "Posts"));
        let latest = named(&window, "Sort by latest activity");
        let newest = named(&window, "Sort by newest posts");
        let (latest_left, latest_right) = horizontal_bounds(&latest);
        let (newest_left, newest_right) = horizontal_bounds(&newest);
        assert!(
            latest_left >= left + 15. && newest_right <= right - 15.,
            "sort controls fit the forum at {width}"
        );
        assert!(
            newest_left >= latest_right + 5.,
            "sort controls do not overlap"
        );
        for label in [
            "Sort by newest posts",
            "Filter tag Bug, selected",
            "Load more posts",
        ] {
            named(&window, label)
                .accessible_action(&i_slint_core::accessibility::AccessibilityAction::Default);
        }
    }
    assert_eq!(*calls.borrow(), ["sort:true", "tag:7", "more"].repeat(3));
    window.hide().unwrap();
}

fn popup_bounds(window: &YapfastWindow, label: &str, width: u32, height: u32) {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    let popups = inner.active_popups();
    let popup = popups.last().expect("native menu must be open");
    let i_slint_core::window::PopupWindowLocation::ChildWindow(place) = popup.location else {
        panic!("offscreen popup must be embedded");
    };
    let panel = ItemRc::new_root(popup.component.clone())
        .visit_descendants(|item| {
            if item.is_visible()
                && item
                    .accessible_string_property(AccessibleStringProperty::Label)
                    .as_deref()
                    == Some(label)
            {
                ControlFlow::Break(item.clone())
            } else {
                ControlFlow::Continue(())
            }
        })
        .unwrap_or_else(|| panic!("menu panel {label} missing"));
    let geometry = panel.geometry();
    let point = panel.map_to_item_tree(geometry.origin, &popup.component);
    let left = place.x + point.x;
    let top = place.y + point.y;
    assert!(
        left >= 0. && left + geometry.width() <= width as f32 + 1.,
        "{label} leaves horizontal viewport"
    );
    assert!(
        top >= 0. && top + geometry.height() <= height as f32 + 1.,
        "{label} leaves vertical viewport"
    );
}

fn close_menu(window: &YapfastWindow) {
    window
        .window()
        .dispatch_event(slint::platform::WindowEvent::KeyPressed {
            text: slint::platform::Key::Escape.into(),
        });
    window
        .window()
        .dispatch_event(slint::platform::WindowEvent::KeyReleased {
            text: slint::platform::Key::Escape.into(),
        });
    // Message menus inherit the popup's close policy rather than ContextMenu keys.
    i_slint_core::window::WindowInner::from_pub(window.window()).close_all_popups();
}

fn capture(window: &YapfastWindow, output: &Path, name: &str, width: u32, height: u32) {
    window
        .window()
        .set_size(slint::LogicalSize::new(width as f32, height as f32));
    // Materialize layout before advancing the popup motions, then render only
    // a bounded number of frames. Mock time never sleeps or drives a desktop.
    for _ in 0..4 {
        let _ = window.invoke_timeline_extent();
        window.window().take_snapshot().unwrap();
        i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(250));
        slint::platform::update_timers_and_animations();
    }
    // The synthetic backend has no connection to maintain. Leave the Local
    // preview banner visible, but omit its unrelated offline notice.
    window.set_notice(SharedString::default());
    window.set_sidebar_title("S;C lounge".into());
    let frame = window.window().take_snapshot().unwrap();
    assert_eq!((frame.width(), frame.height()), (width, height));
    assert!(
        frame.as_slice().windows(2).any(|pair| pair[0] != pair[1]),
        "{name} must contain rendered UI, not a flat frame"
    );
    image::save_buffer(
        output.join(name),
        frame.as_bytes(),
        width,
        height,
        image::ColorType::Rgba8,
    )
    .unwrap();
}

fn review_message() -> MessageRow {
    use yapfast_core::chat::{ButtonStyle, Card, CardButton, CardRow, Embed, EmbedField};
    let button = |label: &str, style| CardButton {
        label: label.into(),
        style,
        custom_id: Some(format!("review:{label}")),
        url: None,
        sku_id: None,
        disabled: false,
    };
    let message = ChatMessage {
        id: "review-message".into(),
        item: "review:message".into(),
        author: "Cart Assistant".into(),
        sender: "review:bot".into(),
        bot: true,
        time: "12:45".into(),
        body: "Your receipt and build are ready.".into(),
        embeds: vec![Embed {
            color: Some(0x66cfa5),
            title: "Card payment confirmed — your order is ready for download".into(),
            description: "A long receipt title should stay readable beside its thumbnail.".into(),
            fields: vec![
                EmbedField {
                    name: "Amount".into(),
                    value: "$24.00 USD".into(),
                    inline: true,
                    ..Default::default()
                },
                EmbedField {
                    name: "Payment method".into(),
                    value: "Card ending in 4242".into(),
                    inline: true,
                    ..Default::default()
                },
                EmbedField {
                    name: "Receipt".into(),
                    value: "```text\nORDER-EXAMPLE-0123456789\nStatus: confirmed\n```".into(),
                    inline: false,
                    ..Default::default()
                },
            ],
            footer: "Synthetic review fixture · no payment or request was made".into(),
            ..Default::default()
        }],
        cards: vec![Card {
            framed: true,
            color: Some(0x9e97ee),
            rows: vec![
                CardRow::Text {
                    text: "### Build ready\nChoose what happens next.".into(),
                    mentions: vec![],
                    beside: None,
                },
                CardRow::Buttons(vec![
                    button("DownloadCart JS", ButtonStyle::Primary),
                    button("Rebuild", ButtonStyle::Secondary),
                    button("Abort", ButtonStyle::Danger),
                ]),
            ],
        }],
        ..Default::default()
    };
    let mut row = message_row(&message, &HashSet::new());
    let mut embed = row.embeds.row_data(0).unwrap();
    embed.thumbnail = picture(96, 96);
    embed.has_thumbnail = true;
    embed.thumbnail_loading = false;
    row.embeds = ModelRc::new(VecModel::from(vec![embed]));
    row.has_command = true;
    row.command_user = "Aurora".into();
    row.command_sender = "review:user".into();
    row.command_initial = "A".into();
    row.command_name = "/fetch".into();
    row.command_slash = "fetch".into();
    row.command_inspectable = true;
    row.command_detail = "/fetch lines: 1".into();
    row
}

#[test]
fn message_delete_menu_near_composer_and_confirmation_stay_visible() {
    use slint::platform::{PointerEventButton, WindowEvent};
    fn click(window: &YapfastWindow, position: slint::LogicalPosition, button: PointerEventButton) {
        window
            .window()
            .dispatch_event(WindowEvent::PointerMoved { position });
        window
            .window()
            .dispatch_event(WindowEvent::PointerPressed { position, button });
        window
            .window()
            .dispatch_event(WindowEvent::PointerReleased { position, button });
    }
    fn settle(window: &YapfastWindow) {
        for _ in 0..3 {
            window.window().take_snapshot().unwrap();
            i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(16));
            slint::platform::update_timers_and_animations();
        }
    }
    fn menu_point(window: &YapfastWindow, label: &str) -> slint::LogicalPosition {
        let inner = i_slint_core::window::WindowInner::from_pub(window.window());
        let popups = inner.active_popups();
        let popup = popups.last().unwrap();
        let i_slint_core::window::PopupWindowLocation::ChildWindow(place) = popup.location else {
            panic!("review uses embedded native popups");
        };
        let item = named_in(&ItemRc::new_root(popup.component.clone()), label);
        let local = item.map_to_item_tree(item.geometry().center(), &popup.component);
        slint::LogicalPosition::new(place.x + local.x, place.y + local.y)
    }
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    for (width, height, tall, writable, aside) in [
        (800., 600., false, true, false),
        (800., 600., true, true, false),
        (1120., 760., true, false, false),
        (1120., 760., true, false, true),
        (1120., 760., true, true, true),
    ] {
        eprintln!("delete case {width}x{height}: tall={tall}, writable={writable}, aside={aside}");
        let window = yapfast::window().unwrap();
        Layout::default().apply_appearance(&window);
        window.global::<ClientStyle>().set_interface_motion(false);
        window.global::<PictureStore>().on_request(|_| {});
        window.set_workspace(true);
        window.set_room_selected(true);
        window.set_room_ready(true);
        window.set_room_name("general".into());
        window.set_composer_enabled(!aside && writable);
        window.set_trusted(true);
        window.set_members_available(true);
        let mut row = message_row(
            &ChatMessage {
                item: "d:900".into(),
                author: "Review author".into(),
                body: if tall {
                    "A long message line that stays in the timeline.\n".repeat(50)
                } else {
                    "Message immediately above the composer".into()
                },
                ..Default::default()
            },
            &HashSet::new(),
        );
        row.can_delete = true;
        row.can_reply = true;
        row.can_edit = true;
        if aside {
            window.set_aside_open(true);
            window.set_aside_name("Review thread".into());
            window.set_aside_room("discord:10:22".into());
            window.set_aside_ready(true);
            window.set_aside_composer_enabled(writable);
            window.set_aside_messages(ModelRc::new(VecModel::from(vec![row])));
        } else {
            window.set_messages(ModelRc::new(VecModel::from(vec![row])));
        }
        let requested = Rc::new(RefCell::new(Vec::new()));
        let request = requested.clone();
        let weak = window.as_weak();
        window.on_request_delete(move |item| {
            request.borrow_mut().push(item.to_string());
            weak.unwrap().set_confirm_delete(item);
        });
        let deleted = Rc::new(Cell::new(0));
        let calls = deleted.clone();
        let weak = window.as_weak();
        window.on_confirm_delete_message(move || {
            calls.set(calls.get() + 1);
            weak.unwrap().set_confirm_delete(SharedString::default());
        });
        let weak = window.as_weak();
        window.on_cancel_delete(move || weak.unwrap().set_confirm_delete(SharedString::default()));
        title_bar::show(&window, Some(false));
        window.show().unwrap();
        window
            .window()
            .set_size(slint::LogicalSize::new(width, height));
        for _ in 0..3 {
            let _ = window.invoke_timeline_extent();
            window.window().take_snapshot().unwrap();
            i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(100));
            slint::platform::update_timers_and_animations();
        }
        let save = |stage: &str| {
            if let Some(directory) = std::env::var_os("SC_DELETE_REVIEW_DIR") {
                let directory = Path::new(&directory);
                std::fs::create_dir_all(directory).unwrap();
                let frame = window.window().take_snapshot().unwrap();
                let name = format!(
                    "delete-{stage}-{}x{}-tall{tall}-write{writable}-aside{aside}.png",
                    width as u32, height as u32
                );
                image::save_buffer(
                    directory.join(name),
                    frame.as_bytes(),
                    frame.width(),
                    frame.height(),
                    image::ColorType::Rgba8,
                )
                .unwrap();
            }
        };
        let chat = named(&window, if aside { "Thread messages" } else { "Messages" });
        let geometry = chat.geometry();
        let at = chat.map_to_window(geometry.origin);
        let position = slint::LogicalPosition::new(at.x + 96., at.y + geometry.height() - 30.);
        let row_position = position;
        window
            .window()
            .dispatch_event(WindowEvent::PointerMoved { position });
        window.window().dispatch_event(WindowEvent::PointerPressed {
            position,
            button: PointerEventButton::Right,
        });
        window
            .window()
            .dispatch_event(WindowEvent::PointerReleased {
                position,
                button: PointerEventButton::Right,
            });
        settle(&window);
        popup_bounds(&window, "Message menu", width as u32, height as u32);
        let before = menu_point(&window, "Delete message");
        if aside && writable {
            menu_point(&window, "Edit message");
            menu_point(&window, "Reply");
        }
        window.set_app_menu_commands(ModelRc::new(VecModel::from(
            (0..if aside && writable { 2 } else { 24 })
                .map(|index| CommandChoice {
                    id: format!("review:{index}").into(),
                    name: format!("Command {index}").into(),
                    app: "Offline app".into(),
                    ..Default::default()
                })
                .collect::<Vec<_>>(),
        )));
        window.window().take_snapshot().unwrap();
        let initial = menu_point(&window, "Delete message");
        // Popup windows settle their location after a newly loaded row changes
        // layout. Observe real frame boundaries, rather than a half-laid-out tree.
        for _ in 0..2 {
            i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(16));
            slint::platform::update_timers_and_animations();
            window.window().take_snapshot().unwrap();
        }
        let loaded = menu_point(&window, "Delete message");
        eprintln!(
            "Delete position: before={before:?}, first Apps frame={initial:?}, settled={loaded:?}, pointer={row_position:?}"
        );
        popup_bounds(&window, "Message menu", width as u32, height as u32);
        assert!(
            loaded.y >= row_position.y - 60. && loaded.y <= row_position.y + 34.,
            "adding Apps may flip placement above the pointer; the primary menu must stay nearby: {before:?} -> {loaded:?}"
        );
        let position = menu_point(&window, "Apps");
        window
            .window()
            .dispatch_event(WindowEvent::PointerMoved { position });
        window.window().take_snapshot().unwrap();
        for _ in 0..2 {
            i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(16));
            slint::platform::update_timers_and_animations();
            window.window().take_snapshot().unwrap();
        }
        popup_bounds(&window, "Message menu", width as u32, height as u32);
        popup_bounds(&window, "Message Apps submenu", width as u32, height as u32);
        let position = menu_point(&window, "Delete message");
        assert!(
            (loaded.y - position.y).abs() <= 1.,
            "opening Apps must not move the primary menu"
        );
        assert!(position.x > 0. && position.x < width && position.y > 0. && position.y < height);
        save("menu");
        window
            .window()
            .dispatch_event(WindowEvent::PointerMoved { position });
        window.window().dispatch_event(WindowEvent::PointerPressed {
            position,
            button: PointerEventButton::Left,
        });
        window
            .window()
            .dispatch_event(WindowEvent::PointerReleased {
                position,
                button: PointerEventButton::Left,
            });
        window.window().take_snapshot().unwrap();
        save("confirmation");
        assert_eq!(&*requested.borrow(), &["d:900"]);
        assert_eq!(deleted.get(), 0, "opening confirmation must not delete");
        for label in ["Delete", "Cancel"] {
            let item = named(&window, label);
            let geometry = item.geometry();
            let at = item.map_to_window(geometry.origin);
            assert!(
                at.x >= 0.
                    && at.x + geometry.width() <= width
                    && at.y >= 0.
                    && at.y + geometry.height() <= height,
                "{label} confirmation is clipped: {at:?}, {geometry:?}, tall={tall}, writable={writable}"
            );
        }
        let cancel = named(&window, "Cancel");
        let at = cancel.map_to_window(cancel.geometry().center());
        let position = slint::LogicalPosition::new(at.x, at.y);
        window
            .window()
            .dispatch_event(WindowEvent::PointerMoved { position });
        window.window().dispatch_event(WindowEvent::PointerPressed {
            position,
            button: PointerEventButton::Left,
        });
        window
            .window()
            .dispatch_event(WindowEvent::PointerReleased {
                position,
                button: PointerEventButton::Left,
            });
        assert!(window.get_confirm_delete().is_empty());
        assert_eq!(deleted.get(), 0);
        window.window().take_snapshot().unwrap();
        click(&window, row_position, PointerEventButton::Right);
        window.window().take_snapshot().unwrap();
        click(
            &window,
            menu_point(&window, "Delete message"),
            PointerEventButton::Left,
        );
        window.window().take_snapshot().unwrap();
        let confirm = named(&window, "Delete");
        let at = confirm.map_to_window(confirm.geometry().center());
        click(
            &window,
            slint::LogicalPosition::new(at.x, at.y),
            PointerEventButton::Left,
        );
        assert_eq!(
            deleted.get(),
            1,
            "only explicit confirmation calls the local delete mock"
        );
        assert!(window.get_confirm_delete().is_empty());
        // The submenu footprint is reserved for stable fast pointer clicks;
        // its transparent area must still dismiss the visible menu.
        click(&window, row_position, PointerEventButton::Right);
        settle(&window);
        let blank = {
            let inner = i_slint_core::window::WindowInner::from_pub(window.window());
            let popups = inner.active_popups();
            let popup = popups.last().unwrap();
            let i_slint_core::window::PopupWindowLocation::ChildWindow(place) = popup.location
            else {
                panic!("review uses embedded native popups");
            };
            let panel = named_in(&ItemRc::new_root(popup.component.clone()), "Message menu");
            let geometry = panel.geometry();
            let at = panel.map_to_item_tree(geometry.origin, &popup.component);
            assert!(at.y > 4., "reserved space exists above the primary menu");
            slint::LogicalPosition::new(place.x + at.x + geometry.width() / 2., place.y + 2.)
        };
        click(&window, blank, PointerEventButton::Left);
        assert!(
            i_slint_core::window::WindowInner::from_pub(window.window())
                .active_popups()
                .is_empty()
        );
        click(&window, row_position, PointerEventButton::Right);
        settle(&window);
        click(
            &window,
            slint::LogicalPosition::new(2., 2.),
            PointerEventButton::Left,
        );
        assert!(
            i_slint_core::window::WindowInner::from_pub(window.window())
                .active_popups()
                .is_empty()
        );
        assert_eq!(deleted.get(), 1, "outside clicks never delete");
        window.hide().unwrap();
    }
}

#[test]
#[ignore = "manual native visual review; requires renderer-skia and SC_REVIEW_DIR"]
fn sc_visual_review_snapshots() {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let output = std::env::var_os("SC_REVIEW_DIR").expect("set SC_REVIEW_DIR for review PNGs");
    let output = Path::new(&output);
    std::fs::create_dir_all(output).unwrap();
    let window = yapfast::window().unwrap();
    window.set_emoji_font(emoji::family().into());
    emoji_text::register();
    window
        .global::<Twemoji>()
        .on_text(|text| emoji_text::text(&text).into());
    Layout::default().apply_appearance(&window);
    let directory = tempfile::tempdir().unwrap();
    let adapter = Adapter::new(
        Arc::new(BackgroundRuntime::new().unwrap()),
        directory.path().into(),
        &window,
    )
    .unwrap();
    bind_callbacks(&window, &adapter);
    // All assets below are in memory, and opening the synthetic profile
    // cannot request a service. No interaction or link callback is invoked.
    window.global::<PictureStore>().on_request(|_| {});
    window.on_profile_tab_opened(|_| {});
    adapter.borrow_mut().action(&window, Action::Preview);
    window.set_sidebar_title("S;C lounge".into());
    window.set_workspace(true);
    window.set_room_selected(true);
    window.set_room_ready(true);
    window.set_composer_enabled(true);
    window.set_trusted(true);
    window.set_messages(ModelRc::new(VecModel::from(vec![review_message()])));
    // Tests default to an OS title bar; this build is installed with its own.
    title_bar::show(&window, Some(false));
    window.show().unwrap(); // TestingBackend owns this offscreen window.
    for (width, height) in [(800, 600), (1120, 760), (1600, 900)] {
        capture(
            &window,
            output,
            &format!("chat-{width}x{height}.png"),
            width,
            height,
        );
        // The native Messages focus scope fills only the conversation, so
        // its right edge is the member panel boundary, not the window edge.
        let (chat_left, chat_right) = horizontal_bounds(&named(&window, "Messages"));
        for label in ["DownloadCart JS", "Rebuild", "Abort"] {
            let (left, right) = horizontal_bounds(&named(&window, label));
            assert!(
                left >= chat_left - 1. && right <= chat_right + 1.,
                "{label} bounds [{left}, {right}] leave chat [{chat_left}, {chat_right}] at {width}x{height}"
            );
        }
    }

    for id in ["sc-civic", "sc-civic-night", "sc-discord"] {
        theme::find(id).unwrap().theme.apply(&window);
        capture(&window, output, &format!("{id}-1120x760.png"), 1120, 760);
    }
    theme::SC_MIDNIGHT.apply(&window);
    for density in [0, 2] {
        window.global::<ClientStyle>().set_density(density);
        capture(
            &window,
            output,
            &format!("density-{density}-800x600.png"),
            800,
            600,
        );
        let (left, right) = horizontal_bounds(&named(&window, "Messages"));
        assert!(left >= 0. && right <= 801.);
    }
    window.global::<ClientStyle>().set_density(1);
    window.global::<ClientStyle>().set_enhanced_surfaces(false);
    capture(&window, output, "classic-finish-1120x760.png", 1120, 760);
    window.global::<ClientStyle>().set_enhanced_surfaces(true);

    // These are inert, synthetic picker rows. Keyboard highlight and narrow
    // popup bounds can be reviewed without asking Discord for commands.
    window.set_command_choices(ModelRc::new(VecModel::from(
        (0..12)
            .map(|index| CommandChoice {
                id: format!("review:{index}").into(),
                app: "Cart Assistant".into(),
                icon: picture(64, 64),
                name: if index == 0 {
                    "fetch".into()
                } else {
                    format!("fetch option{index}").into()
                },
                description: "Fetch recent order details and choose the number of lines.".into(),
                application_id: "500".into(),
                favorite_app: true,
                source_index: index,
                ..Default::default()
            })
            .collect::<Vec<_>>(),
    )));
    window.set_command_heading("Commands matching /fet".into());
    window.set_command_rows_are_commands(true);
    window.set_command_picker_open(true);
    window.set_command_choice_index(10);
    for (width, height) in [(800, 600), (1120, 760), (1600, 900)] {
        capture(
            &window,
            output,
            &format!("commands-{width}x{height}.png"),
            width,
            height,
        );
        let popup = named(&window, "Application commands");
        let (left, right) = horizontal_bounds(&popup);
        assert!(left >= 0. && right <= width as f32 + 1.);
        let bounds = popup.geometry();
        let position = popup.map_to_window(bounds.origin);
        assert!(position.y >= 64. && position.y + bounds.height() <= height as f32);
        let selected = named(
            &window,
            "/fetch option10, Cart Assistant, Fetch recent order details and choose the number of lines.",
        );
        let selected_y = selected.map_to_window(selected.geometry().origin).y;
        assert!(
            selected_y >= position.y
                && selected_y + selected.geometry().height() <= position.y + bounds.height()
        );
    }
    window.set_command_picker_open(false);

    // The active editor, separate from the command suggestion popover above.
    // These inert option values cannot execute a command or open an account.
    let link = CommandOptionPill {
        name: "link".into(),
        description: "The order link".into(),
        value: "https://example.test/order/123".into(),
        required: true,
        ..Default::default()
    };
    let chef = CommandOptionPill {
        name: "chef".into(),
        description: "Optional chef name".into(),
        ..Default::default()
    };
    window.global::<ClientStyle>().set_inline_slash_input(true);
    window.set_command_name("claim".into());
    window.set_command_options(ModelRc::new(VecModel::from(vec![link.clone(), chef])));
    window.set_command_before(ModelRc::new(VecModel::from(vec![link])));
    window.set_command_after(ModelRc::default());
    window.set_command_focus(1);
    window.set_command_text_bytes(0);
    window.set_command_other_values(true);
    window.set_draft(SharedString::default());
    capture(&window, output, "slash-input-800x600.png", 800, 600);
    let value = named(&window, "Value for chef");
    let (left, right) = horizontal_bounds(&value);
    assert!(left >= 0. && right <= 800.);
    named(&window, "Remove optional chef");
    window.set_command_name(SharedString::default());
    window.set_command_options(ModelRc::default());
    window.set_command_before(ModelRc::default());
    window.set_command_after(ModelRc::default());
    window.set_command_focus(0);
    window.set_command_other_values(false);

    let glyphs = ["💀", "😂", "😭", "😄", "😅", "😊", "🥰", "😎", "🤩", "🙂"];
    window.set_emoji_suggestions(ModelRc::new(VecModel::from(
        glyphs
            .iter()
            .enumerate()
            .map(|(index, glyph)| EmojiCell {
                glyph: (*glyph).into(),
                name: if index == 0 {
                    ":skull:".into()
                } else {
                    format!(":smile_{index}:").into()
                },
                key: (*glyph).into(),
                picture: crate::twemoji::picture(glyph, 24., 1.).unwrap(),
                usable: true,
            })
            .collect::<Vec<_>>(),
    )));
    window.set_emoji_suggestion_query("smi".into());
    window.set_emoji_suggestion_index(9);
    for (width, height) in [(800, 600), (1120, 760), (1600, 900)] {
        capture(
            &window,
            output,
            &format!("emoji-{width}x{height}.png"),
            width,
            height,
        );
        let popup = named(&window, "Emoji suggestions");
        let position = popup.map_to_window(popup.geometry().origin);
        assert!(position.y >= 64. && position.y + popup.geometry().height() <= height as f32);
        let selected = named(&window, ":smile_9:");
        let selected_y = selected.map_to_window(selected.geometry().origin).y;
        assert!(
            selected_y >= position.y
                && selected_y + selected.geometry().height()
                    <= position.y + popup.geometry().height()
        );
    }
    window.set_emoji_suggestions(ModelRc::new(VecModel::<EmojiCell>::default()));

    let details_requested = Rc::new(Cell::new(false));
    let request = details_requested.clone();
    window.on_inspect_command(move |_, item| {
        assert_eq!(item, "review:message");
        request.set(true);
    });
    let chip = named(&window, "Use /fetch");
    let at = chip.map_to_window(chip.geometry().origin);
    window
        .window()
        .dispatch_event(slint::platform::WindowEvent::PointerMoved {
            position: slint::LogicalPosition::new(at.x + 6., at.y + 8.),
        });
    capture(&window, output, "command-details-1600x900.png", 1600, 900);
    assert!(
        details_requested.get(),
        "command inspection must request details on hover"
    );
    let _ = named(&window, "/fetch lines: 1");
    window
        .window()
        .dispatch_event(slint::platform::WindowEvent::PointerExited);
    let long_details = "/ologroup link: https://example.test/group-order/join/00000000-1111-2222-3333-444444444444";
    let mut linked = review_message();
    linked.command_detail = long_details.into();
    // Keep this reply short so its command header is in view at 600px tall.
    // Tall embed scrolling is already exercised by the chat frames above.
    linked.embeds = ModelRc::new(VecModel::<EmbedCard>::default());
    linked.cards = ModelRc::new(VecModel::<ComponentCard>::default());
    window.set_messages(ModelRc::new(VecModel::from(vec![linked])));
    capture(
        &window,
        output,
        "command-link-details-800x600.png",
        800,
        600,
    );
    let chip = named(&window, "Use /fetch");
    let at = chip.map_to_window(chip.geometry().origin);
    window
        .window()
        .dispatch_event(slint::platform::WindowEvent::PointerMoved {
            position: slint::LogicalPosition::new(at.x + 6., at.y + 8.),
        });
    capture(
        &window,
        output,
        "command-link-details-800x600.png",
        800,
        600,
    );
    let tooltip = named(&window, long_details);
    let (left, right) = horizontal_bounds(&tooltip);
    let y = tooltip.map_to_window(tooltip.geometry().origin).y;
    assert!(left >= 8. && right <= 792. && y >= 8.);
    assert!(
        tooltip.geometry().height() > 32.,
        "long command contents must wrap"
    );
    window
        .window()
        .dispatch_event(slint::platform::WindowEvent::PointerExited);

    window.set_settings_section(7);
    window.set_settings_open(true);
    capture(&window, output, "appearance-1600x900.png", 1600, 900);
    let (left, right) = horizontal_bounds(&named(&window, "Themes"));
    assert!(
        left >= 0. && right <= 1601.,
        "theme gallery leaves the viewport"
    );
    window.set_settings_open(false);

    let profile_name = "Aurora with a styled display name";
    let activity_name =
        "A very long song title with enough words to exercise the profile's right edge";
    window.set_profile(ProfileData {
        id: "review-profile".into(),
        name: profile_name.into(),
        initial: "A".into(),
        picture: picture(96, 96),
        banner: picture(340, 140),
        name_style: name_style::row(Some(&yapfast_core::chat::NameStyle::new(14, 3, &[0x99aaff])), profile_name),
        handle: "aurora.example".into(),
        friend: 4,
        can_message: true,
        presence: "online".into(),
        bio: slint::StyledText::from_plain_text("A synthetic profile for checking native layout, names, and activity cards."),
        has_bio: true,
        created: "May 4, 2024".into(),
        activities: ModelRc::new(VecModel::from(vec![ActivityRow {
            heading: "LISTENING TO SPOTIFY".into(),
            name: activity_name.into(),
            details: "by An artist with an unusually long display name".into(),
            state: "on A very long album title that must stay inside this column".into(),
            link: "review://song".into(),
            ..Default::default()
        }])),
        recent: ModelRc::new(VecModel::from((0..4).map(|index| ProfileRecentRow {
            title: format!("Recent activity {index}: a deliberately long game or song title that cannot widen its card").into(),
            subtitle: "A very long artist, studio, or session detail that should elide at the panel edge".into(),
            when: "Played for 2 hours and 45 minutes · yesterday evening".into(),
            initial: "R".into(),
            music: index % 2 == 0,
            ..Default::default()
        }).collect::<Vec<_>>())),
        recent_known: true,
        mutuals_known: true,
        wishlist_tab: true,
        friends_tab: true,
        servers_tab: true,
        friends_label: "24 Mutual Friends".into(),
        servers_label: "12 Mutual Servers".into(),
        ..Default::default()
    });
    window.set_profile_large(true);
    window.set_profile_open(true);
    for (width, height) in [(800, 600), (1120, 760), (1600, 900)] {
        capture(
            &window,
            output,
            &format!("profile-{width}x{height}.png"),
            width,
            height,
        );
        let (left, right) =
            horizontal_bounds(&named(&window, &format!("{profile_name}'s full profile")));
        assert!(left >= 0. && right <= width as f32 + 1.);
        profile_action_bounds(&window, profile_name, "Friends");
        for label in [format!("Open {activity_name}"), "Close profile".into()] {
            let (child_left, child_right) = horizontal_bounds(&named(&window, &label));
            assert!(
                child_left >= left - 1. && child_right <= right + 1.,
                "{label} leaves the profile"
            );
        }
    }
    window.set_profile_open(false);
    let favorites = window.global::<yapfast_ui::ChannelFavorites>();
    favorites.set_active(true);
    favorites.set_enabled(true);
    favorites.set_has_cloud(true);
    favorites.set_imported(true);
    favorites.set_showing(true);
    favorites.set_count(7);
    favorites.set_status(SharedString::default());
    favorites.set_rows(ModelRc::new(VecModel::from(vec![
        yapfast_ui::FavoriteChannelRow {
            key: "review:category".into(),
            title: "Daily spaces".into(),
            category: true,
            ..Default::default()
        },
        yapfast_ui::FavoriteChannelRow {
            key: "review:channel".into(),
            title: "announcements-and-releases".into(),
            subtitle: "Community with a long server name".into(),
            available: true,
            selected: true,
            unread: true,
            badge: "3".into(),
            ..Default::default()
        },
        yapfast_ui::FavoriteChannelRow {
            key: "review:voice".into(),
            title: "Evening lounge".into(),
            subtitle: "S;C community".into(),
            available: true,
            voice: true,
            ..Default::default()
        },
        yapfast_ui::FavoriteChannelRow {
            key: "review:forum".into(),
            title: "ideas-and-feedback".into(),
            subtitle: "S;C community".into(),
            available: true,
            forum: true,
            ..Default::default()
        },
        yapfast_ui::FavoriteChannelRow {
            key: "review:friends".into(),
            title: "Friends".into(),
            category: true,
            ..Default::default()
        },
        yapfast_ui::FavoriteChannelRow {
            key: "review:dm".into(),
            title: "Aurora".into(),
            subtitle: "Direct message".into(),
            available: true,
            direct: true,
            initial: "A".into(),
            ..Default::default()
        },
        yapfast_ui::FavoriteChannelRow {
            key: "review:missing".into(),
            title: "Unavailable channel".into(),
            subtitle: "You may no longer have access".into(),
            ..Default::default()
        },
    ])));
    for (width, height) in [(800, 600), (1120, 760), (1600, 900)] {
        capture(
            &window,
            output,
            &format!("favorites-{width}x{height}.png"),
            width,
            height,
        );
        let pane = named(&window, "Favorite channels and direct messages");
        let (left, right) = horizontal_bounds(&pane);
        assert!(left >= 0. && right <= width as f32);
        for label in [
            "Import from Discord",
            "Create Favorites category",
            "announcements-and-releases, Community with a long server name",
            "Aurora, Direct message",
        ] {
            let (row_left, row_right) = horizontal_bounds(&named(&window, label));
            assert!(
                row_left >= left - 1. && row_right <= right + 1.,
                "{label} leaves Favorites at {width}px"
            );
        }
    }
    favorites.set_showing(false);
    favorites.set_rows(ModelRc::default());
    window
        .window()
        .set_size(slint::LogicalSize::new(800., 600.));
    window.invoke_open_button_link_menu("https://example.test/order".into(), 650., 500.);
    capture(&window, output, "button-link-menu-800x600.png", 800, 600);
    popup_bounds(&window, "Context menu", 800, 600);
    close_menu(&window);
    // Synthetic models exercise geometry only. Existing permission tests build
    // the real member menu; no moderation choice or app command executes here.
    window.on_ask_app_commands(|| {});
    window.on_ask_message_app_commands(|_| {});
    window.on_prepare_menu(|_, _| {});
    let menu_row = |text: &str, separated, danger| MenuRow {
        id: text.into(),
        text: text.into(),
        plain: true,
        separated,
        danger,
        ..Default::default()
    };
    let mut person_rows = vec![
        menu_row("Profile", false, false),
        menu_row("Mention", false, false),
        menu_row("Message", false, false),
        menu_row("Start a Call", false, false),
        menu_row("Add Note", false, false),
        menu_row("Apps", true, false),
        menu_row("Invite to Server", false, false),
        menu_row("Add Friend", false, false),
        menu_row("Ignore", false, false),
        menu_row("Block", false, true),
        menu_row("Change Nickname", true, false),
        menu_row("Roles", false, false),
        menu_row("Timeout Aurora", true, true),
        menu_row("Kick Aurora", false, true),
        menu_row("Ban Aurora", false, true),
        menu_row("Copy User ID", true, false),
    ];
    person_rows[4].subtitle = "Only visible to you".into();
    window.set_menu_rows(ModelRc::new(VecModel::from(person_rows)));
    let mut submenus = vec![ModelRc::default(); 16];
    submenus[11] = ModelRc::new(VecModel::from(vec![MenuRow {
        id: "crew".into(),
        text: "Crew".into(),
        plain: true,
        checkbox: true,
        checked: true,
        ..Default::default()
    }]));
    window.set_menu_submenus(ModelRc::new(VecModel::from(submenus)));
    for (width, height) in [(800, 600), (1600, 900)] {
        window
            .window()
            .set_size(slint::LogicalSize::new(width as f32, height as f32));
        window.invoke_open_context_menu("review:person".into(), true, 600., 120.);
        capture(
            &window,
            output,
            &format!("person-menu-{width}x{height}.png"),
            width,
            height,
        );
        popup_bounds(&window, "Context menu", width, height);
        close_menu(&window);
        let mut row = review_message();
        row.item = "d:100".into();
        row.can_edit = true;
        row.can_reply = true;
        row.can_forward = true;
        row.can_pin = true;
        row.can_delete = true;
        row.can_react = true;
        window.set_new_reactions_enabled(true);
        window.set_forward_allowed(true);
        window.set_can_start_threads(true);
        window.set_menu_reactions(ModelRc::new(VecModel::from(
            ["👍", "❤️", "😂", "🎉"]
                .into_iter()
                .map(|glyph| EmojiCell {
                    key: glyph.into(),
                    glyph: glyph.into(),
                    name: glyph.into(),
                    picture: crate::twemoji::picture(glyph, 24., 1.).unwrap(),
                    usable: true,
                })
                .collect::<Vec<_>>(),
        )));
        window.set_app_menu_commands(ModelRc::new(VecModel::from(
            (0..24)
                .map(|index| CommandChoice {
                    id: format!("review:{index}").into(),
                    name: format!("Command {index}").into(),
                    app: "Offline app".into(),
                    ..Default::default()
                })
                .collect::<Vec<_>>(),
        )));
        window.invoke_open_menu(row);
        capture(
            &window,
            output,
            &format!("message-menu-{width}x{height}.png"),
            width,
            height,
        );
        popup_bounds(&window, "Message menu", width, height);
        close_menu(&window);
    }
    // Project a coherent synthetic session through the real adapter. Merely
    // changing window flags leaves preview verification and guild state behind.
    // No connection action or service callback is dispatched here.
    window.set_friend_filter(SharedString::default());
    window.set_friends_blocked(false);
    {
        use yapfast_core::chat::{Blocked, ChatRoom, Friend};
        let mut adapter = adapter.borrow_mut();
        let prototype = adapter.app.state.rooms[0].as_ref().clone();
        let rooms = [
            ("10", "Aurora", Some("2"), 2, Presence::Online),
            ("11", "Weekend plans", None, 5, Presence::Online),
            ("12", "Marin", Some("3"), 2, Presence::Online),
            ("13", "Sol", Some("4"), 2, Presence::Offline),
        ]
        .into_iter()
        .map(|(id, name, person, members, presence)| {
            Arc::new(ChatRoom {
                id: format!("discord:@me:{id}"),
                network: Network::Discord,
                name: name.into(),
                direct: true,
                voice: false,
                encrypted: false,
                members,
                unread: u64::from(id == "11"),
                mentions: if id == "11" { 2 } else { 0 },
                locked: false,
                join_locked: false,
                read_only: false,
                category: String::new(),
                category_id: None,
                request: false,
                person: person.map(str::to_owned),
                avatar: None,
                decoration: None,
                nameplate: None,
                style: None,
                presence: Some(presence),
                activity: None,
                activities: Arc::default(),
                parent: None,
                forum: false,
                unlisted: false,
                tag: None,
                preview: None,
                ..prototype.clone()
            })
        })
        .collect();
        let friends = [("2", "Aurora"), ("3", "Marin"), ("4", "Sol")]
            .into_iter()
            .map(|(id, name)| Friend {
                id: id.into(),
                name: name.into(),
                nickname: None,
                avatar: None,
                presence: Some(if id == "4" {
                    Presence::Offline
                } else {
                    Presence::Online
                }),
                activity: None,
                activities: Arc::default(),
                since: None,
            })
            .collect();
        let mut state = AppState::default();
        state.account = Some("@review:example.invalid".into());
        state.discord_user = Some("1".into());
        state.discord_online = true;
        state.online = true;
        state.trusted = true;
        state.navigation = Navigation::DirectMessages;
        state.dm_screen = Some(DmScreen::Friends);
        state.rooms = rooms;
        state.friends = friends;
        state.discord_dm_pins = Some(Arc::from([
            "discord:@me:10".to_owned(),
            "discord:@me:11".to_owned(),
        ]));
        state.discord_blocked = vec![
            Blocked {
                id: "21".into(),
                name: "Atlas".into(),
                username: Some("atlas_review".into()),
                avatar: None,
            },
            Blocked {
                id: "22".into(),
                name: "A longer display name that stays inside its row".into(),
                username: Some("offline_review".into()),
                avatar: None,
            },
        ];
        state.list_changes = adapter.app.state.list_changes + 1;
        adapter.app.state = state;
        // Earlier card snapshots inject their own model directly on the window.
        // Restore the adapter's model before testing a real no-selection screen.
        window.set_messages(ModelRc::from(adapter.models.messages.clone()));
        adapter.refresh(&window);
        assert_eq!(
            window.get_messages().row_count(),
            0,
            "the Friends screen must not retain the synthetic chat message"
        );
    }
    for (width, height) in [(800, 600), (1600, 900)] {
        capture(
            &window,
            output,
            &format!("pinned-dms-{width}x{height}.png"),
            width,
            height,
        );
        let pinned = named(&window, "Pinned DMs");
        let regular = named(&window, "Direct Messages");
        let pinned_y = pinned.map_to_window(pinned.geometry().origin).y;
        let regular_y = regular.map_to_window(regular.geometry().origin).y;
        assert!(pinned_y >= 32. && regular_y > pinned_y && regular_y < height as f32);
        for item in [&pinned, &regular] {
            let (left, right) = horizontal_bounds(item);
            assert!(left >= 72. && right <= 72. + window.get_sidebar_shown() + 1.);
        }
    }
    window.set_friends_blocked(true);
    for (width, height) in [(800, 600), (1600, 900)] {
        capture(
            &window,
            output,
            &format!("friends-blocked-{width}x{height}.png"),
            width,
            height,
        );
        for label in [
            "Search blocked accounts",
            "Unblock Atlas",
            "Blocked",
            "Add Friend",
        ] {
            let item = named(&window, label);
            let (left, right) = horizontal_bounds(&item);
            assert!(
                left >= 0. && right <= width as f32,
                "{label} must stay inside the window"
            );
        }
    }
    window.set_friend_filter("ATLAS".into());
    window.invoke_friend_filter_edited();
    assert_eq!(window.get_friends_blocked_rows().row_count(), 1);
    assert_eq!(
        window.get_friends_blocked_rows().row_data(0).unwrap().id,
        "21"
    );
    window.hide().unwrap();
    println!("Saved native review frames to {}", output.display());
}
