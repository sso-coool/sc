//! What [`Adapter::refresh`] shows: the application's state, area by area.

use super::*;

/// What changed since the last refresh, read before it changes anything.
pub(super) struct Changes {
    reset: bool,
    selection: bool,
    messages: bool,
    /// The newest message was in view.
    at_end: bool,
}

impl Changes {
    fn read(adapter: &Adapter, window: &YapfastWindow) -> Self {
        let state = &adapter.app.state;
        Self {
            reset: adapter.reset_version != state.reset_version,
            selection: adapter.selection_version != state.selection_version,
            messages: !Arc::ptr_eq(&adapter.messages, &state.messages),
            at_end: window.invoke_timeline_at_end(),
        }
    }
}

/// What a backend event can change on screen.
#[derive(Clone, Copy, Default)]
pub(super) struct Reach {
    composer: bool,
    voice: bool,
    /// Pictures arrived, which can show anywhere.
    pictures: bool,
    /// A picker's own picture arrived, which no row shows but its own.
    picker: bool,
    /// A custom emoji's picture arrived: the emoji picker shows it at once,
    /// without laying the rest of the window out again.
    emoji: bool,
    /// The video or voice message playing changed.
    video: bool,
    pub(super) everything: bool,
}

impl Reach {
    pub(super) const EVERYTHING: Self = Self {
        composer: true,
        voice: true,
        pictures: true,
        picker: true,
        emoji: true,
        video: true,
        everything: true,
    };

    pub(super) fn of(event: &Event) -> Self {
        match event {
            // Who's typing shows only above the composer.
            Event::Typing { .. } => Self {
                composer: true,
                ..Self::default()
            },
            // The call, with who's speaking, which changes several times a
            // second, shows only in the call's own views.
            Event::Voice(_) => Self {
                voice: true,
                ..Self::default()
            },
            Event::Picture { url, .. } if url.contains("/emojis/") => Self {
                emoji: true,
                ..Self::default()
            },
            Event::Picture { .. } => Self {
                pictures: true,
                ..Self::default()
            },
            // A GIF's or a sticker's picture shows in its picker alone, which
            // lays out nothing else as it arrives.
            Event::GifPicture { .. } | Event::StickerPicture { .. } => Self {
                picker: true,
                ..Self::default()
            },
            Event::Video(_) | Event::VoiceMessage(_) => Self {
                video: true,
                ..Self::default()
            },
            _ => Self::EVERYTHING,
        }
    }

    pub(super) fn and(self, other: Self) -> Self {
        Self {
            composer: self.composer || other.composer,
            voice: self.voice || other.voice,
            pictures: self.pictures || other.pictures,
            picker: self.picker || other.picker,
            emoji: self.emoji || other.emoji,
            video: self.video || other.video,
            everything: self.everything || other.everything,
        }
    }
}

/// How long a picture that arrived waits for others to show with it.
const PICTURE_BATCH: std::time::Duration = std::time::Duration::from_millis(100);

/// How long a member list stays as built while its people change: in a busy
/// server someone comes, goes or changes what they're doing several times a
/// second, and each change drew a frame. So the list shows at most two
/// changes a second, the first at once and those in the pause after it
/// together at its end.
pub(super) const ROSTER_PAUSE: std::time::Duration = std::time::Duration::from_millis(500);

/// How long a custom emoji's picture waits for others before the emoji picker
/// shows it: a few frames, as showing them costs little.
const EMOJI_BATCH: std::time::Duration = std::time::Duration::from_millis(32);
/// A server's Discord id, from Yapfast's id for it.
fn discord_server_id(id: &str) -> &str {
    id.rsplit(':').next().unwrap_or(id)
}

impl Adapter {
    /// Browse Channels' rows whose channel's name has its search in it, each
    /// under its category's heading.
    fn browse_rows(&self, state: &AppState, window: &YapfastWindow) -> Vec<BrowseRow> {
        use yapfast_core::application::BrowsedKind;
        let Some(browse) = &state.browse else {
            return Vec::new();
        };
        let query = window.get_browse_filter().trim().to_lowercase();
        let row = |channel: &yapfast_core::application::BrowsedChannel| BrowseRow {
            id: channel.id.as_str().into(),
            name: channel.name.as_str().into(),
            topic: channel.topic.as_str().into(),
            icon: match channel.kind {
                BrowsedKind::Voice => self.icons.voice.plain.clone(),
                BrowsedKind::Forum => self.icons.forum.plain.clone(),
                BrowsedKind::Announcement => self.icons.announcement.plain.clone(),
                BrowsedKind::Category | BrowsedKind::Text => self.icons.text.plain.clone(),
            },
            category: channel.kind == BrowsedKind::Category,
            voice: channel.kind == BrowsedKind::Voice,
            forum: channel.kind == BrowsedKind::Forum,
            followed: channel.followed,
            by_category: channel.by_category,
        };
        let mut rows = Vec::new();
        let mut heading = None;
        for channel in &browse.rows {
            if channel.kind == BrowsedKind::Category {
                heading = Some(channel);
                continue;
            }
            if !channel.name.to_lowercase().contains(&query) {
                continue;
            }
            if let Some(category) = heading.take() {
                rows.push(row(category));
            }
            rows.push(row(channel));
        }
        rows
    }
}

/// The account's own profile its card was built from, with how many of the
/// card's pictures had come then, and the count of picture changes they were
/// counted at.
pub(super) struct AccountCardShown {
    profile: Arc<yapfast_core::chat::Profile>,
    changes: u64,
    pictures: usize,
}

/// How many of the pictures a profile's card draws have come.
fn card_pictures(state: &AppState, profile: &yapfast_core::chat::Profile) -> usize {
    let servers = profile
        .servers
        .iter()
        .flat_map(|server| [server.icon.as_deref(), server.banner.as_deref()]);
    let friends = profile
        .friends
        .iter()
        .map(|friend| friend.avatar.as_deref());
    [profile.avatar.as_deref(), profile.banner.as_deref()]
        .into_iter()
        .chain(servers)
        .chain(friends)
        .flatten()
        .filter(|url| state.pictures.contains_key(*url))
        .count()
}

/// What the profile editor's preview takes from the account's own profile:
/// what the editor doesn't change.
fn own_profile_parts(own: Option<&yapfast_core::chat::Profile>) -> yapfast_core::chat::Profile {
    let Some(own) = own else {
        return Default::default();
    };
    yapfast_core::chat::Profile {
        decoration: own.decoration.clone(),
        effect: own.effect.clone(),
        tag: own.tag.clone(),
        badges: own.badges.clone(),
        connections: own.connections.clone(),
        presence: own.presence,
        activity: own.activity.clone(),
        activities: own.activities.clone(),
        ..Default::default()
    }
}

/// What the sidebar was built from, kept to tell whether it changed. The
/// rooms and servers go by their count of changes and the other lists by a
/// hash: copies of them took megabytes on a large account.
#[derive(PartialEq)]
pub(super) struct SidebarShown {
    lists: u64,
    navigation: Navigation,
    selected: Option<String>,
    dm_screen: Option<DmScreen>,
    filter: SharedString,
    friend_filter: SharedString,
    browse_filter: SharedString,
    picture_changes: u64,
    category_changes: u64,
    list_changes: u64,
    /// Active unjoined threads may change without a visible room changing.
    active_thread_parents: HashSet<String>,
    /// Whether Discord took changes, which the header's invite button needs.
    discord_online: bool,
    /// What the profile switches let DM rows show.
    cosmetics: yapfast_core::application::Cosmetics,
}

impl SidebarShown {
    fn of(state: &AppState, window: &YapfastWindow, active_thread_parents: HashSet<String>) -> Self {
        Self {
            lists: Self::lists(state),
            navigation: state.navigation.clone(),
            selected: state.selected.clone(),
            dm_screen: state.dm_screen,
            filter: window.get_filter(),
            friend_filter: window.get_friend_filter(),
            browse_filter: window.get_browse_filter(),
            picture_changes: state.picture_changes,
            category_changes: state.category_changes,
            list_changes: state.list_changes,
            active_thread_parents,
            discord_online: state.discord_online,
            cosmetics: state.cosmetics,
        }
    }

    /// The smaller lists the sidebar shows; the rooms and servers count
    /// their changes.
    fn lists(state: &AppState) -> u64 {
        use std::hash::{Hash, Hasher};
        let mut hasher = std::hash::DefaultHasher::new();
        (
            &state.friends,
            &state.friend_requests,
            &state.discord_blocked,
            &state.pinned,
            &state.browse,
        )
            .hash(&mut hasher);
        hasher.finish()
    }

    /// Whether the sidebar would show the same.
    fn shows(&self, state: &AppState, window: &YapfastWindow) -> bool {
        self.navigation == state.navigation
            && self.selected == state.selected
            && self.dm_screen == state.dm_screen
            && self.filter == window.get_filter()
            && self.friend_filter == window.get_friend_filter()
            && self.browse_filter == window.get_browse_filter()
            && self.picture_changes == state.picture_changes
            && self.category_changes == state.category_changes
            && self.list_changes == state.list_changes
            && self.discord_online == state.discord_online
            && self.lists == Self::lists(state)
    }
}

/// What the member list and its Activity panel were built from last, so each
/// is built again only once that changed, not on every message and presence
/// that refreshes the window.
pub(super) struct RosterShown {
    members: Members,
    selection_version: u64,
    owner: Option<String>,
    cosmetics: yapfast_core::application::Cosmetics,
    hide_nameplates: bool,
    /// When the soonest timeout the list shows ends.
    timeout_ends: Option<u64>,
    feed: Arc<[yapfast_core::chat::FeedEntry]>,
    people: Option<(String, Arc<[yapfast_core::chat::FeedPerson]>)>,
    /// The second the panel's rows were worded in: they count the time
    /// since, so a panel with rows is worded again each second.
    panel_second: Option<u64>,
}

/// A conversation's member list, as `AppState::members` holds it.
type Members = Option<Result<Arc<Vec<yapfast_core::chat::ChatMember>>, &'static str>>;

impl RosterShown {
    fn same_members(&self, state: &AppState, members: &Members) -> bool {
        self.selection_version == state.selection_version
            && match (&self.members, members) {
                (Some(Ok(shown)), Some(Ok(members))) => Arc::ptr_eq(shown, members),
                (shown, members) => {
                    shown.is_none() && members.is_none()
                        || matches!((shown, members), (Some(Err(a)), Some(Err(b))) if a == b)
                }
            }
    }

    /// Whether the list would show the same `members`.
    fn shows_list(
        &self,
        state: &AppState,
        members: &Members,
        owner: &Option<String>,
        now: u64,
    ) -> bool {
        self.same_members(state, members)
            && self.owner == *owner
            && self.cosmetics == state.cosmetics
            && self.hide_nameplates == state.hide_nameplates
            && self.timeout_ends.is_none_or(|ends| now < ends)
    }

    /// Whether the Activity panel would show the same of `members`.
    fn shows_panel(&self, state: &AppState, members: &Members, now: u64) -> bool {
        self.same_members(state, members)
            && Arc::ptr_eq(&self.feed, &state.activity_feed)
            && match (&self.people, &state.activity_people) {
                (None, None) => true,
                (Some((asked, people)), Some((room, known))) => {
                    asked == room && Arc::ptr_eq(people, known)
                }
                _ => false,
            }
            && self.panel_second.is_none_or(|second| second == now / 1000)
    }
}

impl Icons {
    /// A conversation's icon, as the sidebar shows it: a lock for one this
    /// account may not read.
    pub(super) fn room(&self, room: &yapfast_core::chat::ChatRoom) -> slint::Image {
        if room.locked {
            self.lock.clone()
        } else {
            self.channel(room)
        }
    }

    /// A conversation's own icon, as its header shows it: for a Discord
    /// channel, its kind's, marked as Discord's client marks it, with a
    /// warning sign before a lock.
    pub(super) fn channel(&self, room: &yapfast_core::chat::ChatRoom) -> slint::Image {
        use yapfast_core::chat::MarkKind;
        if room.direct {
            return self.dm.clone();
        } else if room.parent.is_some() {
            return self.thread.clone();
        }
        let icon = match room.mark.kind {
            MarkKind::Rules => return self.rules.clone(),
            MarkKind::Stage => &self.stage,
            _ if room.voice => &self.voice,
            MarkKind::Media => &self.media,
            _ if room.forum => &self.forum,
            MarkKind::Announcement => &self.announcement,
            MarkKind::Plain => &self.text,
        };
        if room.mark.age_restricted {
            icon.age_restricted.clone()
        } else if room.mark.private {
            icon.private.clone()
        } else {
            icon.plain.clone()
        }
    }
}

/// What the quick switcher listed last, so its places are found again only
/// once that changes.
pub(super) struct SwitcherShown {
    query: String,
    list_changes: u64,
    places_used: u64,
    selected: Option<String>,
}

impl SwitcherShown {
    fn of(state: &AppState) -> Self {
        Self {
            query: state.switcher.clone().unwrap_or_default(),
            list_changes: state.list_changes,
            places_used: state.places_used.changes(),
            selected: state.selected.clone(),
        }
    }

    /// Whether the switcher would list the same.
    fn shows(&self, state: &AppState) -> bool {
        state.switcher.as_ref() == Some(&self.query)
            && self.list_changes == state.list_changes
            && self.places_used == state.places_used.changes()
            && self.selected == state.selected
    }
}

/// What a message row in the thread beside the channel takes across beside
/// its content: the space before the avatar, the avatar and the space after
/// it, and the space at the end, as `ThreadPanel` lays it out.
const ASIDE_GUTTER: i32 = 16 + 40 + 16 + 16;

impl Adapter {
    /// Shows what a burst of backend events can have changed.
    pub(super) fn show(&mut self, window: &YapfastWindow, reach: Reach) {
        if reach.everything {
            self.refresh(window);
            return;
        }
        // A custom emoji's picture shows in the emoji picker alone while it is
        // open, which needs nothing else laid out; otherwise it can show
        // anywhere, as any picture can.
        let picker_open = self.models.emoji_rows.row_count() > 0;
        if reach.emoji && picker_open && !self.emoji_due.running() {
            let (adapter, weak) = (self.weak.clone(), window.as_weak());
            self.emoji_due
                .start(slint::TimerMode::SingleShot, EMOJI_BATCH, move || {
                    if let (Some(adapter), Some(window)) = (adapter.upgrade(), weak.upgrade()) {
                        adapter.borrow_mut().show_emoji_pictures(&window);
                    }
                });
        }
        let pictures = reach.pictures || (reach.emoji && !picker_open);
        // Pictures arrive one at a time, hundreds when the emoji picker opens,
        // so those that come close together show in one refresh.
        if pictures && !self.pictures_due.running() {
            let (adapter, weak) = (self.weak.clone(), window.as_weak());
            self.pictures_due
                .start(slint::TimerMode::SingleShot, PICTURE_BATCH, move || {
                    if let (Some(adapter), Some(window)) = (adapter.upgrade(), weak.upgrade()) {
                        adapter.borrow_mut().refresh(&window);
                    }
                });
        }
        if reach.picker && !self.picker_due.running() {
            let (adapter, weak) = (self.weak.clone(), window.as_weak());
            self.picker_due
                .start(slint::TimerMode::SingleShot, PICTURE_BATCH, move || {
                    if let (Some(adapter), Some(window)) = (adapter.upgrade(), weak.upgrade()) {
                        adapter.borrow_mut().show_picker_pictures(&window);
                    }
                });
        }
        if reach.composer {
            self.show_composer(window);
            self.show_aside(window);
        }
        if reach.voice {
            self.show_voice(window);
        }
        if reach.video {
            self.show_video(window);
            self.show_voice_message(window);
        }
    }

    /// The custom emoji pictures that arrived for the emoji picker, shown in
    /// it and nothing else: the window lays nothing out again, so a scroll
    /// that brings pictures in stays smooth. One that a message on screen
    /// shows too makes its glyph, which lays the messages out, as a full
    /// refresh does.
    fn show_emoji_pictures(&mut self, window: &YapfastWindow) {
        // One a message on screen shows too gets its glyph, which lays the
        // messages out again, as a full refresh does; `add` says so only for a
        // glyph it made, so this happens once a picture.
        let state = &self.app.state;
        let in_messages = state
            .messages
            .iter()
            .chain(state.aside.iter().flat_map(|aside| aside.messages.iter()))
            .flat_map(|message| &message.emoji);
        if custom_emoji::add(in_messages.filter_map(|emoji| arrived(state, emoji))) {
            self.restyle = true;
            self.refresh(window);
            return;
        }
        if self.show_arrived_emoji() && self.emoji_word.is_some() {
            self.show_emoji_suggestions(window);
        }
        super::callbacks::want_shown_animations(self, window);
    }

    /// The pictures a picker's tiles draw that arrived since, and nothing
    /// else: they change no layout, so no row is built again.
    fn show_picker_pictures(&mut self, window: &YapfastWindow) {
        self.show_gifs(window);
        self.show_stickers(window);
    }

    pub(super) fn refresh(&mut self, window: &YapfastWindow) {
        super::activities::sync(self, window);
        self.sync_call_video_popout(window);
        self.sync_command_history();
        self.sync_dm_pins();
        self.sync_channel_favorites(window);
        if self.pictures_sourced != Some(self.app.state.picture_changes) {
            self.pictures_sourced = Some(self.app.state.picture_changes);
            bump_picture_slots(window, refresh_avatar_sources(&self.app.state));
        }
        self.show_viewer(window);
        self.show_profile(window);
        window.set_can_go_back(self.app.state.can_go_back());
        window.set_can_go_forward(self.app.state.can_go_forward());
        if window.get_inbox_open() {
            self.show_inbox(window);
        } else {
            update_model(&self.models.inbox, Vec::new());
        }
        super::message_saves::show(self, window);
        let changes = Changes::read(self, window);
        if changes.reset || self.navigation != self.app.state.navigation {
            window.set_filter(SharedString::default());
        }
        if changes.reset {
            window.set_password(SharedString::default());
            window.set_recovery(SharedString::default());
            window.set_settings_open(false);
        }
        self.show_workspace(window);
        self.show_sidebar(window);
        self.show_account(window);
        // A server's search stays, with its words, in the server's channels.
        if changes.selection && self.app.state.search_shown().is_none() {
            window.set_search_text(SharedString::default());
        }
        self.show_header(window);
        self.show_dm_tools(window);
        self.show_threads(window);
        self.show_forum(window);
        self.show_new_post(window);
        self.show_new_thread(window);
        self.show_members(window);
        self.show_invite(window);
        self.show_join(window);
        self.show_oauth(window);
        self.show_gift(window);
        self.show_event(window);
        self.show_channel_dialog(window);
        self.show_leave(window);
        self.show_move_sync(window);
        self.show_profile_editor(window);
        self.show_server_settings(window);
        self.show_channel_settings(window);
        self.show_thread_settings(window);
        self.show_mfa(window);
        self.show_bot_interactions(window);
        self.show_dialogs(window);
        self.show_reactions(window);
        self.show_gifs(window);
        self.show_emoji_card(window);
        self.show_sticker_card(window);
        self.show_emoji_animations(window);
        self.show_stickers(window);
        self.show_composer(window);
        self.show_messages(window, &changes);
        self.show_aside(window);
        self.show_command_details();
        self.show_menu_command_details(window);
        self.finish_command_use(window);
        self.show_voice(window);
        self.show_video(window);
        self.show_voice_message(window);
        let state = &self.app.state;
        if changes.selection {
            self.focus_when_ready = state.shows_text() && !state.room_ready;
        }
        if changes.selection && state.shows_text() {
            window.invoke_focus_composer();
        } else if self.focus_when_ready && state.room_ready {
            self.focus_when_ready = false;
            window.invoke_focus_composer();
        } else if changes.reset && !state.preview && state.account.is_none() {
            window.invoke_focus_sign_in();
        }
        self.navigation = state.navigation.clone();
        self.selection_version = state.selection_version;
        self.reset_version = state.reset_version;
        self.messages = state.messages.clone();
        self.forwarding = state.forwarding.is_some();
        self.show_tray();
        self.show_title(window);
        window.set_tray_available(self.tray.as_ref().is_some_and(crate::tray::Tray::available));
        if self.app.reaction_uses() != &self.layout.reactions {
            self.layout.reactions = self.app.reaction_uses().clone();
            self.layout.write(&self.root);
        }
        // The stickers sent and those kept, for Frequently Used and Favorites
        // at the next start: compared in place, as this runs on every event,
        // and copied only when they changed.
        let kept = |kept: &KeptSticker, sticker: &yapfast_core::chat::Sticker| {
            kept.id == sticker.id
                && kept.name == sticker.name
                && kept.format == sticker.format
                && kept.picture == sticker.picture
        };
        let uses = self.app.sticker_uses();
        let same_uses = uses.len() == self.layout.sticker_uses.len()
            && uses
                .iter()
                .zip(&self.layout.sticker_uses)
                .all(|(used, known)| {
                    used.uses == known.uses
                        && known.id == used.sticker.id
                        && known.name == used.sticker.name
                        && known.format == used.sticker.format
                        && known.picture == used.sticker.picture
                });
        if !same_uses {
            self.layout.sticker_uses = uses
                .iter()
                .map(|used| KeptStickerUse {
                    id: used.sticker.id.clone(),
                    name: used.sticker.name.clone(),
                    format: used.sticker.format,
                    picture: used.sticker.picture.clone(),
                    uses: used.uses,
                })
                .collect();
            self.layout.write(&self.root);
        }
        let favorites = self.app.sticker_favorites();
        let same_favorites = favorites.len() == self.layout.sticker_favorites.len()
            && favorites
                .iter()
                .zip(&self.layout.sticker_favorites)
                .all(|(sticker, known)| kept(known, sticker));
        if !same_favorites {
            self.layout.sticker_favorites = favorites
                .iter()
                .map(|sticker| KeptSticker {
                    id: sticker.id.clone(),
                    name: sticker.name.clone(),
                    format: sticker.format,
                    picture: sticker.picture.clone(),
                })
                .collect();
            self.layout.write(&self.root);
        }
        if changes.selection && !state.preview && state.account.is_some() {
            let mut layout = self.layout.clone();
            layout.channels.extend(self.app.last_channels());
            if layout != self.layout {
                layout.write(&self.root);
                self.layout = layout;
            }
        }
    }

    /// Drives the animated emoji: the frames the rows and the picker show are
    /// wanted, decoded ahead of the draw, and the clock moves only while
    /// something plays and the window is focused, used and not minimised.
    fn show_emoji_animations(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        let mut shown: Vec<(String, Option<char>, String)> = self
            .app
            .visible_message_emoji()
            .filter(|emoji| emoji.animated)
            .map(|emoji| {
                (
                    emoji::custom_key(emoji),
                    custom_emoji::glyph(&emoji.id),
                    emoji.picture.clone(),
                )
            })
            .collect();
        // The card shows one emoji, which may be from a message no longer on
        // screen, and a call's soundboard shows its sounds' own.
        let card = self.emoji_card.as_ref().and_then(|target| target.custom());
        let on_card = card.and_then(|id| {
            state
                .messages
                .iter()
                .flat_map(|message| &message.emoji)
                .find(|emoji| emoji.id == id)
        });
        if let Some(emoji) = on_card.filter(|emoji| emoji.animated) {
            shown.push((
                emoji::custom_key(emoji),
                custom_emoji::glyph(&emoji.id),
                emoji.picture.clone(),
            ));
        }
        // The bars and menus over messages show their emoji as cells too, and
        // what each decodes is the picture the account may use here.
        let mut cells: Vec<String> = Vec::new();
        for model in [&self.models.bar_reactions, &self.models.menu_reactions] {
            for index in 0..model.row_count() {
                if let Some(cell) = model.row_data(index) {
                    cells.push(cell.key.to_string());
                }
            }
        }
        // Made for those few by their ids, rather than every server's emoji at
        // each refresh.
        let ids: HashSet<&str> = cells
            .iter()
            .filter_map(|key| key.rsplit_once(':').map(|(_, id)| id))
            .collect();
        for emoji in self.app.emoji_by_id(&ids) {
            let key = emoji::custom_key(&emoji);
            if emoji.usable && emoji.animated && cells.contains(&key) {
                shown.push((key, custom_emoji::glyph(&emoji.id), emoji.picture));
            }
        }
        for sound in state
            .voice
            .soundboard
            .iter()
            .flat_map(|groups| groups.iter())
            .flat_map(|group| &group.sounds)
        {
            if let Some(picture) = &sound.picture {
                shown.push((format!("sound:{picture}"), None, picture.clone()));
            }
        }
        self.animations.show(shown, &state.pictures);
        self.run_emoji_animations(window);
    }

    /// Both full refreshes and quiet picker updates can introduce animation
    /// work, including after the last close stopped the timer.
    pub(super) fn run_emoji_animations(&mut self, window: &YapfastWindow) {
        // Idle holds the clock as an unfocused window does, whatever the Animate
        // setting says; a minimised window has lost focus, and `playing` is
        // already false for it.
        let playing = window.global::<Motion>().get_playing() && !self.is_inactive();
        self.animations.run(window, &self.app.state.pictures);
        self.animations.sync(window, playing, self.weak.clone());
    }

    /// The card an emoji in a message opened, built again while it is open, so
    /// it shows what Discord said of its server once that arrives.
    fn show_emoji_card(&mut self, window: &YapfastWindow) {
        let Some(target) = self.emoji_card.as_ref() else {
            return;
        };
        if !window.get_emoji_card_open() {
            return;
        }
        let Adapter { app, pictures, .. } = self;
        let card = messages::emoji_card_for(app, target, pictures);
        window.set_emoji_card(card);
    }

    /// Bots' controls waiting for Discord, and the select menu and form
    /// one opened.
    pub(super) fn show_bot_interactions(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        // The newest control waiting shows so; the core holds back any.
        window.set_bot_busy_item(state.interactions.newest_busy().unwrap_or("").into());
        let (failed, why) = state
            .interaction_failed
            .as_ref()
            .map_or(("", ""), |(item, why)| (item.as_str(), why.as_str()));
        window.set_bot_failed_item(failed.into());
        window.set_bot_failed_text(why.into());
        let select = self.app.state.select_menu.as_ref();
        window.set_bot_select_open(select.is_some());
        if let Some(select) = select {
            window.set_bot_select_heading(select.label.as_str().into());
            window.set_bot_select_query(select.query.as_str().into());
            window.set_bot_select_min(select.min as i32);
            window.set_bot_select_max(select.max as i32);
            window.set_bot_select_searchable(matches!(select.kind, 5..=8));
            use std::hash::{Hash, Hasher};
            let mut hasher = std::hash::DefaultHasher::new();
            select.hash(&mut hasher);
            let shown = hasher.finish();
            if self.bot_select_shown != Some(shown) {
                let query = select.query.to_lowercase();
                // A message's menu shows its custom emoji as the message does.
                let emoji = self
                    .app
                    .state
                    .message(&select.item)
                    .map(|message| message.emoji.as_slice())
                    .unwrap_or_default();
                let rows = select
                    .choices
                    .iter()
                    .enumerate()
                    .filter(|(_, choice)| {
                        query.is_empty()
                            || choice.label.to_lowercase().contains(&query)
                            || choice.description.to_lowercase().contains(&query)
                    })
                    .map(|(index, choice)| SelectChoice {
                        index: index as i32,
                        label: choice.label.as_str().into(),
                        value: choice.value.as_str().into(),
                        description: choice.description.as_str().into(),
                        selected: choice.selected,
                        emoji: custom_emoji::text(&choice.emoji, emoji).into(),
                    })
                    .collect::<Vec<_>>();
                let current = window.get_bot_select_choices();
                if let Some(model) = current.as_any().downcast_ref::<VecModel<SelectChoice>>() {
                    update_model(model, rows);
                } else {
                    window.set_bot_select_choices(ModelRc::new(VecModel::from(rows)));
                }
                self.bot_select_shown = Some(shown);
            }
        } else if self.bot_select_shown.take().is_some() {
            window.set_bot_select_choices(ModelRc::default());
        }
        let modal = self.app.state.interaction_modal.as_ref();
        window.set_bot_modal_open(modal.is_some());
        if let Some(modal) = modal {
            window.set_bot_modal_heading(modal.title.as_str().into());
            window.set_bot_modal_supported(modal.supported);
            window.set_bot_modal_saving(modal.saving());
            window.set_bot_modal_error(modal.error.as_deref().unwrap_or_default().into());
            let current = window.get_bot_modal_fields();
            let shown = current.as_any().downcast_ref::<VecModel<ModalField>>();
            let fields = modal
                .fields
                .iter()
                .enumerate()
                .map(|(index, field)| ModalField {
                    label: field.label.as_str().into(),
                    description: field.description.as_str().into(),
                    // Text to read is laid out again only when it changes.
                    blocks: match shown.and_then(|shown| shown.row_data(index)) {
                        Some(row) if row.kind == 10 && row.value == field.value.as_str() => {
                            row.blocks
                        }
                        _ if field.kind == 10 => {
                            ModelRc::new(VecModel::from(messages::text_blocks(&field.value)))
                        }
                        _ => ModelRc::default(),
                    },
                    choices: if matches!(field.kind, 21 | 22) {
                        ModelRc::new(VecModel::from(
                            field
                                .options
                                .iter()
                                .enumerate()
                                .map(|(index, option)| SelectChoice {
                                    index: index as i32,
                                    label: option.label.as_str().into(),
                                    value: option.value.as_str().into(),
                                    description: option.description.as_str().into(),
                                    selected: field.values.contains(&option.value),
                                    emoji: option.emoji.as_str().into(),
                                })
                                .collect::<Vec<_>>(),
                        ))
                    } else {
                        ModelRc::default()
                    },
                    checked: field.checked,
                    files: ModelRc::new(VecModel::from(
                        field
                            .files
                            .iter()
                            .map(|path| {
                                SharedString::from(
                                    path.file_name()
                                        .unwrap_or(path.as_os_str())
                                        .to_string_lossy()
                                        .as_ref(),
                                )
                            })
                            .collect::<Vec<_>>(),
                    )),
                    max_files: field.max_values as i32,
                    value: field.value.as_str().into(),
                    placeholder: field.placeholder.as_str().into(),
                    required: field.required,
                    paragraph: field.paragraph,
                    kind: field.kind as i32,
                    summary: field
                        .values
                        .iter()
                        .map(|value| {
                            field
                                .options
                                .iter()
                                .find(|option| &option.value == value)
                                .map_or(value.as_str(), |option| option.label.as_str())
                        })
                        .collect::<Vec<_>>()
                        .join(", ")
                        .into(),
                })
                .collect::<Vec<_>>();
            // Keep the repeater's model alive while typing so Slint keeps
            // each input's focus and cursor. Only a row that changed is
            // set again: its lists are compared by what they hold.
            if let Some(model) = shown
                && model.row_count() == fields.len()
            {
                for (index, field) in fields.into_iter().enumerate() {
                    if model
                        .row_data(index)
                        .is_none_or(|shown| !same_field(&shown, &field))
                    {
                        model.set_row_data(index, field);
                    }
                }
            } else {
                window.set_bot_modal_fields(ModelRc::new(VecModel::from(fields)));
            }
        }
    }

    /// The card a clicked sticker opened, as the message and the picker's
    /// lists show it.
    fn show_sticker_card(&mut self, window: &YapfastWindow) {
        let Some((item, index)) = self.sticker_card.clone() else {
            return;
        };
        if !window.get_sticker_card_open() {
            return;
        }
        window.set_sticker_card(messages::sticker_card(&self.app, &item, index));
    }

    /// Whether Yapfast is signed in or previewing, what the account is doing, and
    /// linking Discord.
    fn show_workspace(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        let workspace = state.preview || state.account.is_some();
        window.set_workspace(workspace);
        window.set_preview(state.preview);
        window.set_busy(state.busy);
        window.set_trusted(state.trusted);
        window.set_forward_allowed(
            state.preview
                || state.trusted
                || state
                    .selected
                    .as_deref()
                    .is_some_and(|room| Network::of(room) == Network::Discord),
        );
        window.set_online(state.online);
        // Only the sign-in screen offers it, and finding out reads the OS
        // credential store or the disk.
        if !workspace {
            window.set_restore_available(yapfast_core::chat::can_restore(&self.root));
        }
        window.set_dms_selected(state.navigation == Navigation::DirectMessages);
        window.set_dms_unread(
            state
                .rooms
                .iter()
                .any(|room| room.direct && room.unread > 0),
        );
        // As in Discord, the DM home counts DM mentions and the friend
        // requests waiting for an answer.
        let dm_mentions: u64 = state
            .rooms
            .iter()
            .filter(|room| room.direct)
            .map(|room| room.mentions)
            .sum();
        let incoming = state
            .friend_requests
            .iter()
            .filter(|request| request.incoming && !request.spam)
            .count() as u64;
        window.set_dms_badge(count_badge(dm_mentions + incoming));
        window.set_discord_linked(
            state.discord_linked || state.servers.iter().any(|server| server.discord),
        );
        window.set_discord_build(cfg!(feature = "discord"));
        window.set_matrix_build(cfg!(feature = "matrix"));
        // Without Matrix, the account's dot is its Discord status.
        window.set_account_presence(
            if cfg!(feature = "matrix") || state.preview {
                ""
            } else if !state.discord_online {
                "offline"
            } else {
                match state.discord_presence.as_deref() {
                    Some("idle") => "idle",
                    Some("dnd") => "dnd",
                    Some("invisible") => "offline",
                    _ => "online",
                }
            }
            .into(),
        );
        #[cfg(feature = "discord")]
        {
            use yapfast_core::application::DiscordLink;
            let (phase, name, note) = match &state.discord_link {
                None => (0, "", ""),
                Some(DiscordLink::Starting) => (1, "", ""),
                Some(DiscordLink::Code(_)) => (2, "", ""),
                Some(DiscordLink::Scanned(name)) => (3, name.as_str(), ""),
                Some(DiscordLink::Captcha(_)) => (5, "", ""),
                Some(DiscordLink::Failed(error)) => (4, "", error.as_str()),
                Some(DiscordLink::Checking) => (6, "", ""),
            };
            window.set_link_phase(phase);
            window.set_link_name(name.into());
            window.set_link_note(note.into());
            if let Some(DiscordLink::Code(address)) = &state.discord_link
                && self
                    .link_code
                    .as_ref()
                    .is_none_or(|(shown, _)| shown != address)
            {
                self.link_code = qr_code(address).map(|image| (address.clone(), image));
                window.set_link_code(
                    self.link_code
                        .as_ref()
                        .map(|(_, image)| image.clone())
                        .unwrap_or_default(),
                );
            }
        }
        window.set_show_hidden_channels(state.show_hidden_channels);
        window.set_sync_discord_reads(state.sync_discord_reads);
    }

    /// The rail, the channel or DM list, and the friends and requests screens,
    /// built again only when what they show changed.
    pub(super) fn show_sidebar(&mut self, window: &YapfastWindow) {
        window.set_server_order_context(server_order::context(&self.app.state).into());
        let active_thread_parents = match &self.app.state.navigation {
            Navigation::Server(server) => self.app.other_active_thread_parents(server),
            Navigation::DirectMessages => HashSet::new(),
        };
        if self
            .sidebar
            .as_ref()
            .is_some_and(|shown| {
                shown.active_thread_parents == active_thread_parents
                    && shown.shows(&self.app.state, window)
            })
        {
            return;
        }
        self.sidebar = Some(SidebarShown::of(
            &self.app.state,
            window,
            active_thread_parents.clone(),
        ));
        let state = &self.app.state;
        let cosmetics = state.cosmetics;
        let query = window.get_filter().to_lowercase();
        window.set_sidebar_title(match &state.navigation {
            Navigation::DirectMessages => "Direct messages".into(),
            Navigation::Server(id) => state
                .servers
                .iter()
                .find(|server| &server.id == id)
                .map_or("Server".into(), |server| server.name.clone().into()),
        });
        // A Discord server's name opens its menu, as Discord's does.
        window.set_header_server(match &state.navigation {
            Navigation::Server(id)
                if !state.preview
                    && state
                        .servers
                        .iter()
                        .any(|server| server.discord && &server.id == id) =>
            {
                id.as_str().into()
            }
            _ => SharedString::default(),
        });
        window.set_header_invite(match &state.navigation {
            Navigation::Server(id) => self.app.header_choices(id).contains(&MenuChoice::Invite),
            Navigation::DirectMessages => false,
        });
        window.set_header_community(match &state.navigation {
            Navigation::Server(id) => state
                .servers
                .iter()
                .any(|server| &server.id == id && server.community),
            Navigation::DirectMessages => false,
        });
        let header_server = match &state.navigation {
            Navigation::Server(id) => state.servers.iter().find(|server| &server.id == id),
            Navigation::DirectMessages => None,
        };
        window.set_header_verified(header_server.is_some_and(|server| server.verified));
        window.set_header_banner(
            header_server
                .and_then(|server| server.banner.as_deref())
                .unwrap_or_default()
                .into(),
        );
        window.set_header_events(
            header_server.map_or(0, |server| i32::try_from(server.events.len()).unwrap_or(0)),
        );
        window.set_header_boosts(
            header_server
                .and_then(|server| server.boosts)
                .map_or(-1, |boosts| i32::try_from(boosts).unwrap_or(i32::MAX)),
        );
        window.set_header_events_row(
            header_server.is_some_and(|server| server.community || !server.events.is_empty()),
        );
        window.set_filter_placeholder(
            if state.navigation == Navigation::DirectMessages {
                "Find a DM"
            } else {
                "Find a channel"
            }
            .into(),
        );
        let rooms_by_id: HashMap<&str, &yapfast_core::chat::ChatRoom> = state
            .rooms
            .iter()
            .map(|room| (room.id.as_str(), &**room))
            .collect();
        self.rail_call = call_room(state).map(str::to_owned);
        let rail = rail(
            state,
            &rooms_by_id,
            &self.layout.open_folders,
            server_order::active(state, &self.layout.server_orders),
        );
        update_model_by_id(&self.models.servers, rail, |row| row.id.clone());
        let mut listed_text = false;
        let mut listed_voice = false;
        let mut category = None;
        let mut listed: Vec<_> = state
            .scoped_rooms()
            .filter(|room| room.name.to_lowercase().contains(&query))
            .collect();
        let direct = state.navigation == Navigation::DirectMessages;
        // Friend requests, message requests and spam have their own screen.
        let waiting = |name: &str| {
            state
                .scoped_rooms()
                .filter(|room| room.category == name)
                .collect::<Vec<_>>()
        };
        let (message_requests, spam) = (waiting(discord::REQUESTS), waiting(discord::SPAM));
        let requests = request_rows(
            state,
            &message_requests,
            &spam,
            self.layout.twelve_hour_clock,
        );
        window.set_requests_badge(count_badge(requests.incoming.len() as u64));
        update_model(&self.models.requests_incoming, requests.incoming);
        update_model(&self.models.requests_sent, requests.sent);
        update_model(&self.models.requests_spam, requests.spam);
        // The friends list, those around first; filtered by the screen's search.
        let friend_query = window.get_friend_filter().to_lowercase();
        let in_voice = voice_places(state, &rooms_by_id);
        let friend_rows: Vec<_> = state
            .friends
            .iter()
            .filter(|friend| friend.name.to_lowercase().contains(friend_query.trim()))
            .map(|friend| {
                let (activity, activity_emoji) = activity_line(friend.activity.as_deref());
                let voice = in_voice.get(friend.id.as_str());
                FriendRow {
                    id: friend.id.as_str().into(),
                    name: friend.name.as_str().into(),
                    initial: initial(&friend.name),
                    tint: tint(&friend.id),
                    picture: slint::Image::default(),
                    picture_url: friend.avatar.as_deref().unwrap_or_default().into(),
                    presence: presence_name(Some(friend.presence.unwrap_or(Presence::Offline)))
                        .into(),
                    activity,
                    activity_emoji,
                    voice_room: voice.map_or("", |place| place.room).into(),
                    voice_channel: voice.map_or("", |place| place.channel).into(),
                    voice_server: voice.map_or("", |place| place.server).into(),
                }
            })
            .collect();
        let around: Vec<_> = friend_rows
            .iter()
            .filter(|friend| friend.presence != "offline")
            .cloned()
            .collect();
        update_model(&self.models.friends_online, around);
        update_model(&self.models.friends, friend_rows);
        window.set_friend_count(i32::try_from(state.friends.len()).unwrap_or(i32::MAX));
        // Those blocked, shared by Settings and the searchable Friends tab.
        update_model(
            &self.models.blocked,
            state
                .discord_blocked
                .iter()
                .map(|blocked| BlockedRow {
                    id: blocked.id.as_str().into(),
                    name: blocked.name.as_str().into(),
                    username: blocked.username.as_deref().unwrap_or_default().into(),
                    avatar_url: blocked.avatar.as_deref().unwrap_or_default().into(),
                    initial: initial(&blocked.name),
                })
                .collect(),
        );
        update_model(
            &self.models.blocked_filtered,
            self.models
                .blocked
                .iter()
                .filter(|person| {
                    person.name.to_lowercase().contains(friend_query.trim())
                        || person.username.to_lowercase().contains(friend_query.trim())
                })
                .collect(),
        );
        window.set_friends_open(direct && state.dm_screen == Some(DmScreen::Friends));
        // Browse Channels, at the top of a Community server's channel list;
        // its rows only while it shows, filtered by its search.
        window.set_browse_offered(
            state.discord_online
                && match &state.navigation {
                    Navigation::Server(id) => state
                        .servers
                        .iter()
                        .any(|server| &server.id == id && server.community),
                    Navigation::DirectMessages => false,
                },
        );
        window.set_browse_open(state.browse.is_some());
        update_model(&self.models.browse_rows, self.browse_rows(state, window));
        let requests_open = direct && state.dm_screen == Some(DmScreen::Requests);
        window.set_requests_open(requests_open);
        window.set_requests_current(
            direct
                && (requests_open
                    || state.selected.as_ref().is_some_and(|selected| {
                        message_requests
                            .iter()
                            .chain(&spam)
                            .any(|room| &room.id == selected)
                    })),
        );
        if direct {
            listed.retain(|room| {
                room.category != discord::REQUESTS && room.category != discord::SPAM
            });
            // Pinned DMs come first, in the order they were pinned.
            listed.sort_by_key(|room| {
                state
                    .pinned
                    .iter()
                    .position(|id| *id == room.id)
                    .unwrap_or(usize::MAX)
            });
        }
        let pinned_dms = if direct {
            listed
                .iter()
                .take_while(|room| state.pinned.contains(&room.id))
                .count()
        } else {
            0
        };
        // A Discord server's pinned channels come first, each with its
        // threads, under a heading of their own; as in Discord, they leave
        // their categories rather than show twice.
        let pinned = match &state.navigation {
            Navigation::Server(id) => state
                .servers
                .iter()
                .find(|server| &server.id == id)
                .map_or(&[][..], |server| server.pinned.as_slice()),
            Navigation::DirectMessages => &[],
        };
        let pinned_at = |room: &yapfast_core::chat::ChatRoom| {
            pinned
                .iter()
                .position(|id| *id == room.id || room.parent.as_ref() == Some(id))
        };
        let mut in_pinned = 0;
        if !pinned.is_empty() {
            listed.sort_by_key(|room| pinned_at(room).unwrap_or(usize::MAX));
            in_pinned = listed
                .iter()
                .take_while(|room| pinned_at(room).is_some())
                .count();
        }
        let mut rows: Vec<_> = listed
            .into_iter()
            .enumerate()
            .map(|(index, room)| {
                let mut folds_by = None;
                let heading = if direct {
                    if index == 0 && pinned_dms > 0 {
                        "Pinned DMs".into()
                    } else if index == pinned_dms {
                        "Direct Messages".into()
                    } else {
                        String::new()
                    }
                } else if index < in_pinned {
                    if index == 0 { "PINNED CHANNELS" } else { "" }.into()
                } else if room.capabilities.categories {
                    // Discord channels sit under their categories, as in
                    // Discord, which may share a name.
                    let this = (room.category_id.as_deref(), room.category.as_str());
                    if category.replace(this) != Some(this) {
                        folds_by = room.category_id.as_deref();
                        room.category.clone()
                    } else {
                        String::new()
                    }
                } else if room.voice && !listed_voice {
                    listed_voice = true;
                    "VOICE CHANNELS".into()
                } else if !room.voice && !listed_text {
                    listed_text = true;
                    "TEXT CHANNELS".into()
                } else {
                    String::new()
                };
                let (detail, detail_emoji) = dm_detail(room);
                let voice = room
                    .person
                    .as_deref()
                    .filter(|_| room.network == Network::Discord)
                    .and_then(|person| in_voice.get(person));
                RoomRow {
                    id: room.id.clone().into(),
                    name: room.name.clone().into(),
                    category: folds_by.unwrap_or(&heading).into(),
                    heading: heading.into(),
                    icon: self.icons.room(room),
                    selected: Some(&room.id) == state.selected.as_ref(),
                    unread: room.unread > 0,
                    badge: mention_badge(room),
                    voice: room.voice,
                    chat: room.voice_chat(),
                    direct: room.direct,
                    initial: initial(&room.name),
                    tint: tint(&room.id),
                    picture: slint::Image::default(),
                    picture_url: room.avatar.as_deref().unwrap_or_default().into(),
                    decoration_url: cosmetics
                        .decoration(room.decoration.as_deref())
                        .unwrap_or_default()
                        .into(),
                    nameplate_url: room
                        .nameplate
                        .as_ref()
                        .filter(|_| !state.hide_nameplates)
                        .map(|plate| &*plate.picture)
                        .unwrap_or_default()
                        .into(),
                    nameplate_color: role_color(
                        room.nameplate
                            .as_ref()
                            .and_then(|plate| Some(plate.colors?[0])),
                    ),
                    nameplate_light: role_color(
                        room.nameplate
                            .as_ref()
                            .and_then(|plate| Some(plate.colors?[1])),
                    ),
                    name_style: name_style::row(cosmetics.style(room.style.as_deref()), &room.name),
                    discord: room.direct && room.network == Network::Discord,
                    locked: room.locked || room.join_locked,
                    person: room.person.is_some(),
                    tag: tag_text(cosmetics.tag(room.tag.as_ref())),
                    tag_badge: tag_badge(cosmetics.tag(room.tag.as_ref())),
                    official: room.official,
                    wave: if room.empty && !room.request {
                        room.person.as_deref().unwrap_or_default().into()
                    } else {
                        Default::default()
                    },
                    pinned: if room.direct {
                        state.pinned.contains(&room.id)
                    } else {
                        index < in_pinned
                    },
                    muted: room.muted,
                    people: if room.people.is_empty() {
                        ModelRc::default()
                    } else {
                        let people: Vec<_> = room
                            .people
                            .iter()
                            .map(|person| PersonRow {
                                id: person.id.clone().into(),
                                name: person.name.clone().into(),
                                initial: initial(&person.name),
                                tint: tint(&person.id),
                                picture: cached_picture(
                                    &mut self.pictures,
                                    state,
                                    person.avatar.as_deref(),
                                ),
                                muted: person.muted,
                                deafened: person.deafened,
                                server_muted: person.server_muted,
                                server_deafened: person.server_deafened,
                                live: person.streaming,
                                video: person.video,
                                local: state.discord_user.as_ref() == Some(&person.id),
                                elsewhere: person.elsewhere,
                                person: person.id.clone().into(),
                                connected: true,
                                ..Default::default()
                            })
                            .collect();
                        ModelRc::new(VecModel::from(people))
                    },
                    voice_started: room
                        .voice_started
                        .map_or(0, super::profile::activity_seconds),
                    voice_summary: if room.voice && !room.direct {
                        yapfast_core::voice_roster::Roster::of(&room.people)
                            .summary()
                            .into()
                    } else {
                        SharedString::default()
                    },
                    call: room.direct && !room.people.is_empty(),
                    // Discord sends the presence of friends and of those
                    // sharing a server; anyone else in a one-to-one DM shows
                    // offline, as in Discord's DM list.
                    presence: if room.person.is_some() && room.network == Network::Discord {
                        presence_name(room.presence.or(Some(Presence::Offline)))
                    } else {
                        presence_name(room.presence)
                    }
                    .into(),
                    detail,
                    detail_emoji,
                    voice_room: voice.map_or("", |place| place.room).into(),
                    voice_channel: voice.map_or("", |place| place.channel).into(),
                    voice_server: voice.map_or("", |place| place.server).into(),
                    thread: room.parent.is_some(),
                    more_active_threads: active_thread_parents.contains(&room.id),
                    ..Default::default()
                }
            })
            .collect();
        // A channel's threads follow it, so a thread's line runs on to the
        // next row when that's a thread too.
        for index in 1..rows.len() {
            if rows[index].thread && rows[index - 1].thread {
                rows[index - 1].thread_continues = true;
            }
        }
        // Categories fold as their server last left them, except while
        // filtering; one without channels shows as its heading alone. The
        // pinned channels above them don't fold.
        let rows = match &state.navigation {
            Navigation::Server(server) if query.is_empty() => {
                let mut rows = rows;
                let rest = rows.split_off(in_pinned);
                let rest = with_empty_categories(rest, &self.app.categories(server));
                rows.extend(match self.layout.collapsed.get(server) {
                    Some(collapsed) => fold_collapsed(
                        rest,
                        collapsed,
                        state.voice.room.as_deref().filter(|_| state.voice.active()),
                    ),
                    None => rest,
                });
                rows
            }
            _ => rows,
        };
        window.set_sidebar_empty(if !rows.is_empty() { "" }
            else if state.scoped_rooms().next().is_some() { "No matching conversations." }
            else if state.navigation == Navigation::DirectMessages { "No direct messages yet. Existing DMs appear here after syncing." }
            else if state.servers.iter().any(|server| server.discord && state.navigation == Navigation::Server(server.id.clone())) { "No channels in this server that you can see." }
            else { "No joined channels in this server. Join a channel in another Matrix client to see it here." }.into());
        // A Discord server's channels and categories drag to move, by their
        // places in the list: each category, and each channel that shows
        // outside a collapsed one, as Discord's client lists them to drop
        // on. Pinned channels and threads stay where they are.
        let mut rows = rows;
        let mut places = Vec::new();
        if let Navigation::Server(server) = &state.navigation
            && query.is_empty()
            && state
                .servers
                .iter()
                .any(|known| known.discord && &known.id == server)
        {
            for row in rows.iter_mut().skip(in_pinned) {
                if !row.heading.is_empty() {
                    places.push(row.category.to_string());
                    row.heading_place = places.len() as i32;
                }
                if !row.hidden && !row.thread && !row.collapsed {
                    places.push(row.id.to_string());
                    row.place = places.len() as i32;
                }
            }
        }
        // A voice channel's people come as a new list each time; the one on
        // screen stays while they're the same, so its row counts as unchanged.
        let rows = rows
            .into_iter()
            .enumerate()
            .map(|(index, mut row)| {
                if let Some(shown) = self.models.rooms.row_data(index)
                    && shown.id == row.id
                {
                    row.people = same_list(&shown.people, row.people);
                }
                row
            })
            .collect::<Vec<_>>();
        // A busy voice channel's row counts its call's time on ActivityClock.
        self.voice_timed = rows.iter().any(|row| row.voice_started > 0 && !row.hidden);
        // The voice card goes with its row, which can go without the
        // pointer leaving it: its channel deleted, emptied or filtered out
        // by the channel search.
        let card = window.global::<VoiceCard>();
        if card.get_people().row_count() > 0
            && !rows.iter().any(|row| {
                row.id == card.get_channel() && !row.hidden && row.people.row_count() > 0
            })
        {
            card.set_people(ModelRc::default());
        }
        update_model(&self.models.rooms, rows);
        self.tick_activities(window);
        self.places = places;
        // What's being dragged keeps going, at its new place.
        if self.arranging.is_some() {
            self.show_arranging(window);
        }
        if self.moving_person.is_some() {
            self.show_moving_person(window);
        }
    }

    /// Someone dragged from a voice channel, and which of the list's rows
    /// they may drop on: the voice channels their menu's Move to offers.
    /// A folded category's hidden row names its first channel but takes no
    /// drop. It stops once none is listed, as when they left the channel or
    /// another server's list shows.
    pub(super) fn show_moving_person(&mut self, window: &YapfastWindow) {
        let targets = self
            .moving_person
            .as_ref()
            .map(|(place, user)| self.app.move_targets(place, user))
            .unwrap_or_default();
        let droppable: Vec<bool> = self
            .models
            .rooms
            .iter()
            .map(|row| !row.hidden && targets.iter().any(|(room, _)| row.id == room.as_str()))
            .collect();
        if !droppable.contains(&true) {
            self.stop_moving_person(window);
            return;
        }
        window.set_person_droppable(ModelRc::new(VecModel::from(droppable)));
        window.set_person_moving(true);
    }

    /// Ends dragging someone, wherever it ended.
    pub(super) fn stop_moving_person(&mut self, window: &YapfastWindow) {
        self.moving_person = None;
        window.set_person_moving(false);
        window.set_person_droppable(ModelRc::default());
    }

    /// The channel or category being dragged in a Discord server's channel
    /// list, by its place, and the places it may drop on; it stops if it
    /// left the list.
    pub(super) fn show_arranging(&mut self, window: &YapfastWindow) {
        let dragged = self
            .arranging
            .as_ref()
            .and_then(|room| self.places.iter().position(|place| place == room))
            .filter(|_| {
                self.arranging
                    .as_deref()
                    .is_some_and(|room| self.app.draggable(room))
            });
        let Some(dragged) = dragged else {
            self.arranging = None;
            window.set_room_arranging(0);
            return;
        };
        window.set_room_arranging(dragged as i32 + 1);
        window.set_room_droppable(ModelRc::new(VecModel::from(
            self.app.droppable(&self.places, dragged),
        )));
    }

    /// The account at the bottom of the sidebar, and the notice.
    fn show_account(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        let account = state.account.as_deref().unwrap_or("Preview");
        let account_name = state
            .account_name
            .as_deref()
            .unwrap_or_else(|| display_part(account));
        window.set_account(account.into());
        window.set_account_name(account_name.into());
        window.set_account_username(state.account_username.as_deref().unwrap_or_default().into());
        window.set_account_user_id(state.discord_user.as_deref().unwrap_or_default().into());
        window.set_account_initial(initial(account_name));
        window.set_account_tint(tint(account_name));
        window.set_account_picture(cached_picture(
            &mut self.pictures,
            state,
            state.account_avatar.as_deref(),
        ));
        // The account's card, from its own profile once that's come. Its
        // pictures are counted again only once some picture has come.
        let shown = self.account_profile_shown.take();
        let own = state.account_profile.as_ref().map(|profile| {
            let kept = shown
                .as_ref()
                .filter(|shown| Arc::ptr_eq(&shown.profile, profile));
            let pictures = match kept {
                Some(kept) if kept.changes == state.picture_changes => kept.pictures,
                _ => card_pictures(state, profile),
            };
            AccountCardShown {
                profile: profile.clone(),
                changes: state.picture_changes,
                pictures,
            }
        });
        let same = match (&own, &shown) {
            (Some(own), Some(shown)) => {
                Arc::ptr_eq(&own.profile, &shown.profile) && own.pictures == shown.pictures
            }
            (None, None) => true,
            _ => false,
        };
        if !same {
            let data = own.as_ref().map_or_else(ProfileData::default, |own| {
                let view = ProfileView {
                    profile: yapfast_core::chat::Profile::clone(&own.profile),
                    ..Default::default()
                };
                profile_data(&mut self.pictures, state, &view)
            });
            window.set_account_profile(data);
        }
        self.account_profile_shown = own;
        let look = window.global::<AccountLook>();
        let cosmetics = state.cosmetics;
        look.set_decoration_url(
            cosmetics
                .decoration(state.account_decoration.as_deref())
                .unwrap_or_default()
                .into(),
        );
        look.set_nameplate_url(
            state
                .account_nameplate
                .as_ref()
                .filter(|_| !state.hide_nameplates)
                .map(|plate| &*plate.picture)
                .unwrap_or_default()
                .into(),
        );
        let colors = state
            .account_nameplate
            .as_ref()
            .and_then(|plate| plate.colors);
        look.set_nameplate_color(role_color(colors.map(|colors| colors[0])));
        look.set_nameplate_light(role_color(colors.map(|colors| colors[1])));
        let (custom_status, status_emoji) = state
            .custom_status
            .as_ref()
            .filter(|_| state.online && !state.preview)
            .map(status_line)
            .unzip();
        window.set_account_status_emoji(status_emoji.flatten().unwrap_or_default().into());
        // The game Yapfast shows as playing, as the activity icon Discord puts
        // before the status: alone it names the game, before a status it adds a bullet.
        let playing = state
            .discord_playing
            .as_ref()
            .filter(|_| state.online && !state.preview && state.discord_show_game);
        window.set_account_activity_icon(i32::from(playing.is_some()));
        window.set_account_activity_bullet(playing.is_some() && custom_status.is_some());
        window.set_account_status(
            if state.preview {
                "Local only"
            } else if let Some(status) = &custom_status {
                status
            } else if let Some(playing) = playing {
                &playing.name
            } else if let Some(status) = &state.account_status {
                status
            } else if state.online {
                "Online"
            } else {
                "Offline, sync paused"
            }
            .into(),
        );
        window.set_has_custom_status(state.custom_status.is_some());
        window.set_show_game(state.discord_show_game);
        let playing = state.discord_playing.as_ref();
        window.set_game_activity_name(playing.map_or("", |playing| &playing.name).into());
        window.set_discord_status(state.discord_presence.as_deref().unwrap_or("online").into());
        window.set_storage(state.storage.unwrap_or_default().into());
        window.set_notice(state.notice.as_deref().unwrap_or_default().into());
    }

    /// The rows of the inbox popout's open tab, from what the client already
    /// knows: the channels and conversations with unread messages, muted ones
    /// only for a mention, or those that mention this account.
    fn show_inbox(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        let mentions_only = window.get_inbox_tab() == 1;
        let servers: HashMap<&str, &str> = state
            .servers
            .iter()
            .flat_map(|server| {
                let name = server.name.as_str();
                server.channels.iter().map(move |id| (id.as_str(), name))
            })
            .collect();
        let rows = state
            .rooms
            .iter()
            .filter(|room| !room.request && !room.unlisted)
            .filter(|room| room.mentions > 0 || (!mentions_only && room.unread > 0 && !room.muted))
            .map(|room| InboxRow {
                id: room.id.as_str().into(),
                name: if room.direct {
                    room.name.as_str().into()
                } else {
                    format!("#{}", room.name).into()
                },
                place: servers
                    .get(room.id.as_str())
                    .copied()
                    .unwrap_or_default()
                    .into(),
                initial: initial(&room.name),
                tint: tint(&room.id),
                picture_url: if room.direct {
                    room.avatar.as_deref().unwrap_or_default().into()
                } else {
                    SharedString::default()
                },
                mentions: i32::try_from(room.mentions).unwrap_or(i32::MAX),
            })
            .collect();
        update_model(&self.models.inbox, rows);
    }

    /// Starting a thread: what the open channel offers, and the "New
    /// Thread" form beside it.
    fn show_new_thread(&mut self, window: &YapfastWindow) {
        let app = &self.app;
        let state = &app.state;
        window.set_can_start_threads(app.can_start_threads());
        window.set_can_create_polls(app.can_create_polls());
        window.set_threads_can_create(state.thread_list().is_some_and(|list| {
            let (public, private) = app.thread_starts(&list.room);
            public || private
        }));
        let form = state.new_thread();
        window.set_new_thread_open(form.is_some());
        let Some(form) = form else {
            return;
        };
        // The fields are the window's while it's open; Yapfast writes them only
        // when they differ, so the caret stays.
        if window.get_new_thread_name() != form.name.as_str() {
            window.set_new_thread_name(form.name.as_str().into());
        }
        if window.get_new_thread_body() != form.body.as_str() {
            window.set_new_thread_body(form.body.as_str().into());
        }
        window.set_new_thread_placeholder(
            match form.default_name.as_str() {
                "" => "New Thread",
                name => name,
            }
            .into(),
        );
        let starter = form.message.as_deref().and_then(|item| state.message(item));
        window.set_new_thread_from_message(starter.is_some());
        if let Some(starter) = starter {
            window.set_new_thread_starter(super::messages::found_row(
                starter,
                self.layout.twelve_hour_clock,
            ));
        }
        window.set_new_thread_can_private(form.can_private);
        window.set_new_thread_only_private(form.only_private);
        window.set_new_thread_private(form.private);
        window.set_new_thread_starting(form.starting);
        window.set_new_thread_error(form.error.as_deref().unwrap_or_default().into());
        window.set_new_thread_leaving(form.leaving);
    }

    /// The open channel's list of its threads, built again only once what
    /// it shows changes, or a minute passes.
    /// Who reacted: the tooltip over the reaction the pointer stays on, and
    /// the Reactions window.
    fn show_reactions(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        let emoji_of = |item: &str, key: &str| -> String {
            state.message(item).map_or_else(
                || key.to_owned(),
                |message| custom_emoji::text(key, &message.emoji),
            )
        };
        match state.reaction_tip() {
            Some((tip, reaction)) => {
                let names = tip.names.as_deref().unwrap_or_default();
                window.set_reaction_tip_text(
                    messages::reaction_tip(&emoji::shortcode(&tip.key), names, reaction.count)
                        .into(),
                );
                window.set_reaction_tip_emoji(emoji_of(&tip.item, &tip.key).into());
            }
            None => {
                window.set_reaction_tip_text(SharedString::default());
                window.set_reaction_tip_emoji(SharedString::default());
            }
        }
        let shown = state.reactions.as_ref();
        window.set_reactions_open(shown.is_some());
        let Some(shown) = shown else {
            if self.models.reaction_pills.row_count() > 0
                || self.models.reactor_rows.row_count() > 0
            {
                self.models.reaction_pills.set_vec(Vec::new());
                self.models.reactor_rows.set_vec(Vec::new());
            }
            return;
        };
        window.set_reactions_key(shown.key.as_str().into());
        window.set_reactions_voters(shown.poll);
        window.set_reactors_loading(shown.loading);
        window.set_reactors_more(state.more_reactors());
        window.set_reactors_error(shown.error.clone().unwrap_or_default().into());
        let pills = if shown.poll {
            state
                .window_answers()
                .iter()
                .map(|answer| ReactionPill {
                    key: answer.id.to_string().into(),
                    label: answer
                        .emoji
                        .as_deref()
                        .map(|key| emoji_of(&shown.item, key))
                        .unwrap_or_default()
                        .into(),
                    name: answer.text.as_str().into(),
                    count: i32::try_from(answer.votes).unwrap_or(i32::MAX),
                })
                .collect()
        } else {
            state
                .window_reactions()
                .into_iter()
                .map(|reaction| ReactionPill {
                    key: reaction.key.as_str().into(),
                    label: emoji_of(&shown.item, &reaction.key).into(),
                    name: emoji::shortcode(&reaction.key).into(),
                    count: i32::try_from(reaction.count).unwrap_or(i32::MAX),
                })
                .collect()
        };
        update_model(&self.models.reaction_pills, pills);
        let rows = shown
            .people
            .iter()
            .map(|person| ReactorRow {
                id: person.id.as_str().into(),
                name: person.name.as_str().into(),
                username: person.username.as_str().into(),
                avatar: person.avatar.as_str().into(),
                initial: initial(&person.name),
                tint: tint(&person.name),
                removable: !shown.poll && (person.me || shown.can_remove),
            })
            .collect();
        update_model(&self.models.reactor_rows, rows);
    }

    fn show_threads(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        window.set_can_list_threads(state.threads_channel().is_some());
        let list = state.thread_list();
        if list.is_some() && !window.get_threads_open() {
            window.set_threads_query(SharedString::default());
        }
        window.set_threads_open(list.is_some());
        let Some(list) = list else {
            if self.threads_shown.take().is_some() {
                self.models.thread_rows.set_vec(Vec::new());
            }
            return;
        };
        let channel = &list.room;
        window.set_threads_searchable(
            self.app
                .may(channel, yapfast_core::chat::Permission::ReadHistory),
        );
        window.set_threads_more(list.more && list.search.is_none());
        window.set_threads_loading(list.loading);
        let sections = self.app.thread_sections().unwrap_or_default();
        let found = list.search.as_ref().map(|search| &search.found);
        // While a search shows, its results stand in for the sections.
        let (note, empty) = match found {
            Some(None) => ("Searching...".to_owned(), false),
            Some(Some(Err(error))) => (error.clone(), false),
            Some(Some(Ok(found))) => (String::new(), found.is_empty()),
            None if sections.is_empty() && list.loading => ("Loading threads...".into(), false),
            None if sections.is_empty() => {
                (list.error.clone().unwrap_or_default(), list.error.is_none())
            }
            None => (String::new(), false),
        };
        window.set_threads_note(note.into());
        window.set_threads_empty(empty);
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |now| now.as_millis() as u64);
        use std::hash::{Hash, Hasher};
        let mut hasher = std::hash::DefaultHasher::new();
        (&sections, found, now / 60_000).hash(&mut hasher);
        let shown = hasher.finish();
        if self.threads_shown == Some(shown) {
            return;
        }
        self.threads_shown = Some(shown);
        let mut rows = Vec::new();
        match found {
            Some(Some(Ok(found))) => {
                rows.extend(found.iter().map(|thread| thread_row(thread, now)));
            }
            _ => {
                let headed = [
                    (&sections.joined, "joined thread", "joined threads"),
                    (
                        &sections.other,
                        "other active thread",
                        "other active threads",
                    ),
                ];
                for (threads, one, many) in headed {
                    let heading = match threads.len() {
                        1 => format!("1 {one}"),
                        count => format!("{count} {many}"),
                    };
                    push_section(&mut rows, threads, heading.to_uppercase(), now);
                }
                push_section(&mut rows, &sections.older, "OLDER THREADS".into(), now);
            }
        }
        let headings = rows.iter().filter(|row| !row.heading.is_empty()).count();
        window.set_threads_headings(headings as i32);
        self.models.thread_rows.set_vec(rows);
    }

    /// The open Discord forum's posts, in place of messages.
    fn show_forum(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        let forum = state.forum();
        window.set_room_forum(state.selected_room().is_some_and(|room| room.forum));
        let Some(forum) = forum else {
            if self.forum_shown.take().is_some() {
                self.models.post_rows.set_vec(Vec::new());
                window.set_posts_query(SharedString::default());
            }
            return;
        };
        let room = &forum.list.room;
        window.set_posts_searchable(
            self.app
                .may(room, yapfast_core::chat::Permission::ReadHistory),
        );
        let posts = self.app.forum_posts().unwrap_or_default();
        let info = self.app.forum_info(room).unwrap_or_default();
        let cards = posts.active.len() + posts.older.len();
        window.set_posts_more(forum.wants_more(cards));
        window.set_posts_loading(forum.loading());
        window.set_posts_searching(posts.found.is_some());
        window.set_posts_by_creation(forum.by_creation);
        window.set_posts_result_note(forum.result_note().into());
        window.set_posts_generation(forum.search_generation() as i32);
        let (note, empty) = match &posts.found {
            Some(None) => ("Searching...".to_owned(), false),
            Some(Some(Err(error))) => (error.clone(), false),
            Some(Some(Ok(found))) => (String::new(), found.is_empty()),
            None if cards == 0 && forum.list.loading => ("Loading posts...".into(), false),
            None if cards == 0 => (
                forum.list.error.clone().unwrap_or_default(),
                forum.list.error.is_none(),
            ),
            None => (String::new(), false),
        };
        window.set_posts_note(note.into());
        window.set_posts_empty(empty);
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |now| now.as_millis() as u64);
        use std::hash::{Hash, Hasher};
        let mut hasher = std::hash::DefaultHasher::new();
        (&posts, room, &forum.tags, forum.by_creation, now / 60_000).hash(&mut hasher);
        let shown = hasher.finish();
        if self.forum_shown == Some(shown) {
            return;
        }
        self.forum_shown = Some(shown);
        let tags: Vec<PostTagChoice> = info
            .tags
            .iter()
            .take(20)
            .map(|tag| PostTagChoice {
                id: tag.id.as_str().into(),
                tag: post_tag(&tag.name, tag.emoji.as_ref()),
                chosen: forum.tags.contains(&tag.id),
            })
            .collect();
        window.set_posts_filter_tags(ModelRc::from(Rc::new(VecModel::from(tags))));
        let row = |post| post_row(post, &info, now);
        let rows: Vec<PostRow> = match &posts.found {
            Some(Some(Ok(found))) => found.iter().map(row).collect(),
            _ => {
                let mut rows: Vec<PostRow> = posts.active.iter().map(row).collect();
                let older = posts
                    .older
                    .iter()
                    .map(row)
                    .enumerate()
                    .map(|(index, mut row)| {
                        if index == 0 {
                            row.heading = "OLDER POSTS".into();
                        }
                        row
                    });
                rows.extend(older);
                rows
            }
        };
        self.models.post_rows.set_vec(rows);
    }

    /// The form for a post in the forum on screen.
    fn show_new_post(&mut self, window: &YapfastWindow) {
        let app = &self.app;
        let state = &app.state;
        window.set_can_post(app.can_post());
        let post = state.new_post();
        window.set_post_composing(post.is_some());
        let Some(post) = post else {
            if self.post_tags_shown.take().is_some() {
                self.models.post_chosen_tags.set_vec(Vec::new());
                self.models.post_tag_choices.set_vec(Vec::new());
            }
            return;
        };
        // The fields are the window's while it's open; Yapfast writes them only
        // when they differ, so the caret stays.
        if window.get_post_title() != post.title.as_str() {
            window.set_post_title(post.title.as_str().into());
        }
        if window.get_post_body() != post.body.as_str() {
            window.set_post_body(post.body.as_str().into());
        }
        let info = app.forum_info(&post.room).unwrap_or_default();
        window.set_post_tag_required(info.require_tag);
        window.set_post_more_tags(post.tags.len() < yapfast_core::application::POST_TAGS);
        let topic = state.topic.as_ref();
        window.set_post_has_guidelines(topic.is_some_and(|topic| !topic.body.trim().is_empty()));
        if !matches!((topic, &self.guidelines_shown), (Some(topic), Some(shown)) if Arc::ptr_eq(topic, shown))
        {
            self.guidelines_shown = topic.cloned();
            window.set_post_guidelines(topic.map_or_else(slint::StyledText::default, |topic| {
                super::messages::topic_text(topic, false)
            }));
        }
        window.set_posting(post.posting);
        window.set_post_error(post.error.as_deref().unwrap_or_default().into());
        window.set_post_leaving(post.leaving);
        let tags = app.post_tags(&post.room);
        let shown = (tags.clone(), post.tags.clone());
        if self.post_tags_shown.as_ref() == Some(&shown) {
            return;
        }
        let choice = |tag: &yapfast_core::chat::ForumTag| PostTagChoice {
            id: tag.id.as_str().into(),
            tag: post_tag(&tag.name, tag.emoji.as_ref()),
            chosen: post.tags.contains(&tag.id),
        };
        let chosen: Vec<PostTagChoice> = post
            .tags
            .iter()
            .filter_map(|id| tags.iter().find(|tag| &tag.id == id))
            .map(choice)
            .collect();
        let choices: Vec<PostTagChoice> = tags.iter().map(choice).collect();
        self.models.post_chosen_tags.set_vec(chosen);
        self.models.post_tag_choices.set_vec(choices);
        self.post_tags_shown = Some(shown);
    }

    /// The open conversation's header.
    fn show_header(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        let room = state.selected_room();
        window.set_room_selected(room.is_some());
        window.set_room_name(room.map_or("", |room| room.name.as_str()).into());
        window.set_room_direct(room.is_some_and(|room| room.direct));
        window.set_room_presence(presence_name(room.and_then(|room| room.presence)).into());
        let (activity, activity_emoji) =
            activity_line(room.and_then(|room| room.activity.as_deref()));
        window.set_room_activity(activity);
        window.set_room_activity_emoji(activity_emoji);
        window.set_profile_available(state.one_to_one().is_some());
        window.set_room_request(room.is_some_and(|room| room.request));
        // What opens a server channel's history in Discord's client: "Welcome
        // to" the server for its first channel, else the channel itself.
        let (intro, intro_title, intro_text) = match (room, &state.navigation) {
            (Some(room), Navigation::Server(id))
                if room.network == Network::Discord
                    && !room.direct
                    && !room.voice
                    && room.parent.is_none() =>
            {
                let server = state.servers.iter().find(|server| &server.id == id);
                let first = server.is_some_and(|server| {
                    server
                        .channels
                        .iter()
                        .filter_map(|channel| state.rooms.iter().find(|room| &room.id == channel))
                        .find(|room| !room.voice && room.parent.is_none() && !room.forum)
                        .is_some_and(|first| first.id == room.id)
                });
                let name = room.name.as_str();
                match server {
                    Some(server) if first => (
                        "server",
                        server.name.clone(),
                        "This is the beginning of this server.".to_owned(),
                    ),
                    _ => (
                        "channel",
                        format!("Welcome to #{name}!"),
                        format!("This is the start of the #{name} channel."),
                    ),
                }
            }
            _ => ("", String::new(), String::new()),
        };
        window.set_intro_kind(intro.into());
        window.set_intro_welcome("Welcome to".into());
        window.set_intro_title(intro_title.into());
        window.set_intro_text(intro_text.into());
        // Discord's words: `Message @sam` in a DM, `Message #general` in a
        // channel, and a group's or thread's own name as it is.
        window.set_composer_placeholder(room.map_or(SharedString::default(), |room| {
            match (room.direct, room.person.is_some(), room.parent.is_none()) {
                (true, true, _) => format!("Message @{}", room.name),
                (false, _, true) => format!("Message #{}", room.name),
                _ => format!("Message {}", room.name),
            }
            .into()
        }));
        window.set_request_title(
            match room {
                Some(room) if room.category == discord::SPAM => {
                    format!("Discord thinks {} may be spam", room.name)
                }
                Some(room) => format!("{} wants to message you", room.name),
                None => String::new(),
            }
            .into(),
        );
        window.set_room_initial(room.map_or(SharedString::default(), |room| initial(&room.name)));
        window.set_room_tint(room.map_or(slint::Color::default(), |room| tint(&room.id)));
        window.set_room_picture(cached_picture(
            &mut self.pictures,
            state,
            room.and_then(|room| room.avatar.as_deref()),
        ));
        let parent = room
            .and_then(|room| room.parent.as_deref())
            .and_then(|parent| state.rooms.iter().find(|listed| listed.id == parent));
        window.set_room_parent(parent.map_or("", |parent| parent.name.as_str()).into());
        window.set_room_parent_id(parent.map_or("", |parent| parent.id.as_str()).into());
        window.set_room_parent_forum(parent.is_some_and(|parent| parent.forum));
        window.set_room_icon(room.map_or_else(
            || self.icons.text.plain.clone(),
            |room| self.icons.channel(room),
        ));
        // A forum post's bar: its first message is the post's, whose id is
        // the thread's.
        let post = room.filter(|room| {
            room.network == Network::Discord && parent.is_some_and(|parent| parent.forum)
        });
        window.set_forum_post(post.is_some());
        window.set_forum_post_item(
            post.and_then(|room| {
                let item = format!("d:{}", room.id.rsplit(':').next()?);
                // Messages run oldest first, so the post is the first.
                state
                    .messages
                    .first()
                    .is_some_and(|message| message.item == item)
                    .then_some(item)
            })
            .unwrap_or_default()
            .into(),
        );
        window.set_forum_post_follow(post.map_or(0, |room| {
            let choices = self.app.menu_choices(&room.id);
            if choices.contains(&MenuChoice::LeaveThread) {
                2
            } else {
                i32::from(choices.contains(&MenuChoice::JoinThread))
            }
        }));
        // Discord counts a channel's members only once its list comes.
        window.set_members(
            room.map_or(SharedString::default(), |room| match room.members {
                // A forum has no member list.
                _ if room.forum => SharedString::default(),
                0 => "Members".into(),
                1 => "1 member".into(),
                count => format!("{count} members").into(),
            }),
        );
        window.set_members_available(state.lists_members());
        window.set_room_id(state.selected.as_deref().unwrap_or_default().into());
        if let Some(settings) = state
            .selected
            .as_deref()
            .and_then(|id| self.app.thread_notifications(id))
        {
            window.set_room_muted(settings.muted);
            window.set_can_notify(true);
        } else {
            window.set_room_muted(room.is_some_and(|room| room.muted));
            window.set_can_notify(state.selected.as_deref().is_some_and(|id| {
                state
                    .menu_choices(id)
                    .contains(&MenuChoice::ChannelNotifications)
            }));
        }
        // A forum's topic is its post guidelines, which the form shows.
        let topic = state
            .topic
            .as_ref()
            .filter(|_| !room.is_some_and(|room| room.forum));
        window.set_has_topic(topic.is_some());
        let same = match (topic, &self.topic_shown) {
            (Some(topic), Some(shown)) => Arc::ptr_eq(topic, shown),
            (None, None) => true,
            _ => false,
        };
        if !same {
            self.topic_shown = topic.cloned();
            let styled = |one_line| {
                topic.map_or_else(slint::StyledText::default, |topic| {
                    topic_text(topic, one_line)
                })
            };
            window.set_room_topic(styled(true));
            window.set_room_topic_full(styled(false));
        }
    }

    /// What the open DM's header opens: its pinned messages, what its
    /// search found, and the friends picker.
    fn show_dm_tools(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        let twelve_hour = self.layout.twelve_hour_clock;
        let selected = state.selected.as_deref();
        let spoiler_hidden = selected.is_some_and(|room| state.room_spoiler_hidden(room));
        window.set_room_spoiler_hidden(spoiler_hidden);
        window.set_can_pin(
            !spoiler_hidden
                && state
                    .conversation_that(|can| can.pins)
                    .is_some_and(|room| !room.forum),
        );
        window
            .set_can_search(!spoiler_hidden && state.conversation_that(|can| can.search).is_some());
        window.set_can_add_people(
            state.discord_online && state.dm_that(|can| can.group_dms).is_some(),
        );
        let pins = state
            .pins
            .as_ref()
            .filter(|pins| !spoiler_hidden && Some(pins.room.as_str()) == selected);
        window.set_pins_open(pins.is_some());
        window.set_pins_note(
            match pins.map(|pins| &pins.messages) {
                Some(None) => "Loading pinned messages...",
                Some(Some(Err(error))) => error.as_str(),
                Some(Some(Ok(pinned))) if pinned.is_empty() => {
                    if state.selected_room().is_some_and(|room| room.direct) {
                        "This conversation doesn't have any pinned messages yet."
                    } else {
                        "This channel doesn't have any pinned messages yet."
                    }
                }
                _ => "",
            }
            .into(),
        );
        let pinned = match pins.and_then(|pins| pins.messages.as_ref()) {
            Some(Ok(pinned)) => pinned.as_slice(),
            _ => &[],
        };
        show_found(&self.models.pins, pinned, twelve_hour);

        let search = state.search_shown().filter(|_| !spoiler_hidden);
        let server = search.is_some_and(|search| discord::parse_server(&search.place).is_some());
        // The box names where it looks: the DM, or the channel's server.
        let place = state.search_place();
        let looks_in = place
            .as_deref()
            .and_then(|place| state.servers.iter().find(|server| server.id == place))
            .map(|server| server.name.as_str())
            .or(state.selected_room().map(|room| room.name.as_str()))
            .unwrap_or_default();
        window.set_search_placeholder(format!("Search {looks_in}").into());
        window.set_search_open(search.is_some());
        window.set_search_loading(search.is_some_and(|search| search.loading));
        window.set_search_more(search.is_some_and(Search::more));
        window.set_search_heading(
            match search {
                Some(search) if search.results.is_empty() && search.loading => {
                    "Searching...".into()
                }
                Some(search) if search.results.is_empty() && search.error.is_some() => {
                    "Search".into()
                }
                Some(Search { total: 1, .. }) => "1 Result".into(),
                Some(search) => format!("{} Results", search.total),
                None => String::new(),
            }
            .into(),
        );
        window.set_search_note(
            match search {
                Some(Search {
                    error: Some(error), ..
                }) => error.as_str(),
                Some(search) if !search.loading && search.results.is_empty() => {
                    if server {
                        "Nothing in this server matches. Try other words."
                    } else {
                        "Nothing in this conversation matches. Try other words."
                    }
                }
                _ => "",
            }
            .into(),
        );
        show_hits(
            &self.models.search_results,
            state,
            search.map_or(&[][..], |search| &search.results),
            server,
            twelve_hour,
        );

        let picker = state
            .add_people
            .as_ref()
            .filter(|picker| Some(picker.room.as_str()) == selected);
        if picker.is_some() && !window.get_add_people_open() {
            window.set_add_people_query(SharedString::default());
        }
        window.set_add_people_open(picker.is_some());
        window.set_add_people_one_to_one(state.one_to_one().is_some());
        window.set_add_people_room(state.group_room() as i32);
        window.set_add_people_chosen(picker.map_or(0, |picker| picker.chosen.len() as i32));
        window.set_add_people_adding(picker.is_some_and(|picker| picker.adding));
        window.set_add_people_note(
            picker
                .and_then(|picker| picker.error.as_deref())
                .unwrap_or_default()
                .into(),
        );
        // Friends' presence changes often, and a refresh comes with each
        // change; the rows are built again only when what they show changed.
        let friends = picker.map(|_| state.addable_friends());
        let shown = friends.as_ref().zip(picker).map(|(friends, picker)| {
            use std::hash::{Hash, Hasher};
            let mut hasher = std::hash::DefaultHasher::new();
            (friends, &picker.chosen).hash(&mut hasher);
            hasher.finish()
        });
        if shown == self.picker_shown {
            return;
        }
        self.picker_shown = shown;
        let people = match friends.zip(picker) {
            Some((friends, picker)) => friends
                .into_iter()
                .map(|friend| PickRow {
                    id: friend.id.clone().into(),
                    name: friend.name.clone().into(),
                    initial: initial(&friend.name),
                    tint: tint(&friend.name),
                    picture_url: friend.avatar.clone().unwrap_or_default().into(),
                    presence: presence_name(friend.presence).into(),
                    chosen: picker.chosen.contains(&friend.id),
                })
                .collect(),
            None => vec![],
        };
        update_model(&self.models.add_people, people);
    }

    /// The member list, the reactions offered on messages, and a role's card.
    fn show_members(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        let now = yapfast_core::clock::now_ms();
        let owner = state
            .selected
            .as_deref()
            .and_then(|room| self.app.server_owner(room));
        let shown = self.roster_shown.as_ref();
        // The same conversation's people, changed within the pause after the
        // list was built, wait for its end; see `ROSTER_PAUSE`.
        let held = shown.filter(|shown| {
            self.roster_due.running()
                && shown.selection_version == state.selection_version
                && matches!((&shown.members, &state.members), (Some(Ok(_)), Some(Ok(_))))
                && !shown.same_members(state, &state.members)
        });
        self.roster_held |= held.is_some();
        let shown_members = match held {
            Some(shown) => shown.members.clone(),
            None => state.members.clone(),
        };
        let list = !shown.is_some_and(|shown| shown.shows_list(state, &shown_members, &owner, now));
        let panel = !shown.is_some_and(|shown| shown.shows_panel(state, &shown_members, now));
        let members = match &shown_members {
            Some(Ok(members)) => members.as_slice(),
            _ => &[],
        };
        let panel_second = if panel {
            // Discord shows the panel in a server's channels, but not its forums.
            let in_channel = state
                .selected_room()
                .filter(|room| !room.direct && !room.forum);
            let rows = match in_channel {
                Some(room) => activity_panel(state, &room.id, members, now),
                None => Vec::new(),
            };
            let second = (!rows.is_empty()).then_some(now / 1000);
            update_model(&self.models.roster_activity, rows);
            second
        } else {
            shown.and_then(|shown| shown.panel_second)
        };
        if list {
            self.show_roster(window, members, owner.as_deref(), now);
            self.roster_held = false;
            let (adapter, weak) = (self.weak.clone(), window.as_weak());
            self.roster_due
                .start(slint::TimerMode::SingleShot, ROSTER_PAUSE, move || {
                    if let (Some(adapter), Some(window)) = (adapter.upgrade(), weak.upgrade()) {
                        let mut adapter = adapter.borrow_mut();
                        if adapter.roster_held {
                            adapter.show_members(&window);
                        }
                    }
                });
        }
        if list || panel {
            self.roster_shown = Some(RosterShown {
                members: shown_members.clone(),
                selection_version: state.selection_version,
                owner,
                cosmetics: state.cosmetics,
                hide_nameplates: state.hide_nameplates,
                timeout_ends: members
                    .iter()
                    .filter_map(|member| member.timed_out_until)
                    .filter(|&until| until > now)
                    .min(),
                feed: state.activity_feed.clone(),
                people: state.activity_people.clone(),
                panel_second,
            });
        }
        self.show_reactions_offered(window);
        self.show_role(window);
    }

    /// The member list's rows.
    fn show_roster(
        &self,
        window: &YapfastWindow,
        members: &[yapfast_core::chat::ChatMember],
        owner: Option<&str>,
        now: u64,
    ) {
        let state = &self.app.state;
        let cosmetics = state.cosmetics;
        window.set_roster_note(
            match &state.members {
                None => "Loading members...",
                Some(Err(error)) => *error,
                Some(Ok(members)) if members.is_empty() => "No one else has joined yet.",
                Some(Ok(_)) => "",
            }
            .into(),
        );
        update_model(
            &self.models.roster,
            members
                .iter()
                .enumerate()
                .flat_map(|(index, member)| {
                    // Discord names its groups; Matrix members group by role.
                    // Each heading is a row of its own, so a count that
                    // changes redraws only it, and the list keeps its height.
                    let heading: SharedString = if let Some(group) = &member.group {
                        if index == 0 || members[index - 1].group.as_ref() != Some(group) {
                            group.as_str().into()
                        } else {
                            SharedString::default()
                        }
                    } else if index == 0 || members[index - 1].role != member.role {
                        let count = members
                            .iter()
                            .filter(|other| other.role == member.role)
                            .count();
                        let role = match member.role {
                            Role::Admin => "ADMINS",
                            Role::Moderator => "MODERATORS",
                            Role::Member => "MEMBERS",
                        };
                        format!("{role} — {count}").into()
                    } else {
                        SharedString::default()
                    };
                    let heading = (!heading.is_empty()).then(|| MemberRow {
                        heading,
                        group_icon: member.group_icon.as_deref().unwrap_or_default().into(),
                        ..MemberRow::default()
                    });
                    let (activity_icon, activity_bullet, named) =
                        subline(&member.activities, member.activity.as_deref());
                    let (activity, activity_emoji) =
                        activity_line(named.as_deref().or(member.activity.as_deref()));
                    let row = MemberRow {
                        activity_icon,
                        activity_bullet,
                        id: member.id.clone().into(),
                        name: member.name.clone().into(),
                        initial: initial(&member.name),
                        tint: tint(&member.name),
                        picture: slint::Image::default(),
                        picture_url: member.avatar.as_deref().unwrap_or_default().into(),
                        role_icon: member.role_icon.as_deref().unwrap_or_default().into(),
                        tag: tag_text(cosmetics.tag(member.tag.as_ref())),
                        tag_badge: tag_badge(cosmetics.tag(member.tag.as_ref())),
                        decoration_url: cosmetics
                            .decoration(member.decoration.as_deref())
                            .unwrap_or_default()
                            .into(),
                        name_style: name_style::row(
                            cosmetics.style(member.style.as_deref()),
                            &member.name,
                        ),
                        nameplate_url: member
                            .nameplate
                            .as_ref()
                            .filter(|_| !state.hide_nameplates)
                            .map(|plate| &*plate.picture)
                            .unwrap_or_default()
                            .into(),
                        nameplate_color: role_color(
                            member
                                .nameplate
                                .as_ref()
                                .and_then(|plate| Some(plate.colors?[0])),
                        ),
                        nameplate_light: role_color(
                            member
                                .nameplate
                                .as_ref()
                                .and_then(|plate| Some(plate.colors?[1])),
                        ),
                        timed_out: member.timed_out_until.is_some_and(|until| until > now),
                        bot: member.bot,
                        owner: owner == Some(member.id.as_str()),
                        boosting: member
                            .boosting_since
                            .map(|since| {
                                format!(
                                    "Server boosting since {}",
                                    yapfast_core::clock::day(since / 1000)
                                )
                            })
                            .unwrap_or_default()
                            .into(),
                        presence: presence_name(member.presence).into(),
                        color: role_color(member.color),
                        has_color: member.color.is_some(),
                        // One line under the name, as Discord shows it.
                        activity,
                        activity_emoji,
                        ..MemberRow::default()
                    };
                    heading.into_iter().chain([row])
                })
                .collect(),
        );
    }

    /// The reactions offered on messages, the most used first.
    fn show_reactions_offered(&self, window: &YapfastWindow) {
        let scale = window.window().scale_factor();
        let keys = self.app.frequent_reactions(4);
        // A custom emoji's picture comes from the pictures the application
        // keeps, not the picker's, which it lets go of when it closes; one
        // not there yet is asked for, and shows once it comes.
        let ids: HashSet<&str> = keys
            .iter()
            .filter_map(|key| key.split_once(':').map(|(_, id)| id))
            .collect();
        let custom = self.app.emoji_by_id(&ids);
        let cells: Vec<EmojiCell> = keys
            .iter()
            .map(|key| {
                let cell = emoji::cell(key);
                if cell.picture.size().width > 0 {
                    return cell;
                }
                let Some(emoji) = key
                    .split_once(':')
                    .and_then(|(_, id)| custom.iter().find(|emoji| emoji.id == id))
                else {
                    return cell;
                };
                match self.app.state.pictures.get(&emoji.picture) {
                    Some(arrived) => EmojiCell {
                        picture: picture(arrived),
                        ..cell
                    },
                    None => {
                        window
                            .global::<PictureStore>()
                            .invoke_request(emoji.picture.as_str().into());
                        cell
                    }
                }
            })
            .collect();
        let cells = emoji::with_pictures(cells, scale);
        update_model(
            &self.models.bar_reactions,
            cells[..cells.len().min(3)].to_vec(),
        );
        update_model(&self.models.menu_reactions, cells);
    }

    /// A role's card, with the members known to have it.
    fn show_role(&self, window: &YapfastWindow) {
        let role = self.app.state.role.as_ref();
        window.set_role_open(role.is_some());
        if let Some(role) = role {
            window.set_role_name(role.name.clone().into());
            window.set_role_color(role_color(role.color));
            window.set_role_has_color(role.color.is_some());
            window.set_role_note(
                match &role.members {
                    None => "Loading...",
                    Some(members) if members.is_empty() => {
                        "S;C hasn't seen anyone with this role yet."
                    }
                    Some(_) => "",
                }
                .into(),
            );
        }
        let role_members: Vec<MemberRow> = role
            .and_then(|role| role.members.as_ref())
            .into_iter()
            .flatten()
            .map(|member| MemberRow {
                id: member.id.clone().into(),
                name: member.name.clone().into(),
                initial: initial(&member.name),
                tint: tint(&member.name),
                picture: slint::Image::default(),
                picture_url: member.avatar.as_deref().unwrap_or_default().into(),
                color: role_color(member.color),
                has_color: member.color.is_some(),
                ..Default::default()
            })
            .collect();
        update_model(&self.models.role_members, role_members);
    }

    /// A Discord server's or channel's invite dialog.
    fn show_invite(&self, window: &YapfastWindow) {
        let invite = self.app.state.invite.as_ref();
        // A dialog opening starts from the link it makes first.
        if let Some(invite) = invite
            && !window.get_invite_open()
        {
            let index = |list: &[u32], value| {
                list.iter()
                    .position(|known| *known == value)
                    .map_or(0, |index| index as i32)
            };
            window.set_invite_age(index(&INVITE_AGES, invite.max_age));
            window.set_invite_uses(index(&INVITE_USES, invite.max_uses));
        }
        window.set_invite_open(invite.is_some());
        let Some(invite) = invite else {
            return;
        };
        let lasts = match invite.max_age {
            0 => "never expires".to_owned(),
            1800 => "expires in 30 minutes".to_owned(),
            3600 => "expires in an hour".to_owned(),
            86_400 => "expires in a day".to_owned(),
            age if age % 86_400 == 0 => format!("expires in {} days", age / 86_400),
            age => format!("expires in {} hours", age / 3600),
        };
        let works = match invite.max_uses {
            0 => String::new(),
            1 => " and works once".to_owned(),
            uses => format!(" and works {uses} times"),
        };
        let place = if invite.voice {
            invite.channel.clone()
        } else {
            format!("#{}", invite.channel)
        };
        window.set_invite_prompt(InvitePrompt {
            title: format!("Invite friends to {}", invite.server).into(),
            detail: format!("They'll land in {place}.").into(),
            link: invite.link.as_deref().unwrap_or_default().into(),
            note: if invite.link.is_some() {
                format!("This link {lasts}{works}.").into()
            } else {
                SharedString::default()
            },
            making: invite.making,
            error: invite.error.as_deref().unwrap_or_default().into(),
        });
    }

    /// Join a Server, or the dialog a clicked invite link opens.
    fn show_join(&self, window: &YapfastWindow) {
        let state = &self.app.state;
        window.set_can_join_server(state.discord_online || state.preview);
        let join = state.join.as_ref();
        // A dialog opening starts with an empty field.
        if join.is_some() && !window.get_join_open() {
            window.set_join_link(SharedString::default());
        }
        window.set_join_open(join.is_some());
        let Some(join) = join else {
            return;
        };
        let preview = join.preview.as_ref();
        let detail = preview.map(|preview| match (preview.members, preview.online) {
            (Some(members), Some(online)) if members >= 5 || online > 0 => {
                format!("{online} online, {members} members")
            }
            _ if preview.voice => preview.channel.clone(),
            _ => format!("#{}", preview.channel),
        });
        let confirm = if join.form.is_some() {
            "Open in browser"
        } else if join.member {
            "Open Server"
        } else if preview.is_some() {
            "Join Server"
        } else if join.from_link {
            ""
        } else {
            "Find Invite"
        };
        let status = if join.form.is_some() {
            "You joined. This server asks new members to fill in a form before they can talk, which S;C can't show yet. Finish it in Discord's web app."
        } else if join.captcha.is_some() {
            "Discord asks for a captcha first. Solve it in your browser."
        } else if join.joining {
            "Joining..."
        } else if join.resolving {
            "Looking up the invite..."
        } else if join.member {
            "You're already in this server."
        } else {
            ""
        };
        window.set_join_prompt(JoinPrompt {
            title: if join.from_link {
                "You've been invited to join a server"
            } else {
                "Join a Server"
            }
            .into(),
            field: !join.from_link,
            found: preview.is_some(),
            name: preview
                .map(|preview| preview.name.as_str())
                .unwrap_or_default()
                .into(),
            picture_url: preview
                .and_then(|preview| preview.icon.as_deref())
                .unwrap_or_default()
                .into(),
            initial: preview
                .map(|preview| initial(&preview.name))
                .unwrap_or_default(),
            detail: detail.unwrap_or_default().into(),
            confirm: confirm.into(),
            busy: join.resolving || join.joining,
            status: status.into(),
            captcha: join.captcha.is_some(),
            form: join.form.is_some(),
            error: join.error.as_deref().unwrap_or_default().into(),
        });
    }

    /// The scheduled event a clicked event link opened.
    fn show_event(&self, window: &YapfastWindow) {
        let state = &self.app.state;
        let dialog = state.scheduled_event.as_ref();
        window.set_event_open(dialog.is_some());
        let Some(dialog) = dialog else {
            return;
        };
        let preview = dialog.preview.as_ref();
        let when = preview
            .filter(|preview| preview.starts_at > 0)
            .map(|preview| {
                yapfast_core::clock::event(
                    preview.starts_at,
                    preview.ends_at,
                    yapfast_core::clock::now_ms() / 1000,
                    self.layout.twelve_hour_clock,
                )
            });
        let detail = preview.map(|preview| {
            let mut parts = Vec::new();
            if let Some(location) = &preview.location {
                parts.push(location.clone());
            } else if let Some(room) = &preview.room
                && let Some(found) = state.rooms.iter().find(|known| &known.id == room)
            {
                parts.push(format!("#{}", found.name));
            }
            if let Some(creator) = &preview.creator {
                parts.push(format!("by {creator}"));
            }
            if let Some(count) = preview.interested_count {
                parts.push(format!("{count} interested"));
            }
            parts.join(" · ")
        });
        let confirm = match preview {
            Some(preview) if !preview.over && preview.interested => "Remove interest",
            Some(preview) if !preview.over => "Interested",
            _ => "",
        };
        let status = if dialog.resolving {
            "Looking up the event..."
        } else if dialog.marking {
            "Saving..."
        } else if preview.is_some_and(|preview| preview.over) {
            "This event has ended."
        } else if preview.is_some_and(|preview| preview.active) {
            "This event is going on now."
        } else if preview.is_some_and(|preview| preview.interested) {
            "You're interested in this event."
        } else {
            ""
        };
        window.set_event_prompt(EventPrompt {
            title: "Event".into(),
            found: preview.is_some(),
            name: preview
                .map(|preview| preview.name.as_str())
                .unwrap_or_default()
                .into(),
            when: when.unwrap_or_default().into(),
            detail: detail.unwrap_or_default().into(),
            description: preview
                .and_then(|preview| preview.description.as_deref())
                .unwrap_or_default()
                .into(),
            confirm: confirm.into(),
            busy: dialog.resolving || dialog.marking,
            status: status.into(),
            error: dialog.error.as_deref().unwrap_or_default().into(),
        });
    }

    /// The gift a clicked gift link opened.
    fn show_gift(&self, window: &YapfastWindow) {
        let gift = self.app.state.gift.as_ref();
        window.set_gift_open(gift.is_some());
        let Some(gift) = gift else {
            return;
        };
        let preview = gift.preview.as_ref();
        let detail = preview.map(|preview| {
            let mut parts = Vec::new();
            if let Some(plan) = &preview.plan {
                parts.push(plan.clone());
            }
            if let Some(gifter) = &preview.gifter {
                parts.push(format!("from {gifter}"));
            }
            parts.join(" · ")
        });
        let redeeming = self.app.state.redeeming_gifts.contains(&gift.code);
        let redeemable =
            !gift.redeemed && preview.is_some_and(yapfast_core::chat::GiftPreview::redeemable);
        let in_discord = !gift.redeemed && preview.is_some_and(|preview| preview.in_discord);
        let status = if gift.redeemed {
            "Redeemed. Enjoy!"
        } else if redeeming {
            "Redeeming..."
        } else if gift.resolving {
            "Looking up the gift..."
        } else if preview.is_some_and(|preview| preview.redeemed) {
            "You've already redeemed this gift."
        } else if preview.is_some_and(|preview| preview.spent) {
            "This gift has already been redeemed."
        } else if in_discord {
            "This gift can only be redeemed in Discord. Open it in the browser to redeem it there."
        } else {
            ""
        };
        window.set_gift_prompt(GiftPrompt {
            title: "You've been sent a gift".into(),
            found: preview.is_some(),
            name: preview
                .map(|preview| preview.name.as_str())
                .unwrap_or_default()
                .into(),
            detail: detail.unwrap_or_default().into(),
            confirm: if redeemable {
                "Redeem Gift"
            } else if in_discord {
                "Open in Browser"
            } else {
                ""
            }
            .into(),
            browser: in_discord,
            busy: gift.resolving || redeeming,
            status: status.into(),
            error: gift.error.as_deref().unwrap_or_default().into(),
        });
    }

    /// The application a clicked authorization link opened.
    fn show_oauth(&self, window: &YapfastWindow) {
        let dialog = self.app.state.oauth.as_ref();
        window.set_oauth_open(dialog.is_some());
        let Some(dialog) = dialog else {
            return;
        };
        let preview = dialog.preview.as_ref();
        let addable: Vec<&yapfast_core::chat::OAuthGuild> = preview
            .map(|preview| {
                preview
                    .guilds
                    .iter()
                    .filter(|guild| guild.can_add)
                    .collect()
            })
            .unwrap_or_default();
        window.set_oauth_guilds(
            Rc::new(VecModel::from(
                addable
                    .iter()
                    .map(|guild| SharedString::from(guild.name.as_str()))
                    .collect::<Vec<_>>(),
            ))
            .into(),
        );
        window.set_oauth_guild_chosen(
            addable
                .iter()
                .position(|guild| Some(&guild.id) == dialog.guild.as_ref())
                .map(|index| i32::try_from(index).unwrap_or_default())
                .unwrap_or_default(),
        );
        let detail = preview.and_then(|preview| {
            preview
                .about
                .clone()
                .filter(|about| !about.is_empty())
                .or_else(|| preview.bot.clone())
        });
        let wants = preview.map(|preview| {
            let mut lines: Vec<String> = preview
                .wants
                .iter()
                .map(|wants| format!("- {wants}"))
                .collect();
            if let Some(bits) = preview.permissions.filter(|bits| *bits != 0) {
                lines.push(format!("- Bot permissions: {}", permission_names(bits)));
            }
            match preview.redirect.as_deref() {
                Some(url) if links::openable(url) => {
                    let host = url
                        .split_once("://")
                        .map(|(_, rest)| rest)
                        .and_then(|rest| rest.split(['/', '?', '#']).next())
                        .unwrap_or_default();
                    lines.push(format!("Afterward, Discord sends you to {host}."));
                }
                Some(url) => lines.push(format!(
                    "Afterward, Discord hands its answer to {url}, which S;C won't open."
                )),
                None => {}
            }
            lines.join("\n")
        });
        let mut warnings = Vec::new();
        if preview.is_some_and(|preview| preview.controls_client) {
            warnings.push(
                "It asks to control your Discord client, which can do nearly anything \
                 your account can. Authorize it only if you trust it with your account.",
            );
        }
        if preview
            .and_then(|preview| preview.permissions)
            .is_some_and(|bits| bits & ADMINISTRATOR != 0)
        {
            warnings.push(
                "Its bot asks for Administrator: every permission in the server, \
                 in every channel, whatever its roles allow.",
            );
        }
        let locked = preview.is_some_and(|preview| preview.guild_install && preview.guild_locked);
        let picker =
            preview.is_some_and(|preview| preview.guild_install && !locked && !addable.is_empty());
        // A link that names its one server shows it, as it can't be changed.
        let locked_to = preview
            .filter(|_| locked)
            .zip(dialog.guild.as_ref())
            .and_then(|(preview, chosen)| preview.guilds.iter().find(|guild| &guild.id == chosen))
            .map(|guild| guild.name.as_str());
        let blocked =
            preview.is_some_and(|preview| preview.guild_install && dialog.guild.is_none());
        let status = if dialog.resolving {
            "Looking up the application..."
        } else if dialog.authorizing {
            "Authorizing..."
        } else if dialog.done && dialog.next.is_some() {
            "Authorized. Discord sends you on to this address, which isn't a web page, \
             so S;C doesn't open it. Copy it if the app asks for it."
        } else if dialog.done {
            "Authorized."
        } else if !locked
            && preview.is_some_and(|preview| preview.guild_install && addable.is_empty())
        {
            "You don't manage any server it can be added to."
        } else if preview.is_some_and(|preview| preview.authorized) {
            "You've authorized this before. Authorizing again is fine."
        } else {
            ""
        };
        window.set_oauth_prompt(OAuthPrompt {
            title: match preview {
                Some(preview) => format!("Authorize {}", preview.name),
                None => "Authorize".to_owned(),
            }
            .into(),
            found: preview.is_some(),
            name: preview
                .map(|preview| preview.name.as_str())
                .unwrap_or_default()
                .into(),
            picture_url: preview
                .and_then(|preview| preview.icon.as_deref())
                .unwrap_or_default()
                .into(),
            initial: preview
                .map(|preview| initial(&preview.name))
                .unwrap_or_default(),
            detail: detail.unwrap_or_default().into(),
            wants: wants.unwrap_or_default().into(),
            warning: warnings.join("\n").into(),
            guild_picker: picker,
            guild_name: locked_to.unwrap_or_default().into(),
            address: dialog.next.as_deref().unwrap_or_default().into(),
            confirm: if preview.is_some() && !dialog.done && !blocked {
                "Authorize"
            } else {
                ""
            }
            .into(),
            busy: dialog.resolving || dialog.authorizing,
            status: status.into(),
            error: dialog.error.as_deref().unwrap_or_default().into(),
        });
    }

    /// The dialog that makes, copies or deletes a Discord channel or
    /// category.
    fn show_channel_dialog(&self, window: &YapfastWindow) {
        let dialog = self.app.state.channel_dialog.as_ref();
        // Its fields start from the channel's, as it opens.
        if let Some(dialog) = dialog
            && !window.get_channel_open()
        {
            let settings = dialog.settings.clone().unwrap_or_default();
            window.set_channel_name(settings.name.into());
            window.set_channel_kind(i32::from(dialog.kind == ChannelKind::Voice));
        }
        window.set_channel_open(dialog.is_some());
        let Some(dialog) = dialog else {
            return;
        };
        let category = dialog.kind == ChannelKind::Category;
        let thing = if category { "category" } else { "channel" };
        let named = |name: &str| {
            if dialog.kind == ChannelKind::Text {
                format!("#{name}")
            } else {
                name.to_owned()
            }
        };
        let (title, detail, confirm) = match &dialog.ask {
            ChannelAsk::Create { .. } => (
                format!("Create {thing}"),
                if dialog.name.is_empty() {
                    format!("In {}", dialog.server_name)
                } else {
                    format!("In {}", dialog.name)
                },
                format!("Create {thing}"),
            ),
            ChannelAsk::Duplicate(_) => (
                "Duplicate channel".to_owned(),
                format!(
                    "A copy of {}, with its settings and permissions, in the same category.",
                    named(&dialog.name)
                ),
                "Create channel".to_owned(),
            ),
            ChannelAsk::Delete(_) => (
                format!("Delete {thing}"),
                format!(
                    "Are you sure you want to delete {}? This cannot be undone.",
                    named(&dialog.name)
                ),
                format!("Delete {thing}"),
            ),
        };
        let deleting = matches!(dialog.ask, ChannelAsk::Delete(_));
        window.set_channel_prompt(ChannelPrompt {
            title: title.into(),
            detail: detail.into(),
            confirm: confirm.into(),
            danger: deleting,
            kinds: matches!(dialog.ask, ChannelAsk::Create { .. }) && !category,
            named: !deleting,
            field: if category {
                "CATEGORY NAME"
            } else {
                "CHANNEL NAME"
            }
            .into(),
            placeholder: if category {
                "New Category"
            } else {
                "new-channel"
            }
            .into(),
            saving: dialog.saving,
            error: dialog.error.as_deref().unwrap_or_default().into(),
            ..Default::default()
        });
    }

    /// The editor of this account's Discord profile, its main one or a
    /// server's, as its profile card shows it.
    pub(super) fn show_profile_editor(&mut self, window: &YapfastWindow) {
        use yapfast_core::application::{BIO_LIMIT, NAME_LIMIT, PRONOUNS_LIMIT, ProfileText};
        let editor = self.app.state.profile_editor.as_ref();
        // Its texts follow the editor's: what Discord has once that's here,
        // and again after Reset. Typing changes both alike.
        if let Some(editor) = editor {
            macro_rules! follow {
                ($text:expr, $get:ident, $set:ident) => {
                    if window.$get() != $text.as_str() {
                        window.$set($text.as_str().into());
                    }
                };
            }
            follow!(
                editor.name,
                get_profile_editor_name,
                set_profile_editor_name
            );
            follow!(
                editor.pronouns,
                get_profile_editor_pronouns,
                set_profile_editor_pronouns
            );
            follow!(editor.bio, get_profile_editor_bio, set_profile_editor_bio);
            follow!(
                editor.colour,
                get_profile_editor_colour,
                set_profile_editor_colour
            );
        }
        let Some(editor) = editor else {
            // Its pictures go with it.
            if window.get_profile_editor_open() {
                window.set_profile_editor_open(false);
                window.set_profile_editor_prompt(ProfileEditorPrompt::default());
            }
            return;
        };
        window.set_profile_editor_open(true);
        let main = editor.main();
        let fallback = editor.profile.as_ref().map(|profile| &profile.fallback);
        let fallback_text = |text: Option<&String>| text.cloned().unwrap_or_default();
        let (avatar, new_avatar) = editor.picture(ProfilePicture::Avatar);
        let (banner, new_banner) = editor.picture(ProfilePicture::Banner);
        let written = |text: &str, fallback: Option<&String>| {
            let text = text.trim();
            if text.is_empty() {
                fallback_text(fallback)
            } else {
                text.to_owned()
            }
        };
        let colour = editor.accent();
        let accent = if editor.may_write(ProfileText::Colour) {
            colour.unwrap_or(editor.profile.as_ref().and_then(|profile| profile.accent))
        } else {
            editor.profile.as_ref().and_then(|profile| profile.accent)
        };
        // The bio as written is Markdown, where the fallback's was rendered.
        let view = ProfileView {
            profile: yapfast_core::chat::Profile {
                id: fallback
                    .map(|fallback| fallback.id.clone())
                    .unwrap_or_default(),
                name: written(&editor.name, fallback.map(|fallback| &fallback.name)),
                handle: fallback_text(fallback.map(|fallback| &fallback.handle)),
                avatar: avatar
                    .map(str::to_owned)
                    .or_else(|| fallback.and_then(|fallback| fallback.avatar.clone())),
                banner: banner
                    .map(str::to_owned)
                    .or_else(|| fallback.and_then(|fallback| fallback.banner.clone())),
                accent: accent.or_else(|| fallback.and_then(|fallback| fallback.accent)),
                pronouns: written(
                    &editor.pronouns,
                    fallback.map(|fallback| &fallback.pronouns),
                ),
                // Its times as the profile shows them, as Discord's preview does.
                bio: yapfast_core::clock::render_timestamps(&written(
                    &editor.bio,
                    fallback.map(|fallback| &fallback.bio),
                )),
                created: fallback.and_then(|fallback| fallback.created.clone()),
                joined: fallback.and_then(|fallback| fallback.joined.clone()),
                server_name: fallback_text(fallback.map(|fallback| &fallback.server_name)),
                server_icon: fallback.and_then(|fallback| fallback.server_icon.clone()),
                theme: editor.theme().ok().flatten(),
                style: editor.name_style().map(Arc::new),
                widgets: fallback
                    .map(|fallback| fallback.widgets.clone())
                    .unwrap_or_default(),
                board_asked: fallback.is_some_and(|fallback| fallback.board_asked),
                board_named: fallback.is_some_and(|fallback| fallback.board_named),
                wishlist_place: fallback.and_then(|fallback| fallback.wishlist_place.clone()),
                wishlist: editor.wishlist.clone(),
                // What the editor doesn't change comes from the profile it
                // read: its decoration, effect, tag, badges, connections and
                // activities.
                ..own_profile_parts(fallback)
            },
            large: false,
            loading: false,
            kept: false,
            note: None,
            ..Default::default()
        };
        let mut preview = profile_data(&mut self.pictures, &self.app.state, &view);
        // Someone's own card offers them nothing.
        preview.friend = 0;
        // The tabs' lists stay as they are unless they changed, so a card
        // doesn't lose its place or its pictures as this is shown again.
        let shown_prompt = window.get_profile_editor_prompt();
        let shown = &shown_prompt.preview;
        preview.widgets = same_widget_rows(&shown.widgets, preview.widgets);
        preview.wishlist = same_list(&shown.wishlist, preview.wishlist);
        let cosmetics = self.app.state.cosmetics;
        if editor.loading() {
            preview.board_note = "Loading the board...".into();
        } else if editor.profile.is_none() {
            preview.board_note = "Couldn't load the board.".into();
        }
        if let Some(picture) = new_avatar {
            preview.picture = slint_image(picture);
        }
        if let Some(picture) = new_banner {
            preview.banner = slint_image(picture);
        }
        let reading = match editor.reading.as_ref().map(|(kind, _)| *kind) {
            Some(ProfilePicture::Avatar) => "avatar",
            Some(ProfilePicture::Banner) => "banner",
            None => "",
        };
        let too_long = if editor.name.chars().count() > NAME_LIMIT {
            if main {
                format!("A display name can be up to {NAME_LIMIT} characters.")
            } else {
                format!("A nickname can be up to {NAME_LIMIT} characters.")
            }
        } else if editor.pronouns.chars().count() > PRONOUNS_LIMIT {
            format!("Pronouns can be up to {PRONOUNS_LIMIT} characters.")
        } else {
            String::new()
        };
        let left = BIO_LIMIT as i64 - editor.bio.chars().count() as i64;
        let handle = fallback_text(fallback.map(|fallback| &fallback.handle));
        let (title, detail, bio_placeholder) = if main {
            (
                "Edit profile",
                "Your profile".to_owned(),
                "Tell everyone a bit about yourself",
            )
        } else {
            (
                "Edit server profile",
                format!("Your profile in {}", editor.server_name),
                "Tell this server a bit about yourself",
            )
        };
        let own = fallback;
        // What it would wear: the choice, else what the profile has.
        let shown_tag = match &editor.chosen_tag {
            None => own.and_then(|own| own.tag.clone()),
            Some(None) => None,
            Some(Some(chosen)) => self
                .app
                .state
                .servers
                .iter()
                .find(|server| discord_server_id(&server.id) == chosen)
                .and_then(|server| server.tag.clone()),
        };
        window.set_profile_editor_prompt(ProfileEditorPrompt {
            title: title.into(),
            detail: detail.into(),
            main,
            name_placeholder: handle.as_str().into(),
            pronouns_fallback: fallback
                .map(|fallback| fallback.pronouns.as_str())
                .unwrap_or_default()
                .into(),
            handle: handle.into(),
            bio_placeholder: bio_placeholder.into(),
            loading: editor.loading(),
            saving: editor.saving,
            error: editor.error.as_deref().unwrap_or_default().into(),
            name_enabled: editor.may_write(ProfileText::Name),
            avatar_enabled: editor.may_picture(ProfilePicture::Avatar),
            banner_enabled: editor.may_picture(ProfilePicture::Banner),
            bio_enabled: editor.may_write(ProfileText::Bio),
            offer: !main && !editor.nitro(),
            upgrade: editor.upgrade(),
            banner_shown: !main || editor.nitro(),
            colour_shown: editor.may_write(ProfileText::Colour),
            // The rows stay as they are unless they changed, so the picker
            // doesn't build them all again with every event.
            server_tags: same_list(
                &shown_prompt.server_tags,
                ModelRc::new(VecModel::from(
                    self.app
                        .state
                        .servers
                        .iter()
                        .filter_map(|server| {
                            let tag = server.tag.as_ref()?;
                            Some(ServerTagRow {
                                id: discord_server_id(&server.id).into(),
                                name: server.name.as_str().into(),
                                icon: server.icon.as_deref().unwrap_or_default().into(),
                                tag: (&*tag.text).into(),
                                badge: cosmetics
                                    .tag(tag.badge.as_ref())
                                    .map_or("", |badge| &**badge)
                                    .into(),
                            })
                        })
                        .collect::<Vec<_>>(),
                )),
            ),
            tag_chosen_id: editor
                .chosen_tag
                .as_ref()
                .and_then(|chosen| chosen.as_deref())
                .unwrap_or_default()
                .into(),
            tag_text: shown_tag.as_ref().map_or("", |tag| &*tag.text).into(),
            tag_icon: cosmetics
                .tag(shown_tag.as_ref().and_then(|tag| tag.badge.as_ref()))
                .map_or("", |badge| &**badge)
                .into(),
            look_enabled: editor.may_write(ProfileText::ThemeTop),
            // What the account wears, though the profile switches may keep
            // its pictures from showing.
            decoration_set: own.is_some_and(|own| own.decoration.is_some()),
            effect_set: own.is_some_and(|own| own.effect.is_some()),
            // Yapfast doesn't read profile frames.
            frame_set: false,
            name_font_id: editor.name_font.map_or(11, |font| font as i32),
            name_effect_id: editor.name_effect as i32,
            name_colours_key: editor
                .name_colours
                .iter()
                .map(|colour| format!("{colour:06x}"))
                .collect::<Vec<_>>()
                .join(",")
                .into(),
            theme_top_text: editor.theme_top.as_str().into(),
            theme_bottom_text: editor.theme_bottom.as_str().into(),
            colour: colour
                .ok()
                .flatten()
                .map(|accent| {
                    slint::Color::from_rgb_u8(
                        (accent >> 16) as u8,
                        (accent >> 8) as u8,
                        accent as u8,
                    )
                })
                .unwrap_or_default(),
            has_colour: matches!(colour, Ok(Some(_))),
            colour_wrong: colour.is_err(),
            avatar_reset: editor.resettable(ProfilePicture::Avatar),
            banner_reset: editor.resettable(ProfilePicture::Banner),
            reset_word: if main { "Remove" } else { "Reset" }.into(),
            reading: reading.into(),
            bio_left: i32::try_from(left).unwrap_or(i32::MIN),
            too_long: too_long.into(),
            changed: editor.change().is_some(),
            preview,
        });
    }

    /// Asks before leaving a Discord server or group DM, as Discord's
    /// dialogs do.
    fn show_leave(&self, window: &YapfastWindow) {
        let leave = self.app.state.leave.as_ref();
        window.set_leave_open(leave.is_some());
        let Some(leave) = leave else {
            return;
        };
        let what = if leave.group { "group" } else { "server" };
        window.set_leave_prompt(ChannelPrompt {
            title: format!("Leave '{}'", leave.name).into(),
            detail: format!(
                "Are you sure you want to leave {}? You won't be able to rejoin this {what} unless you are re-invited.",
                leave.name
            )
            .into(),
            confirm: format!("Leave {what}").into(),
            option: if leave.group {
                "Leave without notifying other members".into()
            } else {
                Default::default()
            },
            ticked: leave.silent,
            danger: true,
            saving: leave.leaving,
            error: leave.error.as_deref().unwrap_or_default().into(),
            ..Default::default()
        });
    }

    /// Asks whether a channel dragged into a category takes its
    /// permissions, as Discord's client does.
    fn show_move_sync(&self, window: &YapfastWindow) {
        let asked = self.app.state.move_sync.as_ref();
        window.set_move_sync_open(asked.is_some());
        let Some(asked) = asked else {
            return;
        };
        window.set_move_sync_prompt(ChannelPrompt {
            title: "Sync permissions?".into(),
            detail: format!(
                "Would you like to sync {} permissions with {}?",
                asked.channel, asked.category
            )
            .into(),
            confirm: "Sync Permissions".into(),
            alternative: "Keep Current Permissions".into(),
            ..Default::default()
        });
    }

    /// The dialog from a DM's menu about its other person.
    fn show_person_dialog(&self, window: &YapfastWindow) {
        let dialog = self.app.state.person_dialog.as_ref();
        // The field starts from the note or nickname there is, once it's here.
        if let Some(text) = dialog.and_then(|dialog| dialog.text.as_deref())
            && (!window.get_person_open() || window.get_person_prompt().loading)
        {
            window.set_person_text(text.into());
        }
        window.set_person_open(dialog.is_some());
        let Some(dialog) = dialog else {
            return;
        };
        let name = &dialog.name;
        let (title, text, field, confirm, danger) = match dialog.ask {
            PersonAsk::Note => (
                format!("Note on {name}"),
                "Only you see your note, in Discord too.".into(),
                "Note",
                "Save",
                false,
            ),
            PersonAsk::Call => (
                "Ready to start a call?".into(),
                "Enjoy this moment. Then jump in when you're ready.".into(),
                "",
                "Start Call",
                false,
            ),
            PersonAsk::Nickname => (
                format!("Nickname for {name}"),
                "Only you see the nickname you give a friend. Leave it empty to remove it.".into(),
                "Nickname",
                "Save",
                false,
            ),
            PersonAsk::Unfriend => (
                format!("Remove {name} as a friend?"),
                format!("You'll need to send {name} a friend request to be friends again."),
                "",
                "Remove friend",
                true,
            ),
            PersonAsk::Block => (
                format!("Block {name}?"),
                format!(
                    "Blocking {name} also removes them as a friend. Their messages show collapsed, and they can't message you."
                ),
                "",
                "Block",
                true,
            ),
            PersonAsk::ServerNickname if self.app.state.relation(&dialog.user) == Relation::Me => (
                "Change your nickname".into(),
                "Everyone in this server sees it. Leave it empty to go by your name.".into(),
                "Nickname",
                "Save",
                false,
            ),
            PersonAsk::ServerNickname => (
                format!("Change {name}'s nickname"),
                "Everyone in this server sees it. Leave it empty to reset it to their name.".into(),
                "Nickname",
                "Save",
                false,
            ),
            PersonAsk::Timeout => (
                format!("Time out {name}"),
                format!(
                    "Until it ends, {name} can read the server but can't send messages, react, or join voice. The reason goes in the server's audit log."
                ),
                "Reason (optional)",
                "Time out",
                true,
            ),
            PersonAsk::Kick => (
                format!("Kick {name}?"),
                format!(
                    "{name} can join again with a new invite. The reason goes in the server's audit log."
                ),
                "Reason (optional)",
                "Kick",
                true,
            ),
            PersonAsk::Ban => (
                format!("Ban {name}?"),
                format!(
                    "{name} can't join again until unbanned. The reason goes in the server's audit log."
                ),
                "Reason (optional)",
                "Ban",
                true,
            ),
        };
        let (heading, options) = match dialog.ask {
            PersonAsk::Timeout => ("DURATION", TIMEOUT_TIMES.map(span).to_vec()),
            PersonAsk::Ban => (
                "DELETE THEIR MESSAGES FROM",
                // As Discord's: hours up to a day, then days.
                BAN_HISTORY
                    .map(|seconds| match seconds / 3600 {
                        0 => "Don't delete any".to_owned(),
                        1 => "The last hour".to_owned(),
                        hours if hours <= 24 => format!("The last {hours} hours"),
                        hours => format!("The last {} days", hours / 24),
                    })
                    .to_vec(),
            ),
            _ => ("", vec![]),
        };
        // The same dialog keeps the rows it shows.
        let shown = window.get_person_prompt();
        let options = if shown.title == title.as_str() && shown.options.row_count() == options.len()
        {
            shown.options
        } else {
            let options: Vec<SharedString> = options.into_iter().map(Into::into).collect();
            ModelRc::new(VecModel::from(options))
        };
        window.set_person_prompt(PersonPrompt {
            title: title.into(),
            text: text.into(),
            options_heading: heading.into(),
            options,
            chosen: i32::try_from(dialog.choice).unwrap_or_default(),
            field: field.into(),
            tick: if dialog.ask == PersonAsk::Call {
                "Don't ask again".into()
            } else {
                SharedString::default()
            },
            confirm: confirm.into(),
            danger,
            loading: dialog.text.is_none(),
            saving: dialog.saving,
            error: dialog.error.as_deref().unwrap_or_default().into(),
        });
    }

    /// The dialogs for adding a friend, the custom status, a new DM and
    /// forwarding, and the quick switcher.
    fn show_dialogs(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        let add_friend = state.add_friend.as_ref();
        if add_friend.is_some() && !window.get_add_friend_open() {
            window.set_add_friend_name(SharedString::default());
        }
        window.set_add_friend_open(add_friend.is_some());
        window.set_add_friend_sending(add_friend.is_some_and(|dialog| dialog.sending));
        let sent = add_friend.is_some_and(|dialog| matches!(dialog.outcome, Some(Ok(_))));
        // A request that went clears the name, ready for the next.
        if sent && !window.get_add_friend_sent() {
            window.set_add_friend_name(SharedString::default());
        }
        window.set_add_friend_sent(sent);
        window.set_add_friend_note(match add_friend {
            Some(AddFriend { sending: true, .. }) => "Sending...".into(),
            Some(AddFriend {
                outcome: Some(Ok(name)),
                ..
            }) => format!("Sent {name} a friend request.").into(),
            Some(AddFriend {
                outcome: Some(Err(error)),
                ..
            }) => error.as_str().into(),
            _ => SharedString::default(),
        });
        self.show_person_dialog(window);
        self.show_poll_draft(window);
        let editor = state.status_editor.as_ref();
        // Opening the dialog starts from the status there is.
        if editor.is_some() && !window.get_status_open() {
            let current = state.custom_status.as_ref();
            window.set_status_text(current.map_or("", |status| status.text.as_str()).into());
            window.set_status_emoji(
                current
                    .and_then(status_key)
                    .map_or_else(EmojiCell::default, |key| emoji::cell(&key)),
            );
            window.set_status_clear_after(0);
        }
        window.set_status_open(editor.is_some());
        window.set_status_saving(editor.is_some_and(|editor| editor.saving));
        window.set_status_error(
            editor
                .and_then(|editor| editor.error.as_deref())
                .unwrap_or_default()
                .into(),
        );
        let new_dm = state.new_dm.as_ref();
        if new_dm.is_some() && !window.get_new_dm_open() {
            window.set_new_dm_query(SharedString::default());
        }
        window.set_new_dm_open(new_dm.is_some());
        window.set_new_dm_starting(new_dm.is_some_and(|new_dm| new_dm.starting));
        let people: Vec<ContactRow> = new_dm
            .into_iter()
            .flat_map(|new_dm| new_dm.people())
            .map(|person| ContactRow {
                name: person.name.clone().into(),
                detail: person.detail.clone().into(),
                initial: initial(&person.name),
                tint: tint(&person.name),
                picture: cached_picture(&mut self.pictures, state, person.avatar.as_deref()),
                discord: person.discord,
            })
            .collect();
        window.set_new_dm_note(match new_dm {
            Some(NewDm { error: Some(error), .. }) => error.as_str().into(),
            Some(NewDm { starting: true, .. }) => "Starting the conversation...".into(),
            Some(new_dm) if people.is_empty() && new_dm.query.trim().is_empty() => {
                if cfg!(feature = "matrix") {
                    "Type a name to find people you know on Discord, or a full Matrix id such as @name:example.org."
                } else {
                    "Type a name to find people you know on Discord."
                }
                .into()
            }
            Some(_) if people.is_empty() => if cfg!(feature = "matrix") {
                "No one found. For Matrix, type a full id such as @name:example.org."
            } else {
                "No one found."
            }
            .into(),
            _ => SharedString::default(),
        });
        update_model(&self.models.new_dm_people, people);
        let forwarding = state.forwarding.as_ref();
        window.set_forward_open(forwarding.is_some());
        // Choosing a place clears the search.
        let query = forwarding.map_or("", |forwarding| forwarding.query.as_str());
        if window.get_forward_query() != query {
            window.set_forward_query(query.into());
        }
        if forwarding.is_some() != self.forwarding {
            window.set_forward_note(
                forwarding
                    .map(|forwarding| forwarding.note.as_str())
                    .unwrap_or_default()
                    .into(),
            );
        }
        window.set_forward_preview(
            forwarding
                .map(|forwarding| forwarding.quote.as_str())
                .unwrap_or_default()
                .into(),
        );
        window.set_forward_limit(yapfast_core::application::FORWARD_LIMIT as i32);
        window
            .set_forward_chosen(forwarding.map_or(0, |forwarding| forwarding.chosen.len()) as i32);
        window.set_forward_error(
            forwarding
                .and_then(|forwarding| forwarding.error.as_deref())
                .unwrap_or_default()
                .into(),
        );
        let discord =
            forwarding.is_some_and(|forwarding| Network::of(&forwarding.room) == Network::Discord);
        window.set_forward_empty(
            if discord {
                "We searched far and wide. Unfortunately, no results were found."
            } else if !query.is_empty() {
                "No conversations match."
            } else {
                "There's nowhere to forward to yet. S;C forwards Matrix messages only into encrypted conversations."
            }
            .into(),
        );
        // As Discord's client warns, the message added doesn't go where
        // slowmode would hold it.
        let slowed: Vec<String> = forwarding
            .into_iter()
            .flat_map(|forwarding| &forwarding.chosen)
            .filter_map(|id| state.rooms.iter().find(|room| room.id == *id))
            .filter(|room| room.slowed)
            .map(|room| state.destination(room))
            .collect();
        window.set_forward_slowmode(
            match slowed.as_slice() {
                [] => String::new(),
                [one] => {
                    format!("The message you added will not be sent to slowmode channel: {one}.")
                }
                many => format!(
                    "The message you added will not be sent to slowmode channels: {}.",
                    many.join(", ")
                ),
            }
            .into(),
        );
        update_model(
            &self.models.forward_targets,
            forwarding.map_or_else(Vec::new, |forwarding| {
                state
                    .forward_places()
                    .into_iter()
                    .map(|room| PlaceRow {
                        chosen: forwarding.chosen.contains(&room.id),
                        ..self.place_row(room, true)
                    })
                    .collect()
            }),
        );
        window.set_switcher_open(state.switcher.is_some());
        if self
            .switcher
            .as_ref()
            .is_some_and(|shown| shown.shows(state))
        {
            return;
        }
        self.switcher = state.switcher.as_ref().map(|_| SwitcherShown::of(state));
        if let Some(query) = &state.switcher
            && window.get_switcher_query() != query.as_str()
        {
            window.set_switcher_query(query.as_str().into());
        }
        let mut mention_group = false;
        let blank = state
            .switcher
            .as_deref()
            .is_some_and(|query| query.trim().is_empty());
        update_model(
            &self.models.switcher_places,
            state
                .switcher_places()
                .into_iter()
                .enumerate()
                .map(|(index, place)| match place {
                    Place::Room(room) => {
                        let group = if blank
                            && !mention_group
                            && room.mentions != 0
                            && !room.muted
                            && !state.switcher_recent_room(&room.id)
                        {
                            mention_group = true;
                            "Mentions"
                        } else if blank && index == 0 {
                            "Previous Channels"
                        } else {
                            ""
                        };
                        PlaceRow {
                            unread: room.unread > 0 && !room.muted,
                            badge: mention_badge(room),
                            group: group.into(),
                            ..self.place_row(room, false)
                        }
                    }
                    Place::Server(server) => PlaceRow {
                        id: server.id.clone().into(),
                        name: server.name.clone().into(),
                        place: "Server".into(),
                        avatar: true,
                        initial: initial(&server.name),
                        tint: tint(&server.id),
                        picture_url: server.icon.clone().unwrap_or_default().into(),
                        ..PlaceRow::default()
                    },
                    Place::Friend(friend) => PlaceRow {
                        id: format!("switcher-friend:{}", friend.id).into(),
                        name: friend.name.as_str().into(),
                        place: "Start a direct message".into(),
                        avatar: true,
                        initial: initial(&friend.name),
                        tint: tint(&friend.id),
                        picture_url: friend.avatar.as_deref().unwrap_or_default().into(),
                        ..PlaceRow::default()
                    },
                })
                .collect(),
        );
        let mentions = self
            .models
            .switcher_places
            .iter()
            .position(|row| row.group == "Mentions");
        window.set_switcher_mention_start(mentions.map_or(10000, |index| index as i32));
    }

    /// A conversation as Forward To and the quick switcher list it: a DM by
    /// its picture, and a channel by its server's icon in Forward To, as
    /// Discord's dialog shows it, or else by its own.
    fn place_row(&self, room: &yapfast_core::chat::ChatRoom, server_icon: bool) -> PlaceRow {
        let state = &self.app.state;
        let server = state
            .servers
            .iter()
            .find(|server| !room.direct && server.channels.contains(&room.id));
        let icon = server.filter(|_| server_icon);
        PlaceRow {
            id: room.id.clone().into(),
            name: room.name.clone().into(),
            place: match server {
                _ if room.direct => "Direct message".into(),
                Some(server) => server.name.clone().into(),
                None => "Channel".into(),
            },
            icon: self.icons.room(room),
            avatar: room.direct || icon.is_some(),
            initial: initial(icon.map_or(&room.name, |server| &server.name)),
            tint: tint(icon.map_or(&room.id, |server| &server.id)),
            picture_url: icon
                .map_or(room.avatar.as_deref(), |server| server.icon.as_deref())
                .unwrap_or_default()
                .into(),
            ..PlaceRow::default()
        }
    }

    /// The composer: what it may do, its files, its reply or edit, mentions and
    /// its hint.
    /// The thread beside the open channel: its rows, built again only for
    /// messages that changed, and its composer.
    pub(super) fn show_aside(&mut self, window: &YapfastWindow) {
        self.mark_mentions();
        let state = &self.app.state;
        let Some(aside) = &state.aside else {
            if window.get_aside_open() {
                window.set_aside_open(false);
                window.set_aside_spoiler_hidden(false);
                self.aside_messages = Arc::new(Vec::new());
                self.aside_rows.clear();
                self.models.aside_messages.clear();
                self.models.aside_staged.clear();
            }
            return;
        };
        let room = &aside.room;
        window.set_aside_spoiler_hidden(state.room_spoiler_hidden(room));
        window.set_aside_can_attach(state.aside_can_attach());
        window.set_aside_can_mark_spoilers(state.aside_can_mark_spoilers());
        let rows = staged_rows(
            &mut self.thumbnails,
            &self.runtime,
            &self.weak,
            state.aside_staged(),
            !state.preview && Network::of(room) == Network::Discord && state.can_write_in(room),
        );
        update_model(&self.models.aside_staged, rows);
        let name = state.aside_room().map_or("", |listed| listed.name.as_str());
        window.set_aside_open(true);
        if window.get_aside_room() != room.as_str() {
            window.set_aside_room(room.as_str().into());
        }
        window.set_aside_name(name.into());
        window.set_aside_ready(aside.ready);
        window.set_aside_loading(aside.loading_history);
        window.set_aside_start(aside.history_start);
        window.set_aside_failed(aside.history_failed);
        window.set_aside_composer_enabled(state.can_write_in(room));
        let reacts = state.reacts_in(room);
        window.set_aside_reactions_enabled(reacts != Reacts::None);
        window.set_aside_new_reactions_enabled(reacts == Reacts::Any);
        window.set_aside_can_send(state.can_send_in(room));
        let draft = state.aside_draft();
        if window.get_aside_draft() != draft {
            window.set_aside_draft(draft.into());
        }
        window.set_aside_reply_ping(matches!(
            state.aside_compose(),
            Some(Compose::Reply { ping: true, .. })
        ));
        window.set_aside_compose_label(match state.aside_compose() {
            Some(Compose::Reply { author, body, .. }) => {
                format!("Replying to {author}: {body}").into()
            }
            None => SharedString::default(),
        });
        // Pictures and link previews fit the panel's width beside the avatar.
        let fit = window.get_aside_shown() as i32 - ASIDE_GUTTER;
        if self.aside_fit != fit {
            self.aside_fit = fit;
            self.aside_restyle = true;
        }
        if Arc::ptr_eq(&self.aside_messages, &aside.messages) && !self.aside_restyle {
            return;
        }
        let marks = Marks {
            first_new: yapfast_core::chat::first_new(&aside.messages, aside.seen.as_deref()),
            first_unread: None,
            revealed: &self.revealed,
            restyle: std::mem::take(&mut self.aside_restyle),
            decorations: self.layout.cosmetics().decorations,
        };
        let layout = &self.layout;
        show_timeline(
            &self.models.aside_messages,
            &mut self.aside_rows,
            &self.aside_messages,
            &aside.messages,
            &marks,
            |message| {
                layout.restyle(
                    message,
                    app_commands::command_details_row(
                        state,
                        room,
                        message_row_in(Some(state), message, marks.revealed, Some(fit)),
                    ),
                )
            },
        );
        self.aside_messages = aside.messages.clone();
    }

    /// Colours the people and roles the draft mentions, as its message will
    /// show them. Who it may mention is found again only when the draft or
    /// what they come from changed.
    fn mark_mentions(&mut self) {
        self.mark_mentions_of(Field::Channel);
        self.mark_mentions_of(Field::Aside);
        self.mark_mentions_of(Field::Edit);
    }

    /// [`Self::mark_mentions`] of what `field` holds.
    fn mark_mentions_of(&mut self, field: Field) {
        let state = &self.app.state;
        let (draft, slot) = match field {
            Field::Channel => (state.draft(), 0),
            Field::Aside => (state.aside_draft(), 1),
            Field::Edit => (state.edit().map_or("", |edit| edit.text.as_str()), 2),
        };
        let sources = MentionSources {
            messages: Arc::as_ptr(&state.messages) as usize,
            members: state
                .members
                .iter()
                .flatten()
                .map(|members| members.len())
                .sum(),
            found: state.found_members.len(),
            groups: state.mention_groups.len(),
            color: theme::mention_color(),
        };
        if self.mentions_marked[slot]
            .as_ref()
            .is_some_and(|marked| marked.draft == draft && marked.sources == sources)
        {
            return;
        }
        let marks = if draft.contains(['@', '#']) {
            yapfast_core::mention::marks(draft, &state.mention_candidates())
        } else {
            Vec::new()
        };
        let marked = MentionsMarked {
            draft: draft.to_owned(),
            sources,
        };
        i_slint_core::yapfast_marks::mark(
            slot,
            marked.draft.as_str().into(),
            marks.into_iter().map(|(range, color)| {
                let rgb = color.unwrap_or(sources.color) & 0xff_ffff;
                (range, slint::Color::from_argb_encoded(0xff00_0000 | rgb))
            }),
        );
        self.mentions_marked[slot] = Some(marked);
    }

    /// The field of the message being edited, in its row: what it holds, and
    /// the keys when an edit starts, with the cursor after its text.
    fn show_inline_edit(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        let edit = state.edit();
        let shown = window.global::<InlineEdit>();
        let text = edit.map_or("", |edit| edit.text.as_str());
        if shown.get_text() != text {
            shown.set_text(text.into());
        }
        // In the thread beside the channel when its room is the one edited.
        shown.set_aside(edit.is_some_and(|edit| {
            state.selected.as_ref() != Some(&edit.room)
                && state.aside_room().is_some_and(|room| room.id == edit.room)
        }));
        shown.set_item(edit.map_or("", |edit| edit.item.as_str()).into());
        let started = edit.map(|edit| (edit.room.clone(), edit.item.clone()));
        let end = edit.map(|edit| edit.text.len());
        if started != self.edit_focused {
            self.edit_focused = started;
            if let Some(end) = end {
                callbacks::focus_edit(window, end);
            }
        }
        // Suggestions for a field that's gone go with it.
        if self.suggesting == Field::Edit && edit.is_none() {
            self.suggesting = Field::Channel;
            self.mention_at = None;
            self.emoji_word = None;
            window.set_suggesting_edit(false);
            shown.set_suggesting(false);
            window.set_mention_index(0);
            if self.app.state.mention_query.is_some() {
                self.action(window, Action::MentionQuery(None));
            }
            self.show_emoji_suggestions(window);
        }
    }

    pub(super) fn sync_inline_edit_suggestions(&self, window: &YapfastWindow) {
        window.global::<InlineEdit>().set_suggesting(
            self.suggesting == Field::Edit
                && (self.models.mentions.row_count() > 0
                    || self.models.emoji_suggestions.row_count() > 0),
        );
    }

    pub(super) fn show_composer(&mut self, window: &YapfastWindow) {
        self.mark_mentions();
        self.show_inline_edit(window);
        let state = &self.app.state;
        let room = state.selected_room();
        window.set_voice_room(room.is_some_and(|room| room.voice));
        window.set_voice_chat(state.voice_chat);
        window.set_has_voice_chat(room.is_some_and(|room| room.voice_chat()));
        window.set_room_encrypted(room.is_some_and(|room| room.encrypted));
        window.set_call_encrypted(room.is_some_and(|room| room.call_encrypted()));
        window.set_room_ready(state.room_ready);
        window.set_draft(state.draft().into());
        let discord_room = room.is_some_and(|room| room.network == Network::Discord);
        // An unverified Matrix device can type; the hint says why it can't send.
        window.set_composer_enabled(
            state.room_ready
                && !state.busy
                && state.shows_text()
                && room.is_some_and(|room| {
                    if discord_room {
                        state.writable(room)
                    } else {
                        state.preview || room.encrypted
                    }
                }),
        );
        // A Discord channel may take reactions where it takes no messages.
        let reacts = room
            .filter(|_| state.shows_text())
            .map_or(Reacts::None, |room| state.reacts_in(&room.id));
        window.set_reactions_enabled(reacts != Reacts::None);
        window.set_new_reactions_enabled(reacts == Reacts::Any);
        window.set_can_send(state.can_send());
        window.set_can_attach(state.can_attach());
        window.set_can_mark_spoilers(room.is_some_and(|room| room.capabilities.spoilers));
        let staged = state.staged();
        // The thread beside keeps its files' pictures too.
        let aside_staged = state.aside_staged();
        self.thumbnails.retain(|path, _| {
            staged
                .iter()
                .chain(aside_staged)
                .any(|file| &file.path == path)
        });
        let rows = staged_rows(&mut self.thumbnails, &self.runtime, &self.weak, staged,
            !state.preview && discord_room && room.is_some_and(|room| state.can_write_in(&room.id)));
        update_model(&self.models.staged, rows);
        window.set_confirm_delete(state.confirm_delete.clone().unwrap_or_default().into());
        window
            .global::<Polls>()
            .set_confirm_end(state.confirm_end_poll.clone().unwrap_or_default().into());
        window.set_reply_ping(matches!(
            state.compose(),
            Some(Compose::Reply { ping: true, .. })
        ));
        window.set_compose_label(match state.compose() {
            Some(Compose::Reply { author, body, .. }) => {
                format!("Replying to {author}: {body}").into()
            }
            None => SharedString::default(),
        });
        window.set_sending(state.sending.is_some());
        window.set_typing(state.typing_line().into());
        let suggestions = state.mention_suggestions();
        let mentions: Vec<MentionRow> = suggestions
            .iter()
            .enumerate()
            .map(|(index, candidate)| {
                // People come first, then roles and groups, each under a heading;
                // `#` lists channels alone.
                let starts_section = index == 0 || suggestions[index - 1].group != candidate.group;
                MentionRow {
                    heading: match (starts_section, candidate.group, candidate.channel) {
                        (false, ..) => "",
                        (true, false, _) => "MEMBERS",
                        (true, true, false) => "ROLES",
                        (true, true, true) => "CHANNELS",
                    }
                    .into(),
                    sigil: candidate.sigil().to_string().into(),
                    voice: candidate.voice,
                    initial: initial(&candidate.name),
                    tint: tint(&candidate.name),
                    picture: cached_picture(&mut self.pictures, state, candidate.avatar.as_deref()),
                    color: role_color(candidate.color),
                    has_color: candidate.color.is_some(),
                    group: candidate.group,
                    detail: match candidate.mention.as_str() {
                        "@everyone" => "Everyone in this channel".into(),
                        "@here" => "Everyone online here".into(),
                        _ => candidate.username.clone().unwrap_or_default().into(),
                    },
                    name: candidate.name.as_str().into(),
                }
            })
            .collect();
        if window.get_mention_index() >= mentions.len() as i32 {
            window.set_mention_index(0);
        }
        update_model(&self.models.mentions, mentions);
        self.sync_inline_edit_suggestions(window);
        window.set_loading_history(state.loading_history);
        window.set_history_start(state.history_start);
        window.set_history_failed(state.history_failed);
        window.set_detached(state.detached);
        window.set_loading_later(state.loading_later);
        window.set_later_failed(state.later_failed);
        // Without Matrix everything is Discord, so the encryption and key hints
        // say nothing new; what stops sending still shows.
        let discord_only = !cfg!(feature = "matrix");
        let timed_out = room
            .and_then(|room| room.timed_out_until)
            .filter(|_| discord_room)
            .map(|until| {
                format!(
                    "You're timed out in this server until {}.",
                    super::menus::until(until / 1000, self.layout.twelve_hour_clock)
                )
            });
        // Discord swaps the composer for one disabled bar saying so, with no
        // buttons and no caption.
        let no_permission = window.global::<ClientStyle>().get_enabled()
            && timed_out.is_none()
            && !state.preview
            && discord_room
            && room.is_some_and(|room| !room.request && (room.read_only || room.locked));
        window.set_composer_locked(no_permission);
        window.set_composer_locked_text(
            "You do not have permission to send messages in this channel.".into(),
        );
        window.set_composer_hint(
            if room.is_none() {
                "Choose a DM or server channel to write a message."
            } else if state.preview {
                ""
            } else if room.is_some_and(|room| room.request) {
                if discord_only {
                    ""
                } else {
                    "Discord · not end-to-end encrypted."
                }
            } else if let Some(timed_out) = &timed_out {
                timed_out
            } else if no_permission {
                ""
            } else if discord_room && room.is_some_and(|room| room.read_only || room.locked) {
                "You can't send messages in this Discord channel."
            } else if discord_room && !state.discord_online {
                "Discord is disconnected. S;C is reconnecting."
            } else if discord_only {
                ""
            } else if discord_room {
                "Discord · not end-to-end encrypted. Enter to send, Shift+Enter for a new line."
            } else if !state.trusted {
                "Sending is locked until this device is verified."
            } else if room.is_some_and(|room| room.encrypted) {
                "End-to-end encrypted. Enter to send, Shift+Enter for a new line."
            } else {
                "Unencrypted room. Reading only in this build."
            }
            .into(),
        );
        // The `:name` word ends when the field that owns it changes.
        if let Some((at, name)) = &self.emoji_word
            && self
                .composer_text(self.suggesting)
                .get(*at..at + 1 + name.len())
                != Some(format!(":{name}").as_str())
        {
            self.emoji_word = None;
            self.show_emoji_suggestions(window);
        }
        // The `/` picker and the command being written follow each keystroke.
        self.show_app_commands(window);
    }

    /// Emoji for the `:name` being typed, or none.
    pub(super) fn show_emoji_suggestions(&mut self, window: &YapfastWindow) {
        let (query, cells) = match &self.emoji_word {
            Some((_, name)) => {
                let custom = self.app.usable_emoji();
                let by_id = custom
                    .iter()
                    .flat_map(|set| &set.emoji)
                    .map(|emoji| (emoji.id.as_str(), emoji))
                    .collect();
                let lists = &self.app.state.discord_emojis;
                let favorites = emoji::discord_keys(&lists.favorites, &by_id);
                let frequent = emoji::discord_keys(&lists.frequent, &by_id);
                (
                    name.as_str(),
                    emoji::suggestions_with_preferences(
                        name,
                        &custom,
                        &favorites,
                        &frequent,
                        EMOJI_SUGGESTIONS,
                    ),
                )
            }
            None => ("", Vec::new()),
        };
        window.set_emoji_suggestion_query(query.into());
        if window.get_emoji_suggestion_index() >= cells.len() as i32 {
            window.set_emoji_suggestion_index(0);
        }
        update_model(
            &self.models.emoji_suggestions,
            emoji::with_pictures(cells, window.window().scale_factor()),
        );
        self.sync_inline_edit_suggestions(window);
    }

    /// The messages, built again only where they changed, and where the list
    /// scrolls.
    fn show_messages(&mut self, window: &YapfastWindow, changes: &Changes) {
        let &Changes {
            reset,
            selection: selection_changed,
            messages: messages_changed,
            at_end,
        } = changes;
        let state = &self.app.state;
        // Avatars that arrived since show on rows built before them.
        let pictures_arrived = self.pictures_seen != state.picture_changes;
        self.pictures_seen = state.picture_changes;
        // Those that went off screen go from the window's copies too.
        if pictures_arrived {
            self.pictures
                .retain(|url, _| state.pictures.contains_key(url));
        }
        // Custom emoji in messages whose pictures arrived get glyphs, and the
        // rows that showed them by name are built again. Those shown on their
        // own, in the picker, suggestions and reaction buttons, show pictures.
        if pictures_arrived || messages_changed {
            let state = &self.app.state;
            let in_messages = || state.messages.iter().flat_map(|message| &message.emoji);
            if custom_emoji::add(in_messages().filter_map(|emoji| arrived(state, emoji))) {
                self.restyle = true;
            }
            // The suggestions build their cells from the pictures kept; the
            // picker keeps its own as they come (`show_arrived_emoji`).
            let usable = if pictures_arrived && self.emoji_word.is_some() {
                self.app.emoji_sets()
            } else {
                Vec::new()
            };
            let state = &self.app.state;
            let added = custom_emoji::add_images(
                usable
                    .iter()
                    .flat_map(|set| &set.emoji)
                    .chain(state.messages.iter().flat_map(|message| &message.emoji))
                    .filter_map(|emoji| arrived(state, emoji)),
            );
            let picker = !window.get_react_item().is_empty() && self.show_arrived_emoji();
            if added || picker {
                if added && self.emoji_word.is_some() {
                    self.show_emoji_suggestions(window);
                }
                if !window.get_react_item().is_empty() {
                    self.fill_emoji_near_sight();
                    // An animated one decodes from its picture, which has
                    // come now.
                    super::callbacks::want_shown_animations(self, window);
                }
            }
            // A server's icon is no custom emoji, and the emoji picker's rail
            // and headings draw it as it comes.
            if pictures_arrived && !window.get_react_item().is_empty() {
                super::callbacks::fill_picker_icons(self);
            }
        }
        let state = &self.app.state;
        // A poll's time left counts down by the minute, and at midnight
        // today's times become yesterday's.
        let minute = yapfast_core::clock::now_ms() / 60_000;
        if self.clock_minute != minute {
            let date = yapfast_core::clock::date;
            let new_day =
                self.clock_minute != 0 && date(self.clock_minute * 60) != date(minute * 60);
            self.clock_minute = minute;
            self.restyle |= polls::open_poll(&state.messages, minute * 60) | new_day;
        }
        let restyle = std::mem::take(&mut self.restyle);
        // The thread beside builds its rows again with the timeline's.
        self.aside_restyle |= restyle;
        if messages_changed || selection_changed || reset || pictures_arrived || restyle {
            if selection_changed || reset {
                window.set_react_item(SharedString::default());
                window.set_active_item(SharedString::default());
                window.set_jump_item(SharedString::default());
            }
            let marks = Marks {
                first_new: yapfast_core::chat::first_new(&state.messages, state.seen.as_deref()),
                first_unread: state.first_unread.as_deref(),
                revealed: &self.revealed,
                restyle,
                decorations: self.layout.cosmetics().decorations,
            };
            let layout = &self.layout;
            show_timeline(
                &self.models.messages,
                &mut self.rows,
                &self.messages,
                &state.messages,
                &marks,
                |message| {
                    layout.restyle(
                        message,
                        app_commands::command_details_row(
                            state,
                            state.selected.as_deref().unwrap_or_default(),
                            message_row_in(Some(state), message, marks.revealed, None),
                        ),
                    )
                },
            );
            if selection_changed || reset {
                self.latest_due = false;
            } else if messages_changed && !state.detached && std::mem::take(&mut self.latest_due) {
                window.invoke_scroll_to_latest();
            }
            // A sent echo can get its event id without changing the row count
            // or scroll indexes. Report the new item ids after layout settles.
            if messages_changed || selection_changed || reset {
                window.invoke_media_viewport();
            }
            // A jump to a message places the list itself, even one made after
            // this refresh; see `show_message`.
            let weak = window.as_weak();
            let jumped = move || {
                weak.upgrade()
                    .filter(|window| window.get_jump_item().is_empty())
            };
            if selection_changed || at_end {
                slint::Timer::single_shot(Duration::ZERO, move || {
                    if let Some(window) = jumped() {
                        window.invoke_scroll_to_latest();
                    }
                });
            }
        }
        let unread = state.first_unread.as_ref().and_then(|item| {
            let index = state
                .messages
                .iter()
                .position(|message| &message.item == item)?;
            Some((index, item))
        });
        window.set_caught_up(state.caught_up);
        if messages_changed || selection_changed || reset {
            window.set_unread_index(
                unread.map_or(-1, |(index, _)| i32::try_from(index).unwrap_or(i32::MAX)),
            );
            window.set_unread_label(
                unread
                    .map(|(index, _)| unread_label(&state.messages[index..], state.detached))
                    .unwrap_or_default()
                    .into(),
            );
        }
        if state.jump != self.jumped {
            self.jumped = state.jump.clone();
            if let Some((item, _)) = &state.jump
                && let Some(index) = state
                    .messages
                    .iter()
                    .position(|message| &message.item == item)
            {
                show_message(window, index, item, true);
            }
        }
        if state.unread_jump != self.unread_jumped {
            self.unread_jumped = state.unread_jump;
            if let Some((index, item)) = unread {
                show_message(window, index, item, false);
            }
        }
    }

    /// Which of the call's tiles shows large, the streams with tiles of their
    /// own, and what the corner shows while the call is off screen.
    pub(super) fn show_stage(&mut self, window: &YapfastWindow) {
        let voice = &self.app.state.voice;
        let people = self.stage_people_for_call();
        let watching = voice
            .watching
            .as_ref()
            .map(|watching| watching.user.as_str());
        if watching != self.watched.as_deref() {
            // A stream starts large, and leaves when watching it stops.
            if let Some(user) = watching {
                self.call_focus = Some(Focus::Stream(user.to_owned()));
            } else if matches!(&self.call_focus, Some(Focus::Stream(user)) if self.watched.as_ref() == Some(user))
            {
                self.call_focus = None;
            }
            self.watched = watching.map(str::to_owned);
        }
        let stage = Stage {
            participants: if voice.active() { &people } else { &[] },
            sharing: voice.sharing.is_some(),
        };
        let focused = self.call_focus.as_ref().and_then(|focus| stage.slot(focus));
        if focused.is_none() {
            self.call_focus = None;
        }
        let slot = |slot: Option<usize>| slot.map_or(-1, |slot| slot as i32);
        window.set_call_focus(slot(focused));
        update_model(
            &self.models.stream_tiles,
            stage.streams().map(|person| person as i32).collect(),
        );
        window.set_watch_user(watching.unwrap_or_default().into());
        let pip = stage.pip(self.call_focus.as_ref(), watching);
        window.set_pip_kind(match pip {
            Pip::None => 0,
            Pip::Watched => 1,
            Pip::Shared => 2,
            Pip::Camera(_) => 3,
        });
        window.set_pip_person(match pip {
            Pip::Camera(person) => person as i32,
            _ => -1,
        });
        window.set_pip_slot(slot(stage.pip_slot(pip, watching)));
    }

    pub(super) fn stage_people_for_call(&self) -> Vec<voice::Participant> {
        tiles::stage_people(
            &self.app.state.voice.participants,
            &self.stage_people,
            &self.call_hidden_video,
        )
    }

    pub(super) fn call_video_disabled(&self, user: &str) -> bool {
        self.call_hidden_video.contains(user)
    }

    pub(super) fn show_non_video_participants(&self) -> bool {
        !self.layout.hide_non_video_participants
    }

    pub(super) fn toggle_call_video(&mut self, window: &YapfastWindow, user: &str) {
        if !self.app.state.voice.active()
            || !self
                .app
                .state
                .voice
                .participants
                .iter()
                .any(|p| p.id == user && !p.local)
        {
            return;
        }
        if !self.call_hidden_video.remove(user) {
            self.call_hidden_video.insert(user.to_owned());
        }
        self.show_voice(window);
    }

    pub(super) fn toggle_non_video_participants(&mut self, window: &YapfastWindow) {
        self.layout.hide_non_video_participants = !self.layout.hide_non_video_participants;
        self.layout.write(&self.root);
        self.show_voice(window);
    }

    /// The call: the voice dock, sharing and watching a screen, a DM's call,
    /// ringing, and the devices.
    fn show_voice(&mut self, window: &YapfastWindow) {
        self.ring();
        // The server of a call shows it on the rail, so the rail follows a
        // call that starts, ends or moves; other voice events leave it be.
        let state = &self.app.state;
        if self.rail_call.as_deref() != call_room(state) {
            self.rail_call = call_room(state).map(str::to_owned);
            let rooms_by_id = state
                .rooms
                .iter()
                .map(|room| (room.id.as_str(), &**room))
                .collect();
            let rail = rail(
                state,
                &rooms_by_id,
                &self.layout.open_folders,
                server_order::active(state, &self.layout.server_orders),
            );
            update_model_by_id(&self.models.servers, rail, |row| row.id.clone());
        }
        let timed = matches!(state.voice.phase, Phase::Connected | Phase::Reconnecting)
            .then(|| state.voice.room.clone())
            .flatten();
        self.time_call(window, timed.as_deref());
        let state = &self.app.state;
        let room = state.selected_room();
        let voice = &state.voice;
        window.set_voice_displaced_room(
            voice
                .displaced_from
                .as_deref()
                .filter(|_| !voice.active())
                .unwrap_or_default()
                .into(),
        );
        window.set_can_reconnect_voice(
            voice
                .displaced_from
                .as_ref()
                .is_some_and(|room| state.can_join_voice(room)),
        );
        let voice_here =
            room.is_some_and(|room| voice.room.as_ref() == Some(&room.id)) && voice.active();
        let account = state.account.as_deref().unwrap_or("Preview");
        window.set_voice_active(voice.active());
        // The account panel's picture rings as the account's own row in the call does.
        window.set_account_speaking(
            voice.active()
                && voice.participants.iter().any(|person| {
                    person.local && person.speaking && !person.muted && person.connected
                }),
        );
        window.set_voice_visible(voice.active() || voice.error.is_some());
        window.set_voice_ready(matches!(
            voice.phase,
            Phase::Connected | Phase::Reconnecting
        ));
        window.set_voice_leaving(voice.phase == Phase::Leaving);
        window.set_voice_here(voice_here);
        window.set_voice_discord(
            voice
                .room
                .as_deref()
                .is_some_and(|room| Network::of(room) == Network::Discord),
        );
        window.set_can_share(
            !state.preview
                && voice.phase == Phase::Connected
                && voice
                    .room
                    .as_deref()
                    .is_some_and(|room| Network::of(room) == Network::Discord),
        );
        window.set_sharing(voice.sharing.is_some());
        window.set_share_resolution(match voice.quality.resolution {
            voice::Resolution::P720 => 0,
            voice::Resolution::P1080 => 1,
            voice::Resolution::Source => 2,
        });
        window.set_share_fps(voice.quality.fps as i32);
        window.set_share_high_quality(voice.quality.high_quality);
        window.set_share_live(
            voice
                .sharing
                .as_ref()
                .is_some_and(|sharing| sharing.phase == voice::SharePhase::Live),
        );
        window.set_share_status(
            match voice.sharing.as_ref().map(|sharing| sharing.phase) {
                Some(voice::SharePhase::Choosing) => "Choose what to share",
                Some(voice::SharePhase::Starting) => "Starting your stream...",
                Some(voice::SharePhase::Live) => "Live",
                None => "",
            }
            .into(),
        );
        if voice.sharing.is_none() {
            window.set_share_frame(slint::Image::default());
        }
        window.set_watching(voice.watching.is_some());
        match &voice.watching {
            Some(watching) => {
                window.set_watch_title(format!("{}'s screen", watching.name).into());
                window.set_watch_status(
                    if watching.frames.is_none() {
                        format!("Connecting to {}'s stream...", watching.name)
                    } else {
                        format!("Waiting for {}'s picture...", watching.name)
                    }
                    .into(),
                );
            }
            None => window.set_watch_frame(slint::Image::default()),
        }
        window.set_voice_channel(
            voice
                .room
                .as_deref()
                .filter(|_| voice.active())
                .unwrap_or_default()
                .into(),
        );
        window.set_voice_tone(match voice.phase {
            Phase::Connected => 1,
            Phase::Disconnected => 2,
            _ => 0,
        });
        window.set_voice_detail(
            if state.preview {
                format!("{} · Sample", voice.name)
            } else if voice.end_to_end {
                format!("{} · End-to-end encrypted", voice.name)
            } else {
                format!("{} · Secure connection", voice.name)
            }
            .into(),
        );
        let link = window.global::<CallLink>();
        link.set_measured(voice.active() && voice.link.is_some());
        link.set_quality(match voice.link_quality {
            voice::Quality::Unknown => 0,
            voice::Quality::Fine => 1,
            voice::Quality::Average => 2,
            voice::Quality::Bad => 3,
        });
        link.set_end_to_end(voice.end_to_end);
        window.set_can_join(room.is_some_and(|room| state.can_join_voice(&room.id)));
        window.set_muted(voice.muted);
        window.set_deafened(voice.deafened);
        window.set_voice_status(
            match voice.phase {
                Phase::Disconnected => "Voice disconnected",
                Phase::Joining => "Joining voice...",
                Phase::Connected if state.preview => "Preview voice",
                Phase::Connected => "Voice connected",
                Phase::Reconnecting => "Reconnecting voice...",
                Phase::Leaving => "Leaving voice...",
            }
            .into(),
        );
        window.set_voice_name(voice.name.clone().into());
        window.set_voice_microphone_status(
            if voice.deafened {
                "Deafened and muted"
            } else if voice.muted {
                "Microphone muted"
            } else {
                "Microphone live"
            }
            .into(),
        );
        let present = room.map_or(&[][..], |room| room.people.as_slice());
        // A Discord DM's call, shown above its messages.
        let dm_call = room.filter(|room| room.direct && room.capabilities.dm_calls);
        let dm_person = dm_call.and_then(|room| room.person.as_deref());
        window.set_dm_person(dm_person.unwrap_or_default().into());
        window.set_dm_friend(dm_person.map_or(0, |person| match state.relation(person) {
            // The header offers no "sent", which the profile card shows.
            Relation::Outgoing => 0,
            _ => friend_offer(state, person),
        }));
        window.set_can_call(dm_call.is_some_and(|room| !room.request) && !voice_here);
        window.set_call_going(!present.is_empty());
        window.set_call_shown(
            dm_call.is_some_and(|room| voice_here || !room.people.is_empty() || room.incoming),
        );
        window.set_call_room(dm_call.map_or_else(Default::default, |room| room.id.as_str().into()));
        let incoming = dm_call.is_some_and(|room| room.incoming) && !voice_here;
        window.set_call_incoming(incoming);
        window.set_call_note(
            match (incoming, present.is_empty()) {
                (true, true) => "Incoming call.".into(),
                (true, false) => format!("{} calling you.", who_is_here(present)),
                (false, _) => format!("{} in the call.", who_is_here(present)),
            }
            .into(),
        );
        let call_people: Vec<_> = present
            .iter()
            .map(|person| PersonRow {
                id: person.id.as_str().into(),
                name: person.name.as_str().into(),
                initial: initial(&person.name),
                tint: tint(&person.id),
                picture: cached_picture(&mut self.pictures, state, person.avatar.as_deref()),
                connected: true,
                ..Default::default()
            })
            .collect();
        update_model(&self.models.call_people, call_people);
        show_incoming(window, state, &mut self.pictures);
        window.set_voice_description(
            if room.is_some_and(|room| room.locked) {
                "Your roles on this Discord server don't let you join this channel.".into()
            } else if let Some(room) = dm_call.filter(|_| voice_here) {
                let ringing: Vec<&str> = room
                    .ringing
                    .iter()
                    .map(|person| person.name.as_str())
                    .collect();
                if !ringing.is_empty() {
                    format!("Calling {}...", ringing.join(", "))
                } else if voice.participants.len() == 1 {
                    "Nobody else is in the call yet.".into()
                } else if room.person.is_some() {
                    String::new()
                } else {
                    "The call stays connected while you browse other conversations.".into()
                }
            } else if voice_here && voice.participants.len() == 1 {
                "You're here alone. Stay as long as you like; others can join later.".into()
            } else if voice_here {
                "Voice stays connected while you browse other conversations.".into()
            } else {
                let join = if joins_muted(window) {
                    "Join muted and hang out."
                } else {
                    "Join and hang out."
                };
                if present.is_empty() {
                    format!("{join} The channel stays here when empty.")
                } else {
                    format!("{} here. {join}", who_is_here(present))
                }
            }
            .into(),
        );
        window.set_voice_error(voice.error.as_deref().unwrap_or_default().into());
        window.set_voice_warning(voice.warning.as_deref().unwrap_or_default().into());
        if self.call_visibility_room != voice.room {
            self.call_visibility_room.clone_from(&voice.room);
            self.call_hidden_video.clear();
        }
        self.call_hidden_video
            .retain(|id| voice.participants.iter().any(|person| &person.id == id));
        self.stage_people = if voice.active() {
            let shown = tiles::visible_people(
                &voice.participants,
                !self.layout.hide_non_video_participants,
                &self.call_hidden_video,
            );
            // A one-to-one call still shows both people when there is no
            // camera or shared screen for the video-only view to show.
            if shown.is_empty()
                && voice_here
                && dm_call.is_some_and(|room| room.person.is_some())
                && voice.sharing.is_none()
            {
                (0..voice.participants.len()).collect()
            } else {
                shown
            }
        } else {
            Vec::new()
        };
        update_model(
            &self.models.participants,
            if voice.active() {
                self.stage_people
                    .iter()
                    .map(|&index| &voice.participants[index])
                    .map(|person| PersonRow {
                        id: person.id.clone().into(),
                        local: person.local,
                        name: display_part(&person.user).into(),
                        initial: initial(display_part(&person.user)),
                        tint: tint(display_part(if person.local {
                            account
                        } else {
                            &person.user
                        })),
                        speaking: person.speaking && !person.muted && person.connected,
                        connected: person.connected,
                        status: if let Some(problem) = &person.problem {
                            problem.as_str()
                        } else if !person.connected {
                            "Connection lost"
                        } else if person.deafened {
                            "Deafened"
                        } else if person.muted {
                            "Muted"
                        } else if person.speaking {
                            "Speaking"
                        } else {
                            "Listening"
                        }
                        .into(),
                        muted: person.muted,
                        deafened: person.deafened,
                        live: person.streaming,
                        video: person.video.is_some()
                            && !self.call_hidden_video.contains(&person.id),
                        elsewhere: false,
                        server_muted: person.server_muted,
                        server_deafened: person.server_deafened,
                        person: person.person.clone().into(),
                        picture: cached_picture(
                            &mut self.pictures,
                            state,
                            person.avatar.as_deref(),
                        ),
                    })
                    .collect()
            } else {
                vec![]
            },
        );
        // Viewers in the call's order, as their rows show them.
        let viewers = |ids: &[String], streamer: Option<&str>| -> Vec<PersonRow> {
            self.models
                .participants
                .iter()
                .filter(|row| {
                    Some(row.id.as_str()) != streamer && ids.iter().any(|id| row.id == id.as_str())
                })
                .collect()
        };
        update_model(
            &self.models.share_viewers,
            voice
                .sharing
                .as_ref()
                .map(|sharing| viewers(&sharing.viewers, None))
                .unwrap_or_default(),
        );
        update_model(
            &self.models.watch_viewers,
            voice
                .watching
                .as_ref()
                .map(|watching| viewers(&watching.viewers, Some(&watching.user)))
                .unwrap_or_default(),
        );
        let names = |model: &VecModel<PersonRow>| -> SharedString {
            if model.row_count() == 0 {
                return SharedString::new();
            }
            let names: Vec<String> = model.iter().map(|row| row.name.to_string()).collect();
            format!("Watching: {}", names.join(", ")).into()
        };
        window.set_share_viewer_names(names(&self.models.share_viewers));
        window.set_watch_viewer_names(names(&self.models.watch_viewers));
        // A picture per participant, kept while their camera stays on and
        // they stay in that place.
        let frames = &self.models.participant_frames;
        let count = self.stage_people.len();
        for (index, person) in self
            .stage_people
            .iter()
            .map(|&index| &voice.participants[index])
            .enumerate()
        {
            let moved = self.frame_ids.get(index) != Some(&person.id);
            if (person.video.is_none() || self.call_hidden_video.contains(&person.id) || moved)
                && index < frames.row_count()
            {
                frames.set_row_data(index, slint::Image::default());
            }
        }
        self.frame_ids = self
            .stage_people
            .iter()
            .map(|&index| &voice.participants[index])
            .map(|person| person.id.clone())
            .collect();
        while frames.row_count() > count {
            frames.remove(frames.row_count() - 1);
        }
        while frames.row_count() < count {
            frames.push(slint::Image::default());
        }
        self.show_stage(window);
        self.show_soundboard(window);
        self.show_soundboard_settings(window);
        let state = &self.app.state;
        let voice = &state.voice;
        window.set_can_film(voice.can_film);
        window.set_camera_on(voice.camera_phase != voice::CameraPhase::Off);
        window.set_camera_starting(voice.camera_phase == voice::CameraPhase::Starting);
        window.set_call_video(
            voice.participants.iter().any(|person| {
                person.video.is_some() && !self.call_hidden_video.contains(&person.id)
            }),
        );
        let prompt = state.switch_voice.as_ref().map(|id| {
            let room = state.rooms.iter().find(|room| &room.id == id);
            let target = room.map_or("the other channel", |room| room.name.as_str());
            // Whose stream it joins to watch, if it's for one.
            let watch = state
                .pending_watch
                .as_ref()
                .filter(|(watched, _)| watched == id)
                .map(|(_, user)| {
                    room.and_then(|room| room.people.iter().find(|person| &person.id == user))
                        .map_or("someone", |person| person.name.as_str())
                });
            match watch {
                // Only the prompt shows how it joins; a fading one keeps it.
                Some(name) if !voice.active() => {
                    window.set_switch_joins(true);
                    format!("Join {target} to watch {name}'s stream?")
                }
                Some(name) => {
                    window.set_switch_joins(false);
                    format!(
                        "You're already in {}. Leave it and join {target} to watch {name}'s stream?{}",
                        voice.name,
                        joining_muted(window)
                    )
                }
                None => {
                    window.set_switch_joins(false);
                    format!(
                        "You're already in {}. Leave it and join {target}?{}",
                        voice.name,
                        joining_muted(window)
                    )
                }
            }
        });
        window.set_switch_prompt(prompt.unwrap_or_default().into());
        let names = &mut self.models.device_names;
        let (rows, index) =
            audio_device_rows(&voice.microphones, voice.microphone.as_deref(), names);
        update_model(&self.models.microphones, rows);
        window.set_microphone_index(index);
        let (rows, index) = audio_device_rows(&voice.speakers, voice.speaker.as_deref(), names);
        update_model(&self.models.speakers, rows);
        window.set_speaker_index(index);
        let (rows, index) = device_rows(&voice.cameras, voice.camera.as_deref(), names);
        update_model(&self.models.cameras, rows);
        window.set_camera_index(index);
    }

    /// The call's soundboard, its rows made again only when its sounds
    /// change or pictures arrive, and why it can't play, as Discord says.
    fn show_soundboard(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        let voice = &state.voice;
        let groups = voice.soundboard.as_ref().filter(|_| voice.active());
        window.set_can_soundboard(groups.is_some());
        let server_muted = voice
            .participants
            .iter()
            .any(|person| person.local && person.server_muted);
        window.set_soundboard_note(
            if voice.deafened {
                "Soundboard disabled when deafened"
            } else if server_muted {
                "Soundboard disabled when server muted"
            } else {
                ""
            }
            .into(),
        );
        let Some(groups) = groups else {
            self.soundboard_shown = None;
            if self.models.soundboard_rows.row_count() > 0 {
                self.models.soundboard_rows.set_vec(vec![]);
            }
            return;
        };
        let shown = self.soundboard_shown.as_ref();
        if shown.is_some_and(|(kept, revision)| {
            Arc::ptr_eq(kept, groups) && *revision == state.picture_changes
        }) {
            return;
        }
        self.soundboard_shown = Some((groups.clone(), state.picture_changes));
        let rows = sound_rows(groups, &mut self.pictures, state);
        self.models.soundboard_rows.set_vec(rows);
    }

    /// Settings' soundboard volume and entrance sounds, while Voice & video
    /// shows them.
    fn show_soundboard_settings(&mut self, window: &YapfastWindow) {
        if !window.get_settings_open() || window.get_settings_section() != 1 {
            return;
        }
        let state = &self.app.state;
        window.set_discord_nitro(self.app.discord_nitro());
        if self.soundboard_volume_shown != Some(state.soundboard_volume) {
            self.soundboard_volume_shown = Some(state.soundboard_volume);
            let slider = yapfast_core::volume::to_slider(state.soundboard_volume / 100.0);
            window.set_soundboard_volume(slider.round() as i32);
        }
        // Discord's servers by their own ids, which the app's carry after
        // a prefix.
        let discord_servers = || {
            state.servers.iter().filter_map(|server| {
                Some((yapfast_core::discord::parse_server(&server.id)?, server))
            })
        };
        let same = self.entrance_servers.len() == discord_servers().count() + 1
            && discord_servers()
                .zip(self.entrance_servers.iter().skip(1))
                .all(|((guild, _), kept)| kept.as_deref() == Some(guild));
        if !same {
            let servers: Vec<Option<String>> = std::iter::once(None)
                .chain(discord_servers().map(|(guild, _)| Some(guild.to_owned())))
                .collect();
            let names: Vec<SharedString> = std::iter::once("All servers".into())
                .chain(discord_servers().map(|(_, server)| server.name.as_str().into()))
                .collect();
            self.models.entrance_servers.set_vec(names);
            let chosen = usize::try_from(window.get_entrance_server())
                .ok()
                .and_then(|index| self.entrance_servers.get(index).cloned())
                .flatten();
            let index = servers
                .iter()
                .position(|server| *server == chosen)
                .unwrap_or(0);
            window.set_entrance_server(index as i32);
            self.entrance_servers = servers;
        }
        let server = usize::try_from(window.get_entrance_server())
            .ok()
            .and_then(|index| self.entrance_servers.get(index).cloned())
            .flatten();
        let catalog = state.sound_catalog.as_ref();
        let sound = state
            .join_sounds
            .iter()
            .find(|join| join.server == server)
            .map(|join| {
                let named = catalog
                    .iter()
                    .flat_map(|groups| groups.iter())
                    .flat_map(|group| &group.sounds)
                    .find(|sound| sound.id == join.sound && sound.guild == join.guild);
                match (named, catalog) {
                    (Some(sound), _) => sound.name.as_str(),
                    (None, None) => "Loading...",
                    (None, Some(_)) => "A sound that's gone",
                }
            });
        window.set_entrance_sound(sound.unwrap_or_default().into());
        let Some(groups) = catalog else { return };
        let shown = self.entrance_shown.as_ref();
        if shown.is_some_and(|(kept, revision)| {
            Arc::ptr_eq(kept, groups) && *revision == state.picture_changes
        }) {
            return;
        }
        self.entrance_shown = Some((groups.clone(), state.picture_changes));
        let rows = sound_rows(groups, &mut self.pictures, state);
        self.models.entrance_rows.set_vec(rows);
    }

    /// The open profile card, and the profile beside a one-to-one DM, with
    /// what's known so far.
    fn show_profile(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        window.set_profile_open(state.profile.is_some());
        window.set_panel_profile_shown(state.panel_profile.is_some());
        if let Some(view) = &state.panel_profile {
            let mut data = profile_data(&mut self.pictures, state, view);
            // The DM list keeps up with whether they're around; the profile
            // was as it was when it opened.
            if let Some(room) = state.selected_room() {
                data.presence = presence_name(room.presence.or(view.profile.presence)).into();
                if let Some(activity) = &room.activity {
                    let (emoji, activity) = if names_an_activity(activity, &room.activities) {
                        (None, "")
                    } else {
                        yapfast_core::discord::status_parts(activity)
                    };
                    data.activity = activity.into();
                    data.activity_emoji = emoji.unwrap_or_default().into();
                }
                data.activities = activity_rows(&room.activities);
            }
            let shown = window.get_panel_profile();
            if let Some(data) = changed_profile(&shown, data) {
                window.set_panel_profile(data);
            }
        }
        let Some(view) = &state.profile else {
            window.set_profile_member(SharedString::default());
            self.tick_activities(window);
            return;
        };
        window.set_profile_large(view.large);
        window.set_profile_member(if view.large {
            SharedString::default()
        } else {
            view.profile.id.clone().into()
        });
        let data = profile_data(&mut self.pictures, state, view);
        if let Some(data) = changed_profile(&window.get_profile(), data) {
            window.set_profile(data);
        }
        self.tick_activities(window);
    }

    /// The image viewer: the full image once it arrives, the preview until then.
    /// The video playing, which its cell shows through [`VideoPlayer`]; its
    /// pictures come with each stream tick.
    fn show_video(&mut self, window: &YapfastWindow) {
        let player = window.global::<VideoPlayer>();
        let video = self.app.state.video.as_ref();
        // Stream ticks bring its pictures, until a quiet moment while it
        // isn't playing.
        window.set_video_active(video.is_some_and(|video| video.frames.is_some()));
        self.video_quiet.set(0);
        let same = video.is_some_and(|video| {
            player.get_item() == video.item.as_str() && player.get_index() == video.index as i32
        });
        if !same {
            player.set_has_frame(false);
            player.set_frame(slint::Image::default());
            player.set_progress(0.0);
            player.set_time(SharedString::default());
            player.set_expanded(false);
        }
        let Some(video) = video else {
            player.set_item(SharedString::default());
            player.set_index(-1);
            player.set_error(SharedString::default());
            return;
        };
        player.set_item(video.item.clone().into());
        player.set_index(video.index as i32);
        player.set_loading(video.loading);
        player.set_playing(video.playing);
        player.set_ended(video.ended);
        player.set_sound(video.sound);
        player.set_muted(video.muted);
        player.set_volume(video.volume);
        player.set_error(video.error.clone().unwrap_or_default().into());
        let attachment = self
            .app
            .state
            .message(&video.item)
            .and_then(|message| message.attachments.get(video.index));
        player.set_name(attachment.map_or_else(SharedString::default, |attachment| {
            attachment.name.as_str().into()
        }));
        let (width, height) = video
            .size
            .or_else(|| attachment.and_then(|attachment| attachment.dimensions))
            .unwrap_or_default();
        player.set_video_width(i32::try_from(width).unwrap_or(0));
        player.set_video_height(i32::try_from(height).unwrap_or(0));
        player.set_duration(
            video
                .duration_ms
                .and_then(|duration| i32::try_from(duration).ok())
                .unwrap_or(0),
        );
        if video.ended {
            player.set_progress(1.0);
        }
        if !same || video.ended {
            let at = if video.ended {
                video.duration_ms.unwrap_or(0)
            } else {
                0
            };
            player.set_time(video_time(at, video.duration_ms).into());
        }
    }

    /// The voice message playing, or paused, which its card shows through
    /// [`VoicePlayer`].
    fn show_voice_message(&self, window: &YapfastWindow) {
        let player = window.global::<VoicePlayer>();
        let state = &self.app.state;
        player.set_speed(format!("{}x", state.voice_tuning.speed).into());
        player.set_volume(state.voice_tuning.volume);
        player.set_muted(state.voice_tuning.muted);
        let Some(playback) = &state.voice_message else {
            player.set_item(SharedString::default());
            player.set_playing(false);
            player.set_progress(0.0);
            player.set_time(SharedString::default());
            return;
        };
        let duration = state
            .message(&playback.item)
            .and_then(|message| message.voice.as_ref())
            .map_or(0, |voice| voice.duration_ms);
        player.set_item(playback.item.as_str().into());
        player.set_loading(playback.loading);
        player.set_playing(playback.playing);
        player.set_error(playback.error.clone().unwrap_or_default().into());
        player.set_progress(if duration > 0 {
            (playback.position_ms as f64 / duration as f64).min(1.0) as f32
        } else {
            0.0
        });
        // Once started it counts down what's left, as Discord's does; at
        // its start the card shows how long it is.
        let started = playback.playing || playback.position_ms > 0;
        player.set_time(if started {
            voice_time(duration.saturating_sub(playback.position_ms)).into()
        } else {
            SharedString::default()
        });
    }

    fn show_viewer(&mut self, window: &YapfastWindow) {
        let state = &self.app.state;
        let viewing = state.viewer.as_ref().and_then(|viewer| {
            let message = state.message(&viewer.item)?;
            Some((viewer, message, message.attachments.get(viewer.index)?))
        });
        window.set_viewer_open(viewing.is_some());
        let Some((viewer, message, attachment)) = viewing else {
            // The window would keep the picture it showed, up to 9 MiB, until
            // the next one.
            if self.viewer_image.take().is_some() {
                window.set_viewer_image(slint::Image::default());
                window.set_viewer_frames(ModelRc::default());
                window.set_viewer_delays(ModelRc::default());
            }
            self.viewer_size = None;
            return;
        };
        let loaded = viewer.pictures.get(&viewer.index);
        let full = match loaded {
            Some(Some(Ok(picture))) => Some(picture),
            _ => None,
        };
        window.set_viewer_note(
            match loaded {
                Some(Some(Err(error))) => error,
                Some(None) => "Loading the full image...",
                _ => "",
            }
            .into(),
        );
        // The full image's size from the start where it's known, else the
        // preview's. Either way the image keeps the size it opened at, so the
        // full image only sharpens it on arrival.
        let (width, height) = match &self.viewer_size {
            Some((item, index, width, height))
                if *item == viewer.item && *index == viewer.index =>
            {
                (*width, *height)
            }
            _ => {
                let size = match (full, attachment.dimensions, &attachment.preview) {
                    (Some(full), _, _) => Some((full.width, full.height)),
                    (None, Some((width, height)), _) => Some(fit(width, height)),
                    (None, None, Some(preview)) => Some((preview.width, preview.height)),
                    _ => None,
                };
                self.viewer_size =
                    size.map(|(width, height)| (viewer.item.clone(), viewer.index, width, height));
                size.unwrap_or((1, 1))
            }
        };
        window.set_viewer_width(width as i32);
        window.set_viewer_height(height as i32);
        let shown = full.or(attachment.preview.as_ref());
        let image = match (shown, &self.viewer_image) {
            (Some(shown), Some((cached, image))) if Arc::ptr_eq(shown, cached) => image.clone(),
            (Some(shown), _) => {
                let image = picture(shown);
                self.viewer_image = Some((shown.clone(), image.clone()));
                image
            }
            (None, _) => slint::Image::default(),
        };
        window.set_viewer_image(image);
        let (frames, delays) = shown.map(animation).unwrap_or_default();
        window.set_viewer_frames(frames);
        window.set_viewer_delays(delays);
        window.set_viewer_name(attachment.name.clone().into());
        window.set_viewer_item(viewer.item.clone().into());
        window.set_viewer_index(viewer.index as i32);
        let images: Vec<usize> = message
            .attachments
            .iter()
            .enumerate()
            .filter(|(_, attachment)| attachment.image)
            .map(|(index, _)| index)
            .collect();
        let place = images.iter().position(|index| *index == viewer.index);
        window.set_viewer_position(match place {
            Some(place) if images.len() > 1 => format!("{} / {}", place + 1, images.len()).into(),
            _ => SharedString::default(),
        });
    }
}

/// The DMs with unread messages, the latest first, as Discord lists them on
/// its rail above the servers. Message requests and spam stay on their screen.
pub(super) fn unread_dm_rows(state: &AppState) -> Vec<ServerRow> {
    state
        .rooms
        .iter()
        .filter(|room| {
            room.direct
                && !room.request
                && room.category != discord::SPAM
                && (room.unread > 0 || room.mentions > 0)
        })
        .map(|room| ServerRow {
            id: room.id.as_str().into(),
            name: room.name.as_str().into(),
            initial: initial(&room.name),
            picture_url: room.avatar.as_deref().unwrap_or_default().into(),
            unread: true,
            // Discord counts each of a DM's messages; Matrix counts its
            // unread messages apart from its mentions.
            badge: count_badge(room.mentions.max(room.unread)),
            discord: room.network == Network::Discord,
            dm: true,
            ..Default::default()
        })
        .collect()
}

/// The whole rail: unread DMs, a line, then the servers and folders. Unread
/// DMs come and go above the servers, so the model keeps rows by id rather
/// than all moving down one.
fn rail(
    state: &AppState,
    rooms_by_id: &HashMap<&str, &yapfast_core::chat::ChatRoom>,
    open_folders: &std::collections::BTreeSet<String>,
    order: &[String],
) -> Vec<ServerRow> {
    let mut rail = unread_dm_rows(state);
    rail.push(ServerRow {
        divider: true,
        ..Default::default()
    });
    rail.extend(rail_rows_ordered(state, rooms_by_id, open_folders, order));
    rail
}

/// The rail's rows: each server, and each folder with its servers after it
/// while it's open.
pub(super) fn rail_rows(
    state: &AppState,
    rooms_by_id: &HashMap<&str, &yapfast_core::chat::ChatRoom>,
    open_folders: &std::collections::BTreeSet<String>,
) -> Vec<ServerRow> {
    rail_rows_ordered(state, rooms_by_id, open_folders, &[])
}

fn rail_rows_ordered(
    state: &AppState,
    rooms_by_id: &HashMap<&str, &yapfast_core::chat::ChatRoom>,
    open_folders: &std::collections::BTreeSet<String>,
    order: &[String],
) -> Vec<ServerRow> {
    // A server's channels: whether any is unread, and its mentions. One its
    // channel list leaves out marks it only by mentions, as in Discord.
    let marks = |server: &yapfast_core::chat::ChatServer| {
        let rooms = || {
            server
                .channels
                .iter()
                .filter_map(|channel| rooms_by_id.get(channel.as_str()))
                .filter(|room| !room.direct)
        };
        (
            rooms().any(|room| {
                room.mentions > 0 || (room.unread > 0 && !server.muted && !room.unlisted)
            }),
            rooms().map(|room| room.mentions).sum::<u64>(),
        )
    };
    let selected = |server: &yapfast_core::chat::ChatServer| {
        state.navigation == Navigation::Server(server.id.clone())
    };
    let call = call_room(state);
    let in_call = |server: &yapfast_core::chat::ChatServer| {
        call.is_some_and(|room| server.channels.iter().any(|channel| channel == room))
    };
    let mut rows = Vec::with_capacity(state.servers.len());
    let mut servers = server_order::servers(state, order).into_iter().peekable();
    while let Some(server) = servers.next() {
        let Some(folder) = &server.folder else {
            let (unread, mentions) = marks(server);
            rows.push(ServerRow {
                call: in_call(server),
                ..server_row(server, selected(server), unread, mentions)
            });
            continue;
        };
        let mut inside = vec![server];
        while let Some(next) = servers.next_if(|next| next.folder.as_ref() == Some(folder)) {
            inside.push(next);
        }
        let open = open_folders.contains(&folder.id);
        let tint = folder.color.map_or(FOLDER_COLOR, |rgb| {
            let [_, red, green, blue] = rgb.to_be_bytes();
            slint::Color::from_rgb_u8(red, green, blue)
        });
        let (unread, mentions) = inside
            .iter()
            .map(|server| marks(server))
            .fold((false, 0), |(unread, mentions), (one, more)| {
                (unread || one, mentions + more)
            });
        let name = folder.name.clone().unwrap_or_else(|| {
            let mut names: Vec<_> = inside
                .iter()
                .take(3)
                .map(|server| server.name.as_str())
                .collect();
            if inside.len() > 3 {
                names.push("…");
            }
            names.join(", ")
        });
        rows.push(ServerRow {
            id: folder.id.as_str().into(),
            name: name.into(),
            selected: inside.iter().any(|server| selected(server)),
            unread,
            badge: count_badge(mentions),
            call: inside.iter().any(|server| in_call(server)),
            discord: true,
            folder: true,
            open,
            tint,
            preview: ModelRc::new(VecModel::from(
                inside
                    .iter()
                    .take(4)
                    .map(|server| FolderServer {
                        initial: initials(&server.name),
                        picture_url: server.icon.as_deref().unwrap_or_default().into(),
                    })
                    .collect::<Vec<_>>(),
            )),
            ..Default::default()
        });
        if open {
            let last = inside.len() - 1;
            for (index, server) in inside.into_iter().enumerate() {
                let (unread, mentions) = marks(server);
                rows.push(ServerRow {
                    nested: true,
                    drag_parent: folder.id.as_str().into(),
                    last: index == last,
                    tint,
                    call: in_call(server),
                    ..server_row(server, selected(server), unread, mentions)
                });
            }
        }
    }
    rows
}

/// The voice channel of the call going on, if there is one.
/// A server voice channel someone is in, as the friends list names it.
pub(super) struct VoicePlace<'a> {
    pub room: &'a str,
    pub channel: &'a str,
    pub server: &'a str,
}

/// Who is in a voice channel of a server this account is in, by user id.
/// DM calls stay out: Discord's friends list shows only servers' channels.
pub(super) fn voice_places<'a>(
    state: &'a AppState,
    rooms_by_id: &HashMap<&str, &'a yapfast_core::chat::ChatRoom>,
) -> HashMap<&'a str, VoicePlace<'a>> {
    let mut places = HashMap::new();
    for server in &state.servers {
        for channel in &server.channels {
            let Some(room) = rooms_by_id.get(channel.as_str()).filter(|room| room.voice) else {
                continue;
            };
            for person in &room.people {
                places.insert(
                    person.id.as_str(),
                    VoicePlace {
                        room: &room.id,
                        channel: &room.name,
                        server: &server.name,
                    },
                );
            }
        }
    }
    places
}

fn call_room(state: &AppState) -> Option<&str> {
    state
        .voice
        .active()
        .then_some(state.voice.room.as_deref())
        .flatten()
}

/// Discord's colour for a folder that wasn't given one.
const FOLDER_COLOR: slint::Color = slint::Color::from_rgb_u8(0x58, 0x65, 0xf2);

fn server_row(
    server: &yapfast_core::chat::ChatServer,
    selected: bool,
    unread: bool,
    mentions: u64,
) -> ServerRow {
    ServerRow {
        id: server.id.clone().into(),
        name: server.name.clone().into(),
        initial: initials(&server.name),
        picture: slint::Image::default(),
        picture_url: server.icon.as_deref().unwrap_or_default().into(),
        selected,
        unread,
        discord: server.discord,
        unavailable: server.unavailable,
        badge: count_badge(mentions),
        ..Default::default()
    }
}

/// Rows under a collapsed category: only the selected channel, unread ones and
/// voice channels with people in them stay, as in Discord. A category with
/// none of those keeps its heading alone, to open it again.
pub(super) fn fold_collapsed(
    rows: Vec<RoomRow>,
    collapsed: &std::collections::BTreeSet<String>,
    voice_room: Option<&str>,
) -> Vec<RoomRow> {
    let mut group = SharedString::default();
    let mut folded = Vec::with_capacity(rows.len());
    for mut row in rows {
        if !row.heading.is_empty() {
            group = row.category.clone();
        }
        if group.is_empty() || !collapsed.contains(group.as_str()) {
            folded.push(row);
            continue;
        }
        row.collapsed = true;
        if row.selected
            || row.unread
            || row.people.row_count() > 0
            || voice_room == Some(row.id.as_str())
        {
            folded.push(row);
        } else if !row.heading.is_empty() {
            // Its id still names the category's first channel, for the
            // heading's menu.
            folded.push(RoomRow {
                id: row.id,
                heading: row.heading,
                category: row.category,
                collapsed: true,
                hidden: true,
                ..Default::default()
            });
        }
    }
    folded
}

/// Rows with a heading alone for each of a server's `categories` that holds
/// no channels, where Discord's order puts it among those that do.
pub(super) fn with_empty_categories(
    rows: Vec<RoomRow>,
    categories: &[ListedCategory],
) -> Vec<RoomRow> {
    if !categories.iter().any(|category| category.empty) {
        return rows;
    }
    // Its id names the category, for the heading's menu.
    let heading = |category: &ListedCategory| RoomRow {
        id: category.id.as_str().into(),
        heading: category.name.as_str().into(),
        category: category.id.as_str().into(),
        hidden: true,
        ..Default::default()
    };
    let mut next = 0;
    let mut listed = Vec::with_capacity(rows.len() + categories.len());
    for row in rows {
        if !row.heading.is_empty()
            && let Some(at) = categories[next..]
                .iter()
                .position(|known| known.id == row.category.as_str())
        {
            listed.extend(
                categories[next..next + at]
                    .iter()
                    .filter(|category| category.empty)
                    .map(heading),
            );
            next += at + 1;
        }
        listed.push(row);
    }
    listed.extend(
        categories[next..]
            .iter()
            .filter(|category| category.empty)
            .map(heading),
    );
    listed
}

/// A custom emoji and its picture, once that has arrived.
/// Whether the next call joins with the microphone off: unmuting on joining
/// is turned off, or deafening on joining is on.
fn joins_muted(window: &YapfastWindow) -> bool {
    !window.get_unmute_on_join() || window.get_deafen_on_join()
}

/// What a prompt to switch calls adds when the next one joins muted.
fn joining_muted(window: &YapfastWindow) -> &'static str {
    if joins_muted(window) {
        " You'll join muted."
    } else {
        ""
    }
}

/// A composer's waiting files, each with its picture once decoded; those not
/// decoded yet start decoding.
fn staged_rows(
    thumbnails: &mut HashMap<PathBuf, Option<pictures::Thumbnail>>,
    runtime: &BackgroundRuntime,
    weak: &std::rc::Weak<RefCell<Adapter>>,
    staged: &[yapfast_core::chat::Staged],
    can_modify: bool,
) -> Vec<StagedFile> {
    let mut rows = Vec::with_capacity(staged.len());
    for file in staged {
        let picture = match thumbnails.get(&file.path) {
            Some(thumbnail) => thumbnail.as_ref().map(|thumbnail| {
                if file.spoiler {
                    thumbnail.covered.clone()
                } else {
                    thumbnail.picture.clone()
                }
            }),
            None => {
                if file.image {
                    thumbnails.insert(file.path.clone(), None);
                    load_thumbnail(runtime, weak.clone(), file.path.clone());
                }
                None
            }
        };
        rows.push(StagedFile {
            name: file.name.as_str().into(),
            size: file_size(file.size).into(),
            has_picture: picture.is_some(),
            can_preview: can_modify && file.image,
            can_modify,
            picture: picture.unwrap_or_default(),
            spoiler: file.spoiler,
        });
    }
    rows
}

pub(super) fn arrived<'a>(
    state: &'a AppState,
    emoji: &'a yapfast_core::chat::CustomEmoji,
) -> Option<(&'a str, &'a yapfast_core::chat::Picture)> {
    Some((
        emoji.id.as_str(),
        state.pictures.get(&emoji.picture)?.as_ref(),
    ))
}

/// Discord's Administrator permission, which grants every other.
const ADMINISTRATOR: u64 = 1 << 3;

/// A bot's asked-for permissions, by the titles of a role's switches,
/// and how many more it asks for that no switch shows.
fn permission_names(bits: u64) -> String {
    let mut named = 0u64;
    let mut names: Vec<&str> = Vec::new();
    for permission in yapfast_core::application::ROLE_PERMISSIONS
        .iter()
        .flat_map(|group| group.permissions.iter())
    {
        let bit = 1u64 << permission.bit;
        if bits & bit != 0 && named & bit == 0 {
            named |= bit;
            names.push(permission.title);
        }
    }
    let more = (bits & !named).count_ones();
    let more = match (more, names.is_empty()) {
        (0, _) => None,
        (1, true) => Some("1 permission S;C can't name".to_owned()),
        (count, true) => Some(format!("{count} permissions S;C can't name")),
        (1, false) => Some("1 more permission".to_owned()),
        (count, false) => Some(format!("{count} more permissions")),
    };
    match (names.pop(), more) {
        (Some(last), Some(more)) => {
            names.push(last);
            format!("{} and {more}", names.join(", "))
        }
        (Some(last), None) if names.is_empty() => last.to_owned(),
        (Some(last), None) => format!("{} and {last}", names.join(", ")),
        (None, more) => more.unwrap_or_default(),
    }
}

/// Shows found messages, building rows only for those not shown already:
/// a search's next page adds to the end of the results.
fn show_found(model: &VecModel<FoundRow>, messages: &[ChatMessage], twelve_hour: bool) {
    let kept = model
        .iter()
        .zip(messages)
        .take_while(|(row, message)| row.item == message.item.as_str())
        .count();
    while model.row_count() > kept {
        model.remove(model.row_count() - 1);
    }
    for message in &messages[kept..] {
        model.push(found_row(message, twelve_hour));
    }
}

/// A length of time in seconds as a moderation dialog offers it, such as
/// "60 seconds", "6 hours" or "1 week".
pub(super) fn span(seconds: u32) -> String {
    let (count, unit) = match seconds {
        seconds if seconds % (7 * 86400) == 0 => (seconds / (7 * 86400), "week"),
        seconds if seconds % 86400 == 0 => (seconds / 86400, "day"),
        seconds if seconds % 3600 == 0 => (seconds / 3600, "hour"),
        seconds if seconds % 60 == 0 && seconds > 60 => (seconds / 60, "minute"),
        seconds => (seconds, "second"),
    };
    let plural = if count == 1 { "" } else { "s" };
    format!("{count} {unit}{plural}")
}

/// Search results, keeping the rows of those still first and building the
/// rest. A server's name the channel each is in, above the first of a run
/// in one channel.
fn show_hits(
    model: &VecModel<FoundRow>,
    state: &AppState,
    hits: &[yapfast_core::chat::SearchHit],
    server: bool,
    twelve_hour: bool,
) {
    let kept = model
        .iter()
        .zip(hits)
        .take_while(|(row, hit)| row.item == hit.message.item.as_str())
        .count();
    while model.row_count() > kept {
        model.remove(model.row_count() - 1);
    }
    for (index, hit) in hits.iter().enumerate().skip(kept) {
        let starts = index == 0 || hits[index - 1].room != hit.room;
        let heading = state
            .rooms
            .iter()
            .find(|room| room.id == hit.room)
            .filter(|_| server && starts)
            .map(|room| room.name.as_str())
            .unwrap_or_default();
        model.push(FoundRow {
            room: hit.room.as_str().into(),
            heading: heading.into(),
            ..found_row(&hit.message, twelve_hour)
        });
    }
}

/// What the bar that jumps to the "New" divider says: how many messages
/// others sent from `unread` on, and since when, with the date unless it
/// was today. `more` came after them, past a window of older messages.
pub(super) fn unread_label(unread: &[Arc<ChatMessage>], more: bool) -> String {
    let count = unread.iter().filter(|message| !message.own).count();
    let messages = if count == 1 && !more {
        "message"
    } else {
        "messages"
    };
    let count = if more {
        format!("{count}+")
    } else {
        count.to_string()
    };
    let Some(first) = unread.first().filter(|first| first.time.contains(':')) else {
        return format!("{count} new {messages}");
    };
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |now| now.as_secs());
    let on = day(first.timestamp);
    if on.is_empty() || on == day(now) {
        format!("{count} new {messages} since {}", first.time)
    } else {
        format!("{count} new {messages} since {} on {on}", first.time)
    }
}

/// How far into a video, and how long it is when known, as "0:12 / 1:30".
pub(super) fn video_time(at_ms: u64, duration_ms: Option<u64>) -> String {
    let clock = |ms: u64| {
        let seconds = ms / 1000;
        match seconds / 3600 {
            0 => format!("{}:{:02}", seconds / 60, seconds % 60),
            hours => format!("{hours}:{:02}:{:02}", seconds / 60 % 60, seconds % 60),
        }
    };
    match duration_ms {
        Some(duration) => format!("{} / {}", clock(at_ms.min(duration)), clock(duration)),
        None => clock(at_ms),
    }
}

/// A voice message's time, in whole seconds rounded up as Discord's are, so
/// the last moments read 0:01 and a 2.4-second one 0:03.
pub(super) fn voice_time(ms: u64) -> String {
    video_time(ms.div_ceil(1000) * 1000, None)
}

/// A section of a list of threads: its heading over the first, if it has any.
fn push_section(
    rows: &mut Vec<ThreadRow>,
    threads: &[yapfast_core::chat::ListedThread],
    heading: String,
    now: u64,
) {
    for (index, thread) in threads.iter().enumerate() {
        let mut row = thread_row(thread, now);
        if index == 0 {
            row.heading = heading.clone().into();
        }
        rows.push(row);
    }
}

/// A thread as its list shows it: an active one with its newest message,
/// an archived one with who started it, as Discord's client does.
pub(super) fn thread_row(thread: &yapfast_core::chat::ListedThread, now: u64) -> ThreadRow {
    let ago = ago(thread.active_ms, now);
    let (person, lead, text, time) = match (&thread.recent, &thread.owner, thread.archived) {
        (Some(recent), _, false) => (Some(&recent.author), "", recent.text.as_str(), ago),
        (None, _, false) => (None, "", "No recent messages", ago),
        (_, Some(owner), true) => (Some(owner), "Started by ", "", format!("Last active {ago}")),
        (_, None, true) => (None, "", "", format!("Last active {ago}")),
    };
    ThreadRow {
        room: thread.room.as_str().into(),
        heading: SharedString::default(),
        name: thread.name.as_str().into(),
        private: thread.private,
        archived: thread.archived,
        person: person.map_or("", |person| person.name.as_str()).into(),
        initial: person.map_or(SharedString::default(), |person| initial(&person.name)),
        tint: person.map_or(slint::Color::default(), |person| tint(&person.name)),
        picture_url: person.map_or("", |person| person.avatar.as_str()).into(),
        color: role_color(person.and_then(|person| person.color)),
        has_color: person.is_some_and(|person| person.color.is_some()),
        lead: lead.into(),
        text: text.into(),
        time: time.into(),
        members: match thread.members {
            0 => SharedString::default(),
            count => count.to_string().into(),
        },
        member_pictures: ModelRc::new(VecModel::from(
            thread
                .member_avatars
                .iter()
                .map(|avatar| SharedString::from(avatar.as_str()))
                .collect::<Vec<_>>(),
        )),
    }
}

/// A forum's tag, or an emoji, as a card or the form for a post shows it.
/// Whether a form's field shows the same: its text laid out is the same
/// model when its text is, and its lists hold the same.
fn same_field(shown: &ModalField, field: &ModalField) -> bool {
    shown.label == field.label
        && shown.description == field.description
        && shown.value == field.value
        && shown.placeholder == field.placeholder
        && shown.required == field.required
        && shown.paragraph == field.paragraph
        && shown.kind == field.kind
        && shown.summary == field.summary
        && shown.checked == field.checked
        && shown.max_files == field.max_files
        && shown.blocks == field.blocks
        && shown.choices.iter().eq(field.choices.iter())
        && shown.files.iter().eq(field.files.iter())
}

fn post_tag(name: &str, emoji: Option<&yapfast_core::chat::ShownEmoji>) -> PostTag {
    PostTag {
        name: name.into(),
        emoji: emoji
            .filter(|emoji| emoji.picture.is_none())
            .map_or(SharedString::default(), |emoji| emoji.text.as_str().into()),
        emoji_url: emoji
            .and_then(|emoji| emoji.picture.as_deref())
            .unwrap_or_default()
            .into(),
    }
}

/// A forum post as its card shows it, as Discord's client does: its first
/// three tags, its first message's author and text, its top reaction or the
/// forum's own, its replies, and when it was last active, or made when the
/// forum sorts by that.
fn post_row(
    post: &yapfast_core::application::ForumPost,
    info: &yapfast_core::application::ForumInfo,
    now: u64,
) -> PostRow {
    const TAGS: usize = 3;
    let thread = &post.thread;
    let tag = post_tag;
    let tags: Vec<PostTag> = post
        .tags
        .iter()
        .take(TAGS)
        .map(|shown| tag(&shown.name, shown.emoji.as_ref()))
        .collect();
    let starter = post.starter.as_ref();
    let first = starter.and_then(Option::as_ref);
    let (person, text) = match starter {
        Some(Some(first)) => (Some(&first.author), first.text.as_str()),
        Some(None) => (None, "Original message was deleted"),
        None => (None, ""),
    };
    let reaction = match first.and_then(|first| first.reaction.as_ref()) {
        Some((emoji, count)) => Some((tag("", Some(emoji)), count.to_string())),
        // A post without reactions offers the forum's own.
        None if first.is_some() => info
            .reaction
            .as_ref()
            .map(|emoji| (tag("", Some(emoji)), String::new())),
        None => None,
    };
    let at = if info.by_creation {
        thread.created_ms
    } else {
        thread.active_ms
    };
    PostRow {
        room: thread.room.as_str().into(),
        heading: SharedString::default(),
        name: thread.name.as_str().into(),
        pinned: thread.pinned,
        new: post.new,
        unread: thread.unread,
        tags: ModelRc::new(VecModel::from(tags)),
        more_tags: match post.tags.len().saturating_sub(TAGS) {
            0 => SharedString::default(),
            more => format!("+{more}").into(),
        },
        person: person.map_or("", |person| person.name.as_str()).into(),
        color: role_color(person.and_then(|person| person.color)),
        has_color: person.is_some_and(|person| person.color.is_some()),
        text: text.into(),
        has_reaction: reaction.is_some(),
        reaction_count: reaction
            .as_ref()
            .map_or(SharedString::default(), |(_, count)| count.as_str().into()),
        reaction: reaction.map(|(emoji, _)| emoji).unwrap_or_default(),
        replies: thread.replies.to_string().into(),
        time: ago(at, now).into(),
        picture_url: first
            .and_then(|first| first.picture.as_deref())
            .unwrap_or_default()
            .into(),
        spoiler: first.is_some_and(|first| first.spoiler),
    }
}

/// How long ago something was, as Discord's list of threads says it: "5s
/// ago" up to "30d ago", then ">30d ago" and ">1y ago".
pub(super) fn ago(at_ms: u64, now_ms: u64) -> String {
    let seconds = now_ms.saturating_sub(at_ms) / 1000;
    match seconds {
        seconds if seconds < 60 => format!("{seconds}s ago"),
        seconds if seconds < 3600 => format!("{}m ago", seconds / 60),
        seconds if seconds < 86400 => format!("{}h ago", seconds / 3600),
        seconds if seconds <= 30 * 86400 => format!("{}d ago", seconds / 86400),
        seconds if seconds < 365 * 86400 => ">30d ago".into(),
        _ => ">1y ago".into(),
    }
}

/// The requests screen's rows: those waiting for this account's answer,
/// the friend requests it sent, and spam.
pub(super) struct RequestRows {
    pub(super) incoming: Vec<RequestRow>,
    pub(super) sent: Vec<RequestRow>,
    pub(super) spam: Vec<RequestRow>,
}

/// Friend requests and message requests as the requests screen lists them,
/// someone's friend request and message request on one row.
pub(super) fn request_rows(
    state: &AppState,
    message_requests: &[&yapfast_core::chat::ChatRoom],
    spam: &[&yapfast_core::chat::ChatRoom],
    twelve_hour: bool,
) -> RequestRows {
    let mut rows = RequestRows {
        incoming: Vec::new(),
        sent: Vec::new(),
        spam: Vec::new(),
    };
    let rooms = || message_requests.iter().chain(spam);
    let with_room = |row: &mut RequestRow, room: &yapfast_core::chat::ChatRoom| {
        row.room = room.id.as_str().into();
        row.unread = room.unread > 0;
        if let Some(preview) = &room.preview {
            row.message = preview.text.as_str().into();
            let seconds = preview.at / 1000;
            let today = yapfast_core::clock::date(yapfast_core::clock::now_ms() / 1000);
            row.time = if yapfast_core::clock::date(seconds) == today {
                yapfast_core::clock::time_on(seconds, twelve_hour)
            } else {
                yapfast_core::clock::day(seconds)
            }
            .into();
        }
    };
    for request in &state.friend_requests {
        let mut row = RequestRow {
            id: request.id.as_str().into(),
            name: request.name.as_str().into(),
            initial: initial(&request.name),
            tint: tint(&request.id),
            picture_url: request.avatar.as_deref().unwrap_or_default().into(),
            friend: if request.incoming { 1 } else { 2 },
            ..Default::default()
        };
        let room = rooms().find(|room| room.person.as_deref() == Some(request.id.as_str()));
        if let Some(room) = room {
            with_room(&mut row, room);
        }
        let spammed = request.spam || room.is_some_and(|room| room.category == discord::SPAM);
        match () {
            () if spammed => rows.spam.push(row),
            // A message waits for an answer, whoever asked to be friends.
            () if request.incoming || room.is_some() => rows.incoming.push(row),
            () => rows.sent.push(row),
        }
    }
    let befriending = |room: &&&yapfast_core::chat::ChatRoom| {
        !state
            .friend_requests
            .iter()
            .any(|request| room.person.as_deref() == Some(request.id.as_str()))
    };
    for (list, rooms) in [
        (&mut rows.incoming, message_requests),
        (&mut rows.spam, spam),
    ] {
        for room in rooms.iter().filter(befriending) {
            let mut row = RequestRow {
                id: room.person.as_deref().unwrap_or(&room.id).into(),
                name: room.name.as_str().into(),
                initial: initial(&room.name),
                tint: tint(&room.id),
                picture_url: room.avatar.as_deref().unwrap_or_default().into(),
                ..Default::default()
            };
            with_room(&mut row, room);
            list.push(row);
        }
    }
    rows
}

/// What the composer's mentions were coloured for: its draft, and what those
/// it may mention come from.
pub(super) struct MentionsMarked {
    draft: String,
    sources: MentionSources,
}

#[derive(Clone, Copy, PartialEq)]
struct MentionSources {
    /// The timeline's address, as its authors may be mentioned.
    messages: usize,
    members: usize,
    found: usize,
    groups: usize,
    color: u32,
}

/// A soundboard's groups as its rows show them: each group's heading, then
/// its sounds three to a row.
fn sound_rows(
    groups: &[voice::SoundGroup],
    pictures: &mut HashMap<String, slint::Image>,
    state: &AppState,
) -> Vec<SoundRow> {
    let mut rows = Vec::new();
    for group in groups {
        rows.push(SoundRow {
            heading: group.name.to_uppercase().into(),
            sounds: ModelRc::default(),
        });
        for chunk in group.sounds.chunks(3) {
            let cells: Vec<SoundCell> = chunk
                .iter()
                .map(|sound| SoundCell {
                    id: sound.id.as_str().into(),
                    name: sound.name.as_str().into(),
                    emoji: EmojiCell {
                        // A custom emoji waits as a quiet square until its
                        // picture comes.
                        glyph: if sound.picture.is_some() {
                            sound.name.as_str().into()
                        } else {
                            sound.emoji.as_str().into()
                        },
                        name: sound.name.as_str().into(),
                        // A sound's custom emoji has no name of its own here, so
                        // its picture names its animation.
                        key: sound
                            .picture
                            .as_deref()
                            .map_or_else(SharedString::new, |picture| {
                                format!("sound:{picture}").into()
                            }),
                        picture: cached_picture(pictures, state, sound.picture.as_deref()),
                        usable: true,
                    },
                    favorite: sound.favorite,
                })
                .collect();
            rows.push(SoundRow {
                heading: SharedString::new(),
                sounds: ModelRc::new(VecModel::from(cells)),
            });
        }
    }
    rows
}
