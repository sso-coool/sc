//! The Vencord catalog, native equivalents, and the bundled Vencord profile.
use super::extension_profile::{NATIVE_PLUGINS, Profile};
use super::vencord_profile::{
    companion_plugin_toggleable, companion_snapshot, set_companion_plugin,
};
use super::*;
use std::borrow::Cow;
use std::sync::LazyLock;

#[derive(serde::Deserialize)]
struct Plugin<'a> {
    name: &'a str,
    description: Cow<'a, str>,
}

// Metadata from Vencord/builds at 7b52187d06792777e41ab61e6512f93d52579997.
static CATALOG: LazyLock<Vec<Plugin<'static>>> = LazyLock::new(|| {
    serde_json::from_str(include_str!("vencord_catalog.json"))
        .expect("the bundled Vencord plugin catalog is valid JSON")
});

static COMPANION_PLUGINS: LazyLock<HashSet<&'static str>> = LazyLock::new(|| {
    #[derive(serde::Deserialize)]
    struct Lock<'a> {
        #[serde(borrow)]
        plugins: HashMap<&'a str, &'a str>,
    }
    let lock: Lock<'static> = serde_json::from_str(include_str!(
        "../../tools/vencord-companion/upstream-lock.json"
    ))
    .expect("the bundled Vencord runtime lock is valid JSON");
    lock.plugins.into_values().collect()
});

fn matches_query(plugin: &Plugin<'_>, query: &str) -> bool {
    query.is_empty()
        || plugin.name.to_lowercase().contains(query)
        || plugin.description.to_lowercase().contains(query)
}

fn details_url(name: &str) -> Option<String> {
    CATALOG.iter().find(|plugin| plugin.name == name)?;
    let mut page = reqwest::Url::parse("https://vencord.dev/plugins/").expect("valid catalog URL");
    page.path_segments_mut().ok()?.pop_if_empty().push(name);
    Some(page.into())
}

pub(super) fn refresh(window: &YapfastWindow) {
    let marketplace = window.global::<VencordMarketplace>();
    let query = marketplace.get_query().trim().to_lowercase();
    let supported_only = marketplace.get_native_only();
    let companion_mode = marketplace.get_companion_mode();
    let packaged = window.global::<ClientStyle>().get_companion_available();
    let companion_known = marketplace.get_companion_known();
    let companion_enabled: HashSet<_> = marketplace
        .get_companion_enabled()
        .iter()
        .map(|name| name.to_string())
        .collect();
    let mut profile = Profile::read(window);
    let rows: Vec<_> = CATALOG
        .iter()
        .filter(|plugin| matches_query(plugin, &query))
        .filter_map(|plugin| {
            let native = NATIVE_PLUGINS.iter().find(|(name, _)| *name == plugin.name);
            let bundled = COMPANION_PLUGINS.contains(plugin.name);
            let supported = if companion_mode {
                bundled
            } else {
                native.is_some()
            };
            if supported_only && !supported {
                return None;
            }
            let (status, configurable, enabled) = if companion_mode {
                let configurable = bundled && packaged && companion_plugin_toggleable(plugin.name);
                let enabled = companion_enabled.contains(plugin.name);
                let status = if !bundled {
                    "Unavailable in this Vencord build"
                } else if !packaged {
                    "Requires the bundled Vencord runtime"
                } else if !configurable || !companion_known {
                    "Included in Vencord"
                } else if enabled {
                    "Enabled for Vencord"
                } else {
                    "Disabled for Vencord"
                };
                (status, configurable, enabled)
            } else {
                let configured = native.is_some_and(|(_, enabled)| *enabled(&mut profile));
                let status = if configured && !profile.enabled {
                    "Native plugins paused"
                } else if native.is_some() {
                    "Native S;C"
                } else if bundled && packaged {
                    "Available in the Vencord tab"
                } else {
                    "Unavailable in native S;C"
                };
                (status, native.is_some(), profile.enabled && configured)
            };
            Some(VencordPluginRow {
                id: plugin.name.into(),
                name: plugin.name.into(),
                description: plugin.description.as_ref().into(),
                status: status.into(),
                configurable,
                enabled,
            })
        })
        .collect();
    marketplace.set_status(
        match rows.len() {
            0 => "No matching plugins".into(),
            1 => "1 plugin".into(),
            count => format!("{count} plugins"),
        }
        .into(),
    );
    marketplace.set_rows(ModelRc::new(VecModel::from(rows)));
}

/// Profile I/O and Windows process inspection never run on the Slint thread.
fn update_companion(window: &YapfastWindow, change: Option<(String, bool)>) {
    let marketplace = window.global::<VencordMarketplace>();
    let style = window.global::<ClientStyle>();
    if !style.get_companion_available()
        || style.get_companion_starting()
        || marketplace.get_companion_busy()
    {
        return;
    }
    if let Some((name, _)) = &change
        && (!marketplace.get_companion_known()
            || marketplace.get_companion_running()
            || !COMPANION_PLUGINS.contains(name.as_str())
            || !companion_plugin_toggleable(name))
    {
        return;
    }
    marketplace.set_companion_busy(true);
    marketplace.set_companion_notice(SharedString::default());
    let weak = window.as_weak();
    let work = std::thread::Builder::new()
        .name("sc-vencord-profile".into())
        .spawn(move || {
            let (snapshot, notice) = match change {
                Some((name, enabled)) => match set_companion_plugin(&name, enabled) {
                    Ok(snapshot) => {
                        let action = if enabled { "Enabled" } else { "Disabled" };
                        (
                            Some(snapshot),
                            format!("{action} {name} for the next Vencord launch."),
                        )
                    }
                    Err(error) => (companion_snapshot().ok(), error.to_string()),
                },
                None => match companion_snapshot() {
                    Ok(snapshot) => (Some(snapshot), String::new()),
                    Err(error) => (None, error.to_string()),
                },
            };
            let _ = weak.upgrade_in_event_loop(move |window| {
                let marketplace = window.global::<VencordMarketplace>();
                marketplace.set_companion_busy(false);
                marketplace.set_companion_notice(notice.into());
                marketplace.set_companion_known(snapshot.is_some());
                if let Some(snapshot) = snapshot {
                    marketplace.set_companion_running(snapshot.running);
                    marketplace.set_companion_enabled(ModelRc::new(VecModel::from(
                        COMPANION_PLUGINS
                            .iter()
                            .copied()
                            .filter(|name| snapshot.enabled(name))
                            .map(SharedString::from)
                            .collect::<Vec<_>>(),
                    )));
                }
                refresh(&window);
            });
        });
    if work.is_err() {
        marketplace.set_companion_busy(false);
        marketplace.set_companion_notice("S;C could not open the Vencord profile.".into());
    }
}

pub(super) fn bind(window: &YapfastWindow) {
    let marketplace = window.global::<VencordMarketplace>();
    let weak = window.as_weak();
    marketplace.on_opened(move || {
        if let Some(window) = weak.upgrade() {
            refresh(&window);
            update_companion(&window, None);
        }
    });
    let weak = window.as_weak();
    marketplace.on_search(move || {
        if let Some(window) = weak.upgrade() {
            refresh(&window);
        }
    });
    let weak = window.as_weak();
    marketplace.on_refresh_companion(move || {
        if let Some(window) = weak.upgrade() {
            update_companion(&window, None);
        }
    });
    let weak = window.as_weak();
    marketplace.on_toggle(move |id, on| {
        let Some(window) = weak.upgrade() else { return };
        if window.global::<VencordMarketplace>().get_companion_mode() {
            update_companion(&window, Some((id.to_string(), on)));
            return;
        }
        let Some((_, enabled)) = NATIVE_PLUGINS.iter().find(|(name, _)| *name == id.as_str())
        else {
            return;
        };
        let mut profile = Profile::read(&window);
        *enabled(&mut profile) = on;
        profile.enabled |= on;
        profile.show(&window);
        window.invoke_preferences_changed();
        refresh(&window);
    });
    marketplace.on_details(|id| {
        if let Some(url) = details_url(id.as_str()) {
            super::browser::open(&url);
        }
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vencord_marketplace_catalog_contains_all_native_equivalents() {
        assert!(!CATALOG.is_empty());
        assert!(
            CATALOG
                .windows(2)
                .all(|pair| { pair[0].name.to_lowercase() < pair[1].name.to_lowercase() })
        );
        assert!(CATALOG.iter().all(|entry| !entry.description.is_empty()));
        for (name, _) in NATIVE_PLUGINS {
            assert!(CATALOG.iter().any(|entry| entry.name == name), "{name}");
        }
        assert!(COMPANION_PLUGINS.contains("BetterGifPicker"));
    }

    #[test]
    fn vencord_marketplace_finds_a_plugin_by_name_or_description() {
        let plugin = CATALOG
            .iter()
            .find(|entry| entry.name == "ClearURLs")
            .unwrap();
        assert!(matches_query(plugin, "clearurls"));
        assert!(matches_query(plugin, "tracking"));
        assert!(!matches_query(plugin, "clearurls-extra"));
    }

    #[test]
    fn vencord_marketplace_links_only_known_plugins() {
        assert_eq!(
            details_url("WebRichPresence (arRPC)").as_deref(),
            Some("https://vencord.dev/plugins/WebRichPresence%20(arRPC)")
        );
        assert!(details_url("//example.org").is_none());
    }

    #[test]
    fn vencord_marketplace_filters_and_applies_native_preferences() {
        i_slint_backend_testing::init_no_event_loop();
        let window = YapfastWindow::new().unwrap();
        bind(&window);
        let marketplace = window.global::<VencordMarketplace>();
        marketplace.invoke_opened();
        assert_eq!(marketplace.get_rows().row_count(), CATALOG.len());

        marketplace.set_native_only(true);
        marketplace.invoke_search();
        assert_eq!(marketplace.get_rows().row_count(), NATIVE_PLUGINS.len());
        marketplace.set_query("tracking".into());
        marketplace.invoke_search();
        let rows = marketplace.get_rows();
        assert_eq!(rows.row_count(), 1);
        assert_eq!(rows.row_data(0).unwrap().name, "ClearURLs");
        assert!(!rows.row_data(0).unwrap().enabled);

        marketplace.invoke_toggle("ClearURLs".into(), true);
        assert!(Profile::read(&window).tracking(false));
        assert!(marketplace.get_rows().row_data(0).unwrap().enabled);
        marketplace.invoke_toggle("ClearURLs".into(), false);
        assert!(!Profile::read(&window).tracking(false));
    }

    #[test]
    fn vencord_marketplace_opens_from_the_sidebar_and_returns_to_friends() {
        use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
        use slint::platform::{PointerEventButton, WindowEvent};
        use std::ops::ControlFlow;

        i_slint_backend_testing::init_no_event_loop();
        let window = YapfastWindow::new().unwrap();
        bind(&window);
        window.set_workspace(true);
        window.set_dms_selected(true);
        window.set_discord_linked(true);
        let weak = window.as_weak();
        window.on_open_friends(move || weak.upgrade().unwrap().set_friends_open(true));
        window.show().unwrap();
        let native = window.window();
        native.set_size(slint::LogicalSize::new(1200., 800.));
        let inner = i_slint_core::window::WindowInner::from_pub(native);
        for label in ["Vencord Plugins", "Friends"] {
            slint::platform::update_timers_and_animations();
            let item = ItemRc::new_root(inner.component())
                .visit_descendants(|item| {
                    if item.is_visible()
                        && item
                            .accessible_string_property(AccessibleStringProperty::Label)
                            .as_deref()
                            == Some(label)
                    {
                        ControlFlow::Break(item.clone())
                    } else {
                        ControlFlow::Continue(())
                    }
                })
                .unwrap_or_else(|| panic!("sidebar entry missing: {label}"));
            let at = item.map_to_window(item.geometry().center());
            let position = slint::LogicalPosition::new(at.x, at.y);
            let button = PointerEventButton::Left;
            native.dispatch_event(WindowEvent::PointerMoved { position });
            native.dispatch_event(WindowEvent::PointerPressed { position, button });
            native.dispatch_event(WindowEvent::PointerReleased { position, button });
            slint::platform::update_timers_and_animations();
            let visible = ItemRc::new_root(inner.component())
                .visit_descendants(|item| {
                    if item.is_visible()
                        && item
                            .accessible_string_property(AccessibleStringProperty::Label)
                            .as_deref()
                            == Some("Search Vencord plugins")
                    {
                        ControlFlow::Break(())
                    } else {
                        ControlFlow::Continue(())
                    }
                })
                .is_some();
            assert_eq!(visible, label == "Vencord Plugins");
        }
        window.hide().unwrap();
    }
}
