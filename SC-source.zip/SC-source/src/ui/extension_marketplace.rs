//! Vencord's bundled catalog and the controls for S;C's native equivalents.
use super::extension_profile::{NATIVE_PLUGINS, Profile};
use super::*;
use std::borrow::Cow;
use std::sync::LazyLock;

#[derive(serde::Deserialize)]
struct Plugin<'a> {
    name: &'a str,
    description: Cow<'a, str>,
}

// Metadata from Vencord/builds at 7b52187d06792777e41ab61e6512f93d52579997.
static CATALOG: LazyLock<Vec<Plugin<'static>>> = LazyLock::new(|| {
    serde_json::from_str(include_str!("vencord_catalog.json"))
        .expect("the bundled Vencord plugin catalog is valid JSON")
});

static COMPANION_PLUGINS: LazyLock<HashSet<&'static str>> = LazyLock::new(|| {
    #[derive(serde::Deserialize)]
    struct Lock<'a> {
        #[serde(borrow)]
        plugins: HashMap<&'a str, &'a str>,
    }
    let lock: Lock<'static> = serde_json::from_str(include_str!(
        "../../tools/vencord-companion/upstream-lock.json"
    ))
    .expect("the bundled Vencord runtime lock is valid JSON");
    lock.plugins.into_values().collect()
});

fn matches_query(plugin: &Plugin<'_>, query: &str) -> bool {
    query.is_empty()
        || plugin.name.to_lowercase().contains(query)
        || plugin.description.to_lowercase().contains(query)
}

fn details_url(name: &str) -> Option<String> {
    CATALOG.iter().find(|plugin| plugin.name == name)?;
    let mut page = reqwest::Url::parse("https://vencord.dev/plugins/").expect("valid catalog URL");
    page.path_segments_mut().ok()?.pop_if_empty().push(name);
    Some(page.into())
}

pub(super) fn refresh(window: &YapfastWindow) {
    let marketplace = window.global::<VencordMarketplace>();
    let query = marketplace.get_query().trim().to_lowercase();
    let native_only = marketplace.get_native_only();
    let companion = window.global::<ClientStyle>().get_companion_available();
    let mut profile = Profile::read(window);
    let rows: Vec<_> = CATALOG
        .iter()
        .filter(|plugin| matches_query(plugin, &query))
        .filter_map(|plugin| {
            let native = NATIVE_PLUGINS.iter().find(|(name, _)| *name == plugin.name);
            if native_only && native.is_none() {
                return None;
            }
            let in_companion = companion && COMPANION_PLUGINS.contains(plugin.name);
            let status = match (native.is_some(), in_companion) {
                (true, true) => "Native · bundled companion",
                (true, false) => "Native",
                (false, true) => "Bundled companion",
                (false, false) => "Upstream catalog",
            };
            Some(VencordPluginRow {
                id: plugin.name.into(),
                name: plugin.name.into(),
                description: plugin.description.as_ref().into(),
                status: status.into(),
                native: native.is_some(),
                enabled: profile.enabled
                    && native.is_some_and(|(_, enabled)| *enabled(&mut profile)),
            })
        })
        .collect();
    marketplace.set_status(
        match rows.len() {
            0 => "No matching plugins".into(),
            1 => "1 plugin".into(),
            count => format!("{count} plugins"),
        }
        .into(),
    );
    marketplace.set_rows(ModelRc::new(VecModel::from(rows)));
}

pub(super) fn bind(window: &YapfastWindow) {
    let marketplace = window.global::<VencordMarketplace>();
    let weak = window.as_weak();
    marketplace.on_opened(move || {
        if let Some(window) = weak.upgrade() {
            refresh(&window);
        }
    });
    let weak = window.as_weak();
    marketplace.on_search(move || {
        if let Some(window) = weak.upgrade() {
            refresh(&window);
        }
    });
    let weak = window.as_weak();
    marketplace.on_toggle(move |id, on| {
        let Some(window) = weak.upgrade() else { return };
        let Some((_, enabled)) = NATIVE_PLUGINS.iter().find(|(name, _)| *name == id.as_str())
        else {
            return;
        };
        let mut profile = Profile::read(&window);
        *enabled(&mut profile) = on;
        profile.enabled |= on;
        profile.show(&window);
        window.invoke_preferences_changed();
        refresh(&window);
    });
    marketplace.on_details(|id| {
        if let Some(url) = details_url(id.as_str()) {
            super::browser::open(&url);
        }
    });
    marketplace.on_upstream(|| super::browser::open("https://vesktop.dev/install/windows/"));
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vencord_marketplace_catalog_contains_all_native_equivalents() {
        assert!(!CATALOG.is_empty());
        assert!(
            CATALOG
                .windows(2)
                .all(|pair| { pair[0].name.to_lowercase() < pair[1].name.to_lowercase() })
        );
        assert!(CATALOG.iter().all(|entry| !entry.description.is_empty()));
        for (name, _) in NATIVE_PLUGINS {
            assert!(CATALOG.iter().any(|entry| entry.name == name), "{name}");
        }
        assert!(COMPANION_PLUGINS.contains("BetterGifPicker"));
    }

    #[test]
    fn vencord_marketplace_finds_a_plugin_by_name_or_description() {
        let plugin = CATALOG
            .iter()
            .find(|entry| entry.name == "ClearURLs")
            .unwrap();
        assert!(matches_query(plugin, "clearurls"));
        assert!(matches_query(plugin, "tracking"));
        assert!(!matches_query(plugin, "clearurls-extra"));
    }

    #[test]
    fn vencord_marketplace_links_only_known_plugins() {
        assert_eq!(
            details_url("WebRichPresence (arRPC)").as_deref(),
            Some("https://vencord.dev/plugins/WebRichPresence%20(arRPC)")
        );
        assert!(details_url("//example.org").is_none());
    }

    #[test]
    fn vencord_marketplace_filters_and_applies_native_preferences() {
        i_slint_backend_testing::init_no_event_loop();
        let window = YapfastWindow::new().unwrap();
        bind(&window);
        let marketplace = window.global::<VencordMarketplace>();
        marketplace.invoke_opened();
        assert_eq!(marketplace.get_rows().row_count(), CATALOG.len());

        marketplace.set_native_only(true);
        marketplace.invoke_search();
        assert_eq!(marketplace.get_rows().row_count(), NATIVE_PLUGINS.len());
        marketplace.set_query("tracking".into());
        marketplace.invoke_search();
        let rows = marketplace.get_rows();
        assert_eq!(rows.row_count(), 1);
        assert_eq!(rows.row_data(0).unwrap().name, "ClearURLs");
        assert!(!rows.row_data(0).unwrap().enabled);

        marketplace.invoke_toggle("ClearURLs".into(), true);
        assert!(Profile::read(&window).tracking(false));
        assert!(marketplace.get_rows().row_data(0).unwrap().enabled);
        marketplace.invoke_toggle("ClearURLs".into(), false);
        assert!(!Profile::read(&window).tracking(false));
    }

    #[test]
    fn vencord_marketplace_opens_from_the_sidebar_and_returns_to_friends() {
        use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
        use slint::platform::{PointerEventButton, WindowEvent};
        use std::ops::ControlFlow;

        i_slint_backend_testing::init_no_event_loop();
        let window = YapfastWindow::new().unwrap();
        bind(&window);
        window.set_workspace(true);
        window.set_dms_selected(true);
        window.set_discord_linked(true);
        let weak = window.as_weak();
        window.on_open_friends(move || weak.upgrade().unwrap().set_friends_open(true));
        window.show().unwrap();
        let native = window.window();
        native.set_size(slint::LogicalSize::new(1200., 800.));
        let inner = i_slint_core::window::WindowInner::from_pub(native);
        for label in ["Vencord Plugins", "Friends"] {
            slint::platform::update_timers_and_animations();
            let item = ItemRc::new_root(inner.component())
                .visit_descendants(|item| {
                    if item.is_visible()
                        && item
                            .accessible_string_property(AccessibleStringProperty::Label)
                            .as_deref()
                            == Some(label)
                    {
                        ControlFlow::Break(item.clone())
                    } else {
                        ControlFlow::Continue(())
                    }
                })
                .unwrap_or_else(|| panic!("sidebar entry missing: {label}"));
            let at = item.map_to_window(item.geometry().center());
            let position = slint::LogicalPosition::new(at.x, at.y);
            let button = PointerEventButton::Left;
            native.dispatch_event(WindowEvent::PointerMoved { position });
            native.dispatch_event(WindowEvent::PointerPressed { position, button });
            native.dispatch_event(WindowEvent::PointerReleased { position, button });
            slint::platform::update_timers_and_animations();
            let visible = ItemRc::new_root(inner.component())
                .visit_descendants(|item| {
                    if item.is_visible()
                        && item
                            .accessible_string_property(AccessibleStringProperty::Label)
                            .as_deref()
                            == Some("Search Vencord plugins")
                    {
                        ControlFlow::Break(())
                    } else {
                        ControlFlow::Continue(())
                    }
                })
                .is_some();
            assert_eq!(visible, label == "Vencord Plugins");
        }
        window.hide().unwrap();
    }
}
