//! Apps' commands in the window: the `/` picker over the composer, the
//! values an option may take, and the pills of the command being written.
//! What they show is the core's (`application/slash.rs`); this fills the
//! window's lists from it and binds their callbacks, and gives a message's
//! menu its "Apps" (a person's are `menus.rs`'s).

use yapfast_core::application::CommandTarget;

use super::*;

pub(super) struct PendingCommandCopy {
    account: String,
    reset_version: u64,
    room: String,
    item: String,
    interaction: Option<String>,
}

fn command_category_matches(row: &yapfast_core::application::CommandRow, category: &str) -> bool {
    category.is_empty()
        || category == "@frequent" && row.frequently_used
        || row.application_id.as_deref() == Some(category)
}

/// Presentation-only grouping; each row retains its original ranked index.
/// Searching and explicit filters keep the core's exact relevance order.
fn command_display_rows(
    rows: &[yapfast_core::application::CommandRow],
    category: &str,
    grouped: bool,
) -> Vec<(usize, String)> {
    let indices: Vec<_> = rows
        .iter()
        .enumerate()
        .filter(|(_, row)| command_category_matches(row, category))
        .map(|(index, _)| index)
        .collect();
    if !grouped {
        return indices
            .into_iter()
            .map(|index| (index, String::new()))
            .collect();
    }
    let frequent: Vec<_> = indices
        .iter()
        .copied()
        .filter(|index| rows[*index].frequently_used)
        .take(8)
        .collect();
    let mut result: Vec<_> = frequent
        .iter()
        .enumerate()
        .map(|(at, index)| {
            (
                *index,
                if at == 0 {
                    "Frequently Used".into()
                } else {
                    String::new()
                },
            )
        })
        .collect();
    let mut positions = HashMap::new();
    let mut groups = Vec::<(String, Vec<usize>)>::new();
    for index in indices {
        if frequent.contains(&index) {
            continue;
        }
        let row = &rows[index];
        let app = row.application_id.as_deref().unwrap_or_default();
        let next = groups.len();
        let group = *positions.entry(app).or_insert(next);
        if group == groups.len() {
            groups.push((
                if row.app.is_empty() {
                    "Application".into()
                } else {
                    row.app.clone()
                },
                vec![],
            ));
        }
        groups[group].1.push(index);
    }
    for (label, indices) in groups {
        for (at, index) in indices.into_iter().enumerate() {
            result.push((
                index,
                if at == 0 {
                    label.clone()
                } else {
                    String::new()
                },
            ));
        }
    }
    result
}

/// Binds the command picker's and the "Apps" submenus' callbacks, and gives
/// the window the lists `show_app_commands` fills.
pub(super) fn bind(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    let state = adapter.clone();
    window.on_normalize_command_paste(move |text| {
        state
            .borrow()
            .app
            .state
            .normalized_command_paste(&text)
            .map(SharedString::from)
            .unwrap_or(text)
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_inspect_command(move |room, item| {
        if let Some(window) = weak.upgrade() {
            let mut adapter = state.borrow_mut();
            adapter.command_details_dirty = true;
            adapter.action(
                &window,
                Action::InspectCommand {
                    room: room.to_string(),
                    item: item.to_string(),
                },
            );
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_copy_command(move |item| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        adapter.command_copy_pending = None;
        let state = &adapter.app.state;
        let (Some(account), Some(room)) = (&state.discord_user, state.room_of(&item)) else {
            return;
        };
        if !state.can_inspect_command(room, &item) {
            return;
        }
        if let Some(text) = state.command_copy_text(room, &item) {
            window.invoke_copy_text(text.into());
            return;
        }
        let room = room.clone();
        let item = item.to_string();
        adapter.command_copy_pending = Some(PendingCommandCopy {
            account: account.clone(),
            reset_version: state.reset_version,
            room: room.clone(),
            item: item.clone(),
            interaction: state
                .message(&item)
                .and_then(|message| message.interaction.clone()),
        });
        adapter.command_details_dirty = true;
        adapter.action(&window, Action::InspectCommand { room, item });
    });
    window.set_command_choices(ModelRc::new(VecModel::<CommandChoice>::default()));
    window.set_command_categories(ModelRc::new(VecModel::<CommandCategory>::default()));
    window.set_command_options(ModelRc::new(VecModel::<CommandOptionPill>::default()));
    window.set_command_before(ModelRc::new(VecModel::<CommandOptionPill>::default()));
    window.set_command_after(ModelRc::new(VecModel::<CommandOptionPill>::default()));
    window.set_app_menu_commands(ModelRc::new(VecModel::<CommandChoice>::default()));
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_select_command_category(move |category| {
        let Some(window) = weak.upgrade() else { return };
        if !window.get_command_rows_are_commands()
            || !window
                .get_command_categories()
                .iter()
                .any(|row| row.id == category)
        {
            return;
        }
        window.set_command_category(category);
        window.set_command_choice_index(0);
        state.borrow_mut().show_app_commands(&window);
        window.invoke_focus_composer();
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_toggle_favorite_command_app(move |app| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .toggle_favorite_command_app(&window, &app);
            window.invoke_focus_composer();
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_ask_app_commands(move || {
        if let Some(window) = weak.upgrade() {
            let mut adapter = state.borrow_mut();
            // A menu opening: its Apps follow the permissions as they are now.
            adapter.app_menu = None;
            window.set_app_menu_room(SharedString::default());
            adapter.action(&window, Action::AskAppCommands);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_ask_message_app_commands(move |item| {
        if let Some(window) = weak.upgrade() {
            let mut adapter = state.borrow_mut();
            let room = adapter.app.state.room_of(&item).cloned();
            window.set_app_menu_room(room.as_deref().unwrap_or_default().into());
            adapter.app_menu = None;
            adapter.action(&window, Action::AskMessageAppCommands(item.to_string()));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_slash_query(move |query| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::SlashQuery(query.to_string()));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_pick_command(move |index| {
        let Some(window) = weak.upgrade() else { return };
        let Some(choice) = usize::try_from(index)
            .ok()
            .and_then(|index| window.get_command_choices().row_data(index))
        else {
            return;
        };
        let Ok(source) = usize::try_from(choice.source_index) else {
            return;
        };
        let mut adapter = state.borrow_mut();
        // Categories only change presentation. Recheck the original ranked
        // row before dispatch so a stale menu cannot pick a different command.
        if !adapter.app.command_rows().get(source).is_some_and(|row| {
            row.name == choice.name.as_str()
                && row.application_id.as_deref().unwrap_or_default()
                    == choice.application_id.as_str()
        }) {
            adapter.show_app_commands(&window);
            return;
        }
        window.set_command_choice_index(0);
        adapter.action(&window, Action::PickCommand(source));
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_set_command_option(move |index, value| {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().action(
                &window,
                Action::SetCommandOption {
                    index: index.max(0) as usize,
                    value: value.to_string(),
                },
            );
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_focus_command_option(move |index| {
        let Some(window) = weak.upgrade() else { return };
        window.set_command_choice_index(0);
        state
            .borrow_mut()
            .action(&window, Action::FocusCommandOption(index.max(0) as usize));
        // The text is the option's now; the cursor goes to its end.
        window.invoke_place_composer_caret(1_000_000);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_deselect_command_option(move |index| {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().action(
                &window,
                Action::DeselectCommandOption(index.max(0) as usize),
            );
            window.invoke_place_composer_caret(0);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_close_command(move |back| {
        let Some(window) = weak.upgrade() else { return };
        state
            .borrow_mut()
            .action(&window, Action::CloseCommand(back));
        if back {
            window.invoke_place_composer_caret(1_000_000);
        }
    });
    // A file option's file, from the same dialog as the composer's files.
    let state = adapter.clone();
    window.on_command_file(move |index| {
        let index = index.max(0) as usize;
        let input_id = state
            .borrow()
            .app
            .state
            .command_draft()
            .map(|draft| draft.input_id());
        let weak = Rc::downgrade(&state);
        state.borrow_mut().dialog(async move {
            let file = rfd::AsyncFileDialog::new()
                .set_title("Choose a file")
                .pick_file()
                .await;
            if let (Some(file), Some(adapter)) = (file, weak.upgrade()) {
                if adapter
                    .borrow()
                    .app
                    .state
                    .command_draft()
                    .map(|draft| draft.input_id())
                    != input_id
                {
                    return;
                }
                let window = adapter.borrow().window.upgrade();
                if let Some(window) = window {
                    adapter.borrow_mut().action(
                        &window,
                        Action::SetCommandOption {
                            index,
                            value: file.path().to_string_lossy().into_owned(),
                        },
                    );
                }
            }
        });
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_run_app_command(move |command, target| {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().action(
                &window,
                Action::RunAppCommand {
                    command: command.to_string(),
                    target: (!target.is_empty()).then(|| target.to_string()),
                },
            );
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_dismiss_ephemeral(move |item| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::DismissEphemeral(item.to_string()));
        }
    });
}

impl Adapter {
    pub(super) fn show_menu_command_details(&self, window: &YapfastWindow) {
        let item = window.get_menu_command_item();
        let state = &self.app.state;
        let detail = state
            .room_of(&item)
            .and_then(|room| state.command_detail(room, &item))
            .unwrap_or(if item.is_empty() {
                ""
            } else {
                "Command options are unavailable."
            });
        if window.get_menu_command_detail() != detail {
            window.set_menu_command_detail(detail.into());
        }
    }

    pub(super) fn finish_command_copy(&mut self, window: &YapfastWindow) {
        let Some(pending) = self.command_copy_pending.take() else {
            return;
        };
        let PendingCommandCopy {
            account,
            reset_version,
            room,
            item,
            interaction,
        } = &pending;
        let state = &self.app.state;
        if !state.can_inspect_command(room, item)
            || state.discord_user.as_ref() != Some(account)
            || state.reset_version != *reset_version
            || state
                .message(item)
                .and_then(|message| message.interaction.as_ref())
                != interaction.as_ref()
        {
            return;
        }
        if let Some(text) = state.command_copy_text(room, item) {
            window.invoke_copy_text(text.into());
        } else if state.command_detail_pending(room, item) {
            self.command_copy_pending = Some(pending);
        } else {
            let notice = "Command details are unavailable for this message.";
            self.app.state.notice = Some(notice.into());
            window.set_notice(notice.into());
        }
    }

    /// Apply fetched details to existing rows without rebuilding the model.
    pub(super) fn show_command_details(&mut self) {
        if !std::mem::take(&mut self.command_details_dirty) {
            return;
        }
        fn patch(
            state: &AppState,
            room: &str,
            rows: &mut [MessageRow],
            model: &VecModel<MessageRow>,
        ) {
            for (at, row) in rows
                .iter_mut()
                .enumerate()
                .filter(|(_, row)| row.has_command)
            {
                if apply_command_details(state, room, row) {
                    model.set_row_data(at, row.clone());
                }
            }
        }
        let state = &self.app.state;
        if let Some(room) = state.selected.as_deref() {
            patch(state, room, &mut self.rows, &self.models.messages);
        }
        if let Some(aside) = &state.aside {
            patch(
                state,
                &aside.room,
                &mut self.aside_rows,
                &self.models.aside_messages,
            );
        }
    }

    /// Gives a message's menu its own visible room's message commands for its
    /// "Apps", and says when the room's index came, so a person's menu open
    /// meanwhile is built again with theirs. Returns the app icons it lacks.
    /// The rows are built again only when the room or its index changed, a
    /// menu opened, or an icon they lacked came, not on every refresh.
    fn show_app_menu_commands(&mut self, window: &YapfastWindow) -> Vec<String> {
        let state = &self.app.state;
        // A person's menu still follows the selected channel; message menus
        // may be for the thread beside it, even while its composer is idle.
        window.set_app_commands_ready(
            state
                .selected
                .as_deref()
                .is_some_and(|room| state.app_commands.index(room).is_some()),
        );
        let menu_room = window.get_app_menu_room();
        let room = if menu_room.is_empty() {
            state.selected.as_deref()
        } else {
            state.shows_room(&menu_room).then_some(menu_room.as_str())
        };
        let index = room.and_then(|room| Some((room, state.app_commands.index(room)?)));
        let key = index.map(|(room, index)| (room, Arc::as_ptr(index) as usize));
        if let (Some((room, index)), Some((built, built_index, lacking))) = (key, &self.app_menu)
            && built == room
            && *built_index == index
            && !lacking.iter().any(|icon| state.pictures.contains_key(icon))
        {
            return vec![];
        }
        let Some((room, address)) = key.map(|(room, index)| (room.to_owned(), index)) else {
            self.app_menu = None;
            // A menu opening invalidates the build key before asking. Its
            // prior room's rows must still clear while this index loads.
            let model = window.get_app_menu_commands();
            if let Some(model) = model.as_any().downcast_ref::<VecModel<CommandChoice>>() {
                update_model(model, vec![]);
            }
            return vec![];
        };
        let commands = self.app.commands_for_target(&room, CommandTarget::Message);
        let state = &self.app.state;
        let wanted: Vec<String> = commands
            .iter()
            .filter_map(|command| command.app_icon.clone())
            .filter(|icon| !state.pictures.contains_key(icon))
            .collect();
        self.app_menu = Some((room, address, wanted.clone()));
        let rows: Vec<CommandChoice> = commands
            .iter()
            .map(|command| CommandChoice {
                id: command.command.as_str().into(),
                app: command.app_name.as_str().into(),
                icon: cached_picture(&mut self.pictures, state, command.app_icon.as_deref()),
                name: command.name.as_str().into(),
                description: SharedString::default(),
                ..Default::default()
            })
            .collect();
        let model = window.get_app_menu_commands();
        if let Some(model) = model.as_any().downcast_ref::<VecModel<CommandChoice>>() {
            update_model(model, rows);
        }
        wanted
    }

    /// Fills the list over the composer and the command's pills from the
    /// core's state, asking for the app icons and avatars it lacks.
    pub(super) fn show_app_commands(&mut self, window: &YapfastWindow) {
        let rows = self.app.command_rows();
        let mut heading = self.app.command_heading(&rows);
        let state = &self.app.state;
        let browsing = state.command_draft().is_none() && state.slash_query().is_some();
        let scope = format!(
            "{}|{}|{}",
            state.discord_user.as_deref().unwrap_or_default(),
            state.reset_version,
            state.selected.as_deref().unwrap_or_default()
        );
        if window.get_command_category_scope() != scope.as_str() || !browsing {
            window.set_command_category(SharedString::default());
            window.set_command_category_scope(scope.into());
            window.set_command_choice_index(0);
        }
        let mut categories = Vec::new();
        if browsing {
            categories.push(CommandCategory {
                id: "".into(),
                label: "All Commands".into(),
                count: rows.len() as i32,
                ..Default::default()
            });
            categories.push(CommandCategory {
                id: "@frequent".into(),
                label: "Frequently Used".into(),
                kind: 1,
                count: rows.iter().filter(|row| row.frequently_used).count() as i32,
                ..Default::default()
            });
            // Keep the permitted app rail stable while typing, but never expose
            // applications from another room/account or fetch a separate index.
            let catalog = state
                .selected
                .as_deref()
                .map(|room| self.app.slash_commands(room, ""))
                .unwrap_or_default();
            for command in catalog {
                if categories
                    .iter()
                    .any(|category| category.id == command.app.as_str())
                {
                    continue;
                }
                if categories.len() == 66 {
                    break;
                }
                let label = if command.app_name.is_empty() {
                    "Application"
                } else {
                    &command.app_name
                };
                categories.push(CommandCategory {
                    id: command.app.as_str().into(),
                    label: label.into(),
                    initial: label.chars().next().unwrap_or('/').to_string().into(),
                    kind: 2,
                    icon: cached_picture(&mut self.pictures, state, command.app_icon.as_deref()),
                    count: rows
                        .iter()
                        .filter(|row| row.application_id.as_deref() == Some(command.app.as_str()))
                        .count() as i32,
                });
            }
            if !categories
                .iter()
                .any(|category| category.id == window.get_command_category())
            {
                window.set_command_category(SharedString::default());
            }
        }
        let category = window.get_command_category();
        if browsing && !category.is_empty() {
            if let Some(selected) = categories.iter().find(|row| row.id == category) {
                heading = selected.label.to_string();
            }
        }
        if let Some(model) = window
            .get_command_categories()
            .as_any()
            .downcast_ref::<VecModel<CommandCategory>>()
        {
            update_model(model, categories);
        }
        let mut wanted: Vec<String> = rows
            .iter()
            .filter_map(|row| row.icon.clone())
            .filter(|icon| !state.pictures.contains_key(icon))
            .collect();
        let grouped = browsing
            && category.is_empty()
            && state
                .slash_query()
                .is_some_and(|query| query.trim().is_empty());
        let mut sections_before = 0;
        let choices: Vec<CommandChoice> = command_display_rows(&rows, &category, grouped)
            .into_iter()
            .map(|(index, section)| {
                let row = &rows[index];
                let before = sections_before;
                sections_before += i32::from(!section.is_empty());
                CommandChoice {
                    source_index: index as i32,
                    section: section.into(),
                    sections_before: before,
                    id: SharedString::default(),
                    app: row.app.as_str().into(),
                    icon: cached_picture(&mut self.pictures, state, row.icon.as_deref()),
                    name: row.name.as_str().into(),
                    description: row.description.as_str().into(),
                    application_id: row.application_id.as_deref().unwrap_or_default().into(),
                    favorite_app: row
                        .application_id
                        .as_ref()
                        .is_some_and(|id| state.favorite_command_apps().contains(id)),
                }
            })
            .collect();
        let command = state.command_draft();
        let pills: Vec<CommandOptionPill> = command
            .map(|command| {
                command
                    .options
                    .iter()
                    .zip(state.option_errors(command))
                    .map(|(option, error)| CommandOptionPill {
                        name: option.name.as_str().into(),
                        description: option.description.as_str().into(),
                        value: option.shown().into(),
                        required: option.required,
                        error: error.unwrap_or_default().into(),
                        file: option.is_attachment(),
                    })
                    .collect()
            })
            .unwrap_or_default();
        window.set_command_name(command.map_or_else(SharedString::default, |command| {
            command.name.as_str().into()
        }));
        window.set_command_focus(command.map_or(0, |command| command.focused as i32));
        window.set_command_text_bytes(
            command
                .and_then(|command| command.options.get(command.focused))
                .map_or(0, |option| option.text.len().min(i32::MAX as usize) as i32),
        );
        window.set_command_other_values(command.is_some_and(|command| {
            command.options.iter().skip(1).any(|option| {
                !option.text.is_empty() || option.is_attachment() && !option.shown().is_empty()
            })
        }));
        window.set_command_rows_are_commands(command.is_none());
        // The picker shows while `/` is typed, even with nothing to list
        // yet; an option's values only when there are some.
        window.set_command_picker_open(if command.is_some() {
            !choices.is_empty()
        } else {
            !heading.is_empty()
        });
        window.set_command_heading(heading.into());
        if window.get_command_choice_index() >= choices.len() as i32 {
            window.set_command_choice_index(0);
        }
        // The window holds the models `bind` gave it.
        let rows = window.get_command_choices();
        if let Some(model) = rows.as_any().downcast_ref::<VecModel<CommandChoice>>() {
            update_model(model, choices);
        }
        let rows = window.get_command_options();
        let focused = command.map_or(0, |command| command.focused);
        for (model, values) in [
            (
                window.get_command_before(),
                pills.iter().take(focused).cloned().collect(),
            ),
            (
                window.get_command_after(),
                pills
                    .iter()
                    .skip(focused.saturating_add(1))
                    .cloned()
                    .collect(),
            ),
        ] {
            if let Some(model) = model.as_any().downcast_ref::<VecModel<CommandOptionPill>>() {
                update_model(model, values);
            }
        }
        if let Some(model) = rows.as_any().downcast_ref::<VecModel<CommandOptionPill>>() {
            update_model(model, pills);
        }
        wanted.extend(self.show_app_menu_commands(window));
        // Asked once each, and shown as they come; nothing to refresh now.
        if !wanted.is_empty() {
            let effects = self.app.dispatch(Action::LoadPictures(wanted));
            self.execute(effects);
        }
    }
}

/// Fetched details are presentation-only, never put into persisted messages.
pub(super) fn command_details_row(state: &AppState, room: &str, mut row: MessageRow) -> MessageRow {
    apply_command_details(state, room, &mut row);
    row
}

fn apply_command_details(state: &AppState, room: &str, row: &mut MessageRow) -> bool {
    if !row.has_command {
        return false;
    }
    let name = if row.command_inspectable && row.command_slash.is_empty() {
        state
            .command_verified_name(room, &row.item)
            .or_else(|| Some(state.message(&row.item)?.used.as_ref()?.name.as_str()))
            .unwrap_or(&row.command_name)
    } else {
        row.command_name.as_str()
    };
    let detail = state.command_detail(room, &row.item).unwrap_or(name);
    if row.command_name == name && row.command_detail == detail {
        return false;
    }
    let name = SharedString::from(name);
    row.command_detail = detail.into();
    row.command_name = name;
    true
}

#[cfg(all(test, feature = "discord"))]
mod category_tests {
    use super::*;
    use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
    use std::ops::ControlFlow;
    use yapfast_core::{
        application::CommandHistory,
        chat::CommandIndex,
        yapfast_discord::{
            marked::MarkedServer,
            ready::{Channel, Server},
            service::{Snapshot, Status},
        },
    };

    #[test]
    fn command_categories_group_without_duplicates_or_reordering_search() {
        let rows = (0..12)
            .map(|index| yapfast_core::application::CommandRow {
                application_id: Some(if index % 2 == 0 { "500" } else { "600" }.into()),
                app: if index % 2 == 0 { "Alpha" } else { "Beta" }.into(),
                icon: None,
                name: format!("command{index}"),
                description: String::new(),
                frequently_used: index == 3,
            })
            .collect::<Vec<_>>();
        let grouped = command_display_rows(&rows, "", true);
        assert_eq!(grouped[0], (3, "Frequently Used".into()));
        assert_eq!(
            grouped
                .iter()
                .filter(|(_, section)| !section.is_empty())
                .map(|(_, section)| section.as_str())
                .collect::<Vec<_>>(),
            ["Frequently Used", "Alpha", "Beta"]
        );
        let unique: HashSet<_> = grouped.iter().map(|(index, _)| *index).collect();
        assert_eq!(unique.len(), rows.len());
        assert_eq!(grouped.len(), rows.len());
        assert_eq!(
            command_display_rows(&rows, "", false)
                .iter()
                .map(|(index, _)| *index)
                .collect::<Vec<_>>(),
            (0..12).collect::<Vec<_>>()
        );
        assert!(
            command_display_rows(&rows, "500", false)
                .iter()
                .all(|(index, section)| index % 2 == 0 && section.is_empty())
        );
        let used: Vec<_> = rows
            .into_iter()
            .map(|mut row| {
                row.frequently_used = true;
                row
            })
            .collect();
        let bounded = command_display_rows(&used, "", true);
        assert_eq!(
            bounded
                .iter()
                .skip(1)
                .position(|(_, section)| !section.is_empty()),
            Some(7),
            "Frequently Used is bounded to eight rows; remaining commands stay in app groups"
        );
        assert_eq!(bounded.len(), 12);
    }

    fn named(window: &YapfastWindow, label: &str) -> ItemRc {
        let inner = i_slint_core::window::WindowInner::from_pub(window.window());
        ItemRc::new_root(inner.component())
            .visit_descendants(|item| {
                if item.is_visible()
                    && item
                        .accessible_string_property(AccessibleStringProperty::Label)
                        .as_deref()
                        == Some(label)
                {
                    ControlFlow::Break(item.clone())
                } else {
                    ControlFlow::Continue(())
                }
            })
            .unwrap_or_else(|| panic!("missing category {label}"))
    }

    fn settle(window: &YapfastWindow) {
        for _ in 0..3 {
            window.window().take_snapshot().unwrap();
            i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(100));
            slint::platform::update_timers_and_animations();
        }
    }

    #[test]
    fn command_categories_preserve_usage_search_indices_and_account_scope() {
        slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
            i_slint_backend_testing::TestingBackendOptions {
                mock_time: true,
                threading: false,
                renderer_name: Some("skia".into()),
            },
        )))
        .unwrap();
        let directory = tempfile::tempdir().unwrap();
        let window = yapfast::window().unwrap();
        let adapter = Adapter::new(
            Arc::new(BackgroundRuntime::new().unwrap()),
            directory.path().into(),
            &window,
        )
        .unwrap();
        bind_callbacks(&window, &adapter);
        window.global::<PictureStore>().on_request(|_| {});
        window.global::<ClientStyle>().set_interface_motion(false);
        {
            let mut adapter = adapter.borrow_mut();
            adapter.app.apply(Event::Discord(Arc::new(Snapshot {
                status: Status::Online,
                user_id: Some("1".into()),
                servers: vec![MarkedServer::from(Server {
                    id: "10".into(),
                    name: "Category fixture".into(),
                    owner_id: Some("1".into()),
                    text_channels: vec![Channel {
                        id: "21".into(),
                        name: "commands".into(),
                        ..Default::default()
                    }],
                    ..Default::default()
                })],
                ..Default::default()
            })));
            adapter
                .app
                .dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
            adapter
                .app
                .dispatch(Action::SelectRoom("discord:10:21".into()));
            adapter.app.apply(Event::Timeline {
                room: "discord:10:21".into(),
                messages: vec![],
            });
            adapter.sync_command_history();
            adapter.app.state.set_command_history(serde_json::from_value::<CommandHistory>(serde_json::json!({"entries":[{"app":"500","command":"501","path":[],"count":4}]})).unwrap());
            adapter
                .app
                .state
                .set_favorite_command_apps(vec!["600".into()]);
            adapter.app.dispatch(Action::SetDraft("/".into()));
            adapter.app.apply(Event::CommandIndex { room: "discord:10:21".into(), index: Ok(Arc::new(CommandIndex::parse(&serde_json::json!({
                "applications":[{"id":"500","name":"Alpha bot"},{"id":"600","name":"Beta bot"}],
                "application_commands":[
                    {"id":"501","application_id":"500","version":"1","type":1,"name":"alpha","description":"First alpha action","default_member_permissions":null},
                    {"id":"502","application_id":"500","version":"1","type":1,"name":"apple","description":"Second alpha action","default_member_permissions":null},
                    {"id":"601","application_id":"600","version":"1","type":1,"name":"beta","description":"First beta action","default_member_permissions":null},
                    {"id":"602","application_id":"600","version":"1","type":1,"name":"bravo","description":"Second beta action","default_member_permissions":null}
                ]
            }), false))) });
            adapter.show_app_commands(&window);
        }
        window.set_workspace(true);
        window.set_trusted(true);
        window.set_room_selected(true);
        window.set_room_ready(true);
        window.set_composer_enabled(true);
        window.show().unwrap();
        for (width, height) in [(800., 600.), (1120., 760.)] {
            window
                .window()
                .set_size(slint::LogicalSize::new(width, height));
            settle(&window);
            assert_eq!(
                window
                    .get_command_choices()
                    .iter()
                    .filter(|row| !row.section.is_empty())
                    .map(|row| row.section.to_string())
                    .collect::<Vec<_>>(),
                ["Frequently Used", "Beta bot", "Alpha bot"]
            );
            assert_eq!(
                window
                    .get_command_choices()
                    .iter()
                    .map(|row| row.sections_before)
                    .collect::<Vec<_>>(),
                [0, 1, 2, 2]
            );
            let panel = named(&window, "Application commands");
            let bounds = panel.geometry();
            let at = panel.map_to_window(bounds.origin);
            for label in ["All Commands", "Frequently Used", "Alpha bot", "Beta bot"] {
                let item = named(&window, label);
                let rect = item.geometry();
                let point = item.map_to_window(rect.origin);
                assert!(
                    point.x >= at.x && point.x + rect.width() <= at.x + bounds.width(),
                    "{label} fits at {width}"
                );
                assert!(
                    point.y >= at.y && point.y + rect.height() <= at.y + bounds.height(),
                    "{label} fits vertically"
                );
            }
            window.set_command_choice_index(3);
            settle(&window);
            let last = named(&window, "/apple, Alpha bot, Second alpha action");
            let last_at = last.map_to_window(last.geometry().origin);
            assert!(
                last_at.y >= at.y && last_at.y + last.geometry().height() <= at.y + bounds.height(),
                "keyboard reveal accounts for section heights"
            );
            window.set_command_choice_index(0);
            settle(&window);
            for choice in window
                .get_command_choices()
                .iter()
                .filter(|row| !row.section.is_empty())
            {
                let heading = named(&window, &format!("Section {}", choice.section));
                let command = named(
                    &window,
                    &format!("/{}, {}, {}", choice.name, choice.app, choice.description),
                );
                let heading_at = heading.map_to_window(heading.geometry().origin);
                let command_at = command.map_to_window(command.geometry().origin);
                assert!(
                    heading_at.y + heading.geometry().height() <= command_at.y + 0.5,
                    "{} heading overlaps /{}: heading {}+{}, command {}",
                    choice.section,
                    choice.name,
                    heading_at.y,
                    heading.geometry().height(),
                    command_at.y,
                );
                assert!(
                    (command_at.y - heading_at.y - 24.).abs() <= 0.5,
                    "section owns its reserved header space"
                );
                assert!(
                    heading_at.y >= at.y + 28.,
                    "section heading is visible below the picker title"
                );
            }
            if let Some(output) = std::env::var_os("SC_REVIEW_DIR") {
                let output = std::path::PathBuf::from(output);
                std::fs::create_dir_all(&output).unwrap();
                let frame = window.window().take_snapshot().unwrap();
                image::save_buffer(
                    output.join(format!("command-groups-{width}x{height}.png")),
                    frame.as_bytes(),
                    frame.width(),
                    frame.height(),
                    image::ColorType::Rgba8,
                )
                .unwrap();
            }
            named(&window, "Frequently Used")
                .accessible_action(&i_slint_core::accessibility::AccessibilityAction::Default);
            assert_eq!(window.get_command_choices().row_count(), 1);
            let choice = window.get_command_choices().row_data(0).unwrap();
            assert_eq!(choice.name, "alpha");
            assert!(
                choice.source_index > 0,
                "favorite app comes first in unfiltered ranked source"
            );
            window.invoke_select_command_category("600".into());
            assert_eq!(window.get_command_choices().row_count(), 2);
            assert!(
                window
                    .get_command_choices()
                    .iter()
                    .all(|row| row.application_id == "600" && row.favorite_app)
            );
            for (key, expected) in [
                (slint::platform::Key::DownArrow, 1),
                (slint::platform::Key::UpArrow, 0),
            ] {
                let text: SharedString = key.into();
                window
                    .window()
                    .dispatch_event(slint::platform::WindowEvent::KeyPressed {
                        text: text.clone(),
                    });
                window
                    .window()
                    .dispatch_event(slint::platform::WindowEvent::KeyReleased { text });
                assert_eq!(
                    window.get_command_choice_index(),
                    expected,
                    "arrows navigate the filtered vector"
                );
            }
            settle(&window);
            if let Some(output) = std::env::var_os("SC_REVIEW_DIR") {
                let output = std::path::PathBuf::from(output);
                std::fs::create_dir_all(&output).unwrap();
                let frame = window.window().take_snapshot().unwrap();
                image::save_buffer(
                    output.join(format!("command-categories-{width}x{height}.png")),
                    frame.as_bytes(),
                    frame.width(),
                    frame.height(),
                    image::ColorType::Rgba8,
                )
                .unwrap();
            }
            window.invoke_select_command_category("".into());
        }
        window.invoke_select_command_category("500".into());
        adapter
            .borrow_mut()
            .app
            .dispatch(Action::SetDraft("/apple".into()));
        adapter.borrow_mut().show_app_commands(&window);
        assert_eq!(window.get_command_choices().row_count(), 1);
        assert_eq!(
            window.get_command_choices().row_data(0).unwrap().name,
            "apple"
        );
        assert!(
            window
                .get_command_choices()
                .row_data(0)
                .unwrap()
                .section
                .is_empty(),
            "typed searches preserve the original ranked list"
        );
        window.invoke_select_command_category("600".into());
        assert_eq!(
            window.get_command_choices().row_count(),
            0,
            "search remains inside the selected app"
        );
        window.invoke_select_command_category("500".into());
        window.invoke_pick_command(0);
        assert_eq!(
            adapter.borrow().app.state.command_draft().unwrap().name,
            "apple"
        );
        assert_eq!(
            window.get_command_category(),
            "",
            "option suggestions are never app-filtered"
        );
        adapter
            .borrow_mut()
            .app
            .dispatch(Action::CloseCommand(false));
        adapter
            .borrow_mut()
            .app
            .dispatch(Action::SetDraft("/".into()));
        adapter.borrow_mut().show_app_commands(&window);
        window.invoke_select_command_category("@frequent".into());
        {
            let mut adapter = adapter.borrow_mut();
            adapter.app.state.discord_user = Some("2".into());
            adapter
                .app
                .state
                .set_command_history(CommandHistory::default());
            adapter.show_app_commands(&window);
        }
        assert_eq!(
            window.get_command_category(),
            "",
            "account switch clears ephemeral category"
        );
        window.invoke_select_command_category("@frequent".into());
        assert_eq!(
            window.get_command_choices().row_count(),
            0,
            "new account has no inherited usage"
        );
        window.hide().unwrap();
    }
}
