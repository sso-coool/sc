//! One detachable native viewer. Frames are shared with the call, never decoded twice.
use super::*;

slint::slint! {
    #[edition = "1.19"]
    import { CheckBox, Button, Palette } from "std-widgets.slint";
    export component CallVideoWindow inherits Window {
        in property <string> person-name;
        in property <string> source-name;
        in property <image> frame;
        in property <bool> has-frame;
        in property <color> surface: #242632;
        in property <color> ink: #f6f5f0;
        in property <bool> dark: true;
        in-out property <bool> pinned: false;
        // This viewer alone defaults to stretching the complete frame.
        in-out property <bool> preserve-ratio: false;
        out property <length> video-width: viewport.width;
        out property <length> video-height: viewport.height;
        callback close-view;
        title: "S;C — " + root.person-name;
        preferred-width: 640px; preferred-height: 420px;
        min-width: 340px; min-height: 240px;
        no-frame: false;
        always-on-top: root.pinned;
        background: root.surface;
        default-font-family: "Segoe UI";
        default-font-size: 13px;
        function set-colors() { Palette.color-scheme = root.dark ? ColorScheme.dark : ColorScheme.light; }
        init => { root.set-colors(); }
        changed dark => { root.set-colors(); }
        FocusScope {
            width: root.width; height: root.height;
            init => { self.focus(); }
            key-pressed(event) => {
                if event.text == Key.Escape { root.close-view(); return accept; }
                return reject;
            }
            VerticalLayout {
                spacing: 0px; min-width: 0px; min-height: 0px;
                VerticalLayout {
                    height: 80px; padding-left: 12px; padding-right: 10px;
                    padding-top: 8px; padding-bottom: 8px; spacing: 0px;
                    HorizontalLayout {
                        spacing: 12px;
                        Text { text: root.source-name; color: root.ink; overflow: elide; horizontal-stretch: 1; min-width: 0px; }
                        Button { text: "Close pop-out"; clicked => { root.close-view(); } }
                    }
                    HorizontalLayout {
                        spacing: 12px; alignment: start;
                        CheckBox { text: "Preserve ratio"; checked <=> root.preserve-ratio; }
                        CheckBox { text: "Always on top"; checked <=> root.pinned; }
                    }
                }
                viewport := Rectangle {
                    min-width: 0px; min-height: 0px; vertical-stretch: 1;
                    background: #08090b;
                    clip: true;
                    Image {
                        width: parent.width; height: parent.height;
                        source: root.frame;
                        image-fit: root.preserve-ratio ? contain : fill;
                        horizontal-alignment: center; vertical-alignment: center;
                    }
                    if !root.has-frame: Text {
                        text: "Waiting for video…"; color: #c4c1cf;
                        horizontal-alignment: center; vertical-alignment: center;
                    }
                }
            }
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum Source {
    Camera { person: String, participant: String },
    Watched { participant: String },
}

pub(super) struct Open {
    room: String,
    account: (Option<String>, Option<String>),
    source: Source,
    window: CallVideoWindow,
    _clock: slint::Timer,
}

impl Drop for Open {
    fn drop(&mut self) {
        self._clock.stop();
        self.window.set_frame(slint::Image::default());
        let _ = self.window.hide();
    }
}

fn source(adapter: &Adapter, user: &str) -> Option<(Source, String)> {
    let voice = &adapter.app.state.voice;
    if !voice.active() || voice.room.is_none() {
        return None;
    }
    let person = voice
        .participants
        .iter()
        .find(|person| person.person == user)?;
    if person.video.is_some() && !adapter.call_video_disabled(&person.id) {
        return Some((
            Source::Camera {
                person: user.into(),
                participant: person.id.clone(),
            },
            person.user.clone(),
        ));
    }
    let watched = voice
        .watching
        .as_ref()
        .filter(|watched| watched.user == person.id)?;
    Some((
        Source::Watched {
            participant: watched.user.clone(),
        },
        watched.name.clone(),
    ))
}

fn valid(adapter: &Adapter, open: &Open) -> bool {
    let state = &adapter.app.state;
    if open.account.0 != state.account
        || open.account.1 != state.discord_user
        || state.voice.room.as_deref() != Some(open.room.as_str())
        || !state.voice.active()
    {
        return false;
    }
    match &open.source {
        Source::Camera {
            person,
            participant,
        } => state.voice.participants.iter().any(|known| {
            known.person == *person
                && known.id == *participant
                && known.video.is_some()
                && !adapter.call_video_disabled(participant)
        }),
        Source::Watched { participant } => {
            state
                .voice
                .watching
                .as_ref()
                .is_some_and(|watched| watched.user == *participant)
                && state
                    .voice
                    .participants
                    .iter()
                    .any(|known| known.id == *participant)
        }
    }
}

impl Adapter {
    pub(super) fn can_pop_out_call_video(&self, user: &str) -> bool {
        source(self, user).is_some()
    }

    pub(super) fn pop_out_call_video(&mut self, main: &YapfastWindow, user: &str) {
        let Some((source, name)) = source(self, user) else {
            return;
        };
        self.close_call_video_popout(main);
        let created = title_bar::with_system_frame(|| {
            let window = CallVideoWindow::new()?;
            // Force the adapter to be made while the native-frame override is active.
            let _ = window.window();
            Ok::<_, slint::PlatformError>(window)
        });
        let window = match created {
            Ok(window) => window,
            Err(error) => {
                tracing::warn!(%error, "could not create the video pop-out");
                return;
            }
        };
        window.set_person_name(name.into());
        window.set_source_name(
            match &source {
                Source::Camera { .. } => "Camera",
                Source::Watched { .. } => "Screen share",
            }
            .into(),
        );
        window.set_surface(main.global::<Theme>().get_raised());
        window.set_ink(main.global::<Theme>().get_text());
        window.set_dark(main.global::<Theme>().get_dark());
        let first = match &source {
            Source::Camera { participant, .. } => self
                .stage_people
                .iter()
                .position(|&raw| {
                    self.app
                        .state
                        .voice
                        .participants
                        .get(raw)
                        .is_some_and(|person| person.id == *participant)
                })
                .and_then(|index| self.models.participant_frames.row_data(index))
                .unwrap_or_default(),
            Source::Watched { participant } => {
                if self.watched.as_deref() == Some(participant.as_str())
                    && self
                        .app
                        .state
                        .voice
                        .watching
                        .as_ref()
                        .is_some_and(|watched| !watched.opening)
                {
                    main.get_watch_frame()
                } else {
                    slint::Image::default()
                }
            }
        };
        window.set_has_frame(first.size().width > 0);
        window.set_frame(first);
        let weak = self.weak.clone();
        window.on_close_view(move || {
            if let Some(adapter) = weak.upgrade() {
                let adapter = adapter.borrow();
                if let Some(main) = adapter.window.upgrade() {
                    adapter.close_call_video_popout(&main);
                }
            }
        });
        let weak = self.weak.clone();
        window.window().on_close_requested(move || {
            if let Some(adapter) = weak.upgrade() {
                let adapter = adapter.borrow();
                if let Some(main) = adapter.window.upgrade() {
                    adapter.close_call_video_popout(&main);
                }
            }
            slint::CloseRequestResponse::HideWindow
        });
        let clock = slint::Timer::default();
        let weak = self.weak.clone();
        clock.start(
            slint::TimerMode::Repeated,
            Duration::from_millis(33),
            move || {
                let Some(adapter) = weak.upgrade() else {
                    return;
                };
                let main = {
                    let adapter = adapter.borrow();
                    let Some(main) = adapter.window.upgrade() else {
                        return;
                    };
                    adapter.sync_call_video_popout(&main);
                    main
                };
                // This replaces the main window's frame timer while open, including
                // when that window is in the tray. Feed::take still runs only once.
                main.invoke_stream_tick();
            },
        );
        if let Err(error) = window.show() {
            clock.stop();
            tracing::warn!(%error, "could not show the video pop-out");
            return;
        }
        *self.call_video_popout.borrow_mut() = Some(Open {
            room: self.app.state.voice.room.clone().unwrap(),
            account: (
                self.app.state.account.clone(),
                self.app.state.discord_user.clone(),
            ),
            source,
            window,
            _clock: clock,
        });
        main.set_video_popout_open(true);
    }

    pub(super) fn close_call_video_popout(&self, main: &YapfastWindow) {
        // Dropping one Open releases its sole extra image/window/clock.
        self.call_video_popout.borrow_mut().take();
        main.set_video_popout_open(false);
    }

    pub(super) fn sync_call_video_popout(&self, main: &YapfastWindow) {
        let stale = self
            .call_video_popout
            .borrow()
            .as_ref()
            .is_some_and(|open| !valid(self, open));
        if stale {
            self.close_call_video_popout(main);
        }
    }

    /// Extra visible size for the same camera feed; never a new feed/decoder.
    pub(super) fn detached_video_size(&self, participant: &str) -> Option<(u32, u32)> {
        let guard = self.call_video_popout.borrow();
        let open = guard.as_ref()?;
        if !valid(self, open)
            || !matches!(&open.source, Source::Camera { participant: found, .. } if found == participant)
            || !open.window.window().is_visible()
            || open.window.window().is_minimized()
        {
            return None;
        }
        let scale = open.window.window().scale_factor();
        Some((
            ((open.window.get_video_width() * scale).round() as u32).clamp(1, 1920),
            ((open.window.get_video_height() * scale).round() as u32).clamp(1, 1080),
        ))
    }

    pub(super) fn publish_detached_camera(&self, participant: &str, frame: &slint::Image) {
        let guard = self.call_video_popout.borrow();
        if let Some(open) = guard.as_ref().filter(|open| valid(self, open)
            && matches!(&open.source, Source::Camera { participant: found, .. } if found == participant)) {
            open.window.set_frame(frame.clone());
            open.window.set_has_frame(true);
        }
    }

    pub(super) fn publish_detached_stream(&self, participant: &str, frame: &slint::Image) {
        let guard = self.call_video_popout.borrow();
        if let Some(open) = guard.as_ref().filter(|open| valid(self, open)
            && matches!(&open.source, Source::Watched { participant: found } if found == participant)) {
            open.window.set_frame(frame.clone());
            open.window.set_has_frame(true);
        }
    }
}

/// A single decode must satisfy both visible presentations, with a bounded pop-out request.
pub(super) fn joined_size(
    tile: Option<(u32, u32)>,
    detached: Option<(u32, u32)>,
) -> Option<(u32, u32)> {
    match (tile, detached) {
        (Some((tw, th)), Some((dw, dh))) => Some((tw.max(dw), th.max(dh))),
        (some, None) | (None, some) => some,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn frame(value: u8) -> slint::Image {
        slint::Image::from_rgba8(slint::SharedPixelBuffer::clone_from_slice(
            &[value; 16],
            2,
            2,
        ))
    }

    fn fixture() -> (tempfile::TempDir, YapfastWindow, Rc<RefCell<Adapter>>) {
        i_slint_backend_testing::init_no_event_loop();
        let directory = tempfile::tempdir().unwrap();
        let window = YapfastWindow::new().unwrap();
        let adapter = Adapter::new(
            Arc::new(BackgroundRuntime::new().unwrap()),
            directory.path().into(),
            &window,
        )
        .unwrap();
        {
            let mut adapter = adapter.borrow_mut();
            adapter.app.state.discord_user = Some("1".into());
            adapter.app.state.voice.phase = voice::Phase::Connected;
            adapter.app.state.voice.room = Some("discord:@me:30".into());
            adapter.app.state.voice.participants = vec![voice::Participant {
                id: "2718281".into(),
                person: "2718281".into(),
                user: "Annie".into(),
                local: false,
                muted: false,
                deafened: false,
                server_muted: false,
                server_deafened: false,
                speaking: false,
                connected: true,
                problem: None,
                streaming: false,
                video: Some(yapfast_core::picture::Feed::new()),
                avatar: None,
            }];
            adapter.stage_people = vec![0];
            while adapter.models.participant_frames.row_count() > 0 {
                adapter.models.participant_frames.remove(0);
            }
            adapter.models.participant_frames.push(frame(32));
        }
        (directory, window, adapter)
    }

    #[test]
    fn detached_video_reuses_frames_and_replaces_the_single_window() {
        let (_directory, main, adapter) = fixture();
        assert!(!adapter.borrow().can_pop_out_call_video("unknown"));
        adapter.borrow_mut().pop_out_call_video(&main, "2718281");
        assert!(main.get_video_popout_open());
        let first = adapter
            .borrow()
            .call_video_popout
            .borrow()
            .as_ref()
            .unwrap()
            .window
            .as_weak();
        assert_eq!(
            first.unwrap().get_frame().to_rgba8().unwrap().as_bytes(),
            &[32; 16]
        );
        let newest = frame(96);
        adapter.borrow().publish_detached_camera("other", &newest);
        assert_eq!(
            first.unwrap().get_frame().to_rgba8().unwrap().as_bytes(),
            &[32; 16]
        );
        adapter.borrow().publish_detached_camera("2718281", &newest);
        assert_eq!(
            first.unwrap().get_frame().to_rgba8().unwrap().as_bytes(),
            &[96; 16]
        );
        let size = adapter.borrow().detached_video_size("2718281").unwrap();
        assert!(size.0 <= 1920 && size.1 <= 1080);
        assert_eq!(
            joined_size(Some((800, 450)), Some((1280, 720))),
            Some((1280, 720))
        );
        adapter.borrow_mut().pop_out_call_video(&main, "2718281");
        assert!(
            first
                .upgrade()
                .is_none_or(|window| !window.window().is_visible())
        );
        let second = adapter
            .borrow()
            .call_video_popout
            .borrow()
            .as_ref()
            .unwrap()
            .window
            .as_weak();
        second.unwrap().set_pinned(true);
        assert!(second.unwrap().get_pinned());
        second.unwrap().invoke_close_view();
        assert!(adapter.borrow().call_video_popout.borrow().is_none());
        assert!(!main.get_video_popout_open());
    }

    #[test]
    fn detached_video_rejects_stale_accounts_and_watches_only_existing_streams() {
        let (_directory, main, adapter) = fixture();
        adapter.borrow_mut().pop_out_call_video(&main, "2718281");
        adapter.borrow_mut().app.state.discord_user = Some("2".into());
        adapter.borrow().sync_call_video_popout(&main);
        assert!(!main.get_video_popout_open());
        {
            let mut adapter = adapter.borrow_mut();
            adapter.app.state.voice.participants[0].video = None;
            assert!(!adapter.can_pop_out_call_video("2718281"));
            adapter.app.state.voice.watching = Some(Box::new(voice::Watching {
                user: "2718281".into(),
                name: "Annie's screen".into(),
                opening: false,
                frames: None,
                viewers: vec![],
            }));
            adapter.watched = Some("2718281".into());
        }
        main.set_watch_frame(frame(64));
        adapter.borrow_mut().pop_out_call_video(&main, "2718281");
        let popup = adapter
            .borrow()
            .call_video_popout
            .borrow()
            .as_ref()
            .unwrap()
            .window
            .as_weak();
        assert_eq!(popup.unwrap().get_source_name(), "Screen share");
        assert_eq!(
            popup.unwrap().get_frame().to_rgba8().unwrap().as_bytes(),
            &[64; 16]
        );
        assert_eq!(adapter.borrow().detached_video_size("2718281"), None);
        adapter
            .borrow()
            .publish_detached_stream("2718281", &frame(128));
        assert_eq!(
            popup.unwrap().get_frame().to_rgba8().unwrap().as_bytes(),
            &[128; 16]
        );
        // Closing the viewer never stops or starts the actual stream subscription.
        popup.unwrap().invoke_close_view();
        assert!(adapter.borrow().app.state.voice.watching.is_some());
        adapter.borrow_mut().pop_out_call_video(&main, "2718281");
        adapter.borrow_mut().app.state.voice.watching = None;
        adapter.borrow().sync_call_video_popout(&main);
        assert!(!main.get_video_popout_open());
    }

    #[test]
    fn detached_video_complete_frame_fills_narrow_and_wide_windows() {
        slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
            i_slint_backend_testing::TestingBackendOptions {
                mock_time: true,
                threading: false,
                renderer_name: Some("skia".into()),
            },
        )))
        .unwrap();
        let window = CallVideoWindow::new().unwrap();
        window.set_source_name("Synthetic screen share".into());
        // Each edge has a different stripe. A cover/crop fit or an image left
        // at its intrinsic dimensions loses at least one of these four edges.
        let left = [240, 40, 50];
        let right = [40, 220, 80];
        let top = [40, 80, 240];
        let bottom = [240, 210, 40];
        let center = [70, 80, 100];
        let mut pixels = slint::SharedPixelBuffer::<slint::Rgba8Pixel>::new(320, 180);
        for (index, pixel) in pixels.make_mut_slice().iter_mut().enumerate() {
            let (x, y) = (index % 320, index / 320);
            let color = if x < 8 {
                left
            } else if x >= 312 {
                right
            } else if y < 8 {
                top
            } else if y >= 172 {
                bottom
            } else {
                center
            };
            *pixel = slint::Rgba8Pixel::new(color[0], color[1], color[2], 255);
        }
        window.set_frame(slint::Image::from_rgba8(pixels));
        window.set_has_frame(true);
        assert!(
            !window.get_preserve_ratio(),
            "new viewers stretch by default"
        );
        window.show().unwrap();
        for (width, height) in [(340, 240), (340, 640), (960, 300), (640, 420)] {
            window
                .window()
                .set_size(slint::LogicalSize::new(width as f32, height as f32));
            for preserve in [false, true] {
                window.set_preserve_ratio(preserve);
                let frame = window.window().take_snapshot().unwrap();
                assert_eq!((frame.width(), frame.height()), (width, height));
                let (vw, vh) = (window.get_video_width(), window.get_video_height());
                assert!((vw - width as f32).abs() < 1.);
                assert!((vh - (height - 80) as f32).abs() < 1.);
                let (draw_width, draw_height) = if preserve {
                    let scale = (vw / 320.).min(vh / 180.);
                    (320. * scale, 180. * scale)
                } else {
                    (vw, vh)
                };
                let x = (vw - draw_width) / 2.;
                let y = height as f32 - vh + (vh - draw_height) / 2.;
                let check = |px: f32, py: f32, expected: [u8; 3]| {
                    let pixel = frame.as_slice()[py as usize * width as usize + px as usize];
                    assert!(
                        [pixel.r, pixel.g, pixel.b]
                            .into_iter()
                            .zip(expected)
                            .all(|(actual, expected)| actual.abs_diff(expected) <= 5),
                        "{width}x{height}, preserve={preserve}: ({px},{py}) expected {expected:?}, got {pixel:?}"
                    );
                };
                check(x + 2., y + draw_height / 2., left);
                check(x + draw_width - 3., y + draw_height / 2., right);
                check(x + draw_width / 2., y + 2., top);
                check(x + draw_width / 2., y + draw_height - 3., bottom);
                check(x + draw_width / 2., y + draw_height / 2., center);
                if preserve {
                    if x >= 3. {
                        check(1., y + draw_height / 2., [8, 9, 11]);
                    } else {
                        check(vw / 2., height as f32 - vh + 1., [8, 9, 11]);
                    }
                }
                if let Some(output) = std::env::var_os("SC_REVIEW_DIR") {
                    let output = PathBuf::from(output);
                    std::fs::create_dir_all(&output).unwrap();
                    let mode = if preserve { "ratio" } else { "stretch" };
                    image::save_buffer(
                        output.join(format!("detached-video-edges-{width}x{height}-{mode}.png")),
                        frame.as_bytes(),
                        width,
                        height,
                        image::ColorType::Rgba8,
                    )
                    .unwrap();
                }
            }
        }
        window.hide().unwrap();
    }

    #[test]
    #[ignore = "native offscreen review artifact"]
    fn detached_video_native_snapshot() {
        use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
        use std::ops::ControlFlow;
        slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
            i_slint_backend_testing::TestingBackendOptions {
                mock_time: true,
                threading: false,
                renderer_name: Some("skia".into()),
            },
        )))
        .unwrap();
        let window = CallVideoWindow::new().unwrap();
        window.set_person_name("Native video review".into());
        window.set_source_name("Camera".into());
        let mut pixels = slint::SharedPixelBuffer::<slint::Rgba8Pixel>::new(320, 180);
        for (index, pixel) in pixels.make_mut_slice().iter_mut().enumerate() {
            *pixel = slint::Rgba8Pixel::new((index % 320 / 2) as u8, (index / 320) as u8, 180, 255);
        }
        window.set_frame(slint::Image::from_rgba8(pixels));
        window.set_has_frame(true);
        window.show().unwrap();
        let output = std::env::var_os("SC_REVIEW_DIR")
            .map(PathBuf::from)
            .expect("SC_REVIEW_DIR");
        std::fs::create_dir_all(&output).unwrap();
        for (width, height) in [(340, 240), (640, 420)] {
            window
                .window()
                .set_size(slint::LogicalSize::new(width as f32, height as f32));
            let rendered = window.window().take_snapshot().unwrap();
            assert_eq!((rendered.width(), rendered.height()), (width, height));
            let inner = i_slint_core::window::WindowInner::from_pub(window.window());
            let root = ItemRc::new_root(inner.component());
            for label in ["Preserve ratio", "Always on top", "Close pop-out"] {
                let item = root
                    .visit_descendants(|item| {
                        if item.is_visible()
                            && item
                                .accessible_string_property(AccessibleStringProperty::Label)
                                .as_deref()
                                == Some(label)
                        {
                            ControlFlow::Break(item.clone())
                        } else {
                            ControlFlow::Continue(())
                        }
                    })
                    .unwrap_or_else(|| panic!("missing {label}"));
                let geometry = item.geometry();
                let point = item.map_to_window(geometry.origin);
                assert!(
                    point.x >= 0. && point.x + geometry.width() <= width as f32 + 1.,
                    "{label} clipped"
                );
                assert!(
                    point.y >= 0. && point.y + geometry.height() <= 81.,
                    "{label} leaves toolbar"
                );
            }
            image::save_buffer(
                output.join(format!("detached-video-{width}.png")),
                rendered.as_bytes(),
                width,
                height,
                image::ColorType::Rgba8,
            )
            .unwrap();
        }
        window.hide().unwrap();
    }
}
