//! Device-local recommendations, isolated by Discord account. Only command
//! identities and counts live in layout.json; drafts/options never come here.

use super::*;
use yapfast_core::application::{
    CommandHistory, FAVORITE_COMMAND_APPS_LIMIT, normalize_favorite_command_apps,
};

const ACCOUNTS_KEPT: usize = 8;

#[derive(Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub(super) struct KeptHistory {
    account: String,
    history: CommandHistory,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    favorite_apps: Vec<String>,
}

fn valid_account(account: &str) -> bool {
    !account.is_empty() && account.len() <= 20 && account.bytes().all(|byte| byte.is_ascii_digit())
}

/// Bounds both accounts and each account's command identities on disk load.
pub(super) fn tidy(histories: &mut Vec<KeptHistory>) {
    let mut kept = Vec::<KeptHistory>::new();
    for mut history in histories.drain(..).rev() {
        if kept.len() == ACCOUNTS_KEPT {
            break;
        }
        if !valid_account(&history.account)
            || kept.iter().any(|other| other.account == history.account)
        {
            continue;
        }
        history.history = history.history.normalized();
        history.favorite_apps = normalize_favorite_command_apps(history.favorite_apps);
        kept.push(history);
    }
    kept.reverse();
    *histories = kept;
}

#[derive(Default)]
pub(super) struct ActiveHistory {
    account: Option<String>,
    reset: u64,
}

impl ActiveHistory {
    /// Restore on identity change or core reset before rendering suggestions.
    /// Otherwise copy only changed usage into the layout; true asks for its
    /// existing debounced write. An account switch never saves the outgoing
    /// core state under the incoming identity.
    fn sync(&mut self, state: &mut AppState, histories: &mut Vec<KeptHistory>) -> bool {
        let account = state
            .discord_user
            .as_deref()
            .filter(|account| !state.preview && valid_account(account));
        if self.account.as_deref() != account || self.reset != state.reset_version {
            self.account = account.map(str::to_owned);
            self.reset = state.reset_version;
            let kept = self
                .account
                .as_ref()
                .and_then(|account| histories.iter().find(|kept| &kept.account == account));
            state.set_command_history(kept.map(|kept| kept.history.clone()).unwrap_or_default());
            state.set_favorite_command_apps(
                kept.map(|kept| kept.favorite_apps.clone())
                    .unwrap_or_default(),
            );
            return false;
        }
        let Some(account) = self.account.as_ref() else {
            return false;
        };
        let at = histories.iter().position(|kept| &kept.account == account);
        if let Some(at) = at {
            if &histories[at].history == state.command_history()
                && histories[at].favorite_apps == state.favorite_command_apps()
            {
                return false;
            }
            histories.remove(at);
        } else if state.command_history() == &CommandHistory::default()
            && state.favorite_command_apps().is_empty()
        {
            return false;
        }
        if histories.len() >= ACCOUNTS_KEPT {
            histories.remove(0);
        }
        histories.push(KeptHistory {
            account: account.clone(),
            history: state.command_history().clone(),
            favorite_apps: state.favorite_command_apps().to_vec(),
        });
        true
    }
}

impl Adapter {
    pub(super) fn toggle_favorite_command_app(&mut self, window: &YapfastWindow, app: &str) {
        if self.app.state.preview
            || !self
                .app
                .state
                .discord_user
                .as_deref()
                .is_some_and(valid_account)
            || !window.get_command_rows_are_commands()
            || !window
                .get_command_choices()
                .iter()
                .any(|choice| choice.application_id == app)
        {
            return;
        }
        let mut favorites = self.app.state.favorite_command_apps().to_vec();
        if let Some(at) = favorites.iter().position(|id| id == app) {
            favorites.remove(at);
        } else if favorites.len() < FAVORITE_COMMAND_APPS_LIMIT {
            favorites.push(app.to_owned());
        } else {
            window.set_notice(
                format!("You can star up to {FAVORITE_COMMAND_APPS_LIMIT} bots. Unstar one first.")
                    .into(),
            );
            return;
        }
        self.app.state.set_favorite_command_apps(favorites);
        window.set_command_choice_index(0);
        self.refresh(window);
    }

    pub(super) fn sync_command_history(&mut self) {
        if self
            .command_history
            .sync(&mut self.app.state, &mut self.layout.command_histories)
        {
            self.write_layout_soon();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn history(command: &str) -> CommandHistory {
        serde_json::from_value(serde_json::json!({"entries": [
            {"app": "500", "command": command, "path": [], "count": 2}
        ]}))
        .unwrap()
    }

    #[test]
    fn slash_history_isolates_accounts_and_restores_same_account_after_reset() {
        let mut state = AppState::default();
        let mut active = ActiveHistory::default();
        let mut histories = Vec::new();
        state.discord_user = Some("1".into());
        assert!(!active.sync(&mut state, &mut histories));
        state.set_command_history(history("501"));
        state.set_favorite_command_apps(vec!["500".into()]);
        assert!(active.sync(&mut state, &mut histories));
        assert!(
            !active.sync(&mut state, &mut histories),
            "unchanged refresh does not write"
        );
        state.discord_user = Some("2".into());
        assert!(!active.sync(&mut state, &mut histories));
        assert_eq!(
            state.command_history(),
            &CommandHistory::default(),
            "new account cannot inherit previous usage"
        );
        assert!(state.favorite_command_apps().is_empty());
        state.set_command_history(history("502"));
        state.set_favorite_command_apps(vec!["600".into()]);
        assert!(active.sync(&mut state, &mut histories));
        state.discord_user = Some("1".into());
        assert!(!active.sync(&mut state, &mut histories));
        assert_eq!(state.command_history(), &history("501"));
        assert_eq!(state.favorite_command_apps(), ["500"]);
        state.set_command_history(CommandHistory::default());
        state.set_favorite_command_apps(Vec::new());
        state.reset_version += 1;
        assert!(!active.sync(&mut state, &mut histories));
        assert_eq!(
            state.command_history(),
            &history("501"),
            "same-account core reset reloads saved usage"
        );
        assert_eq!(state.favorite_command_apps(), ["500"]);
        state.discord_user = None;
        assert!(!active.sync(&mut state, &mut histories));
        assert_eq!(state.command_history(), &CommandHistory::default());
        assert!(state.favorite_command_apps().is_empty());
        assert_eq!(
            histories.len(),
            2,
            "sign-out retains separate local histories"
        );
    }

    #[test]
    fn slash_history_layout_bounds_accounts_and_persists_only_identities() {
        let directory = tempfile::tempdir().unwrap();
        let mut layout = Layout {
            theme: Some("sc-ocean".into()),
            ..Default::default()
        };
        for id in 1..=12 {
            layout.command_histories.push(KeptHistory {
                account: id.to_string(),
                history: history("501"),
                favorite_apps: Vec::new(),
            });
        }
        layout.command_histories.push(KeptHistory {
            account: "invalid account".into(),
            history: history("502"),
            favorite_apps: Vec::new(),
        });
        layout.write(directory.path());
        let read = Layout::read(directory.path());
        assert_eq!(
            read.theme.as_deref(),
            Some("sc-ocean"),
            "other preferences survive"
        );
        assert_eq!(read.command_histories.len(), ACCOUNTS_KEPT);
        assert_eq!(read.command_histories[0].account, "5");
        assert_eq!(read.command_histories.last().unwrap().account, "12");
        let json = serde_json::to_value(&read.command_histories[0]).unwrap();
        assert_eq!(
            json,
            serde_json::json!({"account": "5", "history": {"entries": [
                {"app": "500", "command": "501", "path": [], "count": 2}
            ]}})
        );
        let older: Layout = serde_json::from_str(r#"{"theme":"sc-midnight"}"#).unwrap();
        assert!(
            older.command_histories.is_empty(),
            "existing layouts migrate with empty history"
        );
    }

    #[test]
    fn slash_history_adapter_saves_only_changed_usage() {
        i_slint_backend_testing::init_no_event_loop();
        let directory = tempfile::tempdir().unwrap();
        let window = YapfastWindow::new().unwrap();
        let adapter = Adapter::new(
            Arc::new(BackgroundRuntime::new().unwrap()),
            directory.path().into(),
            &window,
        )
        .unwrap();
        let mut adapter = adapter.borrow_mut();
        adapter.app.state.discord_user = Some("1".into());
        adapter.sync_command_history();
        assert!(!adapter.layout_dirty);
        adapter.app.state.set_command_history(history("501"));
        adapter.sync_command_history();
        assert!(adapter.layout_dirty);
        adapter.flush_layout();
        assert!(!adapter.layout_dirty);
        let saved = Layout::read(directory.path());
        assert_eq!(saved.command_histories[0].history, history("501"));
        adapter.sync_command_history();
        assert!(
            !adapter.layout_dirty,
            "unchanged refresh does not schedule another write"
        );
        adapter
            .app
            .state
            .set_command_history(CommandHistory::default());
        adapter.app.state.reset_version += 1;
        adapter.sync_command_history();
        assert_eq!(adapter.app.state.command_history(), &history("501"));
        assert!(
            !adapter.layout_dirty,
            "restoring after reset does not overwrite persisted history"
        );
    }
}
