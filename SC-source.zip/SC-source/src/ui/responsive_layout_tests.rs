//! Pane and stream-preview bounds at native compact window sizes.
use super::*;
use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
use std::ops::ControlFlow;

fn bounds(window: &YapfastWindow, label: &str) -> (f32, f32, f32, f32) {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    let item = ItemRc::new_root(inner.component())
        .visit_descendants(|item| {
            if item.is_visible()
                && item
                    .accessible_string_property(AccessibleStringProperty::Label)
                    .as_deref()
                    == Some(label)
            {
                ControlFlow::Break(item.clone())
            } else {
                ControlFlow::Continue(())
            }
        })
        .unwrap_or_else(|| panic!("missing visible native control: {label}"));
    let geometry = item.geometry();
    let origin = item.map_to_window(geometry.origin);
    (origin.x, origin.y, geometry.width(), geometry.height())
}

#[test]
fn responsive_layout_keeps_thread_members_and_stream_inside_compact_window() {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let window = yapfast::window().unwrap();
    Layout::default().apply_appearance(&window);
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<ClientStyle>().set_auto_resize(true);
    window.global::<PictureStore>().on_request(|_| {});
    window.set_workspace(true);
    window.set_trusted(true);
    window.set_room_selected(true);
    window.set_room_ready(true);
    window.set_room_name("A thread with a deliberately long channel name".into());
    window.set_room_parent("discord:100".into());
    window.set_members_available(true);
    window.set_member_list(true);
    window.set_can_search(true);
    window.set_search_placeholder("Search".into());
    window.set_can_pin(true);
    window.set_sidebar_width(340.);
    window.set_members_width(300.);
    window.set_roster(ModelRc::new(VecModel::from(vec![MemberRow {
        id: "discord:200".into(),
        name: "A member with a deliberately long display name".into(),
        initial: "M".into(),
        presence: "online".into(),
        ..Default::default()
    }])));
    window.set_voice_active(true);
    window.set_pip_kind(2);
    window.set_share_status("Synthetic stream preview".into());
    window.show().unwrap();
    for (width, height) in [(800., 600.), (908., 642.), (1120., 760.)] {
        window
            .window()
            .set_size(slint::LogicalSize::new(width, height));
        window.window().take_snapshot().unwrap();
        i_slint_backend_testing::mock_elapsed_time(std::time::Duration::from_millis(200));
        let frame = window.window().take_snapshot().unwrap();
        assert_eq!(window.window().size().width, width as u32);
        let members = bounds(&window, "Members");
        let messages = bounds(&window, "Messages");
        let preview = bounds(&window, "Your screen. Return to the call");
        assert!(
            members.0 >= 0. && members.0 + members.2 <= width + 1.,
            "members={members:?}, width={width}"
        );
        assert!(members.2 >= 179., "roster stays visible: {members:?}");
        assert!(
            messages.2 >= 280.,
            "chat retains usable width: {messages:?}, window={width}"
        );
        assert!(
            preview.0 >= messages.0 && preview.0 + preview.2 <= messages.0 + messages.2 + 1.,
            "preview={preview:?}, chat={messages:?}"
        );
        assert!(preview.1 >= 0. && preview.1 + preview.3 <= height + 1.);
        assert!((preview.2 / preview.3 - 16. / 9.).abs() < 0.01);
        assert_eq!(window.get_sidebar_width(), 340.);
        assert_eq!(window.get_members_width(), 300.);
        if width == 908. {
            if let Some(directory) = std::env::var_os("SC_REVIEW_DIR") {
                let directory = std::path::Path::new(&directory);
                std::fs::create_dir_all(directory).unwrap();
                image::save_buffer(
                    directory.join("auto-resize908.png"),
                    frame.as_bytes(),
                    frame.width(),
                    frame.height(),
                    image::ColorType::Rgba8,
                )
                .unwrap();
            }
        }
    }
    assert_eq!(window.get_sidebar_shown(), 340.);
    assert_eq!(window.get_members_shown(), 300.);
    window
        .window()
        .set_size(slint::LogicalSize::new(908., 642.));
    window.global::<ClientStyle>().set_auto_resize(false);
    window.window().take_snapshot().unwrap();
    assert_eq!(window.get_sidebar_shown(), 340.);
    assert_eq!(window.get_members_shown(), 300.);
    assert_eq!(bounds(&window, "Your screen. Return to the call").2, 320.);
    window.global::<ClientStyle>().set_auto_resize(true);
    window.window().take_snapshot().unwrap();
    assert!(window.get_sidebar_shown() < 340.);
    assert!(window.get_members_shown() < 300.);
    window.hide().unwrap();
}
