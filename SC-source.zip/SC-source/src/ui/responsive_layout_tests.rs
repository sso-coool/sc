//! Pane and stream-preview bounds at native compact window sizes.
use super::*;
use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
use std::ops::ControlFlow;

fn bounds(window: &YapfastWindow, label: &str) -> (f32, f32, f32, f32) {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    let item = ItemRc::new_root(inner.component())
        .visit_descendants(|item| {
            if item.is_visible()
                && item
                    .accessible_string_property(AccessibleStringProperty::Label)
                    .as_deref()
                    == Some(label)
            {
                ControlFlow::Break(item.clone())
            } else {
                ControlFlow::Continue(())
            }
        })
        .unwrap_or_else(|| panic!("missing visible native control: {label}"));
    let geometry = item.geometry();
    let origin = item.map_to_window(geometry.origin);
    (origin.x, origin.y, geometry.width(), geometry.height())
}

#[test]
fn responsive_layout_keeps_thread_members_and_stream_inside_compact_window() {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let window = yapfast::window().unwrap();
    Layout::default().apply_appearance(&window);
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<ClientStyle>().set_auto_resize(true);
    window.global::<PictureStore>().on_request(|_| {});
    window.set_workspace(true);
    window.set_trusted(true);
    window.set_room_selected(true);
    window.set_room_ready(true);
    window.set_room_name("A thread with a deliberately long channel name".into());
    window.set_room_parent("discord:100".into());
    window.set_members_available(true);
    window.set_member_list(true);
    window.set_can_search(true);
    window.set_search_placeholder("Search".into());
    window.set_can_pin(true);
    window.set_sidebar_width(340.);
    window.set_members_width(300.);
    window.set_roster(ModelRc::new(VecModel::from(vec![MemberRow {
        id: "discord:200".into(),
        name: "A member with a deliberately long display name".into(),
        initial: "M".into(),
        presence: "online".into(),
        ..Default::default()
    }])));
    window.set_voice_active(true);
    window.set_pip_kind(2);
    window.set_share_status("Synthetic stream preview".into());
    window.show().unwrap();
    for (width, height) in [(800., 600.), (908., 642.), (1120., 760.)] {
        window
            .window()
            .set_size(slint::LogicalSize::new(width, height));
        window.window().take_snapshot().unwrap();
        i_slint_backend_testing::mock_elapsed_time(std::time::Duration::from_millis(200));
        let frame = window.window().take_snapshot().unwrap();
        assert_eq!(window.window().size().width, width as u32);
        let members = bounds(&window, "Members");
        let messages = bounds(&window, "Messages");
        let preview = bounds(&window, "Your screen. Return to the call");
        assert!(
            members.0 >= 0. && members.0 + members.2 <= width + 1.,
            "members={members:?}, width={width}"
        );
        assert!(members.2 >= 179., "roster stays visible: {members:?}");
        assert!(
            messages.2 >= 280.,
            "chat retains usable width: {messages:?}, window={width}"
        );
        assert!(
            preview.0 >= messages.0 && preview.0 + preview.2 <= messages.0 + messages.2 + 1.,
            "preview={preview:?}, chat={messages:?}"
        );
        assert!(preview.1 >= 0. && preview.1 + preview.3 <= height + 1.);
        assert!((preview.2 / preview.3 - 16. / 9.).abs() < 0.01);
        assert_eq!(window.get_sidebar_width(), 340.);
        assert_eq!(window.get_members_width(), 300.);
        if width == 908. {
            if let Some(directory) = std::env::var_os("SC_REVIEW_DIR") {
                let directory = std::path::Path::new(&directory);
                std::fs::create_dir_all(directory).unwrap();
                image::save_buffer(
                    directory.join("auto-resize908.png"),
                    frame.as_bytes(),
                    frame.width(),
                    frame.height(),
                    image::ColorType::Rgba8,
                )
                .unwrap();
            }
        }
    }
    assert_eq!(window.get_sidebar_shown(), 340.);
    assert_eq!(window.get_members_shown(), 300.);
    window
        .window()
        .set_size(slint::LogicalSize::new(908., 642.));
    window.global::<ClientStyle>().set_auto_resize(false);
    window.window().take_snapshot().unwrap();
    assert_eq!(window.get_sidebar_shown(), 340.);
    assert_eq!(window.get_members_shown(), 300.);
    assert_eq!(bounds(&window, "Your screen. Return to the call").2, 320.);
    window.global::<ClientStyle>().set_auto_resize(true);
    window.window().take_snapshot().unwrap();
    assert!(window.get_sidebar_shown() < 340.);
    assert!(window.get_members_shown() < 300.);
    window.hide().unwrap();
}

#[test]
fn server_banner_scrolls_away_and_restores_under_the_pinned_server_menu() {
    use slint::platform::{PointerEventButton, WindowEvent};

    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let window = yapfast::window().unwrap();
    Layout::default().apply_appearance(&window);
    window.global::<ClientStyle>().set_interface_motion(false);
    let mut art = slint::SharedPixelBuffer::<slint::Rgba8Pixel>::new(256, 132);
    art.make_mut_slice()
        .fill(slint::Rgba8Pixel::new(231, 64, 167, 255));
    let art = slint::Image::from_rgba8(art);
    let store = window.global::<PictureStore>();
    store.on_request(|_| {});
    store.on_picture(move |url, _| {
        if url == "banner-fixture" {
            art.clone()
        } else {
            slint::Image::default()
        }
    });
    let menu_clicked = Rc::new(Cell::new(false));
    let seen = menu_clicked.clone();
    window.on_prepare_menu(move |target, person| seen.set(target == "header:900" && !person));
    window.set_workspace(true);
    window.set_trusted(true);
    window.set_sidebar_title("Banner fixture".into());
    window.set_header_server("900".into());
    window.set_header_banner("banner-fixture".into());
    window.set_header_events_row(true);
    window.set_header_events(2);
    window.set_rooms(ModelRc::new(VecModel::from(
        (0..120)
            .map(|index| RoomRow {
                id: index.to_string().into(),
                name: format!("Room {index}").into(),
                ..Default::default()
            })
            .collect::<Vec<_>>(),
    )));
    window.show().unwrap();
    window
        .window()
        .set_size(slint::LogicalSize::new(900., 600.));
    let at_top = window.window().take_snapshot().unwrap();
    let menu = bounds(&window, "Banner fixture, server menu");
    let event_y = bounds(&window, "2 events").1;
    let sample = ((menu.0 + 54.) as u32, (menu.1 + 62.) as u32);
    let is_banner = |frame: &slint::SharedPixelBuffer<slint::Rgba8Pixel>| {
        let at = (sample.1 * frame.width() + sample.0) as usize;
        let pixel = frame.as_slice()[at];
        pixel.r > 210 && pixel.g < 90 && pixel.b > 138
    };
    assert!(is_banner(&at_top), "banner image starts visible");
    let settle_scroll = || {
        for _ in 0..12 {
            i_slint_backend_testing::mock_elapsed_time(std::time::Duration::from_millis(45));
            slint::platform::update_timers_and_animations();
            window.window().take_snapshot().unwrap();
        }
        window.window().take_snapshot().unwrap()
    };
    let scroll = |delta_y| {
        window
            .window()
            .dispatch_event(WindowEvent::PointerScrolled {
                position: slint::LogicalPosition::new(menu.0 + 90., menu.1 + 220.),
                delta_x: 0.,
                delta_y,
            });
        settle_scroll()
    };
    let scrolled = scroll(-300.);
    assert!(!is_banner(&scrolled), "banner scrolls out of the list");
    assert_eq!(bounds(&window, "Banner fixture, server menu"), menu);
    let position = slint::LogicalPosition::new(menu.0 + 25., menu.1 + 15.);
    window.window().dispatch_event(WindowEvent::PointerPressed {
        position,
        button: PointerEventButton::Left,
    });
    window
        .window()
        .dispatch_event(WindowEvent::PointerReleased {
            position,
            button: PointerEventButton::Left,
        });
    assert!(menu_clicked.get(), "pinned server menu stays clickable");
    scroll(300.);
    let restored = scroll(180.);
    if let Some(directory) = std::env::var_os("SC_REVIEW_DIR") {
        for (name, frame) in [
            ("server-banner-start", &at_top),
            ("server-banner-scrolled", &scrolled),
            ("server-banner-restored", &restored),
        ] {
            let directory = std::path::Path::new(&directory);
            std::fs::create_dir_all(directory).unwrap();
            image::save_buffer(
                directory.join(format!("{name}.png")),
                frame.as_bytes(),
                frame.width(),
                frame.height(),
                image::ColorType::Rgba8,
            )
            .unwrap();
        }
    }
    assert!(is_banner(&restored), "scrolling up restores the art");
    assert_eq!(bounds(&window, "2 events").1, event_y);

    assert!(!is_banner(&scroll(-300.)));
    window.set_header_server("901".into());
    let second_server = settle_scroll();
    assert!(is_banner(&second_server), "a new server starts at the top");
    window.hide().unwrap();
}
