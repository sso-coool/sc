//! Native equivalents of a small set of Vencord preferences. JSON is data.
use super::*;
use std::io::Read;

const MAX_EXPORT: u64 = 1024 * 1024;

#[derive(Clone, Copy, Default, PartialEq, serde::Serialize, serde::Deserialize)]
#[serde(default)]
pub(super) struct Profile {
    pub(super) enabled: bool,
    pub(super) clear_urls: bool,
    pub(super) silent_typing: bool,
    pub(super) no_reply_mention: bool,
    pub(super) copy_user_urls: bool,
    pub(super) no_typing_animation: bool,
    pub(super) no_blocked_messages: bool,
    pub(super) gif_paste: bool,
    pub(super) no_system_badge: bool,
    pub(super) better_gif_picker: bool,
    pub(super) better_upload_button: bool,
    pub(super) image_filename: bool,
}

pub(super) const NATIVE_PLUGINS: [(&str, fn(&mut Profile) -> &mut bool); 11] = [
    ("ClearURLs", |profile| &mut profile.clear_urls),
    ("SilentTyping", |profile| &mut profile.silent_typing),
    ("NoReplyMention", |profile| &mut profile.no_reply_mention),
    ("CopyUserURLs", |profile| &mut profile.copy_user_urls),
    ("NoTypingAnimation", |profile| {
        &mut profile.no_typing_animation
    }),
    ("NoBlockedMessages", |profile| {
        &mut profile.no_blocked_messages
    }),
    ("GifPaste", |profile| &mut profile.gif_paste),
    ("NoSystemBadge", |profile| &mut profile.no_system_badge),
    ("BetterGifPicker", |profile| &mut profile.better_gif_picker),
    ("BetterUploadButton", |profile| {
        &mut profile.better_upload_button
    }),
    ("ImageFilename", |profile| &mut profile.image_filename),
];

impl Profile {
    pub(super) fn tracking(self, base: bool) -> bool {
        base || (self.enabled && self.clear_urls)
    }

    pub(super) fn typing(self, base: bool) -> bool {
        base && !(self.enabled && self.silent_typing)
    }

    pub(super) fn reply_mentions(self, base: bool) -> bool {
        base && !(self.enabled && self.no_reply_mention)
    }

    pub(super) fn hide_blocked(self, base: bool) -> bool {
        base || (self.enabled && self.no_blocked_messages)
    }

    pub(super) fn insert_gif(self, base: bool) -> bool {
        base || (self.enabled && self.gif_paste)
    }

    pub(super) fn system_badge(self, unread: bool) -> bool {
        unread && !(self.enabled && self.no_system_badge)
    }

    pub(super) fn user_url(self, user: &str) -> Option<String> {
        (self.enabled
            && self.copy_user_urls
            && !user.starts_with('0')
            && user.bytes().all(|byte| byte.is_ascii_digit())
            && user.parse::<u64>().is_ok())
        .then(|| format!("<https://discord.com/users/{user}>"))
    }

    fn from_export(bytes: &[u8]) -> Result<(Self, usize), &'static str> {
        if bytes.len() as u64 > MAX_EXPORT {
            return Err("Choose a Vencord settings JSON file under 1 MB.");
        }
        let bytes = bytes.strip_prefix(&[0xef, 0xbb, 0xbf]).unwrap_or(bytes);
        let value: serde_json::Value =
            serde_json::from_slice(bytes).map_err(|_| "That file is not valid settings JSON.")?;
        let plugins = value
            .get("settings")
            .unwrap_or(&value)
            .get("plugins")
            .and_then(serde_json::Value::as_object)
            .ok_or("This file does not contain Vencord plugin settings.")?;
        let plugin = |name| {
            plugins
                .get(name)
                .and_then(|plugin| plugin.get("enabled"))
                .and_then(serde_json::Value::as_bool)
        };
        let mut profile = Self {
            enabled: true,
            ..Self::default()
        };
        let mut matched = 0;
        for (name, enabled) in NATIVE_PLUGINS {
            if let Some(value) = plugin(name) {
                *enabled(&mut profile) = value;
                matched += 1;
            }
        }
        if matched == 0 {
            return Err(
                "No supported plugin settings found. Import the enable switches listed under Native Vencord equivalents in Appearance.",
            );
        }
        Ok((profile, matched))
    }

    pub(super) fn show(self, window: &YapfastWindow) {
        let style = window.global::<ClientStyle>();
        style.set_vencord_mode(self.enabled);
        style.set_extension_clear_urls(self.clear_urls);
        style.set_extension_silent_typing(self.silent_typing);
        style.set_extension_no_reply_mention(self.no_reply_mention);
        style.set_extension_copy_user_urls(self.copy_user_urls);
        style.set_extension_no_typing_animation(self.no_typing_animation);
        style.set_extension_no_blocked_messages(self.no_blocked_messages);
        style.set_extension_gif_paste(self.gif_paste);
        style.set_extension_no_system_badge(self.no_system_badge);
        style.set_extension_better_gif_picker(self.better_gif_picker);
        style.set_extension_better_upload_button(self.better_upload_button);
        style.set_extension_image_filename(self.image_filename);
    }

    pub(super) fn read(window: &YapfastWindow) -> Self {
        let style = window.global::<ClientStyle>();
        Self {
            enabled: style.get_vencord_mode(),
            clear_urls: style.get_extension_clear_urls(),
            silent_typing: style.get_extension_silent_typing(),
            no_reply_mention: style.get_extension_no_reply_mention(),
            copy_user_urls: style.get_extension_copy_user_urls(),
            no_typing_animation: style.get_extension_no_typing_animation(),
            no_blocked_messages: style.get_extension_no_blocked_messages(),
            gif_paste: style.get_extension_gif_paste(),
            no_system_badge: style.get_extension_no_system_badge(),
            better_gif_picker: style.get_extension_better_gif_picker(),
            better_upload_button: style.get_extension_better_upload_button(),
            image_filename: style.get_extension_image_filename(),
        }
    }
}

pub(super) fn bind(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    super::vencord_companion::bind(window);
    let state = adapter.clone();
    window.on_import_extension_preferences(move || {
        let weak = Rc::downgrade(&state);
        state.borrow_mut().dialog(async move {
            let file = rfd::AsyncFileDialog::new()
                .set_title("Import Vencord settings")
                .add_filter("Vencord settings", &["json"])
                .pick_file()
                .await;
            let (Some(file), Some(adapter)) = (file, weak.upgrade()) else {
                return;
            };
            let Some(window) = adapter.borrow().window.upgrade() else {
                return;
            };
            let result = (|| {
                let mut data = Vec::new();
                std::fs::File::open(file.path())
                    .and_then(|file| file.take(MAX_EXPORT + 1).read_to_end(&mut data))
                    .map_err(|_| "S;C could not read that file.")?;
                Profile::from_export(&data)
            })();
            let style = window.global::<ClientStyle>();
            match result {
                Ok((profile, count)) => {
                    profile.show(&window);
                    window.invoke_preferences_changed();
                    super::extension_marketplace::refresh(&window);
                    style.set_extension_import_status(
                        format!("Imported {count} supported settings.").into(),
                    );
                }
                Err(message) => style.set_extension_import_status(message.into()),
            }
        });
    });
}

#[cfg(test)]
mod tests {
    use super::Profile;

    #[test]
    fn extension_profile_eleven_native_switches_import_without_overwriting_baselines() {
        let (profile, count) = Profile::from_export(
            br#"{"plugins":{
            "ClearURLs":{"enabled":true},"SilentTyping":{"enabled":true},
            "NoReplyMention":{"enabled":true},"CopyUserURLs":{"enabled":true},
            "NoTypingAnimation":{"enabled":true},
            "NoBlockedMessages":{"enabled":true,"ignoreMessages":true,"applyToIgnoredUsers":false},
            "GifPaste":{"enabled":true},"NoSystemBadge":{"enabled":true},
            "BetterGifPicker":{"enabled":true},"BetterUploadButton":{"enabled":true},
            "ImageFilename":{"enabled":true,"showFullUrl":true},
            "Unknown":{"enabled":true,"code":"ignored"}},"quickCss":"ignored"}"#,
        )
        .unwrap();
        assert_eq!(count, 11);
        assert!(
            profile.no_typing_animation
                && profile.no_blocked_messages
                && profile.gif_paste
                && profile.no_system_badge
                && profile.better_gif_picker
                && profile.better_upload_button
                && profile.image_filename
        );
        assert!(profile.hide_blocked(false) && profile.insert_gif(false));
        assert!(!profile.system_badge(true));
        let vanilla = Profile {
            enabled: false,
            ..profile
        };
        for base in [false, true] {
            assert_eq!(vanilla.hide_blocked(base), base);
            assert_eq!(vanilla.insert_gif(base), base);
            assert_eq!(vanilla.system_badge(base), base);
        }
        let restored: Profile =
            serde_json::from_str(&serde_json::to_string(&profile).unwrap()).unwrap();
        assert!(restored == profile);
        let old: Profile =
            serde_json::from_str(r#"{"enabled":true,"copy_user_urls":true}"#).unwrap();
        assert!(
            !old.no_typing_animation
                && !old.no_blocked_messages
                && !old.gif_paste
                && !old.no_system_badge
                && !old.better_gif_picker
                && !old.better_upload_button
                && !old.image_filename
        );
    }

    #[cfg(feature = "discord")]
    fn native_fixture() -> (
        tempfile::TempDir,
        super::YapfastWindow,
        super::Rc<super::RefCell<super::Adapter>>,
    ) {
        use super::super::*;
        i_slint_backend_testing::init_no_event_loop();
        let directory = tempfile::tempdir().unwrap();
        let window = YapfastWindow::new().unwrap();
        let adapter = Adapter::new(
            Arc::new(BackgroundRuntime::new().unwrap()),
            directory.path().into(),
            &window,
        )
        .unwrap();
        bind_callbacks(&window, &adapter);
        {
            let mut adapter = adapter.borrow_mut();
            adapter.app = yapfast_core::application::member_server(&["30"]);
            adapter.backend_commands = Some(Rc::new(RefCell::new(vec![])));
            adapter.layout.apply(&window);
            adapter.app.apply(Event::Timeline {
                room: "discord:10:11".into(),
                messages: vec![],
            });
        }
        (directory, window, adapter)
    }

    #[test]
    #[cfg(feature = "discord")]
    fn extension_profile_blocked_filter_and_system_badge_restore_underlying_state() {
        use super::super::*;
        let (_directory, window, adapter) = native_fixture();
        {
            let mut adapter = adapter.borrow_mut();
            adapter.app.apply(Event::Timeline {
                room: "discord:10:11".into(),
                messages: vec![
                    Arc::new(ChatMessage {
                        item: "100".into(),
                        sender: "3".into(),
                        body: "Visible".into(),
                        ..Default::default()
                    }),
                    Arc::new(ChatMessage {
                        item: "101".into(),
                        sender: "4".into(),
                        body: "Blocked".into(),
                        blocked: true,
                        ..Default::default()
                    }),
                ],
            });
            Arc::make_mut(&mut adapter.app.state.rooms[0]).mentions = 3;
            adapter.app.state.voice.phase = yapfast_core::voice::Phase::Connected;
            assert!(adapter.tray_state().unread && adapter.tray_state().call);
            adapter.refresh(&window);
        }
        assert_eq!(adapter.borrow().app.state.messages.len(), 2);
        let style = window.global::<ClientStyle>();
        style.set_vencord_mode(true);
        style.set_extension_no_blocked_messages(true);
        style.set_extension_no_system_badge(true);
        window.invoke_preferences_changed();
        {
            let adapter = adapter.borrow();
            assert_eq!(adapter.app.state.messages.len(), 1);
            assert!(!adapter.layout.hide_blocked, "base preference is retained");
            assert!(!adapter.tray_state().unread);
            assert!(
                adapter.tray_state().call,
                "call Disconnect is unrelated to badges"
            );
            assert_eq!(
                adapter.app.state.rooms[0].mentions, 3,
                "badge suppression never marks messages read"
            );
        }
        // Changing the normal setting while the override is enabled changes
        // the saved baseline, without defeating the effective override.
        window.invoke_hide_blocked_toggled(false);
        assert_eq!(adapter.borrow().app.state.messages.len(), 1);
        style.set_vencord_mode(false);
        window.invoke_preferences_changed();
        assert_eq!(adapter.borrow().app.state.messages.len(), 2);
        assert!(adapter.borrow().tray_state().unread);
        window.invoke_hide_blocked_toggled(true);
        assert_eq!(adapter.borrow().app.state.messages.len(), 1);
        style.set_vencord_mode(true);
        window.invoke_preferences_changed();
        style.set_vencord_mode(false);
        window.invoke_preferences_changed();
        assert_eq!(
            adapter.borrow().app.state.messages.len(),
            1,
            "Vanilla retains an independently enabled base setting"
        );
        let restored: Layout =
            serde_json::from_str(&serde_json::to_string(&adapter.borrow().layout).unwrap())
                .unwrap();
        assert!(restored.hide_blocked && restored.extensions.no_blocked_messages);
        assert!(!restored.extensions.enabled);
    }

    #[test]
    #[cfg(feature = "discord")]
    fn extension_profile_gif_paste_stages_without_sending_and_vanilla_keeps_insert_modifier() {
        use super::super::*;
        let (_directory, window, adapter) = native_fixture();
        let commands = adapter.borrow().backend_commands.clone().unwrap();
        let url = "https://example.test/synthetic-gif";
        {
            let mut adapter = adapter.borrow_mut();
            adapter.layout.extensions.enabled = true;
            adapter.layout.extensions.gif_paste = true;
            adapter.app.dispatch(Action::SetDraft("Before".into()));
            assert!(adapter.app.state.can_pick_gifs());
        }
        window.invoke_gif_pick(url.into(), false);
        assert_eq!(adapter.borrow().app.state.draft(), format!("Before {url}"));
        assert!(
            !commands
                .borrow()
                .iter()
                .any(|command| matches!(command, Command::Send { .. })),
            "GifPaste must never send the chosen GIF"
        );
        {
            let mut adapter = adapter.borrow_mut();
            adapter.layout.extensions.enabled = false;
            adapter.app.dispatch(Action::SetDraft("Shift".into()));
        }
        window.invoke_gif_pick(url.into(), true);
        assert_eq!(adapter.borrow().app.state.draft(), format!("Shift {url}"));
        assert!(
            !commands
                .borrow()
                .iter()
                .any(|command| matches!(command, Command::Send { .. }))
        );
        window.invoke_gif_pick(url.into(), false);
        assert_eq!(
            commands
                .borrow()
                .iter()
                .filter(|command| matches!(command, Command::Send { body, .. } if body == url))
                .count(),
            1,
            "Vanilla restores the existing single-click send path"
        );
    }

    #[test]
    #[cfg(feature = "discord")]
    fn extension_profile_better_gif_picker_uses_cached_favorites_and_respects_vanilla() {
        use super::super::*;
        use yapfast_core::application::GifView;
        let (_directory, window, adapter) = native_fixture();
        let commands = adapter.borrow().backend_commands.clone().unwrap();
        {
            let mut adapter = adapter.borrow_mut();
            adapter.layout.extensions.enabled = true;
            adapter.layout.extensions.better_gif_picker = true;
        }
        window.invoke_open_gifs();
        assert_eq!(adapter.borrow().app.state.gifs.view, GifView::Favorites);
        assert!(adapter.borrow().app.state.gifs.open);
        let requests = commands.borrow().len();
        window.invoke_close_gifs();
        window.invoke_open_gifs();
        assert_eq!(
            commands.borrow().len(),
            requests,
            "opening again coalesces pending loads"
        );
        window.invoke_close_gifs();
        {
            let mut adapter = adapter.borrow_mut();
            adapter.layout.extensions.enabled = false;
            adapter.app.dispatch(Action::ShowGifs(GifView::Home));
        }
        window.invoke_open_gifs();
        assert_eq!(adapter.borrow().app.state.gifs.view, GifView::Home);
        window.invoke_close_gifs();
        {
            let mut adapter = adapter.borrow_mut();
            adapter.layout.extensions.enabled = true;
            adapter.app.state.selected = None;
        }
        window.invoke_open_gifs();
        assert!(!adapter.borrow().app.state.gifs.open);
        assert_eq!(adapter.borrow().app.state.gifs.view, GifView::Home);
        assert_eq!(
            commands.borrow().len(),
            requests,
            "an unavailable picker cannot load data"
        );
    }

    fn rendered_window() -> super::YapfastWindow {
        use super::super::*;
        slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
            i_slint_backend_testing::TestingBackendOptions {
                mock_time: true,
                threading: false,
                renderer_name: Some("skia".into()),
            },
        )))
        .unwrap();
        let window = yapfast::window().unwrap();
        Layout::default().apply_appearance(&window);
        window.global::<ClientStyle>().set_interface_motion(false);
        window.set_workspace(true);
        window.set_room_selected(true);
        window.set_room_ready(true);
        window.set_trusted(true);
        window.set_composer_enabled(true);
        window.show().unwrap();
        window
            .window()
            .set_size(slint::LogicalSize::new(1120., 760.));
        window
    }

    fn settle(window: &super::YapfastWindow) {
        use super::super::*;
        for _ in 0..3 {
            i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(100));
            slint::platform::update_timers_and_animations();
            window.window().take_snapshot().unwrap();
        }
    }

    fn visible_named(
        window: &super::YapfastWindow,
        label: &str,
    ) -> Option<i_slint_core::item_tree::ItemRc> {
        use super::super::*;
        use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
        use std::ops::ControlFlow;
        let inner = i_slint_core::window::WindowInner::from_pub(window.window());
        ItemRc::new_root(inner.component()).visit_descendants(|item| {
            if item.is_visible()
                && item
                    .accessible_string_property(AccessibleStringProperty::Label)
                    .as_deref()
                    == Some(label)
            {
                ControlFlow::Break(item.clone())
            } else {
                ControlFlow::Continue(())
            }
        })
    }

    fn control_point(window: &super::YapfastWindow, label: &str) -> slint::LogicalPosition {
        let item = visible_named(window, label)
            .unwrap_or_else(|| panic!("missing visible control: {label}"));
        let at = item.map_to_window(item.geometry().center());
        slint::LogicalPosition::new(at.x, at.y)
    }

    fn pointer(
        window: &super::YapfastWindow,
        position: slint::LogicalPosition,
        button: slint::platform::PointerEventButton,
    ) {
        use super::super::*;
        use slint::platform::WindowEvent;
        window
            .window()
            .dispatch_event(WindowEvent::PointerMoved { position });
        window
            .window()
            .dispatch_event(WindowEvent::PointerPressed { position, button });
        window
            .window()
            .dispatch_event(WindowEvent::PointerReleased { position, button });
        settle(window);
    }

    #[test]
    fn extension_profile_better_upload_button_keeps_menu_and_permissions() {
        use super::super::*;
        use slint::platform::PointerEventButton;
        let window = rendered_window();
        let style = window.global::<ClientStyle>();
        style.set_vencord_mode(true);
        style.set_extension_better_upload_button(true);
        window.set_can_attach(true);
        window.set_can_start_threads(true);
        let files = Rc::new(Cell::new(0));
        let picked = files.clone();
        window.on_attach(move || picked.set(picked.get() + 1));
        settle(&window);
        let at = control_point(&window, "Attach files (right-click for more options)");
        pointer(&window, at, PointerEventButton::Left);
        assert_eq!(
            files.get(),
            1,
            "left click uses the existing file chooser callback"
        );
        let inner = i_slint_core::window::WindowInner::from_pub(window.window());
        assert!(inner.active_popups().is_empty());
        pointer(&window, at, PointerEventButton::Right);
        assert_eq!(files.get(), 1, "right click does not attach");
        assert_eq!(
            inner.active_popups().len(),
            1,
            "the existing plus menu remains available"
        );
        pointer(
            &window,
            slint::LogicalPosition::new(1100., 90.),
            PointerEventButton::Left,
        );
        assert!(inner.active_popups().is_empty());
        style.set_vencord_mode(false);
        settle(&window);
        pointer(
            &window,
            control_point(&window, "More options"),
            PointerEventButton::Left,
        );
        assert_eq!(files.get(), 1, "Vanilla restores the menu on left click");
        assert_eq!(inner.active_popups().len(), 1);
        pointer(
            &window,
            slint::LogicalPosition::new(1100., 90.),
            PointerEventButton::Left,
        );
        style.set_vencord_mode(true);
        window.set_can_attach(false);
        settle(&window);
        pointer(
            &window,
            control_point(&window, "More options"),
            PointerEventButton::Left,
        );
        assert_eq!(
            files.get(),
            1,
            "thread permission does not grant upload permission"
        );
        assert_eq!(inner.active_popups().len(), 1);
        window.hide().unwrap();
    }

    #[test]
    fn extension_profile_image_filename_uses_received_metadata_without_revealing_spoilers() {
        use super::super::*;
        use slint::platform::WindowEvent;
        let window = rendered_window();
        let style = window.global::<ClientStyle>();
        style.set_vencord_mode(true);
        style.set_extension_image_filename(true);
        let mut message = message_row(
            &ChatMessage {
                item: "image:1".into(),
                author: "Synthetic".into(),
                ..Default::default()
            },
            &HashSet::new(),
        );
        message.gallery_width = 180;
        message.gallery_height = 100;
        let mut pixels = slint::SharedPixelBuffer::<slint::Rgba8Pixel>::new(2, 2);
        pixels
            .make_mut_slice()
            .fill(slint::Rgba8Pixel::new(70, 120, 180, 255));
        let cell = ImageCell {
            name: "holiday.png".into(),
            description: "A synthetic image".into(),
            image: slint::Image::from_rgba8(pixels),
            width: 180,
            height: 100,
            ..Default::default()
        };
        let cells = Rc::new(VecModel::from(vec![cell.clone()]));
        message.images = ModelRc::from(cells.clone());
        window.set_messages(ModelRc::new(VecModel::from(vec![message])));
        settle(&window);
        let at = control_point(&window, "A synthetic image");
        window
            .window()
            .dispatch_event(WindowEvent::PointerMoved { position: at });
        settle(&window);
        assert!(
            visible_named(&window, "holiday.png").is_some(),
            "the filename is drawn in the tooltip"
        );
        style.set_vencord_mode(false);
        settle(&window);
        assert!(
            visible_named(&window, "holiday.png").is_none(),
            "Vanilla removes an already-hovered tooltip"
        );
        style.set_vencord_mode(true);
        let mut gif = cell.clone();
        gif.gif = "https://tenor.com/view/synthetic-123".into();
        cells.set_row_data(0, gif);
        settle(&window);
        assert!(visible_named(&window, "https://tenor.com/view/synthetic-123").is_some());
        let mut secret = cell;
        secret.spoiler = true;
        cells.set_row_data(0, secret);
        settle(&window);
        assert!(
            visible_named(&window, "holiday.png").is_none()
                && visible_named(&window, "https://tenor.com/view/synthetic-123").is_none(),
            "hidden spoilers do not leak filenames"
        );
        window.hide().unwrap();
    }

    #[test]
    fn extension_profile_no_typing_animation_stops_only_the_indicator_clock() {
        use super::super::*;
        slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
            i_slint_backend_testing::TestingBackendOptions {
                mock_time: true,
                threading: false,
                renderer_name: Some("skia".into()),
            },
        )))
        .unwrap();
        let window = yapfast::window().unwrap();
        Layout::default().apply_appearance(&window);
        let style = window.global::<ClientStyle>();
        style.set_interface_motion(false);
        window.set_workspace(true);
        window.set_room_selected(true);
        window.set_room_ready(true);
        window.set_trusted(true);
        window.set_typing("Dave is typing…".into());
        window.global::<Motion>().set_playing(true);
        window.show().unwrap();
        window
            .window()
            .set_size(slint::LogicalSize::new(1120., 760.));
        let settle = || {
            for _ in 0..3 {
                i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(100));
                slint::platform::update_timers_and_animations();
                window.window().take_snapshot().unwrap();
            }
            window.window().has_active_animations()
        };
        assert!(settle(), "baseline typing indicator animates");
        style.set_vencord_mode(true);
        style.set_extension_no_typing_animation(true);
        assert!(
            !settle(),
            "the native typing indicator should not keep a clock active"
        );
        assert!(
            window.global::<Motion>().get_playing(),
            "other media retains playback"
        );
        assert_eq!(window.get_typing(), "Dave is typing…");
        style.set_vencord_mode(false);
        assert!(settle(), "Vanilla resumes the baseline typing animation");
        style.set_vencord_mode(true);
        style.set_extension_no_typing_animation(false);
        assert!(settle(), "turning only the plugin off also restores motion");
        window.hide().unwrap();
    }

    #[test]
    fn extension_profile_only_imports_supported_boolean_settings() {
        let (profile, matched) = Profile::from_export(br#"{"settings":{"plugins":{"ClearURLs":{"enabled":true,"code":"ignore"},"SilentTyping":{"enabled":true},"NoReplyMention":{"enabled":true},"Unknown":{"enabled":true}}},"quickCss":"ignore"}"#).unwrap();
        assert_eq!(matched, 3);
        assert!(profile.tracking(false));
        assert!(!profile.typing(true));
        assert!(!profile.reply_mentions(true));
        let vanilla = Profile {
            enabled: false,
            ..profile
        };
        assert!(!vanilla.tracking(false));
        assert!(vanilla.typing(true));
        assert!(vanilla.reply_mentions(true));
        assert!(Profile::from_export(br#"{"plugins":{"ClearURLs":{"enabled":"true"}}}"#).is_err());
        assert!(Profile::from_export(&vec![0; super::MAX_EXPORT as usize + 1]).is_err());
    }

    #[test]
    fn extension_profile_copy_user_urls_imports_and_accepts_only_numeric_people() {
        let (profile, count) = Profile::from_export(
            br#"{"plugins":{"CopyUserURLs":{"enabled":true},"Unknown":{"enabled":true}}}"#,
        )
        .unwrap();
        assert_eq!(count, 1);
        assert_eq!(
            profile.user_url("123456789012345678").as_deref(),
            Some("<https://discord.com/users/123456789012345678>")
        );
        for invalid in [
            "",
            "0",
            "04",
            "-4",
            "4/5",
            "@sam:example.test",
            "discord:10:4",
            "18446744073709551616",
        ] {
            assert!(profile.user_url(invalid).is_none(), "reject {invalid}");
        }
        assert!(
            Profile {
                enabled: false,
                ..profile
            }
            .user_url("4")
            .is_none()
        );
        let (off, count) =
            Profile::from_export(br#"{"settings":{"plugins":{"CopyUserURLs":{"enabled":false}}}}"#)
                .unwrap();
        assert_eq!(count, 1);
        assert!(off.user_url("4").is_none());
        assert!(
            Profile::from_export(br#"{"plugins":{"CopyUserURLs":{"enabled":"true"}}}"#).is_err()
        );
        let old: Profile = serde_json::from_str(r#"{"enabled":true,"clear_urls":true}"#).unwrap();
        assert!(!old.copy_user_urls, "existing preferences do not opt in");
        let restored: Profile =
            serde_json::from_str(&serde_json::to_string(&profile).unwrap()).unwrap();
        assert!(restored == profile);
    }

    #[test]
    #[cfg(feature = "discord")]
    fn extension_profile_copy_user_urls_menu_uses_the_person_and_rechecks_the_switch() {
        use super::super::*;

        i_slint_backend_testing::init_no_event_loop();
        let directory = tempfile::tempdir().unwrap();
        let window = YapfastWindow::new().unwrap();
        let adapter = Adapter::new(
            Arc::new(BackgroundRuntime::new().unwrap()),
            directory.path().into(),
            &window,
        )
        .unwrap();
        bind_callbacks(&window, &adapter);
        {
            let mut adapter = adapter.borrow_mut();
            adapter.app = yapfast_core::application::member_server(&["30"]);
            let mut dm = (*adapter.app.state.rooms[0]).clone();
            dm.id = "discord:@me:700".into();
            dm.direct = true;
            dm.voice = false;
            dm.person = Some("4".into());
            adapter.app.state.rooms.push(Arc::new(dm));
            adapter.layout.developer_mode = false;
            adapter.layout.extensions = Profile {
                enabled: true,
                copy_user_urls: true,
                ..Default::default()
            };
            adapter.layout.extensions.show(&window);
            assert!(Profile::read(&window) == adapter.layout.extensions);
        }
        // TestingBackend owns this clipboard in memory; no OS clipboard is used.
        let clipboard = || {
            i_slint_core::window::WindowInner::from_pub(window.window())
                .context()
                .platform()
                .clipboard_text(i_slint_core::platform::Clipboard::DefaultClipboard)
        };
        let reset_clipboard = || {
            i_slint_core::window::WindowInner::from_pub(window.window())
                .context()
                .platform()
                .set_clipboard_text(
                    "untouched",
                    i_slint_core::platform::Clipboard::DefaultClipboard,
                );
        };
        for (target, person) in [
            ("4", true),
            ("profile-more:4", true),
            ("in-voice:discord:10:12/4", true),
            ("discord:@me:700", false),
        ] {
            reset_clipboard();
            window.invoke_prepare_menu(target.into(), person);
            assert!(
                window
                    .get_menu_rows()
                    .iter()
                    .any(|row| row.id == "copy-user-url"
                        && row.text == "Copy User URL"
                        && !row.disabled),
                "{target} offers a user URL without Developer Mode"
            );
            window.invoke_choose_menu(target.into(), person, "copy-user-url".into());
            assert_eq!(
                clipboard().as_deref(),
                Some("<https://discord.com/users/4>")
            );
        }
        for (target, person) in [
            ("discord:10:11", false),
            ("@sam:example.test", true),
            ("in-voice:discord:999:100/4", true),
        ] {
            reset_clipboard();
            window.invoke_prepare_menu(target.into(), person);
            assert!(
                !window
                    .get_menu_rows()
                    .iter()
                    .any(|row| row.id == "copy-user-url")
            );
            window.invoke_choose_menu(target.into(), person, "copy-user-url".into());
            assert_eq!(
                clipboard().as_deref(),
                Some("untouched"),
                "non-user contexts cannot copy a profile URL"
            );
        }
        for disable_mode in [true, false] {
            reset_clipboard();
            {
                let mut adapter = adapter.borrow_mut();
                adapter.layout.extensions.enabled = true;
                adapter.layout.extensions.copy_user_urls = true;
            }
            window.invoke_prepare_menu("profile-more:4".into(), true);
            {
                let mut adapter = adapter.borrow_mut();
                if disable_mode {
                    adapter.layout.extensions.enabled = false;
                } else {
                    adapter.layout.extensions.copy_user_urls = false;
                }
            }
            window.invoke_choose_menu("profile-more:4".into(), true, "copy-user-url".into());
            window.invoke_prepare_menu("4".into(), true);
            assert!(
                !window
                    .get_menu_rows()
                    .iter()
                    .any(|row| row.id == "copy-user-url")
            );
            assert_eq!(
                clipboard().as_deref(),
                Some("untouched"),
                "a stale menu respects both switches"
            );
        }
    }
}
