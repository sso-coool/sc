//! Real menu callbacks and native thread settings, with no Discord transport.
#![cfg(feature = "discord")]
use super::*;
use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
use slint::platform::{Key, PointerEventButton, WindowEvent};
use std::ops::ControlFlow;
use yapfast_core::yapfast_discord::{
    marked::MarkedServer,
    ready::{self, permission},
    service::{Snapshot, Status},
};

const THREAD: &str = "discord:10:30";

fn fixture() -> (tempfile::TempDir, YapfastWindow, Rc<RefCell<Adapter>>) {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let directory = tempfile::tempdir().unwrap();
    let window = yapfast::window().unwrap();
    let adapter = Adapter::new(
        Arc::new(BackgroundRuntime::new().unwrap()),
        directory.path().into(),
        &window,
    )
    .unwrap();
    bind_callbacks(&window, &adapter);
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<PictureStore>().on_request(|_| {});
    let server = ready::server(&serde_json::json!({
        "id":"10", "owner_id":"99", "properties":{"name":"Thread fixture"},
        "roles":[{"id":"10", "name":"@everyone", "permissions": (permission::VIEW_CHANNEL | permission::READ_MESSAGE_HISTORY | permission::SEND_MESSAGES | permission::SEND_MESSAGES_IN_THREADS | permission::MANAGE_THREADS).to_string()}],
        "channels":[{"id":"11", "type":0, "name":"parent"}],
        "threads":[{"id":"30", "type":12, "name":"Private ticket", "owner_id":"1", "parent_id":"11", "rate_limit_per_user":5,
            "member":{"id":"30", "user_id":"1", "flags":1},
            "thread_metadata":{"archived":false, "locked":false, "invitable":true, "auto_archive_duration":1440}}]
    })).unwrap();
    {
        let mut adapter = adapter.borrow_mut();
        adapter.layout.developer_mode = true;
        adapter.app.apply(Event::Discord(Arc::new(Snapshot {
            status: Status::Online,
            user_id: Some("1".into()),
            servers: vec![MarkedServer::from(server)],
            viewing: vec!["30".into()],
            ..Default::default()
        })));
        adapter
            .app
            .dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
        adapter
            .app
            .dispatch(Action::SelectRoom("discord:10:11".into()));
        adapter.app.apply(Event::Timeline {
            room: "discord:10:11".into(),
            messages: vec![],
        });
        adapter.refresh(&window);
        assert!(adapter.backend.is_none());
    }
    window
        .window()
        .set_size(slint::LogicalSize::new(800., 600.));
    (directory, window, adapter)
}

fn named(window: &YapfastWindow, label: &str) -> ItemRc {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    ItemRc::new_root(inner.component())
        .visit_descendants(|item| {
            if item.is_visible()
                && item
                    .accessible_string_property(AccessibleStringProperty::Label)
                    .as_deref()
                    == Some(label)
            {
                ControlFlow::Break(item.clone())
            } else {
                ControlFlow::Continue(())
            }
        })
        .unwrap_or_else(|| panic!("missing visible thread control: {label}"))
}

fn click(window: &YapfastWindow, label: &str) {
    let item = named(window, label);
    let point = item.map_to_window(item.geometry().center());
    let position = slint::LogicalPosition::new(point.x, point.y);
    window
        .window()
        .dispatch_event(WindowEvent::PointerMoved { position });
    window.window().dispatch_event(WindowEvent::PointerPressed {
        position,
        button: PointerEventButton::Left,
    });
    window
        .window()
        .dispatch_event(WindowEvent::PointerReleased {
            position,
            button: PointerEventButton::Left,
        });
}

#[test]
fn thread_menu_dialog_callbacks_keep_toolbar_and_aside_targets_scoped() {
    let (_directory, window, adapter) = fixture();
    for prefix in ["thread-toolbar:", "thread-sidebar:"] {
        let target = format!("{prefix}{THREAD}");
        window.invoke_prepare_menu(target.clone().into(), false);
        let rows = window.get_menu_rows();
        assert_eq!(rows.row_data(0).unwrap().id, super::favorites::MENU_TOGGLE);
        assert!(rows.iter().any(|row| row.text == "Copy Thread ID"));
        for id in [
            "close-thread",
            "lock-thread",
            "edit-thread",
            "thread-invitable",
            "delete-thread",
        ] {
            assert!(
                rows.iter().any(|row| row.id == id),
                "missing {id} in {prefix}"
            );
        }
        assert!(
            rows.iter()
                .any(|row| row.id == "thread-invitable" && row.checkbox && row.checked)
        );
        assert!(
            rows.iter()
                .any(|row| row.id == "delete-thread" && row.danger)
        );
        window.invoke_choose_menu(target.clone().into(), false, "edit-thread".into());
        assert!(window.get_thread_settings_open());
        assert!(!window.get_thread_settings_prompt().deleting);
        assert!(window.get_thread_settings_prompt().invitable);
        assert!(!window.get_thread_settings_prompt().changed);
        assert_eq!(window.get_thread_settings_name(), "Private ticket");
        window.invoke_thread_settings_input(0, "Renamed ticket".into(), 0);
        window.invoke_thread_settings_input(1, "".into(), 2);
        window.invoke_thread_settings_input(2, "".into(), 3);
        window.invoke_thread_settings_input(5, "".into(), 0);
        {
            let adapter = adapter.borrow();
            let dialog = adapter.app.state.thread_dialog.as_ref().unwrap();
            assert_eq!(dialog.room, THREAD);
            assert_eq!(dialog.name, "Renamed ticket");
            assert_eq!(dialog.slowmode, 10);
            assert_eq!(dialog.archive_minutes, 10080);
            assert_eq!(dialog.invitable, Some(false));
            assert!(!dialog.saving);
            assert_eq!(adapter.app.state.selected.as_deref(), Some("discord:10:11"));
        }
        assert!(window.get_thread_settings_prompt().changed);
        window.invoke_thread_settings_input(8, "".into(), 0);
        assert!(!window.get_thread_settings_prompt().changed);
        assert!(window.get_thread_settings_prompt().invitable);
        assert_eq!(window.get_thread_settings_name(), "Private ticket");
        window.invoke_thread_settings_input(4, "".into(), 0);
        assert!(!window.get_thread_settings_open());
        window.invoke_choose_menu(target.into(), false, "delete-thread".into());
        assert!(window.get_thread_settings_prompt().deleting);
        assert!(
            !adapter
                .borrow()
                .app
                .state
                .thread_dialog
                .as_ref()
                .unwrap()
                .saving,
            "opening confirmation must never delete"
        );
        window.invoke_thread_settings_input(4, "".into(), 0);
        assert!(adapter.borrow().app.state.thread_dialog.is_none());
    }
    window.invoke_prepare_menu(THREAD.into(), false);
    assert_eq!(window.get_menu_rows().row_data(0).unwrap().id, "mark-read");
    assert_eq!(
        window.get_menu_rows().row_data(1).unwrap().id,
        super::favorites::MENU_TOGGLE
    );
    window.invoke_choose_menu(THREAD.into(), false, super::favorites::MENU_TOGGLE.into());
    window.invoke_prepare_menu(THREAD.into(), false);
    assert!(
        window
            .get_menu_rows()
            .iter()
            .any(|row| row.id == super::favorites::MENU_TOGGLE
                && row.text == "Remove from Favorites")
    );
}

#[test]
fn joined_thread_header_exposes_notification_preferences() {
    let (_directory, window, adapter) = fixture();
    {
        let mut adapter = adapter.borrow_mut();
        adapter.app.dispatch(Action::SelectRoom(THREAD.into()));
        assert_eq!(adapter.app.state.selected.as_deref(), Some(THREAD));
        adapter.refresh(&window);
    }
    assert!(window.get_can_notify());
    window.invoke_prepare_menu(format!("notifications:{THREAD}").into(), false);
    let rows = window.get_menu_rows();
    for label in ["Mute thread", "Use channel default", "Only @mentions"] {
        assert!(rows.iter().any(|row| row.text == label), "missing {label}");
    }
}

#[test]
fn thread_menu_dialog_narrow_native_controls_and_explicit_delete_pointer() {
    let (_directory, window, adapter) = fixture();
    window.show().unwrap();
    window.invoke_open_context_menu(format!("thread-toolbar:{THREAD}").into(), false, 780., 570.);
    window.window().take_snapshot().unwrap();
    window.window().dispatch_event(WindowEvent::KeyPressed {
        text: Key::UpArrow.into(),
    });
    window.window().dispatch_event(WindowEvent::KeyReleased {
        text: Key::UpArrow.into(),
    });
    let frame = window.window().take_snapshot().unwrap();
    {
        let inner = i_slint_core::window::WindowInner::from_pub(window.window());
        let popups = inner.active_popups();
        let popup = popups.last().expect("thread context menu is open");
        let i_slint_core::window::PopupWindowLocation::ChildWindow(place) = popup.location else {
            panic!("synthetic popup must be embedded")
        };
        for label in ["Context menu", "Copy Thread ID"] {
            let item = ItemRc::new_root(popup.component.clone())
                .visit_descendants(|item| {
                    if item.is_visible()
                        && item
                            .accessible_string_property(AccessibleStringProperty::Label)
                            .as_deref()
                            == Some(label)
                    {
                        ControlFlow::Break(item.clone())
                    } else {
                        ControlFlow::Continue(())
                    }
                })
                .unwrap_or_else(|| panic!("thread menu missing {label}"));
            let geometry = item.geometry();
            let origin = item.map_to_item_tree(geometry.origin, &popup.component);
            let (x, y) = (place.x + origin.x, place.y + origin.y);
            assert!(
                x >= 0. && y >= 0. && x + geometry.width() <= 801. && y + geometry.height() <= 601.,
                "{label}: {x},{y} {geometry:?}"
            );
        }
    }
    if let Some(directory) = std::env::var_os("SC_REVIEW_DIR") {
        let directory = std::path::Path::new(&directory);
        std::fs::create_dir_all(directory).unwrap();
        image::save_buffer(
            directory.join("thread-menu800.png"),
            frame.as_bytes(),
            frame.width(),
            frame.height(),
            image::ColorType::Rgba8,
        )
        .unwrap();
    }
    window.window().dispatch_event(WindowEvent::KeyPressed {
        text: Key::Escape.into(),
    });
    window.window().dispatch_event(WindowEvent::KeyReleased {
        text: Key::Escape.into(),
    });
    for (choice, title) in [
        ("edit-thread", "Thread settings"),
        ("delete-thread", "Delete thread"),
    ] {
        window.invoke_choose_menu(
            format!("thread-toolbar:{THREAD}").into(),
            false,
            choice.into(),
        );
        let frame = window.window().take_snapshot().unwrap();
        let dialog = named(&window, title);
        let geometry = dialog.geometry();
        let origin = dialog.map_to_window(geometry.origin);
        assert!(
            origin.x >= 0.
                && origin.y >= 0.
                && origin.x + geometry.width() <= 801.
                && origin.y + geometry.height() <= 601.,
            "{title}: {origin:?}, {geometry:?}"
        );
        if let Some(directory) = std::env::var_os("SC_REVIEW_DIR") {
            let directory = std::path::Path::new(&directory);
            std::fs::create_dir_all(directory).unwrap();
            image::save_buffer(
                directory.join(format!("{choice}800.png")),
                frame.as_bytes(),
                frame.width(),
                frame.height(),
                image::ColorType::Rgba8,
            )
            .unwrap();
        }
        if choice == "edit-thread" {
            for label in [
                "Thread name",
                "Slowmode",
                "Hide after inactivity",
                "Anyone can invite",
            ] {
                let _ = named(&window, label);
            }
            click(&window, "Delete Thread");
            assert!(window.get_thread_settings_prompt().deleting);
            assert!(!window.get_thread_settings_prompt().saving);
            window.window().take_snapshot().unwrap();
            click(&window, "Cancel thread settings");
            assert!(!window.get_thread_settings_open());
        } else {
            assert!(
                !adapter
                    .borrow()
                    .app
                    .state
                    .thread_dialog
                    .as_ref()
                    .unwrap()
                    .saving
            );
            click(&window, "Confirm delete thread");
            assert!(
                adapter
                    .borrow()
                    .app
                    .state
                    .thread_dialog
                    .as_ref()
                    .unwrap()
                    .saving
            );
            assert!(
                adapter.borrow().backend.is_none(),
                "synthetic confirmation has no transport"
            );
        }
    }
    window.hide().unwrap();
}
