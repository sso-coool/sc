//! In-app Windows release checks and the user-authorized update handoff.
use super::*;
use crate::sc_update::{self, Prepared, Release};

// Retained so notifications from an older build can still open About.
pub(super) const ABOUT: &str = "yapfast:about";
const INTERVAL: Duration = Duration::from_secs(6 * 60 * 60);

#[derive(Default)]
pub(super) struct State {
    found: Option<Result<Option<Release>, String>>,
    checking: bool,
    timer: slint::Timer,
    install_timer: slint::Timer,
    installing: bool,
    install_error: String,
    hidden: Option<String>,
    pub(super) prepared: Option<Prepared>,
}

fn checking_enabled(layout: &Layout) -> bool {
    layout
        .sc_check_for_updates
        .unwrap_or(cfg!(all(windows, target_arch = "x86_64")))
}

fn available(state: &State) -> Option<&Release> {
    state.found.as_ref()?.as_ref().ok()?.as_ref()
}

pub(super) fn show(window: &YapfastWindow, layout: &Layout, state: &State, root: &std::path::Path) {
    let shown = window.global::<Updates>();
    let check = checking_enabled(layout);
    shown.set_check(check);
    let release = available(state);
    let skipped =
        release.is_some_and(|release| layout.skipped_update.as_deref() == Some(&release.tag));
    let status = match &state.found {
        _ if state.checking => UpdateStatus::Checking,
        None => UpdateStatus::Idle,
        Some(Err(_)) => UpdateStatus::Failed,
        Some(Ok(None)) => UpdateStatus::Current,
        Some(Ok(Some(_))) if skipped => UpdateStatus::Skipped,
        Some(Ok(Some(_))) => UpdateStatus::Available,
    };
    shown.set_status(status);
    shown.set_notice_visible(
        state.installing
            || (check
                && release.is_some_and(|r| state.hidden.as_deref() != Some(&r.tag))
                && !skipped),
    );
    shown.set_latest(release.map_or("", |r| &r.tag).into());
    shown.set_notes(release.map_or("", |r| &r.notes).into());
    shown.set_error(
        match &state.found {
            Some(Err(error)) => error.as_str(),
            _ => "",
        }
        .into(),
    );
    let result = release.filter(|_| !state.installing).map(|release| {
        sc_update::install_directory(root).map(|_| release.bytes.div_ceil(1_000_000))
    });
    shown.set_can_install(!state.installing && matches!(&result, Some(Ok(_))));
    shown.set_install_note(
        match result {
            Some(Ok(mb)) => format!(
                "{mb} MB. S;C downloads first, then restarts. Restarting leaves any active call."
            ),
            Some(Err(why)) => why,
            None => String::new(),
        }
        .into(),
    );
    shown.set_install_error(state.install_error.as_str().into());
    shown.set_installing(state.installing);
    shown.set_can_cancel(false);
    shown.set_install_progress(-1.0);
    shown.set_install_text(
        if state.prepared.is_some() {
            "Restarting…"
        } else {
            "Downloading and verifying the update…"
        }
        .into(),
    );
}

fn show_state(adapter: &Adapter) {
    if let Some(window) = adapter.window.upgrade() {
        show(&window, &adapter.layout, &adapter.updates, &adapter.root);
    }
}

fn look(adapter: &Rc<RefCell<Adapter>>) {
    let mut guard = adapter.borrow_mut();
    if guard.updates.checking || guard.updates.installing {
        return;
    }
    guard.updates.checking = true;
    show_state(&guard);
    let task = guard.runtime.spawn(sc_update::check());
    drop(guard);
    let weak = Rc::downgrade(adapter);
    if slint::spawn_local(async move {
        let found = task
            .await
            .unwrap_or_else(|_| Err("The update check stopped.".into()));
        if let Some(adapter) = weak.upgrade() {
            let mut state = adapter.borrow_mut();
            state.updates.checking = false;
            if available(&state.updates).map(|r| &r.tag)
                != found.as_ref().ok().and_then(Option::as_ref).map(|r| &r.tag)
            {
                state.updates.install_error.clear();
            }
            state.updates.found = Some(found);
            show_state(&state);
        }
    })
    .is_err()
    {
        let mut state = adapter.borrow_mut();
        state.updates.checking = false;
        state.updates.found = Some(Err("The update check couldn't start.".into()));
        show_state(&state);
    }
}

fn start_install(adapter: &Rc<RefCell<Adapter>>) {
    let mut guard = adapter.borrow_mut();
    if guard.updates.installing || guard.updates.checking {
        return;
    }
    let Some(release) = available(&guard.updates) else {
        return;
    };
    let tag = release.tag.clone();
    guard.updates.install_error.clear();
    guard.updates.installing = true;
    show_state(&guard);
    let root = guard.root.clone();
    let (send, work) = std::sync::mpsc::channel();
    if std::thread::Builder::new()
        .name("sc-update".into())
        .spawn(move || {
            let _ = send.send(sc_update::stage(&tag, &root));
        })
        .is_err()
    {
        guard.updates.installing = false;
        guard.updates.install_error = "The update couldn't start.".into();
        show_state(&guard);
        return;
    }
    let weak = Rc::downgrade(adapter);
    guard.updates.install_timer.start(slint::TimerMode::Repeated, Duration::from_millis(250), move || {
        let result = match work.try_recv() {
            Ok(result) => result,
            Err(std::sync::mpsc::TryRecvError::Empty) => return,
            Err(std::sync::mpsc::TryRecvError::Disconnected) => Err("The update stopped while downloading.".into()),
        };
        let Some(adapter) = weak.upgrade() else {
            return;
        };
        let mut state = adapter.borrow_mut();
        state.updates.install_timer.stop();
        match result {
            Ok(prepared) => {
                state.layout.write(&state.root);
                state.updates.prepared = Some(prepared);
                if slint::quit_event_loop().is_err() {
                    state.updates.prepared = None;
                    state.updates.installing = false;
                    state.updates.install_error = "Couldn't restart S;C. Try again later.".into();
                }
            }
            Err(error) => {
                state.updates.install_error = error;
                state.updates.installing = false;
            }
        }
        show_state(&state);
    });
}

pub(super) fn start(adapter: &Rc<RefCell<Adapter>>, window: &YapfastWindow) {
    {
        let state = adapter.borrow();
        show(window, &state.layout, &state.updates, &state.root);
        let weak = Rc::downgrade(adapter);
        state
            .updates
            .timer
            .start(slint::TimerMode::Repeated, INTERVAL, move || {
                if let Some(adapter) = weak.upgrade()
                    && checking_enabled(&adapter.borrow().layout)
                {
                    look(&adapter);
                }
            });
    }
    let weak = Rc::downgrade(adapter);
    slint::Timer::single_shot(Duration::from_secs(5), move || {
        if let Some(adapter) = weak.upgrade()
            && checking_enabled(&adapter.borrow().layout)
        {
            look(&adapter);
        }
    });
}

pub(super) fn bind(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    let shown = window.global::<Updates>();
    let (state, weak) = (adapter.clone(), window.as_weak());
    shown.on_preferences_changed(move || {
        let Some(window) = weak.upgrade() else { return };
        let check = window.global::<Updates>().get_check();
        {
            let mut adapter = state.borrow_mut();
            adapter.layout.sc_check_for_updates = Some(check);
            adapter.layout.write(&adapter.root);
            show_state(&adapter);
        }
        if check {
            look(&state);
        }
    });
    let state = adapter.clone();
    shown.on_check_now(move || look(&state));
    let state = adapter.clone();
    shown.on_dismiss_notice(move || {
        let mut adapter = state.borrow_mut();
        adapter.updates.hidden = available(&adapter.updates).map(|r| r.tag.clone());
        show_state(&adapter);
    });
    let state = adapter.clone();
    shown.on_skip(move || {
        let mut adapter = state.borrow_mut();
        if let Some(release) = available(&adapter.updates) {
            adapter.layout.skipped_update = Some(release.tag.clone());
            adapter.layout.write(&adapter.root);
        }
        show_state(&adapter);
    });
    let state = adapter.clone();
    shown.on_view(move || {
        if let Some(release) = available(&state.borrow().updates) {
            browser::open(&sc_update::page(release));
        }
    });
    let state = adapter.clone();
    shown.on_install(move || start_install(&state));
    shown.on_open_website(|| browser::open(sc_update::RELEASES));
    shown.on_open_github(|| browser::open("https://github.com/sso-coool/sc"));
}
