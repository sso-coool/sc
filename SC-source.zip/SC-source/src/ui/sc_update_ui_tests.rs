//! Native update controls with a synthetic release and captured callbacks only.
//! No GitHub request, process restart, installed files or account are involved.
use super::*;
use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
use slint::platform::{PointerEventButton, WindowEvent};
use std::{ops::ControlFlow, path::Path};

const CARD: &str = "S;C update available";

fn fixture() -> (YapfastWindow, Rc<RefCell<Vec<&'static str>>>) {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let window = yapfast::window().unwrap();
    Layout::default().apply_appearance(&window);
    title_bar::show(&window, Some(false));
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<PictureStore>().on_request(|_| {});
    window.set_workspace(true);
    window.set_trusted(true);
    window.set_sidebar_title("Synthetic update preview".into());
    window.set_room_selected(true);
    window.set_room_ready(true);
    window.set_room_name("release-preview".into());
    window
        .global::<BuildInfo>()
        .set_headline("S;C 0.3.0.7".into());
    window.global::<BuildInfo>().set_channel("Stable".into());
    let updates = window.global::<Updates>();
    updates.set_status(UpdateStatus::Available);
    updates.set_latest("v0.3.0.99".into());
    updates.set_notes(
        "Synthetic release for native UI checks.\n\n• Clearer update controls\n• Small visual improvements\n\nThis fixture never downloads or installs anything."
            .into(),
    );
    updates.set_can_install(true);
    updates.set_notice_visible(true);
    let calls = Rc::new(RefCell::new(Vec::new()));
    let captured = calls.clone();
    let weak = window.as_weak();
    updates.on_dismiss_notice(move || {
        captured.borrow_mut().push("dismiss");
        weak.upgrade()
            .unwrap()
            .global::<Updates>()
            .set_notice_visible(false);
    });
    let captured = calls.clone();
    let weak = window.as_weak();
    updates.on_skip(move || {
        captured.borrow_mut().push("skip");
        let window = weak.upgrade().unwrap();
        let updates = window.global::<Updates>();
        updates.set_notice_visible(false);
        updates.set_status(UpdateStatus::Skipped);
    });
    let captured = calls.clone();
    updates.on_install(move || captured.borrow_mut().push("install"));
    let captured = calls.clone();
    updates.on_view(move || captured.borrow_mut().push("view"));
    let captured = calls.clone();
    updates.on_check_now(move || captured.borrow_mut().push("check"));
    let captured = calls.clone();
    updates.on_preferences_changed(move || captured.borrow_mut().push("preferences"));
    let captured = calls.clone();
    updates.on_cancel_install(move || captured.borrow_mut().push("cancel"));
    window.show().unwrap();
    (window, calls)
}

fn named(window: &YapfastWindow, label: &str) -> Option<ItemRc> {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    ItemRc::new_root(inner.component()).visit_descendants(|item| {
        if item.is_visible()
            && item
                .accessible_string_property(AccessibleStringProperty::Label)
                .as_deref()
                == Some(label)
        {
            ControlFlow::Break(item.clone())
        } else {
            ControlFlow::Continue(())
        }
    })
}

fn settle(window: &YapfastWindow) {
    for _ in 0..3 {
        window.window().take_snapshot().unwrap();
        i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(300));
        slint::platform::update_timers_and_animations();
    }
}

fn bounds(item: &ItemRc) -> (f32, f32, f32, f32) {
    let geometry = item.geometry();
    let at = item.map_to_window(geometry.origin);
    (
        at.x,
        at.y,
        at.x + geometry.width(),
        at.y + geometry.height(),
    )
}

fn click(window: &YapfastWindow, label: &str) {
    let item = named(window, label).unwrap_or_else(|| panic!("missing update control: {label}"));
    let (left, top, right, bottom) = bounds(&item);
    assert!(
        right > left && bottom > top,
        "{label} has real pointer bounds"
    );
    let size = window.window().size();
    assert!(
        left >= 0. && top >= 0. && right <= size.width as f32 && bottom <= size.height as f32,
        "{label} must be on screen: {left},{top}..{right},{bottom}"
    );
    let position = slint::LogicalPosition::new((left + right) / 2., (top + bottom) / 2.);
    window
        .window()
        .dispatch_event(WindowEvent::PointerMoved { position });
    window.window().dispatch_event(WindowEvent::PointerPressed {
        position,
        button: PointerEventButton::Left,
    });
    window
        .window()
        .dispatch_event(WindowEvent::PointerReleased {
            position,
            button: PointerEventButton::Left,
        });
    settle(window);
}

fn capture(window: &YapfastWindow, name: &str) {
    if let Some(dir) = std::env::var_os("SC_REVIEW_DIR") {
        std::fs::create_dir_all(&dir).unwrap();
        let frame = window.window().take_snapshot().unwrap();
        image::save_buffer(
            Path::new(&dir).join(name),
            frame.as_bytes(),
            frame.width(),
            frame.height(),
            image::ColorType::Rgba8,
        )
        .unwrap();
    }
}

#[test]
fn sc_update_card_native_actions_fit_and_hide_in_settings() {
    let (window, calls) = fixture();
    for (width, height) in [(800., 600.), (1120., 760.)] {
        window
            .window()
            .set_size(slint::LogicalSize::new(width, height));
        settle(&window);
        let card = named(&window, CARD).expect("the available release has a visible card");
        let (left, top, right, bottom) = bounds(&card);
        assert!(left >= 8. && top >= 50. && right <= width - 8. && bottom <= height - 8.);
        for label in ["Update and restart", "Disregard", "Dismiss update notice"] {
            let (x, y, end, lower) = bounds(&named(&window, label).unwrap());
            assert!(
                x >= left && y >= top && end <= right && lower <= bottom,
                "{label} fits the card at {width}"
            );
        }
        assert!(
            calls.borrow().is_empty(),
            "rendering never checks, installs or restarts"
        );
        capture(&window, &format!("sc-update-card{}.png", width as u32));
    }
    click(&window, "Dismiss update notice");
    assert_eq!(&*calls.borrow(), &["dismiss"]);
    assert!(named(&window, CARD).is_none());

    window.global::<Updates>().set_notice_visible(true);
    settle(&window);
    click(&window, "Disregard");
    assert_eq!(&*calls.borrow(), &["dismiss", "skip"]);
    assert!(named(&window, CARD).is_none());

    let updates = window.global::<Updates>();
    updates.set_notice_visible(true);
    updates.set_status(UpdateStatus::Available);
    settle(&window);
    click(&window, "Update and restart");
    assert_eq!(calls.borrow().last(), Some(&"install"));

    updates.set_can_install(false);
    settle(&window);
    assert!(named(&window, "Update and restart").is_none());
    click(&window, "View release");
    assert_eq!(calls.borrow().last(), Some(&"view"));
    capture(&window, "sc-update-card-manual1120.png");

    window.set_settings_section(9);
    window.set_settings_open(true);
    settle(&window);
    assert!(
        updates.get_notice_visible(),
        "opening Settings does not discard the release"
    );
    assert!(
        named(&window, CARD).is_none(),
        "About owns the update controls while Settings is open"
    );
    window.set_settings_open(false);
    settle(&window);
    assert!(named(&window, CARD).is_some());

    updates.set_installing(true);
    updates.set_install_text("Verifying the download…".into());
    updates.set_can_cancel(true);
    settle(&window);
    assert!(named(&window, "Update and restart").is_none());
    assert!(named(&window, "Disregard").is_none());
    click(&window, "Cancel download");
    assert_eq!(calls.borrow().last(), Some(&"cancel"));
    window.window().dispatch_event(WindowEvent::PointerExited);
    settle(&window);
    assert!(
        !window.window().has_active_animations(),
        "a progress label needs no idle animation"
    );
    window.hide().unwrap();
}

#[test]
fn sc_update_about_native_check_and_explicit_install_controls() {
    let (window, calls) = fixture();
    window
        .window()
        .set_size(slint::LogicalSize::new(1600., 1000.));
    window.set_settings_section(9);
    window.set_settings_open(true);
    settle(&window);
    assert!(named(&window, CARD).is_none());
    capture(&window, "sc-update-about1600.png");
    click(&window, "Check now");
    assert_eq!(&*calls.borrow(), &["check"]);
    click(&window, "Check for updates");
    assert!(window.global::<Updates>().get_check());
    assert_eq!(calls.borrow().last(), Some(&"preferences"));
    click(&window, "Update and restart");
    assert_eq!(calls.borrow().last(), Some(&"install"));
    window
        .global::<Updates>()
        .set_status(UpdateStatus::Checking);
    settle(&window);
    click(&window, "Checking…");
    assert_eq!(
        calls
            .borrow()
            .iter()
            .filter(|call| **call == "check")
            .count(),
        1,
        "a pending check cannot be submitted again"
    );
    window.hide().unwrap();
}
