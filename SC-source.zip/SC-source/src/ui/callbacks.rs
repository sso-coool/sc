//! What the window's callbacks do: most dispatch an action to the application.

use super::*;

use super::emoji_grid::{FETCH_ROWS, GRID_ROWS};

/// The rows either side of those shown that the picker makes ready: their
/// pictures are drawn and their custom emoji's fetched before a scroll brings
/// them into sight, so a row arrives as it draws and never fills in. A screen
/// either way, since the grid shows [`GRID_ROWS`] of them.
///
/// They're kept for as long as they're ready, and a row further off lets go of
/// its own: three screens of pictures are 5 MiB on a display of twice the
/// scale, against the 36 MiB the whole list would take.
const READY_ROWS: usize = GRID_ROWS;

/// A native file picker may outlive the bot form or account that opened it.
#[derive(Clone, PartialEq, Eq)]
struct ModalFileTarget {
    account: Option<String>,
    discord_user: Option<String>,
    modal_id: String,
    application_id: String,
    channel_id: String,
    custom_id: String,
    field_id: String,
    index: usize,
}

impl ModalFileTarget {
    fn capture(state: &AppState, index: usize) -> Option<Self> {
        let modal = state
            .interaction_modal
            .as_ref()
            .filter(|modal| !modal.saving())?;
        let field = modal.fields.get(index).filter(|field| field.kind == 19)?;
        Some(Self {
            account: state.account.clone(),
            discord_user: state.discord_user.clone(),
            modal_id: modal.id.clone(),
            application_id: modal.application_id.clone(),
            channel_id: modal.channel_id.clone(),
            custom_id: modal.custom_id.clone(),
            field_id: field.custom_id.clone(),
            index,
        })
    }

    fn returned(&self, state: &AppState, files: Vec<std::path::PathBuf>) -> Option<Action> {
        (Self::capture(state, self.index).as_ref() == Some(self)).then_some(Action::AddModalFiles {
            index: self.index,
            files,
        })
    }
}

/// The rows the picker makes ready, around those shown between `first` and
/// `last`: a scroll into them finds them drawn.
fn ready_rows(first: usize, last: usize) -> (usize, usize) {
    (
        first.saturating_sub(READY_ROWS),
        last.saturating_add(READY_ROWS),
    )
}

/// Fetches the pictures of the custom emoji in the rows [`FETCH_ROWS`] either
/// side of those shown between `first` and `last` that have none yet, those
/// this account may not use where it is looking too, as they show greyed. The
/// picker brings the rest as it scrolls them in, since a server list can hold
/// more emoji than fit in memory at once.
fn fetch_shown_pictures(adapter: &mut Adapter, window: &YapfastWindow, first: usize, last: usize) {
    let ids = custom_ids_to_fetch(&adapter.models.emoji_rows, first, last, FETCH_ROWS);
    request_custom_pictures(adapter, window, &ids);
}

/// Lets go of the custom emoji pictures of the rows further than [`FETCH_ROWS`]
/// from those shown between `first` and `last`: their cells', the copies kept
/// to make cells, the downloads not yet come, and the application's. So scrolling through every server's emoji holds a few
/// screens of them however far it goes, as Twemoji's do, and a row scrolled
/// back to asks for them again, from the disk cache.
fn let_go_of_far_emoji(adapter: &mut Adapter, window: &YapfastWindow, first: usize, last: usize) {
    let rows = &adapter.models.emoji_rows;
    let count = rows.row_count();
    if count == 0 || first >= count {
        return;
    }
    let (from, to) = (
        first.saturating_sub(FETCH_ROWS),
        last.saturating_add(FETCH_ROWS).min(count - 1),
    );
    let id = |key: &str| key.rsplit_once(':').map(|(_, id)| id.to_owned());
    // The ids near, and those the rail's buttons show.
    let mut near: HashSet<String> = HashSet::new();
    for index in from..=to {
        if let Some(row) = rows.row_data(index) {
            near.extend(row.cells.iter().filter_map(|cell| id(&cell.key)));
        }
    }
    near.extend(
        adapter
            .models
            .emoji_sections
            .iter()
            .filter_map(|section| id(&section.icon.key)),
    );
    if let Some((held_from, held_to)) = adapter.emoji_grid.custom_held {
        for index in held_from..=held_to.min(count - 1) {
            if (from..=to).contains(&index) {
                continue;
            }
            let Some(row) = rows.row_data(index) else {
                continue;
            };
            for cell_index in 0..row.cells.row_count() {
                let Some(cell) = row.cells.row_data(cell_index) else {
                    continue;
                };
                if cell.picture.size().width > 0
                    && id(&cell.key).is_some_and(|id| !near.contains(&id))
                {
                    row.cells.set_row_data(
                        cell_index,
                        EmojiCell {
                            picture: Default::default(),
                            ..cell
                        },
                    );
                }
            }
        }
    }
    adapter.emoji_grid.custom_held = Some((from, to));
    custom_emoji::forget_images_except(&near);
    adapter.emoji_grid.wanted.retain(|id, _| near.contains(id));
    // Pending downloads count too: on a fast scroll none may have completed
    // yet. Waiting for a decoded-picture threshold let obsolete requests pile
    // up, decoding what the picker had already scrolled past.
    let keep: Vec<String> = adapter
        .app
        .emoji_by_id(&near.iter().map(String::as_str).collect())
        .into_iter()
        .map(|emoji| emoji.picture)
        .collect();
    adapter.action(window, Action::KeepEmojiPictures(keep));
}

/// Makes the rows shown between `first` and `last` and those around them
/// ready: the custom emoji's pictures asked for three screens out, Twemoji's
/// drawn a screen out, the animations of those near decoded, and the grid
/// given what is in sight.
fn prepare_emoji_rows(adapter: &mut Adapter, window: &YapfastWindow, first: usize, last: usize) {
    let_go_of_far_emoji(adapter, window, first, last);
    fetch_shown_pictures(adapter, window, first, last);
    // Those already in memory, which no arrival brings, show now.
    adapter.show_arrived_emoji();
    let (from, to) = ready_rows(first, last);
    fill_shown_glyphs(window, adapter, from, to);
    want_shown_animations(adapter, window);
    adapter.publish_emoji_grid();
}

/// Decodes the animations of the custom emoji in the rows ready around those
/// shown, so the grid moves without waiting for a message to show them first.
/// Called again as pictures arrive: an animation decodes from its picture, so
/// one whose picture had not come yet when its row scrolled in starts then.
pub(super) fn want_shown_animations(adapter: &mut Adapter, window: &YapfastWindow) {
    let (first, last) = adapter.emoji_grid.shown;
    let (first, last) = ready_rows(first, last);
    let rows = &adapter.models.emoji_rows;
    let count = rows.row_count();
    if count == 0 || first >= count {
        adapter
            .animations
            .also(std::iter::empty(), &adapter.app.state.pictures);
        adapter.run_emoji_animations(window);
        return;
    }
    let mut shown: HashSet<SharedString> = HashSet::new();
    for index in first..=last.min(count - 1) {
        if let Some(row) = rows.row_data(index) {
            shown.extend(
                row.cells
                    .iter()
                    .map(|cell| cell.key)
                    .filter(|key| key.contains(':')),
            );
        }
    }
    // An empty set replaces the previous picker rows too, so scrolling into
    // Unicode emoji stops work for the custom emoji left behind.
    // Only those shown are made, by their ids, rather than every server's
    // emoji at each scroll.
    let ids: HashSet<&str> = shown
        .iter()
        .filter_map(|key| key.rsplit_once(':').map(|(_, id)| id))
        .collect();
    let jobs: Vec<(String, Option<char>, String)> = adapter
        .app
        .emoji_by_id(&ids)
        .into_iter()
        .filter(|emoji| emoji.animated)
        .map(|emoji| {
            (
                emoji::custom_key(&emoji),
                custom_emoji::glyph(&emoji.id),
                emoji.picture,
            )
        })
        .collect();
    let pictures = &adapter.app.state.pictures;
    adapter.animations.also(jobs, pictures);
    // Picker actions and picture arrivals are deliberately quiet: they do
    // not cause a full refresh to start the decoder or restart its timer.
    adapter.run_emoji_animations(window);
}

/// The rail's own icons, which are unicode glyphs unless a server's icon or a
/// custom emoji's picture came: Twemoji's, as its grid draws them, at the 32px
/// the rail shows them.
fn fill_rail_glyphs(window: &YapfastWindow, adapter: &Adapter) {
    let scale = window.window().scale_factor();
    let rail = &adapter.models.emoji_rail;
    for index in 0..rail.row_count() {
        let Some(section) = rail.row_data(index) else {
            continue;
        };
        if section.glyph != SectionGlyph::None {
            continue;
        }
        let icon = section.icon;
        if icon.picture.size().width > 0 || icon.key.contains(':') || icon.glyph != icon.key {
            continue;
        }
        if let Some(image) = crate::twemoji::picture(&icon.glyph, emoji::RAIL_GLYPH, scale) {
            rail.set_row_data(
                index,
                RailSection {
                    icon: EmojiCell {
                        picture: image,
                        ..icon
                    },
                    ..section
                },
            );
        }
    }
}

/// The icons of the picker's sections that came since the rail and the grid
/// were built: a server's own, or, for one without, its first emoji's. The rail
/// and the headings draw them then, as the sticker picker's do; until then a
/// button is a quiet square.
pub(super) fn fill_picker_icons(adapter: &Adapter) {
    let rail = &adapter.models.emoji_rail;
    let rows = &adapter.models.emoji_rows;
    let sections = &adapter.models.emoji_sections;
    for index in 0..sections.row_count() {
        let Some(section) = sections.row_data(index) else {
            continue;
        };
        // Matches have no headings, and the rail keeps the sections it jumps
        // back to.
        let came = if section.icon_url.is_empty() {
            Some(section.icon.picture.clone()).filter(|picture| picture.size().width > 0)
        } else {
            adapter
                .app
                .state
                .pictures
                .get(section.icon_url.as_str())
                .map(|source| picture(source))
        };
        let Some(came) = came else {
            continue;
        };
        if let Some(button) = rail.row_data(index)
            && button.name == section.icon.name
            && button.icon.picture.size().width == 0
        {
            rail.set_row_data(
                index,
                RailSection {
                    icon: EmojiCell {
                        picture: came.clone(),
                        ..button.icon
                    },
                    ..button
                },
            );
        }
        let row = section.heading.max(0) as usize;
        if let Some(heading) = rows.row_data(row)
            && heading.heading == section.icon.name
            && heading.icon.size().width == 0
        {
            rows.set_row_data(
                row,
                EmojiRow {
                    icon: came,
                    ..heading
                },
            );
        }
    }
}

/// Asks for the pictures of the custom emoji with these ids, in their order,
/// ahead of those asked for before, and keeps them wanted until they come.
fn request_custom_pictures(adapter: &mut Adapter, window: &YapfastWindow, ids: &[String]) {
    if ids.is_empty() {
        return;
    }
    let mut pictures: HashMap<String, String> = adapter
        .app
        .emoji_by_id(&ids.iter().map(String::as_str).collect())
        .into_iter()
        .map(|emoji| (emoji.id, emoji.picture))
        .collect();
    // Each is wanted until its picture comes, which then shows at once; see
    // `show_emoji_pictures`.
    let mut ordered = Vec::new();
    for id in ids {
        if let Some(url) = pictures.remove(id) {
            adapter.emoji_grid.wanted.insert(id.clone(), url.clone());
            ordered.push(url);
        }
    }
    if !ordered.is_empty() {
        adapter.action(window, Action::LoadPicturesFirst(ordered));
    }
}

/// Gives the picker's grid the emoji it shows between `first` and `last` rows a
/// picture each, Twemoji's, decoded once, so scrolling draws a bitmap.
fn fill_shown_glyphs(window: &YapfastWindow, adapter: &mut Adapter, first: usize, last: usize) {
    fill_rail_glyphs(window, adapter);
    fill_picker_icons(adapter);
    let scale = window.window().scale_factor();
    let_go_of_far_glyphs(adapter, first, last);
    let rows = &adapter.models.emoji_rows;
    let count = rows.row_count();
    if count == 0 || first >= count {
        return;
    }
    for index in first..=last.min(count - 1) {
        let Some(row) = rows.row_data(index) else {
            continue;
        };
        for cell_index in 0..row.cells.row_count() {
            let Some(cell) = row.cells.row_data(cell_index) else {
                continue;
            };
            // A custom emoji draws its own picture, and a cell whose glyph is a
            // name rather than an emoji has nothing to draw.
            if cell.picture.size().width > 0 || cell.key.contains(':') || cell.glyph != cell.key {
                continue;
            }
            // Twemoji's picture, as Discord's client draws emoji; the grid lists
            // only emoji Twemoji has one for.
            if let Some(image) = crate::twemoji::picture(&cell.glyph, emoji::GLYPH, scale) {
                row.cells.set_row_data(
                    cell_index,
                    EmojiCell {
                        picture: image,

                        usable: true,
                        ..cell
                    },
                );
            }
        }
    }
}

/// Takes the pictures [`fill_shown_glyphs`] gave back from the rows it did not
/// make ready: `first` and `last` are the rows it filled, and a row outside
/// them lets go of its own. It looks only at the rows that may hold one, so a
/// scroll costs what it moved past.
fn let_go_of_far_glyphs(adapter: &mut Adapter, first: usize, last: usize) {
    let (from, to) = adapter.emoji_rows_filled;
    let rows = &adapter.models.emoji_rows;
    let last = last.min(rows.row_count().saturating_sub(1));
    for index in from..=to.min(rows.row_count().saturating_sub(1)) {
        if (first..=last).contains(&index) {
            continue;
        }
        let Some(row) = rows.row_data(index) else {
            continue;
        };
        for cell_index in 0..row.cells.row_count() {
            let Some(cell) = row.cells.row_data(cell_index) else {
                continue;
            };
            // As in filling: a custom emoji's picture isn't this one's to take.
            if cell.picture.size().width > 0 && !cell.key.contains(':') && cell.glyph == cell.key {
                row.cells.set_row_data(
                    cell_index,
                    EmojiCell {
                        picture: Default::default(),
                        ..cell
                    },
                );
            }
        }
    }
    adapter.emoji_rows_filled = (first, last);
}

/// The ids of the custom emoji without a picture yet in the rows shown,
/// `first` to `last`, and `around` rows either side, nearest first: those
/// shown, then a row below and a row above in turn, as Discord's downloads go
/// a few at a time. The picker asks for these as it shows them.
pub(super) fn custom_ids_to_fetch(
    rows: &VecModel<EmojiRow>,
    first: usize,
    last: usize,
    around: usize,
) -> Vec<String> {
    let count = rows.row_count();
    if count == 0 || first >= count {
        return Vec::new();
    }
    let last = last.min(count - 1);
    let mut order: Vec<usize> = (first..=last).collect();
    for step in 1..=around {
        if last + step < count {
            order.push(last + step);
        }
        if let Some(above) = first.checked_sub(step) {
            order.push(above);
        }
    }
    let mut ids = Vec::new();
    for index in order {
        let Some(row) = rows.row_data(index) else {
            continue;
        };
        // A custom emoji's reaction key is `name:id`; a Unicode one is the
        // glyph itself.
        ids.extend(
            row.cells
                .iter()
                .filter(|cell| cell.picture.size().width == 0)
                .filter_map(|cell| Some(cell.key.rsplit_once(':')?.1.to_owned())),
        );
    }
    ids
}

thread_local! {
    /// The Discord account's favourite emoji, by picker key, which the
    /// picker's stars ask about as they draw.
    static EMOJI_FAVORITES: std::cell::RefCell<std::collections::HashSet<String>> =
        std::cell::RefCell::default();
}

/// The picker's stars, from the Discord account's favourites: `favorites`,
/// by picker key.
fn show_emoji_stars(window: &YapfastWindow, favorites: &[(String, bool)]) {
    EMOJI_FAVORITES.with_borrow_mut(|set| {
        set.clear();
        set.extend(favorites.iter().map(|(key, _)| key.clone()));
    });
    let global = window.global::<EmojiFavorites>();
    global.set_revision(global.get_revision().wrapping_add(1));
}

/// Gives the picker's grid the emoji `query` finds, `columns` to a row, and
/// fetches the pictures of the custom emoji it shows.
fn show_emoji(adapter: &Rc<RefCell<Adapter>>, window: &YapfastWindow, query: &str, columns: usize) {
    let mut adapter = adapter.borrow_mut();
    let (rows, sections) = {
        let custom = adapter.app.emoji_sets();
        // Closing the picker let go of the images made from the pictures still
        // kept, which won't arrive again.
        custom_emoji::add_images(
            custom
                .iter()
                .flat_map(|set| &set.emoji)
                .filter_map(|emoji| super::refresh::arrived(&adapter.app.state, emoji)),
        );
        // Discord's favourites and frequents form the empty picker's sections
        // and break relevance ties during search, including reaction context.
        let (favorites, frequent) = {
            let by_id: HashMap<&str, &yapfast_core::chat::CustomEmoji> = custom
                .iter()
                .flat_map(|set| &set.emoji)
                .map(|emoji| (emoji.id.as_str(), emoji))
                .collect();
            let lists = &adapter.app.state.discord_emojis;
            let item = window.get_react_item();
            let used = if item.is_empty() || item.starts_with("yapfast:") {
                &lists.frequent
            } else {
                &lists.reactions
            };
            let mut frequent = emoji::discord_keys(used, &by_id);
            for key in adapter.app.frequent_reactions(16) {
                if !frequent.iter().any(|(known, _)| *known == key) {
                    frequent.push((key, true));
                }
            }
            (emoji::discord_keys(&lists.favorites, &by_id), frequent)
        };
        // A search lists no Favorites, and keeps the stars it had.
        if query.trim().trim_matches(':').is_empty() {
            show_emoji_stars(window, &favorites);
        }
        emoji::rows(query, &favorites, &frequent, &custom, columns, |set| {
            let url = set.icon.clone()?;
            let icon = adapter.app.state.pictures.get(&url)?;
            Some((url, picture(icon)))
        })
    };
    // The rail lists the same sections the grid has, at the rows they start
    // and end at; matches have none, and it keeps those it jumps back to.
    if !sections.is_empty() {
        let rail: Vec<RailSection> = sections
            .iter()
            .map(|section| RailSection {
                name: section.icon.name.clone(),
                icon: section.icon.clone(),
                // The sticker picker's clock, for the one heading both share.
                glyph: emoji::section_glyph(section.icon.name.as_str()),
                top: section.top,
                end: section.end,
            })
            .collect();
        update_model(&adapter.models.emoji_rail, rail);
    }
    // Each server's icon heads its emoji in the rail, and need not be on
    // screen anywhere else, so the ones not in memory are asked for.
    let wanted: Vec<String> = sections
        .iter()
        .map(|section| section.icon_url.to_string())
        .filter(|url| !url.is_empty() && !adapter.app.state.pictures.contains_key(url))
        .collect();
    if !wanted.is_empty() {
        adapter.action(window, Action::WantedPictures(wanted));
    }
    let grid_height = rows.last().map_or(0.0, |row| row.top + row.height);
    update_model(&adapter.models.emoji_rows, rows);
    window.set_emoji_grid_height(grid_height);
    // The rows where the grid is scrolled to, its top for a grid built for a
    // search, are made ready with those around them, so the first scroll finds
    // them drawn.
    let (first, last) = adapter.emoji_rows_in_sight();
    adapter.emoji_rows_filled = ready_rows(first, last);
    // The grid shares the width it shows at among these, so its cells need the
    // count the rows were built with.
    window.set_emoji_columns(columns as i32);
    // Matches have no sections; the sidebar keeps those it jumps back to.
    if !sections.is_empty() {
        update_model(&adapter.models.emoji_sections, sections);
    }
    // A grid laid out again is made of new cells, and the custom emoji whose
    // pictures this device already holds are drawn at once rather than waiting
    // for one to arrive, which a drag of the picker's edge would not bring.
    // Only the rows near those in sight hold their custom emoji's pictures;
    // see `let_go_of_far_emoji`.
    // A grid built again sweeps every row once, for what it made from
    // pictures already kept.
    let rows = adapter.models.emoji_rows.row_count();
    adapter.emoji_grid.custom_held = (rows > 0).then(|| (0, rows - 1));
    emoji::fill_pictures_in(
        &adapter.models.emoji_rows,
        first.saturating_sub(FETCH_ROWS),
        last.saturating_add(FETCH_ROWS),
    );
    emoji::fill_section_pictures(&adapter.models.emoji_sections);
    // The rail shows every section's icon at once, so the first emoji of each
    // server without an icon of its own is asked for with the rows in sight.
    let icons: Vec<String> = adapter
        .models
        .emoji_sections
        .iter()
        .filter(|section| section.icon_url.is_empty() && section.icon.picture.size().width == 0)
        .filter_map(|section| Some(section.icon.key.rsplit_once(':')?.1.to_owned()))
        .collect();
    request_custom_pictures(&mut adapter, window, &icons);
    prepare_emoji_rows(&mut adapter, window, first, last);
    // The rest of the account's emoji go to the disk cache behind these, once
    // a session, so a scroll reads them from there rather than Discord.
    adapter.action(window, Action::CacheEmojiPictures);
}

#[cfg(feature = "discord")]
fn bind_copy_discord_token(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    let adapter = Rc::downgrade(adapter);
    let weak_window = window.as_weak();
    window.on_copy_discord_token(move || {
        let (Some(window), Some(adapter)) = (weak_window.upgrade(), adapter.upgrade()) else {
            return;
        };
        if window.get_copying_discord_token() {
            return;
        }
        let (account, version, pending) = {
            let adapter = adapter.borrow();
            let state = &adapter.app.state;
            if state.preview || !state.discord_linked {
                return;
            }
            let (Some(account), Some(backend)) = (&state.discord_user, &adapter.backend) else {
                window.set_copy_discord_token_note("Connect to Discord first.".into());
                return;
            };
            (
                account.clone(),
                state.reset_version,
                backend.request_discord_token(account.clone()),
            )
        };
        window.set_copy_discord_token_note("".into());
        window.set_copying_discord_token(true);
        let weak_window = window.as_weak();
        let weak_adapter = Rc::downgrade(&adapter);
        let task = slint::spawn_local(async move {
            let token = pending.await;
            let (Some(window), Some(adapter)) = (weak_window.upgrade(), weak_adapter.upgrade())
            else {
                return;
            };
            window.set_copying_discord_token(false);
            let adapter = adapter.borrow();
            let state = &adapter.app.state;
            if state.preview
                || !state.discord_linked
                || state.reset_version != version
                || state.discord_user.as_ref() != Some(&account)
            {
                return;
            }
            let Some(token) = token else {
                window.set_copy_discord_token_note("Couldn’t read the linked Discord token.".into());
                return;
            };
            #[cfg(windows)]
            let copied = crate::copy::discord_token(token.as_str()).is_ok();
            #[cfg(not(windows))]
            let copied = {
                window.invoke_copy_text(token.as_str().into());
                true
            };
            window.set_copy_discord_token_note(
                if copied {
                    "Discord token copied."
                } else {
                    "Couldn’t access the clipboard."
                }
                .into(),
            );
        });
        if task.is_err() {
            window.set_copying_discord_token(false);
            window.set_copy_discord_token_note("Couldn’t copy the Discord token.".into());
        }
    });
}

pub(super) fn bind_callbacks(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    #[cfg(feature = "discord")]
    bind_copy_discord_token(window, adapter);
    super::menus::bind_message_addresses(window, adapter);
    super::message_saves::bind(window, adapter);
    super::activities::bind(window, adapter);
    super::extension_profile::bind(window, adapter);
    super::extension_marketplace::bind(window);
    super::favorites::bind(window, adapter);
    super::app_commands::bind(window, adapter);
    super::games::bind(window, adapter);
    super::gifs::bind(window, adapter);
    super::updates::bind(window, adapter);
    super::new_tags::bind(window, adapter);
    super::stickers::bind(window, adapter);
    {
        let state = adapter.clone();
        let weak = window.as_weak();
        window.on_open_sticker(move |item, index| {
            let Some(window) = weak.upgrade() else { return };
            let mut adapter = state.borrow_mut();
            let item = item.to_string();
            let index = index.max(0) as usize;
            adapter.sticker_card = Some((item.clone(), index));
            let card = messages::sticker_card(&adapter.app, &item, index);
            let server = card.server.to_string();
            window.set_sticker_card(card);
            window.set_sticker_card_open(true);
            if !server.is_empty() {
                adapter.action(&window, Action::PreviewServer(server));
            }
        });
    }
    {
        let state = adapter.clone();
        let weak = window.as_weak();
        window.on_emoji_favorite(move |key| {
            let Some(window) = weak.upgrade() else { return };
            // Discord's settings keep it by its id or its Discord name.
            let Some(name) = emoji::discord_name(&key) else {
                return;
            };
            state
                .borrow_mut()
                .action(&window, Action::FavoriteEmoji(name));
            // The grid again, so its Favorites section and the stars follow;
            // a search keeps its matches and shows the star alone.
            let query = window.get_emoji_query();
            if query.trim().trim_matches(':').is_empty() {
                let columns = window.get_emoji_columns().max(1) as usize;
                show_emoji(&state, &window, query.as_str(), columns);
            } else {
                let favorites = {
                    let adapter = state.borrow();
                    let custom = adapter.app.emoji_sets();
                    let by_id: HashMap<&str, &yapfast_core::chat::CustomEmoji> = custom
                        .iter()
                        .flat_map(|set| &set.emoji)
                        .map(|emoji| (emoji.id.as_str(), emoji))
                        .collect();
                    emoji::discord_keys(&adapter.app.state.discord_emojis.favorites, &by_id)
                };
                show_emoji_stars(&window, &favorites);
            }
        });
    }
    window
        .global::<EmojiFavorites>()
        .on_is_favorite(|key, _| EMOJI_FAVORITES.with_borrow(|set| set.contains(key.as_str())));
    super::polls::bind(window, adapter);
    super::call_link::bind(window, adapter);
    super::server_settings::bind(window, adapter);
    super::channel_settings::bind(window, adapter);
    super::thread_settings::bind(window, adapter);
    super::title_bar::bind(window, adapter);
    // UI bindings can request images while refresh borrows the adapter.
    // Deliver their requests in one batch after the current UI work.
    let pending = Rc::new(RefCell::new(HashSet::new()));
    let timer = Rc::new(slint::Timer::default());
    let last = Rc::new(Cell::new(None));
    let state = Rc::downgrade(adapter);
    let weak = window.as_weak();
    window
        .global::<PictureStore>()
        .on_slot(|url| picture_slot(url.as_str()) as i32);
    window
        .global::<PictureStore>()
        .on_picture(|url, _revision| avatar_picture(url.as_str()));
    // An animated emoji's frame, by the name the picker knows it by; a still
    // one has none and keeps its picture.
    window
        .global::<EmojiAnimations>()
        .on_frame(|key, _revision| {
            i_slint_core::yapfast_emoji::frame_of_key(key.as_str()).unwrap_or_default()
        });
    window
        .global::<PictureStore>()
        .on_animated(|url| animated_url(url.as_str()).into());
    window
        .global::<PictureStore>()
        .on_moving_avatar(|url| moving_avatar_url(url.as_str()).into());
    window
        .global::<PictureStore>()
        .on_frames(|url, _revision| avatar_animation(url.as_str()).0);
    window
        .global::<PictureStore>()
        .on_delays(|url, _revision| avatar_animation(url.as_str()).1);
    window
        .global::<PictureStore>()
        .on_plays(|url, _revision| picture_plays(url.as_str()));
    window
        .global::<ActivityClock>()
        .on_lasted(super::profile::activity_lasted);
    window.global::<PictureStore>().on_request(move |url| {
        if url.is_empty() {
            return;
        }
        pending.borrow_mut().insert(url.to_string());
        if !timer.running() {
            let (pending, state, weak) = (pending.clone(), state.clone(), weak.clone());
            timer.start(
                slint::TimerMode::SingleShot,
                report_delay(&last),
                move || {
                    let urls = pending.borrow_mut().drain().collect();
                    if let (Some(adapter), Some(window)) = (state.upgrade(), weak.upgrade()) {
                        adapter
                            .borrow_mut()
                            .action(&window, Action::LoadPictures(urls));
                    }
                },
            );
        }
    });
    let timer = Rc::new(slint::Timer::default());
    let last = Rc::new(Cell::new(None));
    let state = Rc::downgrade(adapter);
    let weak = window.as_weak();
    window.on_media_viewport(move || {
        if timer.running() {
            return;
        }
        let (state, weak) = (state.clone(), weak.clone());
        timer.start(
            slint::TimerMode::SingleShot,
            report_delay(&last),
            move || {
                let (Some(adapter), Some(window)) = (state.upgrade(), weak.upgrade()) else {
                    return;
                };
                let mut adapter = adapter.borrow_mut();
                let messages = &adapter.app.state.messages;
                let Some(room) = adapter.app.state.selected.clone() else {
                    return;
                };
                if messages.is_empty() || window.get_top_index() < 0 {
                    return;
                }
                const MARGIN: usize = 6;
                let first = (window.get_top_index() as usize).min(messages.len() - 1);
                let last = (window.get_bottom_index().max(window.get_top_index()) as usize)
                    .min(messages.len() - 1);
                let items = messages[first.saturating_sub(MARGIN)
                    ..=last.saturating_add(MARGIN).min(messages.len() - 1)]
                    .iter()
                    .map(|message| message.item.clone())
                    .collect();
                let at_end = window.invoke_timeline_at_end();
                adapter.action(
                    &window,
                    Action::VisibleMessages {
                        room,
                        items,
                        at_end,
                    },
                );
            },
        );
    });
    // The thread beside the open channel reports its rows in view the same
    // way, the latest of those a burst of scrolling reported.
    let timer = Rc::new(slint::Timer::default());
    let last = Rc::new(Cell::new(None));
    let range = Rc::new(Cell::new((-1, -1)));
    let state = Rc::downgrade(adapter);
    let weak = window.as_weak();
    window.on_aside_viewport(move |top, bottom| {
        range.set((top, bottom));
        if timer.running() {
            return;
        }
        let (state, weak, range) = (state.clone(), weak.clone(), range.clone());
        timer.start(
            slint::TimerMode::SingleShot,
            report_delay(&last),
            move || {
                let (Some(adapter), Some(window)) = (state.upgrade(), weak.upgrade()) else {
                    return;
                };
                let mut adapter = adapter.borrow_mut();
                let Some(aside) = &adapter.app.state.aside else {
                    return;
                };
                let (top, bottom) = range.get();
                let messages = &aside.messages;
                if messages.is_empty() || top < 0 {
                    return;
                }
                const MARGIN: usize = 6;
                let first = (top as usize).min(messages.len() - 1);
                let last = (bottom.max(top) as usize).min(messages.len() - 1);
                let items = messages[first.saturating_sub(MARGIN)
                    ..=last.saturating_add(MARGIN).min(messages.len() - 1)]
                    .iter()
                    .map(|message| message.item.clone())
                    .collect();
                let room = aside.room.clone();
                adapter.action(
                    &window,
                    Action::VisibleMessages {
                        room,
                        items,
                        at_end: false,
                    },
                );
            },
        );
    });
    macro_rules! bind {
        ($callback:ident, $action:expr) => {{
            let adapter = adapter.clone();
            let weak = window.as_weak();
            window.$callback(move || {
                if let Some(window) = weak.upgrade() {
                    adapter.borrow_mut().action(&window, $action);
                }
            });
        }};
    }
    bind!(on_explore_preview, Action::Preview);
    {
        let state = adapter.clone();
        let weak = window.as_weak();
        window.on_use_button(move |item, custom_id| {
            if let Some(window) = weak.upgrade() {
                state.borrow_mut().action(
                    &window,
                    Action::UseButton {
                        item: item.to_string(),
                        custom_id: custom_id.to_string(),
                    },
                );
            }
        });
    }
    {
        let state = adapter.clone();
        let weak = window.as_weak();
        window.on_open_select(move |item, custom_id| {
            if let Some(window) = weak.upgrade() {
                state.borrow_mut().action(
                    &window,
                    Action::OpenSelect {
                        item: item.to_string(),
                        custom_id: custom_id.to_string(),
                    },
                );
            }
        });
    }
    bind!(on_bot_select_close, Action::CloseSelect);
    {
        let state = adapter.clone();
        let weak = window.as_weak();
        window.on_bot_select_search(move |query| {
            if let Some(window) = weak.upgrade() {
                state
                    .borrow_mut()
                    .action(&window, Action::SearchSelect(query.to_string()));
            }
        });
    }
    bind!(on_bot_modal_submit, Action::SubmitModal);
    // A form's file upload takes files from the same dialog as the
    // composer's.
    {
        let state = adapter.clone();
        window.on_bot_modal_choose_files(move |index| {
            let Ok(index) = usize::try_from(index) else {
                return;
            };
            let Some(target) = ModalFileTarget::capture(&state.borrow().app.state, index) else {
                return;
            };
            let weak = Rc::downgrade(&state);
            state.borrow_mut().dialog(async move {
                let files = rfd::AsyncFileDialog::new()
                    .set_title("Choose files")
                    .pick_files()
                    .await;
                if let (Some(files), Some(adapter)) = (files, weak.upgrade()) {
                    let window = adapter.borrow().window.upgrade();
                    if let Some(window) = window {
                        let files = files.iter().map(|file| file.path().to_owned()).collect();
                        let mut adapter = adapter.borrow_mut();
                        if let Some(action) = target.returned(&adapter.app.state, files) {
                            adapter.action(&window, action);
                        }
                    }
                }
            });
        });
    }
    {
        let state = adapter.clone();
        let weak = window.as_weak();
        window.on_bot_modal_remove_file(move |index, file| {
            if let Some(window) = weak.upgrade() {
                state.borrow_mut().action(
                    &window,
                    Action::RemoveModalFile {
                        index: index.max(0) as usize,
                        file: file.max(0) as usize,
                    },
                );
            }
        });
    }
    bind!(on_bot_modal_close, Action::CloseModal);
    {
        let state = adapter.clone();
        let weak = window.as_weak();
        window.on_bot_modal_open_select(move |index| {
            if let Some(window) = weak.upgrade() {
                state
                    .borrow_mut()
                    .action(&window, Action::OpenModalSelect(index as usize));
            }
        });
    }
    {
        let state = adapter.clone();
        let weak = window.as_weak();
        window.on_bot_select_toggle(move |index| {
            if let Some(window) = weak.upgrade() {
                state
                    .borrow_mut()
                    .action(&window, Action::ToggleSelect(index as usize));
            }
        });
    }
    {
        let state = adapter.clone();
        let weak = window.as_weak();
        window.on_bot_modal_field_edited(move |index, value| {
            if let Some(window) = weak.upgrade() {
                state.borrow_mut().action(
                    &window,
                    Action::SetModalField {
                        index: index as usize,
                        value: value.to_string(),
                    },
                );
            }
        });
    }
    bind!(on_restore, Action::Restore);
    bind!(on_logout, Action::Logout);
    bind!(on_refresh_trust, Action::RefreshTrust);
    bind!(on_retry_sync, Action::RetrySync);
    bind!(
        on_navigate_dms,
        Action::Navigate(Navigation::DirectMessages)
    );
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_send(move || {
            let Some(window) = weak.upgrade() else { return };
            // Sending goes to the newest message, as Discord does, so the sent one shows.
            // From a window of older messages, that's once the newest replace it:
            // following its end before then would load earlier pages as they go in.
            if window.get_can_send() {
                if window.get_detached() {
                    adapter.borrow_mut().latest_due = true;
                } else {
                    window.invoke_scroll_to_latest();
                }
            }
            adapter.borrow_mut().action(&window, Action::Send);
        });
    }
    bind!(on_earlier, Action::Earlier);
    bind!(on_later, Action::Later);
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_jump_to_present(move || {
            let Some(window) = weak.upgrade() else { return };
            // The newest messages show at the end once they replace the window.
            adapter.borrow_mut().latest_due = true;
            adapter.borrow_mut().action(&window, Action::JumpToPresent);
        });
    }
    bind!(on_jump_to_unread, Action::JumpToUnread);
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_reading_changed(move |reading| {
            if let Some(window) = weak.upgrade() {
                adapter
                    .borrow_mut()
                    .action(&window, Action::Reading(reading));
            }
        });
    }
    bind!(on_accept_request, Action::AnswerRequest(true));
    bind!(on_enlarge_profile, Action::EnlargeProfile);
    bind!(on_close_profile, Action::CloseProfile);
    bind!(on_ignore_request, Action::AnswerRequest(false));
    bind!(on_leave_voice, Action::Voice(voice::Command::Leave));
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_message_from_profile(move |user, text| {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().action(
                &window,
                Action::MessageFromProfile {
                    user: user.into(),
                    text: text.into(),
                },
            );
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_message_person(move |user| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::MessagePerson(user.into()));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_profile_tab_opened(move |page| {
        use yapfast_core::application::ProfileTab;
        // ProfileModal's pages: 0 Activity, 3 Board, 4 Wishlist; the mutual
        // ones ask for nothing.
        let tab = match page {
            0 => ProfileTab::Activity,
            3 => ProfileTab::Board,
            4 => ProfileTab::Wishlist,
            _ => return,
        };
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::OpenProfileTab(tab));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_save_note(move |user, note| {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().action(
                &window,
                Action::SaveNote {
                    user: user.into(),
                    note: note.into(),
                },
            );
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_befriend(move |user| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::Befriend(user.to_string()));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_unblock(move |user| {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().action(
                &window,
                Action::ChangeRelationship {
                    user: user.to_string(),
                    change: yapfast_core::chat::RelationshipChange::Unblock,
                    location: "ContextMenu",
                },
            );
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_remove_friend_request(move |user| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::RemoveFriendRequest(user.to_string()));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_start_call(move || {
        if let Some(window) = weak.upgrade() {
            let id = state.borrow().app.state.selected.clone();
            if let Some(id) = id {
                state
                    .borrow_mut()
                    .action(&window, Action::RequestJoinVoice(id));
            }
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_start_video_call(move || {
        if let Some(window) = weak.upgrade() {
            let id = state.borrow().app.state.selected.clone();
            if let Some(id) = id {
                state
                    .borrow_mut()
                    .action(&window, Action::StartVideoCall(id));
            }
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_answer_call(move |room, accept| {
        if let Some(window) = weak.upgrade() {
            let room = room.to_string();
            state.borrow_mut().action(
                &window,
                if accept {
                    Action::AcceptCall(room)
                } else {
                    Action::DeclineCall(room)
                },
            );
        }
    });
    bind!(on_confirm_switch, Action::ConfirmVoiceSwitch);
    bind!(on_cancel_switch, Action::CancelVoiceSwitch);
    bind!(on_dismiss_voice_error, Action::DismissVoiceError);
    bind!(on_refresh_devices, Action::Voice(voice::Command::Devices));
    bind!(on_confirm_delete_message, Action::ConfirmDelete);
    bind!(on_cancel_delete, Action::CancelDelete);
    bind!(on_cancel_compose, Action::CancelCompose);
    bind!(
        on_toggle_reply_ping,
        Action::ToggleReplyPing { aside: false }
    );
    bind!(
        on_aside_toggle_reply_ping,
        Action::ToggleReplyPing { aside: true }
    );
    bind!(on_aside_close, Action::CloseAside);
    bind!(on_aside_expand, Action::ExpandAside);
    bind!(on_aside_earlier, Action::AsideEarlier);
    bind!(on_aside_send, Action::SendAside);
    bind!(on_aside_cancel_compose, Action::CancelAsideCompose);
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_aside_draft_edited(move |text| {
            let Some(window) = weak.upgrade() else { return };
            let mut adapter = adapter.borrow_mut();
            if adapter.app.state.aside_draft() != text.as_str() {
                adapter.action(&window, Action::SetAsideDraft(text.into()));
            }
        });
    }
    bind!(on_close_forward, Action::CloseForward);
    bind!(on_close_switcher, Action::CloseSwitcher);
    bind!(on_toggle_switcher, Action::ToggleSwitcher);
    bind!(on_dismiss_notice, Action::DismissNotice);
    bind!(on_close_image, Action::CloseImage);
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_view_image(move |item, index| {
            if let Some(window) = weak.upgrade() {
                let action = Action::ViewImage {
                    item: item.into(),
                    index: usize::try_from(index).unwrap_or_default(),
                };
                adapter.borrow_mut().action(&window, action);
            }
        });
    }
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_step_image(move |step| {
            if let Some(window) = weak.upgrade() {
                adapter
                    .borrow_mut()
                    .action(&window, Action::StepImage(step as isize));
            }
        });
    }
    macro_rules! bind_item {
        ($callback:ident, $action:expr) => {{
            let adapter = adapter.clone();
            let weak = window.as_weak();
            window.$callback(move |item| {
                if let Some(window) = weak.upgrade() {
                    adapter.borrow_mut().action(&window, $action(item.into()));
                }
            });
        }};
    }
    bind_item!(on_reply, Action::Reply);
    bind_item!(on_jump_to, Action::Jump);
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_jump_in_room(move |room, item| {
            if let Some(window) = weak.upgrade() {
                let (room, item) = (room.into(), item.into());
                adapter
                    .borrow_mut()
                    .action(&window, Action::JumpInRoom { room, item });
            }
        });
    }
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_prepare_menu(move |id, person| {
            if let Some(window) = weak.upgrade() {
                let menu = menus::menu(&adapter.borrow(), &id, person);
                menus::show(&window, menu);
                let volume = menus::volume_for_menu(&adapter.borrow(), &id, person);
                let (user, name, live) = volume.unwrap_or_default();
                window.invoke_prepare_context_volume(user.into(), name.into(), live);
            }
        });
    }
    {
        let adapter = adapter.clone();
        window.on_may_create_channel(move |category| {
            adapter.borrow().app.may_create_channel(&category)
        });
    }
    {
        let adapter = adapter.clone();
        // An empty category's heading names the category itself.
        window.on_category_of(move |room| {
            let app = &adapter.borrow().app;
            app.category_of(&room)
                .or_else(|| app.state.is_category(&room).then(|| room.to_string()))
                .unwrap_or_default()
                .into()
        });
    }
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_choose_menu(move |target, person, id| {
            if let Some(window) = weak.upgrade() {
                menus::choose(
                    &mut adapter.borrow_mut(),
                    &window,
                    target.into(),
                    person,
                    &id,
                );
            }
        });
    }
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_show_friend_profile(move |user, large| {
            if let Some(window) = weak.upgrade() {
                let user = user.into();
                adapter
                    .borrow_mut()
                    .action(&window, Action::ShowFriendProfile { user, large });
            }
        });
    }
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_enlarge_panel_profile(move || {
            let Some(window) = weak.upgrade() else { return };
            let mut adapter = adapter.borrow_mut();
            if let Some(room) = adapter.app.state.selected.clone() {
                adapter.action(&window, Action::ShowDmProfile(room));
            }
        });
    }
    bind_item!(
        on_show_profile,
        (|user| Action::ShowProfile { user, large: false })
    );
    bind_item!(on_edit, Action::Edit);
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_edit_last(move || {
            let Some(window) = weak.upgrade() else { return };
            // Showing the edit gives its field the keys, the cursor after the text.
            adapter.borrow_mut().action(&window, Action::EditLast);
        });
    }
    bind_item!(on_request_delete, Action::RequestDelete);
    bind_item!(on_delete_now, Action::DeleteNow);
    bind_item!(on_pin_message, Action::PinMessage);
    bind_item!(on_mark_unread, Action::MarkUnread);
    bind_item!(on_retry, Action::Retry);
    bind_item!(on_cancel_send, Action::CancelSend);
    bind_item!(on_start_forward, Action::StartForward);
    bind_item!(on_forward_choose, Action::ChooseForward);
    bind_item!(on_forward_send, Action::Forward);
    bind_item!(on_switcher_search, Action::SearchSwitcher);
    bind_item!(on_reconnect_voice, Action::RequestJoinVoice);
    bind_item!(on_switch_to, Action::SwitchTo);
    bind!(on_open_new_dm, Action::OpenNewDm);
    bind!(on_open_add_friend, Action::OpenAddFriend);
    bind!(on_open_requests, Action::OpenDmScreen(DmScreen::Requests));
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_inbox_opened(move || {
            if let Some(window) = weak.upgrade() {
                super::message_saves::inbox_opened(&mut adapter.borrow_mut(), &window);
            }
        });
    }
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_activity_clock(move || {
            if let Some(window) = weak.upgrade() {
                adapter.borrow_mut().refresh(&window);
            }
        });
    }
    bind!(on_go_back, Action::NavigateBack);
    bind!(on_go_forward, Action::NavigateForward);
    bind!(on_open_friends, Action::OpenDmScreen(DmScreen::Friends));
    bind!(on_open_browse, Action::BrowseChannels);
    bind_item!(on_message_friend, Action::MessagePerson);
    bind!(on_link_discord, Action::LinkDiscord);
    bind_item!(on_link_discord_token, Action::LinkDiscordToken);
    bind!(on_open_discord_captcha, Action::OpenDiscordCaptcha);
    bind!(on_cancel_discord_link, Action::CancelDiscordLink);
    bind!(on_unlink_discord, Action::UnlinkDiscord);
    bind!(on_close_add_friend, Action::CloseAddFriend);
    bind!(on_close_person, Action::ClosePersonDialog);
    bind!(on_close_invite, Action::CloseInvite);
    bind!(on_open_join_server, Action::OpenJoinServer);
    bind!(on_join_server, Action::JoinServer);
    bind!(on_authorize_oauth, Action::AuthorizeOAuth);
    bind!(on_close_oauth, Action::CloseOAuth);
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_choose_oauth_guild(move |index| {
            let guild = {
                let adapter = adapter.borrow();
                adapter
                    .app
                    .state
                    .oauth
                    .as_ref()
                    .and_then(|dialog| dialog.preview.as_ref())
                    .and_then(|preview| {
                        preview
                            .guilds
                            .iter()
                            .filter(|guild| guild.can_add)
                            .nth(usize::try_from(index).unwrap_or_default())
                    })
                    .map(|guild| guild.id.clone())
            };
            if let (Some(window), Some(guild)) = (weak.upgrade(), guild) {
                adapter
                    .borrow_mut()
                    .action(&window, Action::ChooseOAuthGuild(guild));
            }
        });
    }
    bind!(on_redeem_gift, Action::RedeemGift);
    bind!(on_open_gift_in_browser, Action::OpenGiftInBrowser);
    bind!(on_close_gift, Action::CloseGift);
    bind!(on_open_join_captcha, Action::OpenJoinCaptcha);
    bind!(on_open_join_form, Action::OpenJoinForm);
    bind!(on_close_join, Action::CloseJoin);
    bind!(on_toggle_event_interest, Action::ToggleEventInterest);
    bind!(on_close_event, Action::CloseEvent);
    bind_item!(on_find_invite, Action::FindInvite);
    bind_item!(on_open_invite, Action::OpenInvite);
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_make_invite(move |age, uses| {
            let pick = |list: &[u32], index: i32| {
                usize::try_from(index)
                    .ok()
                    .and_then(|index| list.get(index))
                    .copied()
            };
            if let (Some(window), Some(max_age), Some(max_uses)) = (
                weak.upgrade(),
                pick(&INVITE_AGES, age),
                pick(&INVITE_USES, uses),
            ) {
                adapter
                    .borrow_mut()
                    .action(&window, Action::MakeInvite { max_age, max_uses });
            }
        });
    }
    bind!(on_close_channel, Action::CloseChannelDialog);
    bind!(on_edit_profile, Action::EditProfile);
    {
        let state = adapter.clone();
        let weak = window.as_weak();
        window.on_edit_server_profile(move |server| {
            if let Some(window) = weak.upgrade() {
                state
                    .borrow_mut()
                    .action(&window, Action::EditServerProfile(server.into()));
            }
        });
    }
    bind!(on_account_opened, Action::LoadOwnProfile);
    bind!(on_open_profile_wishlist, Action::OpenWishlist);
    bind!(on_undo_profile, Action::UndoProfileEdits);
    bind!(on_save_profile, Action::SaveProfile);
    bind!(on_close_profile_editor, Action::CloseProfileEditor);
    bind!(on_unlock_nitro, Action::UnlockNitro);
    let profile_picture = |kind: i32| {
        if kind == 1 {
            ProfilePicture::Banner
        } else {
            ProfilePicture::Avatar
        }
    };
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_choose_server_tag({
            let (adapter, weak) = (adapter.clone(), weak.clone());
            move |server| {
                if let Some(window) = weak.upgrade() {
                    adapter
                        .borrow_mut()
                        .action(&window, Action::ChooseServerTag(server.to_string()));
                }
            }
        });
        window.on_edit_own_note({
            let (adapter, weak) = (adapter.clone(), weak.clone());
            move || {
                if let Some(window) = weak.upgrade() {
                    let user = adapter.borrow().app.state.discord_user.clone();
                    if let Some(user) = user {
                        adapter.borrow_mut().action(
                            &window,
                            Action::AskPerson {
                                user,
                                ask: yapfast_core::application::PersonAsk::Note,
                                location: "ContextMenu",
                            },
                        );
                    }
                }
            }
        });
        window.on_choose_name_style({
            let (adapter, weak) = (adapter.clone(), weak.clone());
            move |font, effect, colours| {
                if let Some(window) = weak.upgrade() {
                    adapter.borrow_mut().action(
                        &window,
                        Action::ChooseNameStyle {
                            font: u8::try_from(font).unwrap_or(11),
                            effect: u8::try_from(effect.max(1)).unwrap_or(1),
                            colours: colours.to_string(),
                        },
                    );
                }
            }
        });
        // The name style window draws each candidate as names are drawn
        // everywhere else, from its font, effect and colours as hex.
        window
            .global::<NameStyles>()
            .on_row(|font, effect, key, text| {
                let colours = key_colours(&key);
                super::name_style::row(
                    Some(&yapfast_core::chat::NameStyle::new(
                        u8::try_from(font).unwrap_or(11),
                        u8::try_from(effect.max(1)).unwrap_or(1),
                        if colours.is_empty() {
                            &[0xf0_f0_f2]
                        } else {
                            &colours
                        },
                    )),
                    &text,
                )
            });
        window.global::<NameStyles>().on_stripe(|key, index| {
            let colours = key_colours(&key);
            colours
                .get(usize::try_from(index).unwrap_or(0) % colours.len().max(1))
                .map_or_else(slint::Color::default, |rgb| {
                    slint::Color::from_rgb_u8((rgb >> 16) as u8, (rgb >> 8) as u8, *rgb as u8)
                })
        });
        window.global::<NameStyles>().on_contains(|text, query| {
            text.to_lowercase()
                .contains(query.trim().to_lowercase().as_str())
        });
        window.on_key_part(|key, index| {
            key.split(',')
                .nth(index.max(0) as usize)
                .unwrap_or_default()
                .into()
        });
        // Spread evenly over five stops, however many colours it has.
        window.on_key_colour(|key, index| {
            let colours: Vec<[f32; 3]> = key_colours(&key)
                .into_iter()
                .map(|rgb| {
                    [
                        (rgb >> 16 & 255) as f32,
                        (rgb >> 8 & 255) as f32,
                        (rgb & 255) as f32,
                    ]
                })
                .collect();
            let (Some(first), Some(last)) = (colours.first(), colours.last()) else {
                return slint::Color::default();
            };
            let at = index.clamp(0, 4) as f32 / 4.0 * (colours.len() - 1) as f32;
            let low = at.floor() as usize;
            let (from, to) = (
                colours.get(low).unwrap_or(first),
                colours.get(low + 1).unwrap_or(last),
            );
            let part =
                |channel: usize| (from[channel] + (to[channel] - from[channel]) * at.fract()) as u8;
            slint::Color::from_rgb_u8(part(0), part(1), part(2))
        });
        window.on_format_hex(|colour| {
            format!(
                "{:02x}{:02x}{:02x}",
                colour.red(),
                colour.green(),
                colour.blue()
            )
            .into()
        });
        window.on_parse_hex(|text| {
            let hex = text.trim().trim_start_matches('#');
            let value = (hex.len() == 6)
                .then(|| u32::from_str_radix(hex, 16).ok())
                .flatten();
            value.map_or_else(slint::Color::default, |rgb| {
                slint::Color::from_rgb_u8((rgb >> 16) as u8, (rgb >> 8) as u8, rgb as u8)
            })
        });
        window.on_write_profile(move |field, text| {
            let field = match field {
                0 => ProfileText::Name,
                1 => ProfileText::Pronouns,
                2 => ProfileText::Bio,
                4 => ProfileText::ThemeTop,
                5 => ProfileText::ThemeBottom,
                _ => ProfileText::Colour,
            };
            if let Some(window) = weak.upgrade() {
                adapter.borrow_mut().action(
                    &window,
                    Action::WriteProfile {
                        field,
                        text: text.into(),
                    },
                );
            }
        });
    }
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_reset_profile_picture(move |kind| {
            if let Some(window) = weak.upgrade() {
                adapter
                    .borrow_mut()
                    .action(&window, Action::ResetProfilePicture(profile_picture(kind)));
            }
        });
    }
    {
        let state = adapter.clone();
        window.on_pick_profile_picture(move |kind| {
            let kind = profile_picture(kind);
            let weak = Rc::downgrade(&state);
            state.borrow_mut().dialog(async move {
                let file = rfd::AsyncFileDialog::new()
                    .set_title(match kind {
                        ProfilePicture::Avatar => "Change Avatar",
                        ProfilePicture::Banner => "Change Banner",
                    })
                    .add_filter("Pictures", &["png", "jpg", "jpeg", "gif", "webp"])
                    .pick_file()
                    .await;
                if let (Some(file), Some(adapter)) = (file, weak.upgrade()) {
                    let window = adapter.borrow().window.upgrade();
                    if let Some(window) = window {
                        let path = file.path().to_owned();
                        adapter
                            .borrow_mut()
                            .action(&window, Action::PickProfilePicture { kind, path });
                    }
                }
            });
        });
    }
    bind!(on_confirm_leave, Action::Leave);
    bind!(on_toggle_silent_leave, Action::ToggleSilentLeave);
    bind!(on_close_leave, Action::CloseLeave);
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_save_channel(move || {
            let Some(window) = weak.upgrade() else { return };
            let kind = if window.get_channel_kind() == 1 {
                ChannelKind::Voice
            } else {
                ChannelKind::Text
            };
            let settings = ChannelSettings {
                name: window.get_channel_name().into(),
                ..Default::default()
            };
            adapter
                .borrow_mut()
                .action(&window, Action::SaveChannel { kind, settings });
        });
    }
    bind_item!(on_answer_person, Action::AnswerPerson);
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_choose_person_option(move |index| {
            if let (Some(window), Ok(index)) = (weak.upgrade(), usize::try_from(index)) {
                adapter
                    .borrow_mut()
                    .action(&window, Action::ChoosePersonOption(index));
            }
        });
    }
    bind_item!(on_add_friend, Action::AddFriend);
    bind!(on_open_status, Action::OpenStatusEditor);
    bind_item!(on_set_status, Action::SetStatus);
    bind!(on_close_status, Action::CloseStatusEditor);
    bind!(on_clear_status, Action::ClearCustomStatus);
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_save_status(move || {
        let Some(window) = weak.upgrade() else { return };
        let key = window.get_status_emoji().key.to_string();
        let action = Action::SetCustomStatus {
            emoji: (!key.is_empty()).then_some(key),
            text: window.get_status_text().to_string(),
            clear_after: match window.get_status_clear_after() {
                1 => ClearAfter::Minutes(30),
                2 => ClearAfter::Minutes(60),
                3 => ClearAfter::Minutes(240),
                4 => ClearAfter::Today,
                _ => ClearAfter::Never,
            },
        };
        state.borrow_mut().action(&window, action);
    });
    bind!(on_close_role, Action::CloseRole);
    bind!(on_close_new_dm, Action::CloseNewDm);
    bind!(on_more_results, Action::MoreResults);
    bind!(on_open_add_people, Action::OpenAddPeople);
    bind!(on_confirm_add_people, Action::AddPeople);
    bind!(on_close_add_people, Action::CloseAddPeople);
    bind_item!(on_choose_person, Action::ChoosePerson);
    bind_item!(on_search, Action::Search);
    bind_item!(on_search_threads, Action::SearchThreads);
    bind!(on_more_threads, Action::MoreThreads);
    bind!(on_create_thread, Action::CreateThread);
    bind!(on_close_new_thread, Action::CloseNewThread);
    bind!(on_leave_new_thread, Action::LeaveNewThread);
    bind!(on_stay_in_new_thread, Action::StayInNewThread);
    bind!(on_new_post, Action::NewPost);
    bind!(on_create_post, Action::CreatePost);
    bind!(on_close_post, Action::CloseNewPost);
    bind!(on_leave_post, Action::LeaveNewPost);
    bind!(on_stay_post, Action::StayInNewPost);
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_show_pins(move |shown| {
            if let Some(window) = weak.upgrade() {
                adapter
                    .borrow_mut()
                    .action(&window, Action::ShowPins(shown));
            }
        });
    }
    {
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_show_threads(move |shown| {
            if let Some(window) = weak.upgrade() {
                adapter
                    .borrow_mut()
                    .action(&window, Action::ShowThreads(shown));
            }
        });
    }
    {
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_new_thread(move |item, from| {
            use yapfast_core::application::ThreadFrom;
            let from = match from.as_str() {
                "message" => ThreadFrom::Message,
                "list" => ThreadFrom::List,
                "list-empty" => ThreadFrom::ListEmpty,
                _ => ThreadFrom::PlusButton,
            };
            let message = (!item.is_empty()).then(|| item.to_string());
            if let Some(window) = weak.upgrade() {
                adapter
                    .borrow_mut()
                    .action(&window, Action::NewThread { message, from });
            }
        });
    }
    {
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_new_thread_name_edited(move |name| {
            if let Some(window) = weak.upgrade() {
                adapter.borrow_mut().action(
                    &window,
                    Action::WriteNewThread {
                        name: Some(name.into()),
                        body: None,
                    },
                );
            }
        });
    }
    {
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_new_thread_body_edited(move |body| {
            if let Some(window) = weak.upgrade() {
                adapter.borrow_mut().action(
                    &window,
                    Action::WriteNewThread {
                        name: None,
                        body: Some(body.into()),
                    },
                );
            }
        });
    }
    {
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_post_title_edited(move |title| {
            if let Some(window) = weak.upgrade() {
                adapter.borrow_mut().action(
                    &window,
                    Action::WriteNewPost {
                        title: Some(title.into()),
                        body: None,
                    },
                );
            }
        });
    }
    {
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_post_body_edited(move |body| {
            if let Some(window) = weak.upgrade() {
                adapter.borrow_mut().action(
                    &window,
                    Action::WriteNewPost {
                        title: None,
                        body: Some(body.into()),
                    },
                );
            }
        });
    }
    {
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_toggle_post_tag(move |tag| {
            if let Some(window) = weak.upgrade() {
                adapter
                    .borrow_mut()
                    .action(&window, Action::TogglePostTag(tag.into()));
            }
        });
    }
    {
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_set_thread_private(move |private| {
            if let Some(window) = weak.upgrade() {
                adapter
                    .borrow_mut()
                    .action(&window, Action::SetThreadPrivate(private));
            }
        });
    }
    {
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_load_sidebar_active_threads(move |room| {
            let Some(window) = weak.upgrade() else { return };
            let now = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map_or(0, |now| now.as_millis() as u64);
            let rows = adapter
                .borrow()
                .app
                .other_active_threads(&room)
                .iter()
                .take(5)
                .map(|thread| super::refresh::thread_row(thread, now))
                .collect::<Vec<_>>();
            window.set_sidebar_active_threads(ModelRc::new(VecModel::from(rows)));
        });
    }
    {
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_open_sidebar_active_thread(move |parent, thread| {
            let Some(window) = weak.upgrade() else { return };
            let mut adapter = adapter.borrow_mut();
            let active = adapter.app.other_active_threads(&parent);
            if thread.is_empty() {
                if !active.is_empty() {
                    adapter.action(&window, Action::SelectRoom(parent.into()));
                    adapter.action(&window, Action::ShowThreads(true));
                }
            } else if active.iter().any(|candidate| candidate.room == thread.as_str()) {
                adapter.action(&window, Action::Open(thread.into()));
            }
        });
    }
    {
        // As Discord's: a click shows the thread in place of its channel,
        // and Shift-click beside it.
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_open_listed_thread(move |room, beside| {
            if let Some(window) = weak.upgrade() {
                let action = match beside {
                    true => Action::OpenAside(room.into()),
                    false => Action::Open(room.into()),
                };
                adapter.borrow_mut().action(&window, action);
            }
        });
    }
    {
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_search_posts(move |query| {
            if let Some(window) = weak.upgrade() {
                adapter
                    .borrow_mut()
                    .action(&window, Action::SearchPosts(query.into()));
            }
        });
    }
    {
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_filter_posts(move |tag| {
            if let Some(window) = weak.upgrade() {
                adapter
                    .borrow_mut()
                    .action(&window, Action::FilterPosts(tag.into()));
            }
        });
    }
    {
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_sort_posts(move |by_creation| {
            if let Some(window) = weak.upgrade() {
                adapter
                    .borrow_mut()
                    .action(&window, Action::SortPosts(by_creation));
            }
        });
    }
    {
        let (adapter, weak) = (adapter.clone(), window.as_weak());
        window.on_more_posts(move || {
            if let Some(window) = weak.upgrade() {
                adapter.borrow_mut().action(&window, Action::MorePosts);
            }
        });
    }
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_add_people_search(move || {
            if let Some(window) = weak.upgrade() {
                let query = window.get_add_people_query().to_string();
                adapter
                    .borrow_mut()
                    .action(&window, Action::AddPeopleQuery(query));
            }
        });
    }
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_new_dm_search(move || {
        if let Some(window) = weak.upgrade() {
            let query = window.get_new_dm_query().to_string();
            state
                .borrow_mut()
                .action(&window, Action::NewDmQuery(query));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_start_dm(move |index| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        let contact = usize::try_from(index).ok().and_then(|index| {
            adapter
                .app
                .state
                .new_dm
                .as_ref()
                .and_then(|new_dm| new_dm.people().nth(index).cloned())
        });
        if let Some(contact) = contact {
            adapter.action(&window, Action::StartDm(contact));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_forward_search(move || {
        if let Some(window) = weak.upgrade() {
            let query = window.get_forward_query().into();
            state
                .borrow_mut()
                .action(&window, Action::SearchForward(query));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    // The emoji per row the grid last took, so a width that leaves the columns
    // alone does not build it again.
    let columns_shown: Rc<Cell<usize>> = Rc::new(Cell::new(0));
    let shown = columns_shown.clone();
    window.on_emoji_search(move |query| {
        let Some(window) = weak.upgrade() else { return };
        let columns = emoji::columns(window.get_emoji_panel_width());
        shown.set(columns);
        // A grid built for a search starts at its top.
        state.borrow_mut().emoji_grid.viewport.0 = 0.0;
        show_emoji(&state, &window, &query, columns);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_emoji_reflow(move || {
        let Some(window) = weak.upgrade() else { return };
        let columns = emoji::columns(window.get_emoji_panel_width());
        // A closed picker has no grid to lay out, and builds it as it opens.
        if columns == columns_shown.get() || state.borrow().models.emoji_rows.row_count() == 0 {
            return;
        }
        columns_shown.set(columns);
        // The grid keeps what is being searched for, laid out again, and the
        // rows where it is scrolled to take their pictures: a wider grid puts
        // emoji in them that were a row below the last time.
        show_emoji(&state, &window, &window.get_emoji_query(), columns);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    // The grid went, and its next opening builds it again: its cells and their
    // pictures can go, and those held for them, the custom emoji ones once there
    // were more than a wide grid shows, since the disk cache has them. glibc would
    // keep what that frees, so it's handed back once the grid's items have gone.
    window.on_emoji_picker_closed(move || {
        let Some(window) = weak.upgrade() else { return };
        custom_emoji::forget_images();
        crate::twemoji::forget();
        let mut adapter = state.borrow_mut();
        adapter.emoji_due.stop();
        adapter.animations.hide_picker();
        adapter.models.emoji_rows.set_vec(Vec::new());
        adapter.models.emoji_sections.set_vec(Vec::new());
        adapter.models.emoji_rail.set_vec(Vec::new());
        adapter.emoji_rows_filled = (0, 0);
        adapter.clear_emoji_grid();
        adapter.action(&window, Action::UnloadEmojiPictures);
        let_go_after_picker(&window);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_emoji_scrolled_to(move |scrolled, height| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        // The rows the grid shows, from where each row says it starts: a
        // heading's row is tighter than one of emoji. A scroll within them
        // asks for nothing again.
        let before = adapter.emoji_grid.shown;
        adapter.emoji_grid.viewport = (scrolled, height);
        let (first, last) = adapter.emoji_rows_in_sight();
        if before == (first, last) && adapter.models.emoji_tiles.row_count() > 0 {
            return;
        }
        // What the grid shows, and the rows around it made ready with it, so
        // a row comes into sight drawn rather than making its picture then.
        prepare_emoji_rows(&mut adapter, &window, first, last);
    });
    bind_item!(on_select_reaction, Action::ShowReactors);
    bind!(on_more_reactors, Action::MoreReactors);
    bind_item!(on_remove_reactor, Action::RemoveReactor);
    bind!(on_close_reactions, Action::CloseReactions);
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_hover_reaction(move |item, key| {
            if let Some(window) = weak.upgrade() {
                let hovered = (!key.is_empty()).then(|| (item.into(), key.into()));
                adapter
                    .borrow_mut()
                    .action(&window, Action::HoverReaction(hovered));
            }
        });
    }
    {
        let adapter = adapter.clone();
        let weak = window.as_weak();
        window.on_view_reactions(move |item, key| {
            if let Some(window) = weak.upgrade() {
                let key = (!key.is_empty()).then(|| key.into());
                adapter.borrow_mut().action(
                    &window,
                    Action::ShowReactions {
                        item: item.into(),
                        key,
                    },
                );
            }
        });
    }
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_react(move |item, key| {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().action(
                &window,
                Action::React {
                    item: item.into(),
                    key: key.into(),
                },
            );
        }
    });
    let state = adapter.clone();
    window.on_members_resized(move |width| {
        let mut adapter = state.borrow_mut();
        adapter.layout.members_width = (width > 0.).then_some(width);
        adapter.layout.write(&adapter.root);
    });
    let state = adapter.clone();
    window.on_sidebar_resized(move |width| {
        let mut adapter = state.borrow_mut();
        adapter.layout.sidebar_width = Some(width);
        adapter.layout.write(&adapter.root);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_aside_resized(move |width| {
        let mut adapter = state.borrow_mut();
        adapter.layout.aside_width = Some(width);
        adapter.layout.write(&adapter.root);
        // Its pictures and link previews fit the new width.
        if let Some(window) = weak.upgrade()
            && adapter.app.state.aside.is_some()
        {
            adapter.show_aside(&window);
        }
    });
    let state = adapter.clone();
    window.on_picker_width_chosen(move |width| {
        let mut adapter = state.borrow_mut();
        if adapter.layout.picker_width == Some(width) {
            return;
        }
        adapter.layout.picker_width = Some(width);
        // Drags that end close together write the file once.
        adapter.write_layout_soon();
    });
    let state = adapter.clone();
    window.on_member_list_toggled(move |shown| {
        let mut adapter = state.borrow_mut();
        adapter.layout.members_hidden = !shown;
        adapter.layout.write(&adapter.root);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_profile_panel_toggled(move |shown| {
        let mut adapter = state.borrow_mut();
        adapter.layout.profile_panel_hidden = !shown;
        adapter.layout.write(&adapter.root);
        if let Some(window) = weak.upgrade() {
            adapter.action(&window, Action::ShowProfilePanel(shown));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_show_hidden_channels_toggled(move |shown| {
        let mut adapter = state.borrow_mut();
        adapter.layout.show_hidden_channels = shown;
        adapter.layout.write(&adapter.root);
        if let Some(window) = weak.upgrade() {
            adapter.action(&window, Action::ShowHiddenChannels(shown));
        }
    });
    // Show more or Show less on a long message: only its own rows change,
    // in the timeline and the thread beside it.
    let state = adapter.clone();
    window.on_fold_message(move |item, whole| {
        let mut adapter = state.borrow_mut();
        let key = messages::fold_key(&item);
        if whole {
            adapter.revealed.insert(key);
        } else {
            adapter.revealed.remove(&key);
        }
        let adapter = &mut *adapter;
        for (model, rows) in [
            (&adapter.models.messages, &mut adapter.rows),
            (&adapter.models.aside_messages, &mut adapter.aside_rows),
        ] {
            for (index, row) in rows.iter_mut().enumerate() {
                if row.item == item && row.expanded != whole {
                    row.expanded = whole;
                    model.set_row_data(index, row.clone());
                }
            }
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_reveal_attachment(move |item, index| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        adapter.revealed.insert(format!("{item}/a{index}"));
        adapter.restyle = true;
        adapter.refresh(&window);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_open_link(move |link| {
        // A blocked message shows when asked for.
        if let Some(item) = link.strip_prefix(BLOCKED_LINK) {
            let Some(window) = weak.upgrade() else { return };
            let mut adapter = state.borrow_mut();
            adapter.revealed.insert(format!("{item}/blocked"));
            adapter.restyle = true;
            adapter.refresh(&window);
            return;
        }
        // A spoiler shows what it hides.
        if let Some((item, index)) = spoiler::target(&link) {
            let Some(window) = weak.upgrade() else { return };
            let mut adapter = state.borrow_mut();
            adapter.revealed.insert(format!("{item}/{index}"));
            adapter.restyle = true;
            adapter.refresh(&window);
            return;
        }
        // A pin's notice jumps to the message pinned, or shows the pinned
        // messages.
        if let Some(item) = link.strip_prefix(messages::JUMP_LINK) {
            if let Some(window) = weak.upgrade() {
                state
                    .borrow_mut()
                    .action(&window, Action::Jump(item.to_owned()));
            }
            return;
        }
        if link == messages::PINS_LINK {
            if let Some(window) = weak.upgrade() {
                window.invoke_open_pins();
            }
            return;
        }
        // An emoji in a message's text opens its card, below it.
        if let Some(target) = emoji_text::target(&link) {
            let Some(window) = weak.upgrade() else { return };
            if let Some(rect) = i_slint_core::yapfast_selection::clicked_link() {
                window.invoke_anchor_link(
                    rect.origin.x,
                    rect.origin.y,
                    rect.size.width,
                    rect.size.height,
                );
            }
            let mut adapter = state.borrow_mut();
            let Adapter { app, pictures, .. } = &mut *adapter;
            let card = messages::emoji_card_for(app, &target, pictures);
            let server = card.server.to_string();
            window.set_emoji_card(card);
            window.set_emoji_card_open(true);
            // Its server's card shows how many are online, which Discord is
            // asked for and the card builds again with once it answers.
            adapter.emoji_card = Some(target);
            if !server.is_empty() {
                adapter.action(&window, Action::PreviewServer(server));
            }
            return;
        }
        // A mention opens the person's card, or the role's members, beside the
        // mention, or by the pointer when the link's place isn't known.
        let author = link
            .strip_prefix(messages::AUTHOR_LINK)
            .map(|user| mention::Target::User(user.to_owned()));
        if let Some(target) = author.or_else(|| mention::target(&link)) {
            let Some(window) = weak.upgrade() else { return };
            if let Some(rect) = i_slint_core::yapfast_selection::clicked_link() {
                window.invoke_anchor_link(
                    rect.origin.x,
                    rect.origin.y,
                    rect.size.width,
                    rect.size.height,
                );
            }
            let action = match target {
                mention::Target::User(user) => {
                    window.set_profile_at_pointer(true);
                    Action::ShowProfile { user, large: false }
                }
                mention::Target::Role(role) => Action::ShowRole(role),
                // Opens its chat; a voice channel's doesn't join the call.
                mention::Target::Channel(room) => Action::Open(room),
                // As in Discord's client, @everyone and @here open nothing.
                mention::Target::Everyone => return,
            };
            state.borrow_mut().action(&window, action);
            return;
        }
        // Discord's own links open their place here, when Yapfast can show
        // it, and in the browser otherwise. An invite shows its server
        // first and joins only when asked, whatever the text says.
        #[cfg(feature = "discord")]
        if let Some(route) =
            yapfast_core::discord::discord_route(links::masked(&link).unwrap_or(&link))
                .filter(|route| state.borrow().app.state.opens_discord_route(route))
        {
            if let Some(window) = weak.upgrade() {
                state
                    .borrow_mut()
                    .action(&window, discord_link_action(&window, route));
            }
            return;
        }
        // A link whose text shows something else asks first.
        if let Some(masked) = links::masked(&link) {
            if let Some(window) = weak.upgrade() {
                window.set_leaving_site(links::host(masked).into());
                window.set_leaving_link(masked.into());
            }
            return;
        }
        open_web_page(&link);
    });
    let weak = window.as_weak();
    window.on_visit_leaving_link(move || {
        let Some(window) = weak.upgrade() else { return };
        open_web_page(&window.get_leaving_link());
        window.set_leaving_link(SharedString::default());
    });
    let weak = window.as_weak();
    window.on_close_leaving_link(move || {
        if let Some(window) = weak.upgrade() {
            window.set_leaving_link(SharedString::default());
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_choose_theme(move |id| {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().choose_theme(&window, &id);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_new_theme(move || {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().new_theme(&window);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_edit_theme(move |id| {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().edit_theme(&window, &id);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_theme_start_chosen(move |index| {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().theme_start_chosen(&window, index);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_theme_colour_edited(move |index, text| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .theme_colour_edited(&window, index, &text);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_theme_dark_toggled(move |dark| {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().theme_dark_toggled(&window, dark);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_save_theme(move || {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().save_theme(&window);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_cancel_theme(move || {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().cancel_theme(&window);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_delete_theme(move || {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().delete_theme(&window);
        }
    });
    let weak = window.as_weak();
    window.on_call_volumes_changed(move || {
        if let Some(window) = weak.upgrade() {
            play_call_volumes(&window);
        }
    });
    let weak = window.as_weak();
    window.on_record_talk_key(move |on| {
        if let Some(window) = weak.upgrade() {
            window.set_talk_recording(on);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_preferences_changed(move || {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        let layout = &mut adapter.layout;
        layout.twelve_hour_clock = window.get_twelve_hour_clock();
        layout.clock_seconds = window.get_clock_seconds();
        layout.date_format = Some(window.get_date_format()).filter(|&index| index >= 0);
        layout.apply_date_format();
        layout.text_size = Some(window.get_text_size());
        layout.link_previews = Some(window.get_link_previews());
        layout.boost_gems = Some(window.get_boost_gems());
        layout.reply_ping = Some(window.get_reply_ping_default());
        layout.strip_tracking = Some(window.get_strip_tracking());
        layout.nameplates = Some(window.get_show_nameplates());
        layout.collapse_long = window.get_collapse_long();
        layout.animate = chosen(&ANIMATES, window.get_animate());
        ANIMATE.set(layout.animate);
        layout.read_cosmetics(&window);
        let cosmetics = layout.effective_cosmetics();
        show_motion(&window);
        layout.unmute_on_join = Some(window.get_unmute_on_join());
        layout.deafen_on_join = window.get_deafen_on_join();
        layout.level_voice = Some(window.get_level_voice());
        yapfast_core::leveling::set_enabled(window.get_level_voice());
        layout.noise_suppression = chosen(&SUPPRESSORS, window.get_noise_suppression());
        layout.noise_strength = chosen(&STRENGTHS, window.get_noise_strength());
        yapfast_core::noise::set(layout.noise_suppression);
        yapfast_core::noise::set_strength(layout.noise_strength);
        layout.reduce_room_echo = window.get_dereverb();
        yapfast_core::noise::set_dereverb(layout.reduce_room_echo);
        layout.windows_microphone_effects = window.get_windows_effects();
        yapfast_core::set_windows_effects(layout.windows_microphone_effects);
        layout.input_sensitivity = Some(window.get_sensitivity());
        yapfast_core::noise::set_sensitivity(layout.sensitivity() as f32);
        layout.input_mode = chosen(&INPUT_MODES, window.get_input_mode());
        yapfast_core::push_to_talk::set_on(layout.input_mode == InputMode::PushToTalk);
        layout.push_to_talk_release_delay = Some(window.get_talk_delay().max(0) as u32);
        yapfast_core::push_to_talk::set_release_delay(layout.release_delay());
        layout.microphone_volume = Some(window.get_microphone_volume().clamp(0, 200) as u8);
        layout.speaker_volume = Some(window.get_speaker_volume().clamp(0, 200) as u8);
        play_call_volumes(&window);
        layout.share_typing = Some(window.get_share_typing());
        layout.notifications = Some(window.get_notifications());
        layout.notification_text = Some(window.get_notification_text());
        layout.flash_taskbar = Some(window.get_flash_taskbar());
        layout.sound_set = chosen(&SoundSet::ALL, window.get_sound_set());
        layout.sound_volume = Some(window.get_sound_volume().clamp(0, 200) as u8);
        layout.adjust_each_sound = window.get_adjust_each_sound();
        layout.gpu_rendering = window.get_gpu_rendering();
        layout.gpu_encoding = Some(window.get_gpu_encoding());
        #[cfg(feature = "discord")]
        yapfast_core::stream_worker::set_hardware_encoding(window.get_gpu_encoding());
        layout.close_to_tray = Some(window.get_close_to_tray());
        layout.multiple_windows = window.get_multiple_windows();
        layout.developer_mode = window.get_developer_mode();
        adapter.layout.write(&adapter.root);
        adapter.watch_talk_key(&window);
        let start = window.get_start_on_sign_in();
        if AUTOSTART.get() && start != autostart::enabled() {
            match autostart::set(start) {
                Ok(()) => tracing::info!(start, "starting at sign-in changed"),
                Err(error) => {
                    tracing::warn!(%error, "could not change starting at sign-in");
                    window.set_start_on_sign_in(!start);
                }
            }
        }
        let discord_links = window.get_discord_links();
        if PROTOCOL.get() && discord_links != crate::protocol::discord_enabled(&adapter.root) {
            match crate::protocol::set_discord_enabled(&adapter.root, discord_links) {
                Ok(()) => tracing::info!(discord_links, "Discord link handling changed"),
                Err(error) => {
                    tracing::warn!(%error, "could not change Discord link handling");
                    window.set_discord_links(!discord_links);
                }
            }
        }
        let profile = adapter.layout.extensions;
        let (reply_ping, strip_tracking) = (
            profile.reply_mentions(window.get_reply_ping_default()),
            profile.tracking(window.get_strip_tracking()),
        );
        adapter.app.dispatch(Action::ReplyPing(reply_ping));
        adapter.app.dispatch(Action::StripTracking(strip_tracking));
        let hide_blocked = profile.hide_blocked(adapter.layout.hide_blocked);
        adapter.app.dispatch(Action::HideBlocked(hide_blocked));
        adapter
            .app
            .dispatch(Action::HideNameplates(!window.get_show_nameplates()));
        adapter.restyle = true;
        // It refreshes the window, and asks for what the profile switches
        // may now show.
        adapter.action(&window, Action::SetCosmetics(cosmetics));
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_each_sound_changed(move |index, percent| {
        let Some((row, &sound)) = usize::try_from(index)
            .ok()
            .and_then(|row| Some((row, Sound::ALL.get(row)?)))
        else {
            return;
        };
        // The sliders show the list again when they next appear.
        if let Some(window) = weak.upgrade() {
            window.get_each_sound().set_row_data(row, percent);
        }
        let mut adapter = state.borrow_mut();
        let percent = percent.clamp(0, 100) as u8;
        if percent == 100 {
            adapter.layout.each_sound.remove(&sound);
        } else {
            adapter.layout.each_sound.insert(sound, percent);
        }
        adapter.layout.write(&adapter.root);
    });
    let state = adapter.clone();
    window.on_play_sound(move |index| {
        if let Some(&sound) = usize::try_from(index)
            .ok()
            .and_then(|index| Sound::ALL.get(index))
        {
            state.borrow().play(sound);
        }
    });
    window.on_volume_of(|person, stream| {
        let kind = if stream {
            yapfast_core::volume::Kind::Stream
        } else {
            yapfast_core::volume::Kind::Voice
        };
        yapfast_core::volume::to_slider(yapfast_core::volume::get(kind, &person)).round() as i32
    });
    let state = adapter.clone();
    window.on_volume_changed(move |person, stream, value, done| {
        let kind = if stream {
            yapfast_core::volume::Kind::Stream
        } else {
            yapfast_core::volume::Kind::Voice
        };
        // Within a step of the default is the default, as Discord snaps it.
        let default = kind.default_gain();
        let volume = if (value as f32 - yapfast_core::volume::to_slider(default)).abs() < 1.0 {
            default
        } else {
            yapfast_core::volume::from_slider(value as f32)
        };
        yapfast_core::volume::set(kind, &person, volume);
        // The drag's last step is remembered, rather than every one.
        if done {
            let mut adapter = state.borrow_mut();
            let volumes = if stream {
                &mut adapter.layout.stream_volumes
            } else {
                &mut adapter.layout.volumes
            };
            if volume == default {
                volumes.remove(person.as_str());
            } else {
                volumes.insert(person.into(), volume);
            }
            adapter.layout.write(&adapter.root);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_activity_cards_hidden_toggled(move |hidden| {
        let mut adapter = state.borrow_mut();
        adapter.layout.activity_cards_hidden = hidden;
        adapter.layout.write(&adapter.root);
        if let Some(window) = weak.upgrade() {
            adapter.action(&window, Action::ActivityCardsHidden(hidden));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_skip_call_prompt_toggled(move |skip| {
        let mut adapter = state.borrow_mut();
        adapter.layout.skip_call_prompt = skip;
        adapter.layout.write(&adapter.root);
        if let Some(window) = weak.upgrade() {
            adapter.action(&window, Action::SkipCallPrompt(skip));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_hide_blocked_toggled(move |hide| {
        let mut adapter = state.borrow_mut();
        adapter.layout.hide_blocked = hide;
        adapter.layout.write(&adapter.root);
        if let Some(window) = weak.upgrade() {
            let effective = adapter.layout.extensions.hide_blocked(hide);
            adapter.action(&window, Action::HideBlocked(effective));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_show_idle_toggled(move |shown| {
        let mut adapter = state.borrow_mut();
        adapter.layout.show_idle = Some(shown);
        adapter.layout.write(&adapter.root);
        if let Some(window) = weak.upgrade() {
            adapter.idle_setting_changed(&window);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_sync_discord_reads_toggled(move |sync| {
        let mut adapter = state.borrow_mut();
        adapter.layout.sync_discord_reads = Some(sync);
        adapter.layout.write(&adapter.root);
        if let Some(window) = weak.upgrade() {
            adapter.action(&window, Action::SyncDiscordReads(sync));
        }
    });
    // The channel's composer and the thread beside's pick files alike.
    let pick = |state: Rc<RefCell<Adapter>>, aside: bool| {
        move || {
            let target = {
                let adapter = state.borrow();
                let state = &adapter.app.state;
                let room = if aside {
                    (state.aside.as_ref().map(|thread| thread.room.clone()), None)
                } else {
                    (
                        state.selected.clone(),
                        state
                            .command_draft()
                            .map(|draft| (draft.input_id(), draft.focused)),
                    )
                };
                (state.account.clone(), state.discord_user.clone(), room)
            };
            let weak = Rc::downgrade(&state);
            state.borrow_mut().dialog(async move {
                let files = rfd::AsyncFileDialog::new()
                    .set_title("Attach files")
                    .pick_files()
                    .await;
                if let (Some(files), Some(adapter)) = (files, weak.upgrade()) {
                    let current = {
                        let adapter = adapter.borrow();
                        let state = &adapter.app.state;
                        let room = if aside {
                            (state.aside.as_ref().map(|thread| thread.room.clone()), None)
                        } else {
                            (
                                state.selected.clone(),
                                state
                                    .command_draft()
                                    .map(|draft| (draft.input_id(), draft.focused)),
                            )
                        };
                        (state.account.clone(), state.discord_user.clone(), room)
                    };
                    if current != target {
                        return;
                    }
                    let window = adapter.borrow().window.upgrade();
                    if let Some(window) = window {
                        let paths = files.iter().map(|file| file.path().to_owned()).collect();
                        adapter.borrow_mut().action(
                            &window,
                            if aside {
                                Action::StageAside(paths)
                            } else {
                                Action::Stage(paths)
                            },
                        );
                    }
                }
            });
        }
    };
    window.on_attach(pick(adapter.clone(), false));
    window.on_aside_attach(pick(adapter.clone(), true));
    let state = adapter.clone();
    window.on_unstage(move |index| {
        let mut adapter = state.borrow_mut();
        if let (Ok(index), Some(window)) = (usize::try_from(index), adapter.window.upgrade()) {
            adapter.action(&window, Action::Unstage(index));
        }
    });
    let state = adapter.clone();
    window.on_toggle_spoiler(move |index| {
        let mut adapter = state.borrow_mut();
        if let (Ok(index), Some(window)) = (usize::try_from(index), adapter.window.upgrade()) {
            adapter.action(&window, Action::ToggleSpoiler(index));
        }
    });
    let state = adapter.clone();
    window.on_aside_unstage(move |index| {
        let mut adapter = state.borrow_mut();
        if let (Ok(index), Some(window)) = (usize::try_from(index), adapter.window.upgrade()) {
            adapter.action(&window, Action::UnstageAside(index));
        }
    });
    let state = adapter.clone();
    window.on_aside_toggle_spoiler(move |index| {
        let mut adapter = state.borrow_mut();
        if let (Ok(index), Some(window)) = (usize::try_from(index), adapter.window.upgrade()) {
            adapter.action(&window, Action::ToggleAsideSpoiler(index));
        }
    });
    let state = adapter.clone();
    window.on_paste_into_composer(move || state.borrow_mut().paste(false));
    let state = adapter.clone();
    window.on_aside_paste(move || state.borrow_mut().paste(true));
    let state = adapter.clone();
    window.on_copy_attachment(move |item, index| {
        let mut adapter = state.borrow_mut();
        if let (Ok(index), Some(window)) = (usize::try_from(index), adapter.window.upgrade()) {
            let item = item.into();
            adapter.action(&window, Action::CopyAttachment { item, index });
        }
    });
    window.on_selection_at(|x, y| {
        i_slint_core::yapfast_selection::copied_at(i_slint_core::lengths::LogicalPoint::new(x, y))
            .unwrap_or_default()
            .into()
    });
    window.on_link_at(|x, y| {
        let point = i_slint_core::lengths::LogicalPoint::new(x, y);
        i_slint_core::yapfast_selection::pressed_link_at(point)
            .as_deref()
            .and_then(web_address)
            .unwrap_or_default()
            .into()
    });
    let weak = window.as_weak();
    window
        .global::<yapfast_ui::CardLinks>()
        .on_show(move |link, x, y| {
            if let (Some(window), Some(address)) = (weak.upgrade(), web_address(&link)) {
                window.invoke_open_button_link_menu(address.into(), x, y);
            }
        });
    let weak = window.as_weak();
    window
        .global::<yapfast_ui::CardLinks>()
        .on_show_handoff(move |link, x, y| {
            if let (Some(window), true) = (weak.upgrade(), is_discord_message_handoff(&link)) {
                window.invoke_open_handoff_link_menu(link, x, y);
            }
        });
    window
        .global::<yapfast_ui::CardLinks>()
        .on_open_handoff(|link| {
            if is_discord_message_handoff(&link) {
                open_web_page(&link);
            }
        });
    let state = adapter.clone();
    window.on_attachment_link(move |item, index| {
        let adapter = state.borrow();
        usize::try_from(index)
            .ok()
            .and_then(|index| {
                adapter
                    .app
                    .state
                    .message(&item)?
                    .attachments
                    .get(index)?
                    .url
                    .as_deref()
            })
            .unwrap_or_default()
            .into()
    });
    let state = adapter.clone();
    window.on_save_attachment(move |item, index| {
        let item = item.to_string();
        let index = usize::try_from(index).unwrap_or_default();
        let name = state
            .borrow()
            .app
            .state
            .message(&item)
            .and_then(|message| message.attachments.get(index))
            .map(|attachment| attachment.name.clone())
            .unwrap_or_default();
        let weak = Rc::downgrade(&state);
        state.borrow_mut().dialog(async move {
            // Only the file name is suggested; a sender cannot choose the
            // folder, hide the file with a leading dot, or reverse how its
            // extension reads.
            let name = std::path::Path::new(&name)
                .file_name()
                .map(|name| {
                    name.to_string_lossy()
                        .chars()
                        .filter(|&c| !c.is_control() && !links::hidden(c))
                        .collect::<String>()
                        .trim_start_matches(['.', ' '])
                        .to_owned()
                })
                .filter(|name| !name.is_empty())
                .unwrap_or_else(|| "attachment".into());
            let file = rfd::AsyncFileDialog::new()
                .set_title("Save attachment")
                .set_file_name(name)
                .save_file()
                .await;
            if let (Some(file), Some(adapter)) = (file, weak.upgrade()) {
                let window = adapter.borrow().window.upgrade();
                if let Some(window) = window {
                    adapter.borrow_mut().action(
                        &window,
                        Action::SaveAttachment {
                            item,
                            index,
                            path: file.path().to_owned(),
                        },
                    );
                }
            }
        });
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_login(move || {
        if let Some(window) = weak.upgrade() {
            let mut state = state.borrow_mut();
            let busy = state.app.state.busy;
            state.action(
                &window,
                Action::Login {
                    homeserver: window.get_homeserver().into(),
                    username: window.get_username().into(),
                    password: window.get_password().into(),
                },
            );
            if !busy && state.app.state.busy {
                window.set_password(SharedString::default());
            }
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_recover(move || {
        if let Some(window) = weak.upgrade() {
            let mut state = state.borrow_mut();
            let busy = state.app.state.busy;
            state.action(&window, Action::Recover(window.get_recovery().into()));
            if !busy && state.app.state.busy {
                window.set_recovery(SharedString::default());
            }
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_navigate_server(move |id| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::Navigate(Navigation::Server(id.into())));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_toggle_folder(move |id| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        if !adapter.layout.open_folders.remove(id.as_str()) {
            adapter.layout.open_folders.insert(id.into());
        }
        adapter.layout.write(&adapter.root);
        // What the sidebar was built from leaves the layout out.
        adapter.sidebar = None;
        adapter.show_sidebar(&window);
    });
    server_order::bind(window, adapter);
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_open_aside(move |id| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::OpenAside(id.into()));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_open_conversation(move |id| {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().action(&window, Action::Open(id.into()));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_open_call(move || {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().action(&window, Action::GoToCall);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_open_chat(move |id| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::OpenChat(id.into()));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_show_voice_chat(move |chat| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::ShowVoiceChat(chat));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_select_room(move |id| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::SelectRoom(id.into()));
        }
    });
    for field in [Field::Channel, Field::Aside, Field::Edit] {
        let state = adapter.clone();
        let weak = window.as_weak();
        let caret = move |text: SharedString, offset: i32| {
            let Some(window) = weak.upgrade() else { return };
            // Choosing a suggestion moves the cursor while it's being handled.
            let Ok(mut adapter) = state.try_borrow_mut() else {
                return;
            };
            composer_caret(&mut adapter, &window, &text, offset, field);
        };
        match field {
            Field::Channel => window.on_composer_caret(caret),
            Field::Aside => window.on_aside_composer_caret(caret),
            Field::Edit => window.global::<InlineEdit>().on_caret(caret),
        }
    }
    inline_edit(adapter, window);
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_mention_chosen(move |index| {
        let Some(window) = weak.upgrade() else { return };
        let caret = {
            let mut adapter = state.borrow_mut();
            let chosen = usize::try_from(index).ok().and_then(|index| {
                adapter
                    .app
                    .state
                    .mention_suggestions()
                    .into_iter()
                    .nth(index)
            });
            let (Some(chosen), Some(at), Some((sigil, query))) = (
                chosen,
                adapter.mention_at,
                adapter.app.state.mention_query.clone(),
            ) else {
                return;
            };
            let field = adapter.suggesting;
            let text = adapter.composer_text(field);
            let end = at + 1 + query.len();
            if text.get(at..end) != Some(format!("{sigil}{query}").as_str()) {
                return;
            }
            let inserted = format!("{}{} ", chosen.sigil(), chosen.name);
            let text = format!("{}{inserted}{}", &text[..at], &text[end..]);
            adapter.mention_at = None;
            adapter.action(&window, Action::MentionQuery(None));
            adapter.set_composer_text(&window, field, text);
            (field, at + inserted.len())
        };
        place_composer_caret(&window, caret);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_emoji_suggestion_chosen(move |index| {
        let Some(window) = weak.upgrade() else { return };
        let caret = {
            let mut adapter = state.borrow_mut();
            let chosen = usize::try_from(index)
                .ok()
                .and_then(|index| adapter.models.emoji_suggestions.row_data(index));
            let word = adapter.emoji_word.take();
            adapter.show_emoji_suggestions(&window);
            let (Some(chosen), Some((at, name))) = (chosen, word) else {
                return;
            };
            let field = adapter.suggesting;
            let text = adapter.composer_text(field);
            let end = at + 1 + name.len();
            if text.get(at..end) != Some(format!(":{name}").as_str()) {
                return;
            }
            let inserted = format!("{} ", emoji::composer_text(&chosen.key));
            let text = format!("{}{inserted}{}", &text[..at], &text[end..]);
            adapter.set_composer_text(&window, field, text);
            (field, at + inserted.len())
        };
        place_composer_caret(&window, caret);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_emoji_suggestion_dismissed(move || {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        adapter.emoji_dismissed = adapter.emoji_word.take().map(|(at, _)| at);
        adapter.show_emoji_suggestions(&window);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_insert_emoji(move |key| {
        let Some(window) = weak.upgrade() else { return };
        let caret = {
            let mut adapter = state.borrow_mut();
            let text = adapter.app.state.draft().to_owned();
            // At the cursor this room's composer last had, else at the end.
            let at = adapter
                .caret
                .as_ref()
                .filter(|(room, _)| adapter.app.state.selected.as_ref() == Some(room))
                .map(|&(_, at)| at)
                .filter(|&at| text.is_char_boundary(at))
                .unwrap_or(text.len());
            let inserted = emoji::composer_text(&key);
            let text = format!("{}{inserted}{}", &text[..at], &text[at..]);
            adapter.action(&window, Action::SetDraft(text));
            at + inserted.len()
        };
        window.invoke_place_composer_caret(i32::try_from(caret).unwrap_or(i32::MAX));
        window.invoke_focus_composer();
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_mention_dismissed(move || {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        adapter.mention_dismissed = adapter.mention_at.take();
        adapter.action(&window, Action::MentionQuery(None));
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_draft_edited(move |text| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        // The caret's move usually took the text already; a second refresh
        // with nothing changed is wasted work on every keystroke.
        if adapter.app.state.draft() != text.as_str() {
            adapter.action(&window, Action::SetDraft(text.into()));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    // The filters only narrow the sidebar's lists.
    window.on_filter_edited(move || {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().show_sidebar(&window);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_toggle_category(move |category| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        let Navigation::Server(server) = adapter.app.state.navigation.clone() else {
            return;
        };
        let collapsed = adapter.layout.collapsed.entry(server.clone()).or_default();
        if !collapsed.remove(category.as_str()) {
            collapsed.insert(category.into());
        }
        if collapsed.is_empty() {
            adapter.layout.collapsed.remove(&server);
        }
        adapter.layout.write(&adapter.root);
        // What the sidebar was built from leaves the layout out.
        adapter.sidebar = None;
        adapter.show_sidebar(&window);
    });
    // Dragging a Discord server's channels and categories, by their places
    // in its channel list; see RoomList.
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_start_arranging(move |place| {
        let Some(window) = weak.upgrade() else {
            return false;
        };
        let mut adapter = state.borrow_mut();
        let room = usize::try_from(place - 1)
            .ok()
            .and_then(|at| adapter.places.get(at))
            .cloned();
        adapter.arranging = room;
        adapter.show_arranging(&window);
        adapter.arranging.is_some()
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_arrange_room(move |place| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        window.set_room_arranging(0);
        let Some(room) = adapter.arranging.take() else {
            return;
        };
        let landing = adapter
            .places
            .iter()
            .position(|known| *known == room)
            .zip(usize::try_from(place - 1).ok())
            .and_then(|(dragged, onto)| adapter.app.landing(&adapter.places, dragged, onto));
        if let Some(landing) = landing {
            adapter.action(&window, Action::MoveChannel { room, landing });
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_stop_arranging(move || {
        let Some(window) = weak.upgrade() else { return };
        state.borrow_mut().arranging = None;
        window.set_room_arranging(0);
    });
    // Dragging someone from a voice channel onto another, which moves them
    // as their menu's Move to does; see RoomList.
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_start_moving_person(move |place, user| {
        let Some(window) = weak.upgrade() else {
            return false;
        };
        let mut adapter = state.borrow_mut();
        if adapter.arranging.is_some() {
            return false;
        }
        adapter.moving_person = Some((place.into(), user.into()));
        adapter.show_moving_person(&window);
        adapter.moving_person.is_some()
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_move_person(move |to| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        let action = adapter
            .moving_person
            .as_ref()
            .and_then(|(place, user)| adapter.app.move_to(place, user, &to));
        adapter.stop_moving_person(&window);
        if let Some(action) = action {
            adapter.action(&window, action);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_stop_moving_person(move || {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().stop_moving_person(&window);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_answer_move_sync(move |sync| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::AnswerMoveSync(Some(sync)));
        }
    });
    bind!(on_close_move_sync, Action::AnswerMoveSync(None));
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_friend_filter_edited(move || {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().show_sidebar(&window);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_browse_filter_edited(move || {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().show_sidebar(&window);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_browse_follow(move |room, follow| {
        if let Some(window) = weak.upgrade() {
            let room = room.into();
            state
                .borrow_mut()
                .action(&window, Action::BrowseFollow { room, follow });
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_join_voice(move || {
        if let Some(window) = weak.upgrade() {
            let id = state.borrow().app.state.selected.clone();
            if let Some(id) = id {
                state
                    .borrow_mut()
                    .action(&window, Action::RequestJoinVoice(id));
            }
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_toggle_mute(move || {
        if let Some(window) = weak.upgrade() {
            if !state.borrow().app.state.voice.active() {
                state.borrow_mut().toggle_on_join(&window, false);
                return;
            }
            let muted = state.borrow().app.state.voice.muted;
            state
                .borrow_mut()
                .action(&window, Action::Voice(voice::Command::Mute(!muted)));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_toggle_share(move || {
        if let Some(window) = weak.upgrade() {
            let command = {
                let state = state.borrow();
                let voice = &state.app.state.voice;
                if voice.sharing.is_some() {
                    voice::Command::StopLive
                } else {
                    voice::Command::GoLive(voice.quality)
                }
            };
            state.borrow_mut().action(&window, Action::Voice(command));
        }
    });
    #[cfg(feature = "discord")]
    window.set_share_lists(!yapfast_core::stream_worker::portal_picks());
    #[cfg(feature = "discord")]
    let weak = window.as_weak();
    #[cfg(feature = "discord")]
    window.on_list_share_sources(move || {
        use yapfast_core::stream_worker::{Report, Source, Worker};
        // A picture fills a card in the share menu, in pixels.
        let scale = weak
            .upgrade()
            .map_or(1.0, |window| window.window().scale_factor());
        let (width, height) = ((160.0 * scale).ceil() as u32, (90.0 * scale).ceil() as u32);
        // Listing starts a capturer for screens and one for windows, and
        // looks at each camera, so it runs beside the window, and the menu
        // opens when it's done.
        let weak = weak.clone();
        std::thread::spawn(move || {
            let mut screens = vec![];
            let mut windows = vec![];
            let mut cameras = vec![];
            for listed in yapfast_core::stream_worker::shareable() {
                match listed.source {
                    Source::Display(_) => screens.push(listed),
                    Source::Camera(_) => cameras.push(listed),
                    _ => windows.push(listed),
                }
            }
            let ids: Vec<u64> = screens
                .iter()
                .filter_map(|listed| match listed.source {
                    Source::Display(id) => Some(id),
                    _ => None,
                })
                .collect();
            let opened = weak.upgrade_in_event_loop(move |window| {
                let rows: Vec<ShareScreen> = screens
                    .iter()
                    .map(|listed| ShareScreen {
                        title: listed.title.as_str().into(),
                        picture: Default::default(),
                    })
                    .collect();
                let titles = |listed: &[yapfast_core::stream_worker::Shareable]| {
                    let titles: Vec<SharedString> = listed
                        .iter()
                        .map(|listed| listed.title.as_str().into())
                        .collect();
                    ModelRc::new(VecModel::from(titles))
                };
                window.set_share_screens(Rc::new(VecModel::from(rows)).into());
                window.set_share_windows(titles(&windows));
                window.set_share_cameras(titles(&cameras));
                // Where the system's dialog picks a screen or window, the
                // menu's first choice asks it, before the cameras.
                let dialog = yapfast_core::stream_worker::portal_picks().then_some(Source::Screen);
                SHAREABLE.with_borrow_mut(|shareable| {
                    *shareable = screens
                        .into_iter()
                        .chain(windows)
                        .map(|listed| listed.source)
                        .chain(dialog)
                        .chain(cameras.into_iter().map(|listed| listed.source))
                        .collect();
                });
                window.invoke_show_share_menu();
            });
            if opened.is_err() || ids.is_empty() {
                return;
            }
            // The pictures come from a worker, so capturing the screens takes
            // memory only until they're in.
            let (_worker, mut reports) = match Worker::glance(ids, width, height) {
                Ok(started) => started,
                Err(error) => {
                    tracing::warn!("no pictures of the screens to share: {error:#}");
                    return;
                }
            };
            while let Some(report) = reports.blocking_recv() {
                match report {
                    Report::Screen {
                        id,
                        width,
                        height,
                        rgba,
                    } => {
                        let pixels =
                            slint::SharedPixelBuffer::<slint::Rgba8Pixel>::clone_from_slice(
                                &rgba, width, height,
                            );
                        let _ = weak.upgrade_in_event_loop(move |window| {
                            let at = SHAREABLE.with_borrow(|shareable| {
                                shareable
                                    .iter()
                                    .position(|source| *source == Source::Display(id))
                            });
                            let screens = window.get_share_screens();
                            if let Some(at) = at
                                && let Some(mut row) = screens.row_data(at)
                            {
                                row.picture = slint::Image::from_rgba8(pixels);
                                screens.set_row_data(at, row);
                            }
                        });
                    }
                    Report::Ended { error } => {
                        if let Some(error) = error {
                            tracing::warn!("no pictures of the screens to share: {error}");
                        }
                        break;
                    }
                    _ => {}
                }
            }
        });
    });
    // Without Discord there's nothing to list; the menu still picks the
    // quality.
    #[cfg(not(feature = "discord"))]
    let weak = window.as_weak();
    #[cfg(not(feature = "discord"))]
    window.on_list_share_sources(move || {
        if let Some(window) = weak.upgrade() {
            window.invoke_show_share_menu();
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_go_live(move |source, resolution, fps, high_quality| {
        if let Some(window) = weak.upgrade() {
            #[cfg(feature = "discord")]
            {
                let picked =
                    SHAREABLE.with_borrow(|shareable| shareable.get(source as usize).cloned());
                yapfast_core::stream_worker::pick(
                    picked.unwrap_or(yapfast_core::stream_worker::Source::Screen),
                );
            }
            #[cfg(not(feature = "discord"))]
            let _ = source;
            let resolution = match resolution {
                0 => voice::Resolution::P720,
                2 => voice::Resolution::Source,
                _ => voice::Resolution::P1080,
            };
            let quality = voice::StreamQuality {
                resolution,
                fps: fps.clamp(1, 60) as u32,
                high_quality,
            };
            state
                .borrow_mut()
                .action(&window, Action::Voice(voice::Command::GoLive(quality)));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_switch_live(move |source| {
        if let Some(window) = weak.upgrade() {
            #[cfg(feature = "discord")]
            if let Some(picked) =
                SHAREABLE.with_borrow(|shareable| shareable.get(source as usize).cloned())
            {
                yapfast_core::stream_worker::pick(picked);
            }
            #[cfg(not(feature = "discord"))]
            let _ = source;
            state
                .borrow_mut()
                .action(&window, Action::Voice(voice::Command::SwitchLive));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_show_voice_person(move |room, user| {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().action(
                &window,
                Action::ShowVoicePerson {
                    room: room.into(),
                    user: user.into(),
                },
            );
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_watch_stream(move |id| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::Voice(voice::Command::Watch(id.into())));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_stop_watching(move || {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::Voice(voice::Command::StopWatching));
        }
    });
    let weak = window.as_weak();
    window.on_call_fullscreen_changed(move || {
        if let Some(window) = weak.upgrade() {
            repaint_call_window(&window);
        }
    });
    // Frames skip the application state, which would redraw far more than the pictures.
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_stream_tick(move || {
        let Some(window) = weak.upgrade() else {
            return;
        };
        let adapter = state.borrow();
        adapter.sync_call_video_popout(&window);
        let voice = &adapter.app.state.voice;
        let image = |width, height, pixels: &[u8]| {
            slint::Image::from_rgba8(slint::SharedPixelBuffer::clone_from_slice(
                pixels, width, height,
            ))
        };
        let mut call_frame_changed = false;
        if let Some(frame) = voice
            .sharing
            .as_ref()
            .and_then(|sharing| sharing.frames.take(image))
        {
            window.set_share_frame(frame);
            call_frame_changed = true;
        }
        place_videos(&adapter, &window);
        let frames = &adapter.models.participant_frames;
        for (index, raw) in adapter.stage_people.iter().copied().enumerate() {
            let Some(person) = voice.participants.get(raw) else {
                continue;
            };
            if adapter.call_video_disabled(&person.id) {
                continue;
            }
            if let Some(frame) = person
                .video
                .as_ref()
                .and_then(|feed| feed.take(pictures::frame))
                && index < frames.row_count()
            {
                adapter.publish_detached_camera(&person.id, &frame);
                frames.set_row_data(index, frame);
                call_frame_changed = true;
            }
        }
        if let Some(frame) = adapter
            .camera_test
            .as_ref()
            .and_then(|(_, feed)| feed.take(pictures::frame))
        {
            window.set_camera_preview(frame);
        }
        if let Some(frame) = voice
            .watching
            .as_ref()
            .and_then(|watching| watching.frames.as_ref())
            .and_then(|frames| frames.take(image))
        {
            if let Some(watched) = &voice.watching {
                adapter.publish_detached_stream(&watched.user, &frame);
            }
            window.set_watch_frame(frame);
            call_frame_changed = true;
        }
        if call_frame_changed {
            repaint_popup_over_call(&window);
        }
        let video = adapter.app.state.video.as_ref();
        let taken =
            video.and_then(|video| Some((video, video.frames.as_ref()?.take_timed(image)?)));
        if taken.is_none() && video.is_some_and(|video| !video.playing && !video.loading) {
            // Half a second without a picture: a paused video's ticks stop.
            adapter.video_quiet.set(adapter.video_quiet.get() + 1);
            if adapter.video_quiet.get() > 15 {
                window.set_video_active(false);
            }
        }
        if let Some((video, (frame, time))) = taken {
            adapter.video_quiet.set(0);
            let player = window.global::<VideoPlayer>();
            player.set_frame(frame);
            player.set_has_frame(true);
            // The last picture shows a little before the end.
            let time = match video.duration_ms {
                Some(duration) if video.ended => duration,
                _ => time,
            };
            if let Some(duration) = video.duration_ms.filter(|duration| *duration > 0) {
                player.set_progress((time as f64 / duration as f64).min(1.0) as f32);
            }
            player.set_time(refresh::video_time(time, video.duration_ms).into());
        }
    });
    // The video playing: started from its cell, controlled from its bar.
    let player = window.global::<VideoPlayer>();
    let state = adapter.clone();
    let weak = window.as_weak();
    player.on_play(move |item, index, width, height| {
        if let Some(window) = weak.upgrade() {
            let scale = window.window().scale_factor();
            let pixels = |side: f32| (side * scale).round().max(1.0) as u32;
            let (width, height) = (pixels(width), pixels(height));
            let action = Action::PlayVideo {
                item: item.into(),
                index: index as usize,
                width,
                height,
            };
            let mut adapter = state.borrow_mut();
            adapter.video_cell.set((width, height));
            adapter.action(&window, action);
        }
    });
    // Full screen, its pictures come at the viewer's size; back in its
    // cell, at the cell's.
    let state = adapter.clone();
    let weak = window.as_weak();
    player.on_expand(move |expanded| {
        if let Some(window) = weak.upgrade() {
            window.global::<VideoPlayer>().set_expanded(expanded);
            if !expanded {
                let mut adapter = state.borrow_mut();
                let (width, height) = adapter.video_cell.get();
                adapter.action(&window, Action::Video(VideoCommand::Size { width, height }));
            }
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    player.on_resize(move |width, height| {
        if let Some(window) = weak.upgrade()
            && window.global::<VideoPlayer>().get_expanded()
        {
            let scale = window.window().scale_factor();
            let pixels = |side: f32| (side * scale).round().max(1.0) as u32;
            let size = VideoCommand::Size {
                width: pixels(width),
                height: pixels(height),
            };
            state.borrow_mut().action(&window, Action::Video(size));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    player.on_toggle(move || {
        if let Some(window) = weak.upgrade() {
            let playing = state
                .borrow()
                .app
                .state
                .video
                .as_ref()
                .is_some_and(|video| video.playing);
            let command = if playing {
                VideoCommand::Pause
            } else {
                VideoCommand::Play
            };
            state.borrow_mut().action(&window, Action::Video(command));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    player.on_seek(move |fraction| {
        if let Some(window) = weak.upgrade() {
            let duration = state
                .borrow()
                .app
                .state
                .video
                .as_ref()
                .and_then(|video| video.duration_ms);
            if let Some(duration) = duration {
                let at = (f64::from(fraction.clamp(0.0, 1.0)) * duration as f64) as u64;
                state
                    .borrow_mut()
                    .action(&window, Action::Video(VideoCommand::Seek(at)));
            }
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    player.on_mute(move |muted| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::Video(VideoCommand::Mute(muted)));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    player.on_change_volume(move |volume| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::Video(VideoCommand::Volume(volume)));
        }
    });
    // A voice message's card plays, pauses and moves it, and sets how fast
    // and loud voice messages play.
    let voice = window.global::<VoicePlayer>();
    let state = adapter.clone();
    let weak = window.as_weak();
    voice.on_toggle(move |item| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::ToggleVoiceMessage(item.into()));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    voice.on_cycle_speed(move || {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::CycleVoiceMessageSpeed);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    voice.on_change_volume(move |volume| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::VoiceMessageVolume(volume));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    voice.on_mute(move |muted| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::MuteVoiceMessages(muted));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    voice.on_seek(move |item, fraction| {
        if let Some(window) = weak.upgrade() {
            state
                .borrow_mut()
                .action(&window, Action::MoveVoiceMessage(item.into(), fraction));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_join_unmuted(move || {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().action(&window, Action::UnmuteOnJoin);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_join_deafened(move || {
        if let Some(window) = weak.upgrade() {
            state.borrow_mut().action(&window, Action::DeafenOnJoin);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_toggle_deafen(move || {
        if let Some(window) = weak.upgrade() {
            if !state.borrow().app.state.voice.active() {
                state.borrow_mut().toggle_on_join(&window, true);
                return;
            }
            let deafened = state.borrow().app.state.voice.deafened;
            state
                .borrow_mut()
                .action(&window, Action::Voice(voice::Command::Deafen(!deafened)));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_select_microphone(move |index| {
        if let Some(window) = weak.upgrade() {
            let id = audio_device_choice(&state.borrow().app.state.voice.microphones, index);
            if let Some(id) = id {
                let mut adapter = state.borrow_mut();
                if adapter.app.state.voice.microphone == id {
                    return;
                }
                if adapter.meter.is_some() {
                    adapter.meter = Some(InputMeter::start(id.as_deref()));
                }
                #[cfg(feature = "discord")]
                if adapter.gate_meter.is_some() {
                    adapter.gate_meter =
                        Some(yapfast_core::discord_audio::GateMeter::start(id.as_deref()));
                }
                adapter.action(&window, Action::Voice(voice::Command::Microphone(id)));
            }
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_select_speaker(move |index| {
        if let Some(window) = weak.upgrade() {
            let id = audio_device_choice(&state.borrow().app.state.voice.speakers, index);
            if let Some(id) = id {
                let mut adapter = state.borrow_mut();
                if adapter.app.state.voice.speaker != id {
                    adapter.action(&window, Action::Voice(voice::Command::Speaker(id)));
                }
            }
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_play_soundboard(move |id| {
        let Some(window) = weak.upgrade() else { return };
        state.borrow_mut().action(
            &window,
            Action::Voice(voice::Command::Soundboard(id.into())),
        );
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_preview_soundboard(move |id| {
        let Some(window) = weak.upgrade() else { return };
        state.borrow_mut().action(
            &window,
            Action::Voice(voice::Command::PreviewSound(id.into())),
        );
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_favorite_soundboard(move |id, favorite| {
        let Some(window) = weak.upgrade() else { return };
        state.borrow_mut().action(
            &window,
            Action::Voice(voice::Command::FavoriteSound(id.into(), favorite)),
        );
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_soundboard_volume_committed(move |volume| {
        let Some(window) = weak.upgrade() else { return };
        state
            .borrow_mut()
            .action(&window, Action::SoundboardVolume(volume as f32));
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_entrance_sounds_wanted(move || {
        let Some(window) = weak.upgrade() else { return };
        state.borrow_mut().action(&window, Action::LoadSoundCatalog);
    });
    // Another server's entrance sound shows.
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_entrance_server_chosen(move |_| {
        let Some(window) = weak.upgrade() else { return };
        state.borrow_mut().refresh(&window);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_choose_entrance_sound(move |id| {
        let Some(window) = weak.upgrade() else { return };
        let server = {
            let adapter = state.borrow();
            usize::try_from(window.get_entrance_server())
                .ok()
                .and_then(|index| adapter.entrance_servers.get(index).cloned())
                .flatten()
        };
        let sound = (!id.is_empty()).then(|| id.to_string());
        state
            .borrow_mut()
            .action(&window, Action::SetJoinSound { server, sound });
    });
    // The sounds' custom emoji come once the soundboard shows.
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_soundboard_opened(move || {
        let Some(window) = weak.upgrade() else { return };
        let pictures: Vec<String> = state
            .borrow()
            .app
            .state
            .voice
            .soundboard
            .iter()
            .flat_map(|groups| groups.iter())
            .flat_map(|group| &group.sounds)
            .filter_map(|sound| sound.picture.clone())
            .collect();
        if !pictures.is_empty() {
            state
                .borrow_mut()
                .action(&window, Action::LoadPictures(pictures));
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_toggle_camera(move || {
        let Some(window) = weak.upgrade() else { return };
        // A click while the camera starts cancels it.
        let on = state.borrow().app.state.voice.camera_phase == voice::CameraPhase::Off;
        state
            .borrow_mut()
            .action(&window, Action::Voice(voice::Command::Video(on)));
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_call_tiles(
        move |columns,
              width,
              height,
              gap,
              top,
              scrolled,
              shown,
              focused,
              focus_width,
              focus_height| {
            let Some(window) = weak.upgrade() else { return };
            let mut adapter = state.borrow_mut();
            adapter.tiles = Some(Tiles {
                columns: columns.max(0) as u32,
                width,
                height,
                gap,
                top,
                scrolled,
                shown,
                focused: usize::try_from(focused).ok(),
                focus_width,
                focus_height,
            });
            place_videos(&adapter, &window);
        },
    );
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_focus_tile(move |slot| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        let adapter = &mut *adapter;
        let voice = &adapter.app.state.voice;
        let people = adapter.stage_people_for_call();
        let stage = Stage {
            participants: &people,
            sharing: voice.sharing.is_some(),
        };
        adapter.call_focus = usize::try_from(slot)
            .ok()
            .and_then(|slot| stage.focus_at(slot));
        adapter.show_stage(&window);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_select_camera(move |index| {
        let Some(window) = weak.upgrade() else { return };
        let id = usize::try_from(index).ok().and_then(|index| {
            let adapter = state.borrow();
            adapter
                .app
                .state
                .voice
                .cameras
                .get(index)
                .map(|device| device.id.clone())
        });
        if let Some(id) = id {
            let mut adapter = state.borrow_mut();
            adapter.action(&window, Action::Voice(voice::Command::Camera(id)));
            if adapter.camera_test.is_some() {
                adapter.camera_test = None;
                start_camera_test(&mut adapter, &window);
            }
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_test_camera(move |on| {
        let Some(window) = weak.upgrade() else { return };
        let mut adapter = state.borrow_mut();
        adapter.camera_test = None;
        window.set_camera_note(SharedString::default());
        if on {
            start_camera_test(&mut adapter, &window);
        }
    });
    let state = adapter.clone();
    window.on_metering(move |on| {
        let mut adapter = state.borrow_mut();
        let microphone = adapter.app.state.voice.microphone.clone();
        adapter.meter = on.then(|| InputMeter::start(microphone.as_deref()));
    });
    // The level skips the application state, which would redraw far more than the meter.
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_meter_tick(move || {
        if let (Some(window), Some(meter)) = (weak.upgrade(), &state.borrow().meter) {
            window.set_input_level(meter.level());
            window.set_meter_note(SharedString::from(if !meter::AVAILABLE {
                "The level meter isn't available on this system yet."
            } else if meter.failed() {
                "S;C can't read this microphone. Check that it's connected, or choose another."
            } else {
                ""
            }));
        }
    });
    #[cfg(feature = "discord")]
    {
        let state = adapter.clone();
        window.on_gate_metering(move |on| {
            let mut adapter = state.borrow_mut();
            let microphone = adapter.app.state.voice.microphone.clone();
            adapter.gate_meter =
                on.then(|| yapfast_core::discord_audio::GateMeter::start(microphone.as_deref()));
        });
        let state = adapter.clone();
        let weak = window.as_weak();
        window.on_gate_meter_tick(move || {
            if let (Some(window), Some(meter)) = (weak.upgrade(), &state.borrow().gate_meter) {
                window.set_gate_level(meter.level().max(-100.0));
                window.set_gate_sending(meter.sending());
                window.set_gate_meter_note(SharedString::from(
                    if !yapfast_core::discord_audio::AVAILABLE {
                        "Discord voice and its level aren't available on this system yet."
                    } else if meter.failed() {
                        "S;C can't read this microphone. Check that it's connected, or choose another."
                    } else {
                        ""
                    },
                ));
            }
        });
    }
}

#[cfg(feature = "discord")]
thread_local! {
    /// What the share menu lists to share, in its order.
    static SHAREABLE: RefCell<Vec<yapfast_core::stream_worker::Source>> = const { RefCell::new(Vec::new()) };
}

/// What the field of the message being edited, in its row, asks of the
/// application: its text, keys, suggestions and emoji.
fn inline_edit(adapter: &Rc<RefCell<Adapter>>, window: &YapfastWindow) {
    let edit = window.global::<InlineEdit>();
    let state = adapter.clone();
    let weak = window.as_weak();
    edit.on_edited(move |text| {
        let Some(window) = weak.upgrade() else { return };
        let Ok(mut adapter) = state.try_borrow_mut() else {
            return;
        };
        // The caret's move usually took the text already.
        if adapter.composer_text(Field::Edit) != text.as_str() {
            adapter.set_composer_text(&window, Field::Edit, text.into());
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    edit.on_save(move || {
        let Some(window) = weak.upgrade() else { return };
        state.borrow_mut().action(&window, Action::SaveEdit);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    edit.on_cancel(move || {
        let Some(window) = weak.upgrade() else { return };
        state.borrow_mut().action(&window, Action::CancelEdit);
    });
    // The suggestions are the window's, as the composers' are: only the keys
    // that move among them and choose come from this field.
    let weak = window.as_weak();
    edit.on_suggestion_moved(move |step| {
        let Some(window) = weak.upgrade() else { return };
        let mentions = i32::try_from(window.get_mentions().row_count()).unwrap_or(i32::MAX);
        if mentions > 0 {
            window.set_mention_index((window.get_mention_index() + step).rem_euclid(mentions));
        } else {
            let emoji =
                i32::try_from(window.get_emoji_suggestions().row_count()).unwrap_or(i32::MAX);
            if emoji > 0 {
                window.set_emoji_suggestion_index(
                    (window.get_emoji_suggestion_index() + step).rem_euclid(emoji),
                );
            }
        }
    });
    let weak = window.as_weak();
    edit.on_suggestion_chosen(move || {
        let Some(window) = weak.upgrade() else { return };
        if window.get_mentions().row_count() > 0 {
            window.invoke_mention_chosen(window.get_mention_index());
        } else {
            window.invoke_emoji_suggestion_chosen(window.get_emoji_suggestion_index());
        }
    });
    let weak = window.as_weak();
    edit.on_suggestion_dismissed(move || {
        let Some(window) = weak.upgrade() else { return };
        if window.get_mentions().row_count() > 0 {
            window.invoke_mention_dismissed();
        } else {
            window.invoke_emoji_suggestion_dismissed();
        }
    });
    let weak = window.as_weak();
    edit.on_emoji(move |x, y, width, height| {
        let Some(window) = weak.upgrade() else { return };
        window.invoke_open_edit_picker(x, y, width, height);
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_insert_edit_emoji(move |key| {
        let Some(window) = weak.upgrade() else { return };
        let caret = {
            let mut adapter = state.borrow_mut();
            let text = adapter.composer_text(Field::Edit);
            // At the cursor the field last had, else at the end.
            let at = adapter
                .edit_caret
                .filter(|&at| text.is_char_boundary(at))
                .unwrap_or(text.len());
            let inserted = emoji::composer_text(&key);
            let text = format!("{}{inserted}{}", &text[..at], &text[at..]);
            adapter.set_composer_text(&window, Field::Edit, text);
            at + inserted.len()
        };
        focus_edit(&window, caret);
    });
}

/// Puts the cursor at a byte offset in the channel's composer, or the
/// thread's beside it, and the keyboard there.
fn place_composer_caret(window: &YapfastWindow, (field, caret): (Field, usize)) {
    let offset = i32::try_from(caret).unwrap_or(i32::MAX);
    match field {
        Field::Aside => window.invoke_place_aside_composer_caret(offset),
        Field::Channel => {
            window.invoke_place_composer_caret(offset);
            window.invoke_focus_composer();
        }
        Field::Edit => focus_edit(window, caret),
    }
}

/// Gives the field of the message being edited the keys, with its cursor at
/// a byte offset.
pub(super) fn focus_edit(window: &YapfastWindow, caret: usize) {
    let edit = window.global::<InlineEdit>();
    edit.set_end(i32::try_from(caret).unwrap_or(i32::MAX));
    edit.set_focus_tick(edit.get_focus_tick().wrapping_add(1));
}

/// The text and cursor of `field`: the `:name` and `@` or `#` words it
/// suggests for.
fn composer_caret(
    adapter: &mut Adapter,
    window: &YapfastWindow,
    text: &str,
    offset: i32,
    field: Field,
) {
    // The cursor moves before the edit is reported; take the text first, so the
    // refresh below doesn't put back the text before it.
    if adapter.composer_text(field) != text {
        adapter.set_composer_text(window, field, text.to_owned());
    }
    let offset = usize::try_from(offset).ok();
    match field {
        Field::Channel => adapter.caret = adapter.app.state.selected.clone().zip(offset),
        Field::Edit => adapter.edit_caret = offset,
        Field::Aside => {}
    }
    // Suggestions follow the composer typed in last, as do what was closed.
    if adapter.suggesting != field {
        adapter.suggesting = field;
        adapter.mention_dismissed = None;
        adapter.emoji_dismissed = None;
        window.set_suggesting_aside(field == Field::Aside);
        window.set_suggesting_edit(field == Field::Edit);
    }
    // The `:name` word, unless its suggestions were closed.
    let word = offset.and_then(|offset| emoji::query(text, offset));
    if word.is_none() {
        adapter.emoji_dismissed = None;
    }
    let word = word
        .filter(|(at, _)| adapter.emoji_dismissed != Some(*at))
        .map(|(at, name)| (at, name.to_owned()));
    if adapter.emoji_word != word {
        adapter.emoji_word = word;
        window.set_emoji_suggestion_index(0);
        adapter.show_emoji_suggestions(window);
        // Custom emoji show their pictures once they arrive.
        let wanted: Vec<String> = adapter
            .app
            .usable_emoji()
            .into_iter()
            .flat_map(|set| set.emoji)
            .filter(|custom| {
                let key = emoji::custom_key(custom);
                !adapter.app.state.pictures.contains_key(&custom.picture)
                    && adapter
                        .models
                        .emoji_suggestions
                        .iter()
                        .any(|cell| cell.key == key)
            })
            .map(|custom| custom.picture)
            .collect();
        if !wanted.is_empty() {
            adapter.action(window, Action::LoadPictures(wanted));
        }
    }
    // An app command's option offers its own people, roles and channels.
    let commanding = field == Field::Channel && adapter.app.state.command_draft().is_some();
    let found = offset
        .filter(|_| !commanding)
        .and_then(|offset| mention::query(text, offset));
    if found.is_none() {
        adapter.mention_dismissed = None;
    }
    let found = found.filter(|(at, _, _)| adapter.mention_dismissed != Some(*at));
    adapter.mention_at = found.map(|(at, _, _)| at);
    let query = found.map(|(_, sigil, query)| (sigil, query.to_owned()));
    if adapter.app.state.mention_query != query {
        window.set_mention_index(0);
        adapter.action(window, Action::MentionQuery(query));
    }
    adapter.sync_inline_edit_suggestions(window);
}

/// Films with the chosen camera into the voice settings' preview, which is
/// about 400 by 225 points.
fn start_camera_test(adapter: &mut Adapter, window: &YapfastWindow) {
    let scale = window.window().scale_factor();
    let feed = yapfast_core::picture::Feed::new();
    feed.show_at(Some(((400.0 * scale) as u32, (225.0 * scale) as u32)));
    let camera = adapter.app.state.voice.camera.clone();
    match yapfast_core::camera::Camera::open(camera.as_deref(), Box::new(feed.sink())) {
        Ok(camera) => adapter.camera_test = Some((camera, feed)),
        Err(error) => window.set_camera_note(error.to_string().into()),
    }
}

/// Tells each camera in the call where its tile shows, or that it doesn't,
/// so pictures are made only for tiles in sight, at their size, and
/// whether it's the tile in focus. With the call off screen, the camera in
/// the corner shows there.
fn place_videos(adapter: &Adapter, window: &YapfastWindow) {
    let voice = &adapter.app.state.voice;
    let shown = window.get_grid_shown() && voice.active();
    let scale = window.window().scale_factor();
    let corner = usize::try_from(window.get_pip_person())
        .ok()
        .filter(|_| window.get_pip_shown() && voice.active());
    let pixels = |side: f32| (side * scale).round() as u32;
    // Shared screens take the grid's first places.
    let before = usize::from(voice.sharing.is_some()) + adapter.models.stream_tiles.row_count();
    for (raw, person) in voice.participants.iter().enumerate() {
        if let Some(feed) = &person.video {
            let Some(index) = adapter
                .stage_people
                .iter()
                .position(|&person| person == raw)
                .filter(|_| !adapter.call_video_disabled(&person.id))
            else {
                feed.show_at(None);
                feed.show_large(false);
                continue;
            };
            let at = if corner == Some(index) {
                Some((pixels(PIP_WIDTH), pixels(PIP_HEIGHT)))
            } else {
                adapter
                    .tiles
                    .filter(|_| shown)
                    .and_then(|tiles| tiles.shown_at(index + before, scale))
            };
            let large = corner != Some(index)
                && shown
                && adapter
                    .tiles
                    .is_some_and(|tiles| tiles.focused == Some(index + before));
            let detached = adapter.detached_video_size(&person.id);
            feed.show_at(call_video_popout::joined_size(at, detached));
            feed.show_large(large || detached.is_some());
        }
    }
}

/// The corner's size, as StreamPip draws it.
const PIP_WIDTH: f32 = 320.0;
const PIP_HEIGHT: f32 = 180.0;

/// Opens a web page in the browser. Only web pages open: a message can't
/// start other programs.
/// The web address a link in a message leads to: a masked link's, behind
/// the question asked before leaving. A mention or Yapfast's own link has none.
pub(super) fn web_address(link: &str) -> Option<&str> {
    let link = links::masked(link).unwrap_or(link);
    (links::openable(link) && mention::target(link).is_none()).then_some(link)
}

/// What opening one of Discord's own links does. A profile link anchors
/// its card to the clicked words, or the pointer, as a mention does.
#[cfg(feature = "discord")]
fn discord_link_action(window: &YapfastWindow, route: discord::DiscordRoute) -> Action {
    match route {
        discord::DiscordRoute::Invite { code } => Action::OpenInviteLink(code),
        discord::DiscordRoute::Authorize { query } => Action::OpenOAuthLink(query),
        discord::DiscordRoute::Gift { code } => Action::OpenGiftLink(code),
        discord::DiscordRoute::Event { guild, event } => Action::OpenEventLink { guild, event },
        discord::DiscordRoute::DirectMessages => Action::Navigate(Navigation::DirectMessages),
        discord::DiscordRoute::Server { guild } => {
            Action::Navigate(Navigation::Server(discord::server_id(&guild)))
        }
        discord::DiscordRoute::Channel { guild, channel } => {
            Action::Open(discord::room_id(&guild, &channel))
        }
        discord::DiscordRoute::Message {
            guild,
            channel,
            message,
        } => Action::JumpInRoom {
            room: discord::room_id(&guild, &channel),
            item: format!("d:{message}"),
        },
        discord::DiscordRoute::User { user } => {
            if let Some(rect) = i_slint_core::yapfast_selection::clicked_link() {
                window.invoke_anchor_link(
                    rect.origin.x,
                    rect.origin.y,
                    rect.size.width,
                    rect.size.height,
                );
            }
            window.set_profile_at_pointer(true);
            Action::ShowProfile { user, large: false }
        }
    }
}

#[cfg(feature = "discord")]
fn is_discord_message_handoff(link: &str) -> bool {
    match discord::discord_route(link) {
        Some(discord::DiscordRoute::Message {
            guild,
            channel,
            message,
        }) => link == format!("https://discord.com/channels/{guild}/{channel}/{message}"),
        _ => false,
    }
}

#[cfg(not(feature = "discord"))]
fn is_discord_message_handoff(_link: &str) -> bool {
    false
}

fn open_web_page(link: &str) {
    if links::openable(link) {
        super::browser::open(link);
    }
}

/// The least time between two reports of what's in view, or of the pictures
/// asked for, so scrolling sends one report per this much.
const REPORT_SPACING: Duration = Duration::from_millis(50);

/// How long to wait before a report, noting it as made then: no time after
/// a quiet spell, so a channel just shown asks for its previews and avatars
/// at once, else until [`REPORT_SPACING`] after the last. Even no time
/// gathers everything the current layout asks for.
fn report_delay(last: &Cell<Option<std::time::Instant>>) -> Duration {
    let now = std::time::Instant::now();
    let delay = last.get().map_or(Duration::ZERO, |last| {
        REPORT_SPACING.saturating_sub(now.saturating_duration_since(last))
    });
    last.set(Some(now + delay));
    delay
}

/// A name style's colours, written as hex joined by commas.
fn key_colours(key: &str) -> Vec<u32> {
    key.split(',')
        .filter_map(|hex| u32::from_str_radix(hex.trim().trim_start_matches('#'), 16).ok())
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn modal_file_picker_rejects_stale_forms_accounts_and_fields() {
        fn form() -> Application {
            let mut app = Application::default();
            app.state.account = Some("account-a".into());
            app.state.discord_user = Some("1".into());
            app.apply(yapfast_core::chat::Event::InteractionModal(
                serde_json::json!({
                    "id": "42", "application_id": "3", "channel_id": "7",
                    "custom_id": "upload", "title": "Upload",
                    "components": [{"type": 18, "label": "File", "component": {
                        "type": 19, "custom_id": "attachment", "required": false
                    }}]
                }),
            ));
            app
        }
        let path = std::path::PathBuf::from("synthetic-file.png");
        let mut app = form();
        let target = ModalFileTarget::capture(&app.state, 0).unwrap();
        let action = target.returned(&app.state, vec![path.clone()]).unwrap();
        app.dispatch(action);
        assert_eq!(
            app.state.interaction_modal.as_ref().unwrap().fields[0].files,
            [path.clone()]
        );
        for change in 0..7 {
            let mut app = form();
            let target = ModalFileTarget::capture(&app.state, 0).unwrap();
            match change {
                0 => app.state.interaction_modal = None,
                1 => app.state.interaction_modal.as_mut().unwrap().id = "43".into(),
                2 => app.state.account = Some("account-b".into()),
                3 => app.state.discord_user = Some("2".into()),
                4 => {
                    app.state.interaction_modal.as_mut().unwrap().fields[0].custom_id =
                        "other".into()
                }
                5 => app.state.interaction_modal.as_mut().unwrap().channel_id = "8".into(),
                _ => {
                    app.dispatch(Action::SubmitModal);
                }
            }
            assert!(
                target.returned(&app.state, vec![path.clone()]).is_none(),
                "stale case {change}"
            );
            assert!(
                app.state
                    .interaction_modal
                    .as_ref()
                    .is_none_or(|modal| modal.fields[0].files.is_empty())
            );
        }
        let app = form();
        assert!(ModalFileTarget::capture(&app.state, 1).is_none());
    }

    #[cfg(feature = "discord")]
    #[test]
    fn listening_handoff_only_opens_canonical_discord_message_urls() {
        for link in [
            "https://discord.com/channels/@me/123/456",
            "https://discord.com/channels/100/123/456",
        ] {
            assert!(is_discord_message_handoff(link), "{link}");
        }
        for link in [
            "https://discord.com/channels/@me/123",
            "https://discord.com.example.test/channels/@me/123/456",
            "https://discord.com/channels/@me/123/456?x=1",
            "https://discord.com:443/channels/@me/123/456",
            "discord://-/channels/@me/123/456",
        ] {
            assert!(!is_discord_message_handoff(link), "{link}");
        }
    }
    use std::time::Instant;

    #[test]
    fn reports_at_once_after_a_quiet_spell_and_spaced_while_busy() {
        let last = Cell::new(None);
        assert_eq!(report_delay(&last), Duration::ZERO);
        let busy = report_delay(&last);
        assert!(busy > Duration::from_millis(40) && busy <= REPORT_SPACING);
        last.set(Some(Instant::now() - REPORT_SPACING));
        assert_eq!(report_delay(&last), Duration::ZERO);
    }
}
