//! Historical command details in the native chip, its menu, and the composer.
#![cfg(feature = "discord")]
use super::*;
use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
use slint::platform::{PointerEventButton, WindowEvent};
use std::ops::ControlFlow;
use yapfast_core::{
    chat::{CommandIndex, DiscordCommand, InteractionInfo, InteractionInstallation, UsedCommand},
    yapfast_discord::{
        commands::USE_APPLICATION_COMMANDS,
        marked::{ChannelMarks, MarkedServer},
        ready,
        service::{Snapshot, Status},
    },
};

fn find(window: &YapfastWindow, label: &str) -> Option<ItemRc> {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    ItemRc::new_root(inner.component()).visit_descendants(|item| {
        if item.is_visible()
            && item
                .accessible_string_property(AccessibleStringProperty::Label)
                .as_deref()
                == Some(label)
        {
            ControlFlow::Break(item.clone())
        } else {
            ControlFlow::Continue(())
        }
    })
}

fn named(window: &YapfastWindow, label: &str) -> ItemRc {
    find(window, label).unwrap_or_else(|| panic!("missing hovered native content: {label}"))
}

fn settle(window: &YapfastWindow, millis: u64) {
    window.window().take_snapshot().unwrap();
    i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(millis));
    slint::platform::update_timers_and_animations();
    window.window().take_snapshot().unwrap();
}

#[derive(Clone, Copy)]
enum ChipCheck {
    Hover,
    Copy,
    InteractionInfo,
    FillDraft,
    KeepEditedDraft,
}

fn historical_chip(aside: bool, followup: bool, check: ChipCheck) {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let directory = tempfile::tempdir().unwrap();
    let window = yapfast::window().unwrap();
    let adapter = Adapter::new(
        Arc::new(BackgroundRuntime::new().unwrap()),
        directory.path().into(),
        &window,
    )
    .unwrap();
    bind_callbacks(&window, &adapter);
    let commands = Rc::new(RefCell::new(Vec::new()));
    adapter.borrow_mut().backend_commands = Some(commands.clone());
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<PictureStore>().on_request(|_| {});
    let room = if aside {
        "discord:10:22"
    } else {
        "discord:10:21"
    };
    let item = if followup { "d:101" } else { "d:100" };
    let interaction = if followup { "901" } else { "900" };
    let message = Arc::new(ChatMessage {
        id: item.into(),
        item: item.into(),
        author: "Historical bot".into(),
        sender: "discord:42".into(),
        bot: true,
        body: "A historical command response.".into(),
        application_id: Some("42".into()),
        interaction: Some(interaction.into()),
        interaction_info: Some(InteractionInfo {
            user_id: "1".into(),
            user: "Alice".into(),
            application: "Historical bot".into(),
            installation: Some(InteractionInstallation::Guild {
                name: "Fixture server".into(),
            }),
        }),
        command_interaction: followup.then(|| "900".into()),
        command_message: followup.then(|| "100".into()),
        used: Some(UsedCommand {
            user: "Alice".into(),
            sender: "discord:1".into(),
            name: "/ologroup".into(),
            slash: Some("ologroup".into()),
            avatar: None,
            color: None,
            target: None,
        }),
        ..Default::default()
    });
    let fill_draft = matches!(check, ChipCheck::FillDraft | ChipCheck::KeepEditedDraft);
    let permissions = if fill_draft {
        66560
            | ready::permission::SEND_MESSAGES
            | ready::permission::SEND_MESSAGES_IN_THREADS
            | USE_APPLICATION_COMMANDS
    } else {
        66560
    };
    let server = ready::server(&serde_json::json!({
        "id":"10", "owner_id":"99", "properties":{"name":"Hover fixture"},
        "roles":[{"id":"10", "name":"@everyone", "permissions":permissions.to_string()}],
        "channels":[{"id":"21", "type":0, "name":"fixture channel"}],
        "threads":[{"id":"22", "type":11, "name":"fixture thread", "parent_id":"21", "member":{"id":"22", "user_id":"1", "flags":1}, "thread_metadata":{"archived":false,"locked":false}}]
    })).unwrap();
    {
        let mut adapter = adapter.borrow_mut();
        adapter.app.apply(Event::Discord(Arc::new(Snapshot {
            status: Status::Online,
            user_id: Some("1".into()),
            servers: vec![MarkedServer::marked(server, Default::default(), |_| {
                ChannelMarks {
                    access: if fill_draft {
                        ready::Access::Join
                    } else {
                        ready::Access::Locked
                    },
                    ..Default::default()
                }
            })],
            viewing: vec!["22".into()],
            ..Default::default()
        })));
        adapter.app.state.account = Some("@hover:example.invalid".into());
        adapter.app.state.online = true;
        adapter.app.state.trusted = true;
        adapter
            .app
            .dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
        adapter
            .app
            .dispatch(Action::SelectRoom("discord:10:21".into()));
        adapter.app.apply(Event::Timeline {
            room: "discord:10:21".into(),
            messages: if aside { vec![] } else { vec![message.clone()] },
        });
        if aside {
            adapter.app.dispatch(Action::OpenAside(room.into()));
            adapter.app.apply(Event::Timeline {
                room: room.into(),
                messages: vec![message.clone()],
            });
        }
        adapter.refresh(&window);
        assert!(
            adapter.app.state.command_detail(room, item).is_none(),
            "no local sent-command cache supplies this historical value"
        );
        assert!(adapter.backend.is_none());
    }
    let width = if aside || matches!(check, ChipCheck::FillDraft) {
        1120.
    } else {
        800.
    };
    window
        .window()
        .set_size(slint::LogicalSize::new(width, 600.));
    window.show().unwrap();
    settle(&window, 300);
    let chip = named(&window, "Use /ologroup");
    let bounds = chip.geometry();
    assert!(
        bounds.width() >= 48.,
        "command chip must remain visible at {width}px"
    );
    if !aside {
        assert!(window.get_members_available() && window.get_member_list());
        let chip_right = chip.map_to_window(bounds.origin).x + bounds.width();
        let chat_right = width - window.get_members_shown();
        assert!(
            chip_right <= chat_right - 4.,
            "chip right edge {chip_right}px must fit before the member sidebar at {chat_right}px"
        );
    }
    let at = chip.map_to_window(bounds.center());
    window.window().dispatch_event(WindowEvent::PointerMoved {
        position: slint::LogicalPosition::new(at.x, at.y),
    });
    {
        let adapter = adapter.borrow();
        assert!(
            adapter
                .app
                .state
                .command_detail(room, item)
                .unwrap()
                .contains("Loading command options"),
            "real hover must call the existing inspect binding"
        );
        assert_eq!(adapter.app.state.can_write_in(room), fill_draft);
    }
    let request = commands
        .borrow()
        .iter()
        .find_map(|command| {
            if let Command::Discord(DiscordCommand::CommandDetails {
                room: found_room,
                item: found_item,
                original_message,
                request,
                ..
            }) = command
            {
                if found_room == room && found_item == item {
                    assert_eq!(
                        original_message.as_deref(),
                        followup.then_some("100"),
                        "follow-up retains the original response as a fallback"
                    );
                    return Some(request.clone());
                }
            }
            None
        })
        .expect("real hover emits a correlated read command");
    let clipboard = || {
        i_slint_core::window::WindowInner::from_pub(window.window())
            .context()
            .platform()
            .clipboard_text(i_slint_core::platform::Clipboard::DefaultClipboard)
    };
    let click = |x, y, button| {
        let position = slint::LogicalPosition::new(x, y);
        window
            .window()
            .dispatch_event(WindowEvent::PointerMoved { position });
        window
            .window()
            .dispatch_event(WindowEvent::PointerPressed { position, button });
        window
            .window()
            .dispatch_event(WindowEvent::PointerReleased { position, button });
        settle(&window, 1);
    };
    let menu_label = match check {
        ChipCheck::Copy => Some("Copy Command"),
        ChipCheck::InteractionInfo => Some("View Interaction Info"),
        _ => None,
    };
    if let Some(label) = menu_label {
        window.invoke_copy_text("previous clipboard contents".into());
        click(at.x, at.y, PointerEventButton::Right);
        let inner = i_slint_core::window::WindowInner::from_pub(window.window());
        let (x, y) = {
            let popups = inner.active_popups();
            let popup = popups
                .last()
                .expect("right-clicking the chip opens the message menu");
            let i_slint_core::window::PopupWindowLocation::ChildWindow(place) = popup.location
            else {
                panic!("testing backend uses embedded popups");
            };
            let row = ItemRc::new_root(popup.component.clone())
                .visit_descendants(|item| {
                    if item.is_visible()
                        && item
                            .accessible_string_property(AccessibleStringProperty::Label)
                            .as_deref()
                            == Some(label)
                    {
                        ControlFlow::Break(item.clone())
                    } else {
                        ControlFlow::Continue(())
                    }
                })
                .unwrap_or_else(|| panic!("the message menu exposes {label}"));
            let at = row.map_to_item_tree(row.geometry().center(), &popup.component);
            (place.x + at.x, place.y + at.y)
        };
        click(x, y, PointerEventButton::Left);
        assert_eq!(clipboard().as_deref(), Some("previous clipboard contents"));
        match check {
            ChipCheck::Copy => assert!(adapter.borrow().command_use_pending.is_some()),
            ChipCheck::InteractionInfo => {
                assert_eq!(window.get_menu_command_item(), item);
                assert!(
                    window
                        .get_menu_command_detail()
                        .contains("Loading command options")
                );
                let popups = inner.active_popups();
                let popup = popups.last().unwrap();
                for label in ["Interaction info", "Fixture server", "Alice"] {
                    assert!(
                        ItemRc::new_root(popup.component.clone())
                            .visit_descendants(|item| {
                                if item.is_visible()
                                    && item
                                        .accessible_string_property(AccessibleStringProperty::Label)
                                        .as_deref()
                                        == Some(label)
                                {
                                    ControlFlow::Break(())
                                } else {
                                    ControlFlow::Continue(())
                                }
                            })
                            .is_some(),
                        "interaction submenu contains {label}"
                    );
                }
            }
            _ => unreachable!(),
        }
    }
    if fill_draft {
        assert!(
            if aside {
                window.get_aside_composer_enabled()
            } else {
                window.get_composer_enabled()
            },
            "the composer for {room} must be enabled"
        );
        window.invoke_copy_text("previous clipboard contents".into());
        // Hover can create the message toolbar and relayout the main timeline.
        settle(&window, 1);
        let chip = named(&window, "Use /ologroup");
        let click_at = chip.map_to_window(chip.geometry().center());
        click(click_at.x, click_at.y, PointerEventButton::Left);
        let inner = i_slint_core::window::WindowInner::from_pub(window.window());
        let popup_count = inner.active_popups().len();
        let pending = adapter.borrow().command_use_pending.is_some();
        assert!(
            pending && popup_count == 0,
            "left-click at {click_at:?} for {room}/{item} at {width}px should queue the draft fill without opening the message menu (pending: {pending}, popups: {popup_count})"
        );
        if matches!(check, ChipCheck::KeepEditedDraft) {
            adapter
                .borrow_mut()
                .action(&window, Action::SetDraft("My new draft".into()));
        }
    }
    let weak = window.as_weak();
    let state = adapter.clone();
    let options = if fill_draft {
        serde_json::json!([
            {"name":"link", "type":3, "value":"22122"},
            {"name":"payload", "type":3, "value":"{\n  \"status\": \"  ready\"\n}"},
            {"name":"image", "type":11, "value":"789"}
        ])
    } else {
        serde_json::json!([{"name":"link", "type":3, "value":"22122"}])
    };
    slint::Timer::single_shot(Duration::from_millis(500), move || {
        let window = weak.unwrap();
        let mut adapter = state.borrow_mut();
        adapter.apply(Event::CommandDetails {
            room: room.into(),
            item: item.into(),
            account: "1".into(),
            interaction: interaction.into(),
            request,
            result: Ok(
                serde_json::json!({"id":"900","type":2,"name":"ologroup","options":options,
                    "application_command":{"id":"700","type":1,"name":"ologroup"}}),
            ),
        });
        adapter.refresh(&window);
    });
    settle(&window, 300);
    if matches!(check, ChipCheck::Hover) {
        let _ = named(&window, "/ologroup\nLoading command options…");
    }
    settle(&window, 300);
    let expected = "/ologroup  link: 22122";
    if !matches!(check, ChipCheck::Hover) {
        match check {
            ChipCheck::Copy => {
                assert_eq!(clipboard().as_deref(), Some(expected));
                assert!(adapter.borrow().command_use_pending.is_none());
            }
            ChipCheck::InteractionInfo => {
                assert_eq!(window.get_menu_command_detail(), expected);
                assert_eq!(clipboard().as_deref(), Some("previous clipboard contents"));
            }
            ChipCheck::FillDraft => {
                assert!(adapter.borrow().command_use_pending.is_some());
                assert!(commands.borrow().iter().any(|command| matches!(
                    command,
                    Command::Discord(DiscordCommand::CommandIndex {room: requested}) if requested == room
                )));
                let mut adapter = adapter.borrow_mut();
                adapter.apply(Event::CommandIndex {
                    room: room.into(),
                    index: Ok(Arc::new(CommandIndex::parse(
                        &serde_json::json!({
                            "applications": [{"id":"42","name":"Historical bot"}],
                            "application_commands": [{
                                "id":"700","application_id":"42","version":"1","type":1,
                                "name":"ologroup","description":"Record options",
                                "default_member_permissions":null,
                                "options":[
                                    {"type":3,"name":"link","description":"Link"},
                                    {"type":3,"name":"payload","description":"Payload"},
                                    {"type":11,"name":"image","description":"Image"}
                                ]
                            }]
                        }),
                        false,
                    ))),
                });
                adapter.refresh(&window);
                assert_eq!(adapter.app.state.selected.as_deref(), Some(room));
                if aside {
                    assert!(adapter.app.state.aside.is_none());
                }
                let draft = adapter
                    .app
                    .state
                    .command_draft()
                    .expect("historical slash draft");
                assert_eq!(draft.name, "ologroup");
                assert_eq!(draft.options[0].text, "22122");
                assert_eq!(draft.options[1].text, "{\n  \"status\": \"  ready\"\n}");
                assert!(draft.options[2].is_attachment() && draft.options[2].file.is_none());
                assert!(draft.options[2].text.is_empty());
                assert_eq!(window.get_command_name(), "ologroup");
                assert!(window.get_draft().is_empty());
                assert_eq!(clipboard().as_deref(), Some("previous clipboard contents"));
                assert!(!commands.borrow().iter().any(|command| matches!(
                    command,
                    Command::Send { .. } | Command::Discord(DiscordCommand::Interact(_))
                )));
            }
            ChipCheck::KeepEditedDraft => {
                assert_eq!(window.get_draft(), "My new draft");
                assert!(adapter.borrow().app.state.command_draft().is_none());
                assert!(adapter.borrow().command_use_pending.is_none());
                assert_eq!(clipboard().as_deref(), Some("previous clipboard contents"));
            }
            ChipCheck::Hover => unreachable!(),
        }
        window.hide().unwrap();
        return;
    }
    assert!(
        find(&window, expected).is_some(),
        "async answer updates the tooltip without leaving/re-entering the chip"
    );
    let tooltip = named(&window, expected);
    let geometry = tooltip.geometry();
    let origin = tooltip.map_to_window(geometry.origin);
    assert!(
        origin.x >= 0.
            && origin.y >= 0.
            && origin.x + geometry.width() <= width + 1.
            && origin.y + geometry.height() <= 601.
    );
    if let Some(directory) = std::env::var_os("SC_REVIEW_DIR") {
        let frame = window.window().take_snapshot().unwrap();
        let directory = std::path::Path::new(&directory);
        std::fs::create_dir_all(directory).unwrap();
        image::save_buffer(
            directory.join(if followup {
                "command-hover-followup1120.png"
            } else if aside {
                "command-hover-aside1120.png"
            } else {
                "command-hover-main800.png"
            }),
            frame.as_bytes(),
            frame.width(),
            frame.height(),
            image::ColorType::Rgba8,
        )
        .unwrap();
    }
    window.window().dispatch_event(WindowEvent::PointerExited);
    settle(&window, 1);
    assert!(
        find(&window, expected).is_none(),
        "leaving the command chip dismisses its tooltip"
    );
    window.hide().unwrap();
}

#[test]
fn command_details_hover_historical_response_updates_main_without_reentering() {
    historical_chip(false, false, ChipCheck::Hover);
}

#[test]
fn command_details_hover_historical_response_updates_side_thread_without_reentering() {
    historical_chip(true, false, ChipCheck::Hover);
}

#[test]
fn command_details_hover_modal_followup_updates_from_original_response() {
    historical_chip(true, true, ChipCheck::Hover);
}

#[test]
fn command_details_copy_waits_for_discord_then_copies_original_followup() {
    historical_chip(true, true, ChipCheck::Copy);
}

#[test]
fn command_details_interaction_menu_shows_source_and_updates_from_discord() {
    historical_chip(true, false, ChipCheck::InteractionInfo);
}

#[test]
fn command_details_click_fills_the_main_composer_without_sending() {
    historical_chip(false, false, ChipCheck::FillDraft);
}

#[test]
fn command_details_click_fills_the_thread_composer_without_sending() {
    historical_chip(true, true, ChipCheck::FillDraft);
}

#[test]
fn command_details_click_does_not_replace_a_draft_edited_while_waiting() {
    historical_chip(false, false, ChipCheck::KeepEditedDraft);
}
