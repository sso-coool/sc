//! Historical command details must arrive under an already-hovered native chip.
#![cfg(feature = "discord")]
use super::*;
use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
use slint::platform::WindowEvent;
use std::ops::ControlFlow;
use yapfast_core::{
    chat::{DiscordCommand, UsedCommand},
    yapfast_discord::{
        marked::{ChannelMarks, MarkedServer},
        ready,
        service::{Snapshot, Status},
    },
};

fn find(window: &YapfastWindow, label: &str) -> Option<ItemRc> {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    ItemRc::new_root(inner.component()).visit_descendants(|item| {
        if item.is_visible()
            && item
                .accessible_string_property(AccessibleStringProperty::Label)
                .as_deref()
                == Some(label)
        {
            ControlFlow::Break(item.clone())
        } else {
            ControlFlow::Continue(())
        }
    })
}

fn named(window: &YapfastWindow, label: &str) -> ItemRc {
    find(window, label).unwrap_or_else(|| panic!("missing hovered native content: {label}"))
}

fn settle(window: &YapfastWindow, millis: u64) {
    window.window().take_snapshot().unwrap();
    i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(millis));
    slint::platform::update_timers_and_animations();
    window.window().take_snapshot().unwrap();
}

fn historical_hover(aside: bool, followup: bool) {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let directory = tempfile::tempdir().unwrap();
    let window = yapfast::window().unwrap();
    let adapter = Adapter::new(
        Arc::new(BackgroundRuntime::new().unwrap()),
        directory.path().into(),
        &window,
    )
    .unwrap();
    bind_callbacks(&window, &adapter);
    let commands = Rc::new(RefCell::new(Vec::new()));
    adapter.borrow_mut().backend_commands = Some(commands.clone());
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<PictureStore>().on_request(|_| {});
    let room = if aside {
        "discord:10:22"
    } else {
        "discord:10:21"
    };
    let item = if followup { "d:101" } else { "d:100" };
    let interaction = if followup { "901" } else { "900" };
    let message = Arc::new(ChatMessage {
        id: item.into(),
        item: item.into(),
        author: "Historical bot".into(),
        sender: "discord:42".into(),
        bot: true,
        body: "A historical command response.".into(),
        application_id: Some("42".into()),
        interaction: Some(interaction.into()),
        command_interaction: followup.then(|| "900".into()),
        command_message: followup.then(|| "100".into()),
        used: Some(UsedCommand {
            user: "Alice".into(),
            sender: "discord:1".into(),
            name: "/ologroup".into(),
            slash: Some("ologroup".into()),
            avatar: None,
            color: None,
            target: None,
        }),
        ..Default::default()
    });
    let server = ready::server(&serde_json::json!({
        "id":"10", "owner_id":"99", "properties":{"name":"Hover fixture"},
        "roles":[{"id":"10", "name":"@everyone", "permissions":"66560"}],
        "channels":[{"id":"21", "type":0, "name":"read-only channel"}],
        "threads":[{"id":"22", "type":11, "name":"read-only thread", "parent_id":"21", "member":{"id":"22", "user_id":"1", "flags":1}, "thread_metadata":{"archived":false,"locked":false}}]
    })).unwrap();
    {
        let mut adapter = adapter.borrow_mut();
        adapter.app.apply(Event::Discord(Arc::new(Snapshot {
            status: Status::Online,
            user_id: Some("1".into()),
            servers: vec![MarkedServer::marked(server, Default::default(), |_| {
                ChannelMarks {
                    access: ready::Access::Locked,
                    ..Default::default()
                }
            })],
            viewing: vec!["22".into()],
            ..Default::default()
        })));
        adapter.app.state.account = Some("@hover:example.invalid".into());
        adapter.app.state.online = true;
        adapter.app.state.trusted = true;
        adapter
            .app
            .dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
        adapter
            .app
            .dispatch(Action::SelectRoom("discord:10:21".into()));
        adapter.app.apply(Event::Timeline {
            room: "discord:10:21".into(),
            messages: if aside { vec![] } else { vec![message.clone()] },
        });
        if aside {
            adapter.app.dispatch(Action::OpenAside(room.into()));
            adapter.app.apply(Event::Timeline {
                room: room.into(),
                messages: vec![message.clone()],
            });
        }
        adapter.refresh(&window);
        assert!(
            adapter.app.state.command_detail(room, item).is_none(),
            "no local sent-command cache supplies this historical value"
        );
        assert!(adapter.backend.is_none());
    }
    let width = if aside { 1120. } else { 800. };
    window
        .window()
        .set_size(slint::LogicalSize::new(width, 600.));
    window.show().unwrap();
    settle(&window, 300);
    let chip = named(&window, "Use /ologroup");
    let at = chip.map_to_window(chip.geometry().center());
    window.window().dispatch_event(WindowEvent::PointerMoved {
        position: slint::LogicalPosition::new(at.x, at.y),
    });
    {
        let adapter = adapter.borrow();
        assert!(
            adapter
                .app
                .state
                .command_detail(room, item)
                .unwrap()
                .contains("Loading command options"),
            "real hover must call the existing inspect binding"
        );
        assert!(
            !adapter.app.state.can_write_in(room),
            "hover must work without send permission"
        );
    }
    let request = commands
        .borrow()
        .iter()
        .find_map(|command| {
            if let Command::Discord(DiscordCommand::CommandDetails {
                room: found_room,
                item: found_item,
                message,
                request,
                ..
            }) = command
            {
                if found_room == room && found_item == item {
                    assert_eq!(
                        message, "100",
                        "follow-up reads the original response in the same room"
                    );
                    return Some(request.clone());
                }
            }
            None
        })
        .expect("real hover emits a correlated read command");
    let weak = window.as_weak();
    let state = adapter.clone();
    slint::Timer::single_shot(Duration::from_millis(500), move || {
        let window = weak.unwrap();
        let mut adapter = state.borrow_mut();
        adapter.apply(Event::CommandDetails { room: room.into(), item: item.into(), account: "1".into(), interaction: interaction.into(), request, result: Ok(serde_json::json!({"id":"900","type":2,"name":"ologroup","options":[{"name":"link","type":3,"value":"22122"}]})) });
        adapter.refresh(&window);
    });
    settle(&window, 300);
    let _ = named(&window, "/ologroup\nLoading command options…");
    settle(&window, 300);
    let expected = "/ologroup  link: 22122";
    assert!(
        find(&window, expected).is_some(),
        "async answer updates the tooltip without leaving/re-entering the chip"
    );
    let tooltip = named(&window, expected);
    let geometry = tooltip.geometry();
    let origin = tooltip.map_to_window(geometry.origin);
    assert!(
        origin.x >= 0.
            && origin.y >= 0.
            && origin.x + geometry.width() <= width + 1.
            && origin.y + geometry.height() <= 601.
    );
    if let Some(directory) = std::env::var_os("SC_REVIEW_DIR") {
        let frame = window.window().take_snapshot().unwrap();
        let directory = std::path::Path::new(&directory);
        std::fs::create_dir_all(directory).unwrap();
        image::save_buffer(
            directory.join(if followup {
                "command-hover-followup1120.png"
            } else if aside {
                "command-hover-aside1120.png"
            } else {
                "command-hover-main800.png"
            }),
            frame.as_bytes(),
            frame.width(),
            frame.height(),
            image::ColorType::Rgba8,
        )
        .unwrap();
    }
    window.window().dispatch_event(WindowEvent::PointerExited);
    settle(&window, 1);
    assert!(
        find(&window, expected).is_none(),
        "leaving the command chip dismisses its tooltip"
    );
    window.hide().unwrap();
}

#[test]
fn command_details_hover_historical_response_updates_main_without_reentering() {
    historical_hover(false, false);
}

#[test]
fn command_details_hover_historical_response_updates_side_thread_without_reentering() {
    historical_hover(true, false);
}

#[test]
fn command_details_hover_modal_followup_updates_from_original_response() {
    historical_hover(true, true);
}
