//! Exercise native pointer routing without opening a browser or sending a bot interaction.
use super::*;
use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
use slint::platform::{PointerEventButton, WindowEvent};
use std::ops::ControlFlow;

fn point(window: &YapfastWindow, label: &str) -> slint::LogicalPosition {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    let item = ItemRc::new_root(inner.component())
        .visit_descendants(|item| {
            if item.is_visible()
                && item
                    .accessible_string_property(AccessibleStringProperty::Label)
                    .as_deref()
                    == Some(label)
            {
                ControlFlow::Break(item.clone())
            } else {
                ControlFlow::Continue(())
            }
        })
        .unwrap_or_else(|| panic!("missing visible control: {label}"));
    let at = item.map_to_window(item.geometry().center());
    slint::LogicalPosition::new(at.x, at.y)
}

fn click(window: &YapfastWindow, label: &str, button: PointerEventButton) {
    let position = point(window, label);
    window
        .window()
        .dispatch_event(WindowEvent::PointerMoved { position });
    window
        .window()
        .dispatch_event(WindowEvent::PointerPressed { position, button });
    window
        .window()
        .dispatch_event(WindowEvent::PointerReleased { position, button });
}

#[test]
fn button_link_right_click_does_not_activate_or_invent_bot_links() {
    use yapfast_core::chat::{ButtonStyle, Card, CardButton, CardRow};
    i_slint_backend_testing::init_no_event_loop();
    let window = yapfast::window().unwrap();
    window.set_workspace(true);
    window.set_room_selected(true);
    window.set_room_ready(true);
    window.set_trusted(true);
    let link = "https://example.test/order?reference=123";
    let message = ChatMessage {
        item: "review:button".into(),
        author: "Offline bot".into(),
        sender: "review:bot".into(),
        body: "Button context test".into(),
        cards: vec![Card {
            framed: false,
            color: None,
            rows: vec![CardRow::Buttons(vec![
                CardButton {
                    label: "Open Tracker".into(),
                    style: ButtonStyle::Link,
                    url: Some(link.into()),
                    custom_id: None,
                    sku_id: None,
                    disabled: false,
                },
                CardButton {
                    label: "Re-Sync".into(),
                    style: ButtonStyle::Secondary,
                    url: None,
                    custom_id: Some("sync".into()),
                    sku_id: None,
                    disabled: false,
                },
            ])],
        }],
        ..Default::default()
    };
    window.set_messages(ModelRc::new(VecModel::from(vec![message_row(
        &message,
        &HashSet::new(),
    )])));
    let opened = Rc::new(RefCell::new(Vec::new()));
    let links = opened.clone();
    window.on_open_link(move |link| links.borrow_mut().push(link.to_string()));
    let interactions = Rc::new(Cell::new(0));
    let invoked = interactions.clone();
    window.on_use_button(move |_, _| invoked.set(invoked.get() + 1));
    let menus = Rc::new(RefCell::new(Vec::new()));
    let requested = menus.clone();
    window.global::<CardLinks>().on_show(move |link, x, y| {
        assert!(x >= 0. && y >= 0.);
        requested.borrow_mut().push(link.to_string());
    });
    window.show().unwrap();
    window
        .window()
        .set_size(slint::LogicalSize::new(1120., 760.));
    let _ = window.invoke_timeline_extent();
    i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(1000));
    slint::platform::update_timers_and_animations();
    click(&window, "Open Tracker", PointerEventButton::Right);
    assert_eq!(&*menus.borrow(), &[link]);
    assert!(opened.borrow().is_empty());
    assert_eq!(interactions.get(), 0);
    click(&window, "Re-Sync", PointerEventButton::Right);
    assert_eq!(
        menus.borrow().len(),
        1,
        "action buttons have no underlying link"
    );
    assert_eq!(
        interactions.get(),
        0,
        "right-click cannot send an interaction"
    );
    click(&window, "Open Tracker", PointerEventButton::Left);
    assert_eq!(&*opened.borrow(), &[link]);
    click(&window, "Re-Sync", PointerEventButton::Left);
    assert_eq!(interactions.get(), 1);
    window.hide().unwrap();
}
