//! Exercise native pointer routing without opening a browser or sending a bot interaction.
use super::*;
use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
use slint::platform::{PointerEventButton, WindowEvent};
use std::ops::ControlFlow;

fn point(window: &YapfastWindow, label: &str) -> slint::LogicalPosition {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    let item = ItemRc::new_root(inner.component())
        .visit_descendants(|item| {
            if item.is_visible()
                && item
                    .accessible_string_property(AccessibleStringProperty::Label)
                    .as_deref()
                    == Some(label)
            {
                ControlFlow::Break(item.clone())
            } else {
                ControlFlow::Continue(())
            }
        })
        .unwrap_or_else(|| panic!("missing visible control: {label}"));
    let at = item.map_to_window(item.geometry().center());
    slint::LogicalPosition::new(at.x, at.y)
}

fn click(window: &YapfastWindow, label: &str, button: PointerEventButton) {
    let position = point(window, label);
    window
        .window()
        .dispatch_event(WindowEvent::PointerMoved { position });
    window
        .window()
        .dispatch_event(WindowEvent::PointerPressed { position, button });
    window
        .window()
        .dispatch_event(WindowEvent::PointerReleased { position, button });
}

#[test]
fn button_link_right_click_does_not_activate_or_invent_bot_links() {
    use yapfast_core::chat::{ButtonStyle, Card, CardButton, CardRow};
    i_slint_backend_testing::init_no_event_loop();
    let window = yapfast::window().unwrap();
    window.set_workspace(true);
    window.set_room_selected(true);
    window.set_room_ready(true);
    window.set_trusted(true);
    let link = "https://example.test/order?reference=123";
    let invite = "https://discord.com/channels/@me/20/30";
    let message = ChatMessage {
        item: "review:button".into(),
        author: "Offline bot".into(),
        sender: "review:bot".into(),
        body: "Button context test".into(),
        cards: vec![Card {
            framed: false,
            color: None,
            rows: vec![CardRow::Buttons(vec![
                CardButton {
                    label: "Open Tracker".into(),
                    style: ButtonStyle::Link,
                    url: Some(link.into()),
                    custom_id: None,
                    sku_id: None,
                    disabled: false,
                },
                CardButton {
                    label: "Re-Sync".into(),
                    style: ButtonStyle::Secondary,
                    url: None,
                    custom_id: Some("sync".into()),
                    sku_id: None,
                    disabled: false,
                },
                CardButton {
                    label: "Open Invite in Discord".into(),
                    style: ButtonStyle::DiscordHandoff,
                    url: Some(invite.into()),
                    custom_id: None,
                    sku_id: None,
                    disabled: false,
                },
            ])],
        }],
        ..Default::default()
    };
    window.set_messages(ModelRc::new(VecModel::from(vec![message_row(
        &message,
        &HashSet::new(),
    )])));
    let opened = Rc::new(RefCell::new(Vec::new()));
    let links = opened.clone();
    window.on_open_link(move |link| links.borrow_mut().push(link.to_string()));
    let interactions = Rc::new(Cell::new(0));
    let invoked = interactions.clone();
    window.on_use_button(move |_, _| invoked.set(invoked.get() + 1));
    let menus = Rc::new(RefCell::new(Vec::new()));
    let requested = menus.clone();
    window.global::<CardLinks>().on_show(move |link, x, y| {
        assert!(x >= 0. && y >= 0.);
        requested.borrow_mut().push(link.to_string());
    });
    let handoff_menu = Rc::new(RefCell::new(Vec::new()));
    let requested = handoff_menu.clone();
    window.global::<CardLinks>().on_show_handoff(move |link, _, _| {
        requested.borrow_mut().push(link.to_string());
    });
    let regular = menus.clone();
    let handed_off = handoff_menu.clone();
    window.global::<CardLinks>().on_show_message(move |link, item, handoff, x, y| {
        assert_eq!(item, "review:button");
        assert!(x >= 0. && y >= 0.);
        if handoff { handed_off.borrow_mut().push(link.to_string()); }
        else { regular.borrow_mut().push(link.to_string()); }
    });
    let handoff = Rc::new(RefCell::new(Vec::new()));
    let destination = handoff.clone();
    window.global::<CardLinks>().on_open_handoff(move |link| {
        destination.borrow_mut().push(link.to_string());
    });
    window.show().unwrap();
    window
        .window()
        .set_size(slint::LogicalSize::new(1120., 760.));
    let _ = window.invoke_timeline_extent();
    i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(1000));
    slint::platform::update_timers_and_animations();
    click(&window, "Open Tracker", PointerEventButton::Right);
    assert_eq!(&*menus.borrow(), &[link]);
    assert!(opened.borrow().is_empty());
    assert_eq!(interactions.get(), 0);
    click(&window, "Re-Sync", PointerEventButton::Right);
    assert_eq!(
        menus.borrow().len(),
        1,
        "action buttons have no underlying link"
    );
    assert_eq!(
        interactions.get(),
        0,
        "right-click cannot send an interaction"
    );
    click(&window, "Open Tracker", PointerEventButton::Left);
    assert_eq!(&*opened.borrow(), &[link]);
    click(&window, "Re-Sync", PointerEventButton::Left);
    assert_eq!(interactions.get(), 1);
    click(&window, "Open Invite in Discord", PointerEventButton::Right);
    assert_eq!(&*handoff_menu.borrow(), &[invite]);
    assert!(handoff.borrow().is_empty());
    click(&window, "Open Invite in Discord", PointerEventButton::Left);
    assert_eq!(&*handoff.borrow(), &[invite]);
    assert_eq!(&*opened.borrow(), &[link]);
    window.hide().unwrap();
}

#[test]
fn button_links_open_the_complete_message_menu_and_copy_the_selected_url() {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    ))).unwrap();
    let folder = tempfile::tempdir().unwrap();
    let window = YapfastWindow::new().unwrap();
    window.window().set_size(slint::LogicalSize::new(1100., 760.));
    let adapter = Adapter::new(
        Arc::new(BackgroundRuntime::new().unwrap()),
        folder.path().into(),
        &window,
    ).unwrap();
    bind_callbacks(&window, &adapter);
    let url = "https://example.com/full/path?option=value";
    {
        let mut adapter = adapter.borrow_mut();
        adapter.app.dispatch(Action::Preview);
        let mut message = adapter.app.state.messages[0].as_ref().clone();
        message.can_reply = true;
        message.can_edit = true;
        message.cards = vec![yapfast_core::chat::Card {
            framed: true,
            rows: vec![yapfast_core::chat::CardRow::Buttons(vec![yapfast_core::chat::CardButton {
                label: "Open attachment site".into(),
                style: yapfast_core::chat::ButtonStyle::Link,
                url: Some(url.into()),
                custom_id: None,
                sku_id: None,
                disabled: false,
            }])],
            ..Default::default()
        }];
        adapter.app.state.messages = Arc::new(vec![Arc::new(message)]);
        adapter.refresh(&window);
    }
    window.set_workspace(true);
    window.show().unwrap();
    window.window().take_snapshot().unwrap();
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    let button = ItemRc::new_root(inner.component()).visit_descendants(|item| {
        if item.is_visible()
            && item.accessible_string_property(AccessibleStringProperty::Label).as_deref() == Some("Open attachment site") {
            ControlFlow::Break(item.clone())
        } else {
            ControlFlow::Continue(())
        }
    }).expect("the message contains the actual link button");
    let point = button.map_to_window(button.geometry().center());
    let position = slint::LogicalPosition::new(point.x, point.y);
    window.window().dispatch_event(WindowEvent::PointerMoved { position });
    window.window().dispatch_event(WindowEvent::PointerPressed { position, button: PointerEventButton::Right });
    window.window().dispatch_event(WindowEvent::PointerReleased { position, button: PointerEventButton::Right });
    window.window().take_snapshot().unwrap();
    let position = {
    let popups = inner.active_popups();
    let popup = popups.last().expect("the link button opens a message menu");
    let root = ItemRc::new_root(popup.component.clone());
    let named = |label: &str| root.visit_descendants(|item| {
        if item.is_visible()
            && item.accessible_string_property(AccessibleStringProperty::Label).as_deref() == Some(label) {
            ControlFlow::Break(item.clone())
        } else {
            ControlFlow::Continue(())
        }
    }).unwrap_or_else(|| panic!("missing {label}"));
    named("Reply");
    named("Edit message");
    named("Copy text");
    named("Open Link");
    let copy = named("Copy Link");
    let i_slint_core::window::PopupWindowLocation::ChildWindow(place) = popup.location else {
        panic!("the test menu is embedded in the window");
    };
    let point = copy.map_to_item_tree(copy.geometry().center(), &popup.component);
    slint::LogicalPosition::new(point.x + place.x, point.y + place.y)
    };
    window.window().dispatch_event(WindowEvent::PointerMoved { position });
    window.window().dispatch_event(WindowEvent::PointerPressed { position, button: PointerEventButton::Left });
    window.window().dispatch_event(WindowEvent::PointerReleased { position, button: PointerEventButton::Left });
    assert_eq!(inner.context().platform()
        .clipboard_text(i_slint_core::platform::Clipboard::DefaultClipboard).as_deref(), Some(url));
}
