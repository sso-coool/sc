use std::time::Duration;

use slint::{
    ComponentHandle, LogicalPosition, LogicalSize,
    platform::{PointerEventButton, WindowEvent},
};

slint::slint! {
    #[edition = "1.19"]
    export component SelectionFixture inherits Window {
        in property <styled-text> body;
        out property <length> scroll-y: list.content-y;
        list := Flickable {
            x: 0px; y: 0px; width: 400px; height: 260px;
            content-height: 800px;
            mouse-drag-pan-enabled: false;
            for text in [root.body]: Rectangle {
                y: 100px; width: 400px; height: 100px;
                StyledText {
                    x: 100px; width: 240px; height: 100px;
                    text: text; default-font-size: 20px; link-color: #7289da;
                }
            }
        }
    }
}

fn fixture() -> SelectionFixture {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let window = SelectionFixture::new().unwrap();
    window.set_body(slint::StyledText::from_plain_text(
        "alpha beta\ngamma delta\nepsilon zeta",
    ));
    window.show().unwrap();
    window.window().set_size(LogicalSize::new(600., 400.));
    window.window().take_snapshot().unwrap();
    window
}

fn move_to(window: &SelectionFixture, x: f32, y: f32) {
    window.window().dispatch_event(WindowEvent::PointerMoved {
        position: LogicalPosition::new(x, y),
    });
}

fn press(window: &SelectionFixture, x: f32, y: f32) {
    move_to(window, x, y);
    window.window().dispatch_event(WindowEvent::PointerPressed {
        position: LogicalPosition::new(x, y),
        button: PointerEventButton::Left,
    });
}

fn release(window: &SelectionFixture, x: f32, y: f32) {
    window
        .window()
        .dispatch_event(WindowEvent::PointerReleased {
            position: LogicalPosition::new(x, y),
            button: PointerEventButton::Left,
        });
}

fn selected() -> Option<String> {
    i_slint_core::yapfast_selection::copied_at(i_slint_core::lengths::LogicalPoint::new(120., 110.))
}

#[test]
fn message_selection_follows_visual_line_in_margins_and_keeps_anchor() {
    let window = fixture();
    press(&window, 102., 110.);
    move_to(&window, 150., 110.);
    move_to(&window, 90., 135.);
    assert_eq!(selected().as_deref(), Some("alpha beta\n"));
    move_to(&window, 350., 135.);
    assert_eq!(selected().as_deref(), Some("alpha beta\ngamma delta"));
    move_to(&window, 90., 110.);
    assert_eq!(
        selected(),
        None,
        "returning to the anchor collapses the selection"
    );
    release(&window, 90., 110.);
}

#[test]
fn message_selection_uses_release_position_and_preserves_word_drag() {
    let window = fixture();
    press(&window, 102., 110.);
    move_to(&window, 150., 110.);
    // The last release may arrive at a different location than the last move event.
    release(&window, 350., 135.);
    assert_eq!(selected().as_deref(), Some("alpha beta\ngamma delta"));

    i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(600));
    press(&window, 170., 110.);
    release(&window, 170., 110.);
    press(&window, 170., 110.);
    assert_eq!(selected().as_deref(), Some("beta"));
    move_to(&window, 90., 110.);
    assert_eq!(selected().as_deref(), Some("alpha beta"));
    move_to(&window, 350., 135.);
    // Whole-word dragging at a hard line's far edge includes its newline.
    assert_eq!(selected().as_deref(), Some("beta\ngamma delta\n"));
    release(&window, 350., 135.);
}

#[test]
fn message_selection_autoscroll_stops_on_release() {
    let window = fixture();
    press(&window, 102., 110.);
    move_to(&window, 150., 110.);
    move_to(&window, 150., 255.);
    for _ in 0..8 {
        i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(16));
        slint::platform::update_timers_and_animations();
        window.window().take_snapshot().unwrap();
    }
    assert!(
        window.get_scroll_y() < 0.,
        "holding at the lower edge scrolls the list"
    );
    release(&window, 150., 255.);
    let stopped = window.get_scroll_y();
    i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(320));
    slint::platform::update_timers_and_animations();
    assert_eq!(window.get_scroll_y(), stopped);
}
