//! Device-local server order and folder membership.
use super::*;
use std::collections::BTreeMap;
use yapfast_core::chat::{ChatServer, ServerFolder};

const MAX_ACCOUNTS: usize = 8;
const MAX_ITEMS: usize = 2048;
const LOCAL_FOLDER: &str = "local-folder:";

#[derive(Clone, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(default)]
pub(super) struct KeptOrder {
    account: String,
    items: Vec<String>,
    folders: BTreeMap<String, Option<String>>,
}

fn valid(value: &str) -> bool {
    !value.is_empty() && value.len() <= 256 && !value.chars().any(char::is_control)
}

pub(super) fn tidy(accounts: &mut Vec<KeptOrder>) {
    let mut seen = HashSet::new();
    accounts.reverse();
    accounts.retain_mut(|entry| {
        if !valid(&entry.account)
            || seen.len() >= MAX_ACCOUNTS
            || !seen.insert(entry.account.clone())
        {
            return false;
        }
        let mut ids = HashSet::new();
        entry
            .items
            .retain(|id| ids.len() < MAX_ITEMS && valid(id) && ids.insert(id.clone()));
        entry.folders.retain(|server, folder| {
            entry.account.starts_with("discord:")
                && valid(server)
                && server.starts_with("discord:")
                && folder.as_deref().is_none_or(|id| {
                    valid(id) && (id.starts_with("discord-folder:") || id.starts_with(LOCAL_FOLDER))
                })
        });
        if let Some(first_excess) = entry.folders.keys().nth(MAX_ITEMS).cloned() {
            drop(entry.folders.split_off(&first_excess));
        }
        true
    });
    accounts.reverse();
}

fn account(state: &AppState) -> Option<String> {
    if state.preview {
        return None;
    }
    state
        .discord_user
        .as_deref()
        .filter(|id| {
            !id.is_empty() && id.len() <= 20 && id.bytes().all(|byte| byte.is_ascii_digit())
        })
        .map(|id| format!("discord:{id}"))
        .or_else(|| {
            state
                .account
                .as_deref()
                .filter(|id| id.starts_with('@') && valid(id))
                .map(|id| format!("matrix:{id}"))
        })
}

pub(super) fn context(state: &AppState) -> String {
    format!(
        "{}|{}",
        account(state).unwrap_or_default(),
        state.reset_version
    )
}

pub(super) fn active<'a>(state: &AppState, accounts: &'a [KeptOrder]) -> Option<&'a KeptOrder> {
    let account = account(state)?;
    accounts.iter().find(|entry| entry.account == account)
}

pub(super) struct RailGroup<'a> {
    pub folder: Option<ServerFolder>,
    pub servers: Vec<&'a ChatServer>,
}

impl RailGroup<'_> {
    fn id(&self) -> &str {
        self.folder
            .as_ref()
            .map_or(self.servers[0].id.as_str(), |folder| folder.id.as_str())
    }
}

/// Apply saved membership and order at both levels of the rail.
pub(super) fn groups<'a>(state: &'a AppState, order: Option<&KeptOrder>) -> Vec<RailGroup<'a>> {
    let rank: HashMap<&str, usize> = order
        .into_iter()
        .flat_map(|entry| &entry.items)
        .enumerate()
        .map(|(at, id)| (id.as_str(), at))
        .collect();
    let position = |id: &str| rank.get(id).copied().unwrap_or(usize::MAX);
    let incoming: HashMap<_, _> = state
        .servers
        .iter()
        .filter_map(|server| server.folder.as_ref())
        .map(|folder| (folder.id.as_str(), folder))
        .collect();
    let mut groups: Vec<RailGroup<'a>> = Vec::new();
    let mut indices: HashMap<String, usize> = HashMap::new();
    for server in &state.servers {
        let folder = match order
            .filter(|_| server.discord)
            .and_then(|entry| entry.folders.get(&server.id))
        {
            Some(None) => None,
            Some(Some(id)) => incoming
                .get(id.as_str())
                .map(|&folder| folder.clone())
                .or_else(|| {
                    id.starts_with(LOCAL_FOLDER).then(|| ServerFolder {
                        id: id.clone(),
                        name: None,
                        color: None,
                    })
                })
                .or_else(|| server.folder.clone()),
            None => server.folder.clone(),
        };
        if let Some(folder) = &folder {
            if let Some(&index) = indices.get(&folder.id) {
                groups[index].servers.push(server);
                continue;
            }
            indices.insert(folder.id.clone(), groups.len());
        }
        groups.push(RailGroup {
            folder,
            servers: vec![server],
        });
    }
    groups.sort_by_key(|group| position(group.id()));
    for group in &mut groups {
        if group.folder.is_some() {
            group.servers.sort_by_key(|server| position(&server.id));
        }
    }
    groups
}

enum Drop {
    Edge { after: bool },
    Into,
}

struct RailItem<'a> {
    id: &'a str,
    parent: Option<&'a str>,
    server: Option<&'a ChatServer>,
}

fn remember_parent(entry: &mut KeptOrder, server: &ChatServer, parent: Option<&str>) {
    if server.folder.as_ref().map(|folder| folder.id.as_str()) == parent {
        entry.folders.remove(&server.id);
    } else {
        entry
            .folders
            .insert(server.id.clone(), parent.map(str::to_owned));
    }
}

fn remember_order(entry: &mut KeptOrder, siblings: Vec<String>) {
    entry.items.retain(|id| !siblings.contains(id));
    entry.items.extend(siblings);
    // Keep the most recent arrangement if old departed servers filled the cap.
    if entry.items.len() > MAX_ITEMS {
        entry.items.drain(..entry.items.len() - MAX_ITEMS);
    }
}

fn arrange(
    state: &AppState,
    accounts: &mut Vec<KeptOrder>,
    source: &str,
    target: &str,
    placement: Drop,
) -> bool {
    let Some(account) = account(state) else {
        return false;
    };
    if source == target || !valid(source) || !valid(target) {
        return false;
    }
    let active = active(state, accounts);
    let groups = groups(state, active);
    let mut items = Vec::new();
    for group in &groups {
        let parent = group.folder.as_ref().map(|folder| folder.id.as_str());
        if let Some(id) = parent {
            items.push(RailItem {
                id,
                parent: None,
                server: None,
            });
        }
        items.extend(group.servers.iter().map(|server| RailItem {
            id: &server.id,
            parent,
            server: Some(server),
        }));
    }
    let (Some(from), Some(to)) = (
        items.iter().find(|item| item.id == source),
        items.iter().find(|item| item.id == target),
    ) else {
        return false;
    };
    let siblings = |parent| {
        items
            .iter()
            .filter(|item| item.parent == parent)
            .map(|item| item.id.to_owned())
            .collect::<Vec<_>>()
    };
    let mut entry = active.cloned().unwrap_or_else(|| KeptOrder {
        account: account.clone(),
        ..KeptOrder::default()
    });

    match placement {
        Drop::Edge { after } => {
            let mut order = siblings(to.parent);
            let before = order.clone();
            order.retain(|id| id != source);
            let at = order.iter().position(|id| id == target).unwrap() + usize::from(after);
            order.insert(at, source.to_owned());
            if order == before || order.len() > MAX_ITEMS {
                return false;
            }
            if from.parent != to.parent {
                let Some(server) = from.server.filter(|server| server.discord) else {
                    return false;
                };
                remember_parent(&mut entry, server, to.parent);
                if to.parent.is_some() {
                    let mut roots = siblings(None);
                    roots.retain(|id| id != source);
                    remember_order(&mut entry, roots);
                }
            }
            remember_order(&mut entry, order);
        }
        Drop::Into => {
            let Some(server) = from.server.filter(|server| server.discord) else {
                return false;
            };
            if let Some(other) = to.server {
                if !other.discord || to.parent.is_some() {
                    return false;
                }
                let now = clock::now_ms();
                let folder = (0..=entry.folders.len())
                    .map(|suffix| format!("{LOCAL_FOLDER}{now}:{suffix}"))
                    .find(|id| !entry.folders.values().any(|parent| parent.as_ref() == Some(id)))
                    .expect("there is a free local folder ID");
                let mut roots = siblings(None);
                roots.retain(|id| id != source);
                let at = roots.iter().position(|id| id == target).unwrap();
                roots[at] = folder.clone();
                remember_parent(&mut entry, other, Some(&folder));
                remember_parent(&mut entry, server, Some(&folder));
                remember_order(&mut entry, roots);
                remember_order(&mut entry, vec![target.to_owned(), source.to_owned()]);
            } else {
                let mut order = siblings(Some(target));
                if order.last().is_some_and(|id| id == source) || order.len() >= MAX_ITEMS {
                    return false;
                }
                if from.parent != Some(target) {
                    let mut roots = siblings(None);
                    roots.retain(|id| id != source);
                    remember_order(&mut entry, roots);
                }
                order.retain(|id| id != source);
                order.push(source.to_owned());
                remember_parent(&mut entry, server, Some(target));
                remember_order(&mut entry, order);
            }
        }
    }
    if entry.folders.len() > MAX_ITEMS {
        return false;
    }
    accounts.retain(|entry| entry.account != account);
    accounts.push(entry);
    tidy(accounts);
    true
}

pub(super) fn folder_members<'a>(
    state: &'a AppState,
    accounts: &[KeptOrder],
    id: &str,
) -> Option<Vec<&'a ChatServer>> {
    if !(id.starts_with("discord-folder:") || id.starts_with(LOCAL_FOLDER)) {
        return None;
    }
    Some(
        groups(state, active(state, accounts))
            .into_iter()
            .find(|group| group.id() == id)
            .map_or_else(Vec::new, |group| group.servers),
    )
}

fn apply_drop(
    adapter: &mut Adapter,
    window: &YapfastWindow,
    source: &str,
    target: &str,
    placement: Drop,
) {
    if arrange(
        &adapter.app.state,
        &mut adapter.layout.server_orders,
        source,
        target,
        placement,
    ) {
        adapter.layout.write(&adapter.root);
        adapter.sidebar = None;
        adapter.show_sidebar(window);
    }
}

pub(super) fn bind(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_reorder_server(move |source, target, after| {
        if let Some(window) = weak.upgrade() {
            apply_drop(
                &mut state.borrow_mut(),
                &window,
                source.as_str(),
                target.as_str(),
                Drop::Edge { after },
            );
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_move_server_into(move |source, target| {
        if let Some(window) = weak.upgrade() {
            apply_drop(
                &mut state.borrow_mut(),
                &window,
                source.as_str(),
                target.as_str(),
                Drop::Into,
            );
        }
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fixture() -> AppState {
        let folder = ServerFolder {
            id: "discord-folder:7".into(),
            name: Some("Tools".into()),
            color: None,
        };
        let mut state = AppState::default();
        state.discord_user = Some("1".into());
        state.servers = [
            ("10", "Alpha", None),
            ("20", "Bravo", Some(folder.clone())),
            ("30", "Charlie", Some(folder)),
            ("40", "Delta", None),
        ]
        .into_iter()
        .map(|(id, name, folder)| {
            Arc::new(ChatServer {
                id: format!("discord:{id}"),
                name: name.into(),
                folder,
                discord: true,
                ..Default::default()
            })
        })
        .collect();
        state
    }

    fn ordered(state: &AppState, kept: &[KeptOrder]) -> Vec<String> {
        groups(state, active(state, kept))
            .into_iter()
            .flat_map(|group| group.servers)
            .map(|server| server.id.clone())
            .collect()
    }

    fn reorder(
        state: &AppState,
        kept: &mut Vec<KeptOrder>,
        source: &str,
        target: &str,
        after: bool,
    ) -> bool {
        arrange(state, kept, source, target, Drop::Edge { after })
    }

    #[test]
    fn server_rail_order_preserves_folders_membership_restart_and_accounts() {
        let mut state = fixture();
        let mut kept = vec![];
        assert!(reorder(&state, &mut kept, "discord:10", "discord:40", true));
        assert_eq!(
            ordered(&state, &kept),
            ["discord:20", "discord:30", "discord:40", "discord:10"]
        );
        assert!(reorder(&state, &mut kept, "discord:20", "discord:30", true));
        assert_eq!(
            ordered(&state, &kept),
            ["discord:30", "discord:20", "discord:40", "discord:10"]
        );
        assert!(
            !reorder(&state, &mut kept, "discord-folder:7", "discord:20", false),
            "folders cannot be nested"
        );
        assert!(reorder(
            &state,
            &mut kept,
            "discord-folder:7",
            "discord:10",
            true
        ));
        assert_eq!(
            ordered(&state, &kept),
            ["discord:40", "discord:10", "discord:30", "discord:20"]
        );
        let restored: Vec<KeptOrder> =
            serde_json::from_slice(&serde_json::to_vec(&kept).unwrap()).unwrap();
        assert_eq!(ordered(&state, &restored), ordered(&state, &kept));
        state.discord_user = Some("2".into());
        assert_eq!(
            ordered(&state, &kept),
            ["discord:10", "discord:20", "discord:30", "discord:40"]
        );
        state.discord_user = Some("1".into());
        state.servers.push(Arc::new(ChatServer {
            id: "discord:50".into(),
            name: "New".into(),
            ..Default::default()
        }));
        assert_eq!(ordered(&state, &kept).last().unwrap(), "discord:50");
        state.preview = true;
        assert!(!reorder(
            &state,
            &mut kept,
            "discord:10",
            "discord:40",
            false
        ));
    }

    #[test]
    fn server_rail_order_storage_is_bounded_and_rejects_unknown_targets() {
        let state = fixture();
        let mut kept: Vec<KeptOrder> = (0..12)
            .map(|id| KeptOrder {
                account: format!("discord:{id}"),
                items: (0..3000).map(|id| format!("discord:{id}")).collect(),
                ..KeptOrder::default()
            })
            .collect();
        tidy(&mut kept);
        assert_eq!(kept.len(), MAX_ACCOUNTS);
        assert!(kept.iter().all(|entry| entry.items.len() == MAX_ITEMS));
        let before = kept.clone();
        assert!(!reorder(
            &state,
            &mut kept,
            "discord:10",
            "not-present",
            true
        ));
        assert_eq!(kept, before);
    }

    #[test]
    fn server_rail_folder_membership_survives_reload_and_moves_between_folders() {
        let mut state = fixture();
        state.servers.push(Arc::new(ChatServer {
            id: "discord:50".into(),
            discord: true,
            folder: Some(ServerFolder {
                id: "discord-folder:9".into(),
                name: Some("Games".into()),
                color: None,
            }),
            ..Default::default()
        }));
        // This is the format from previous releases, before folder overrides.
        let mut kept: Vec<KeptOrder> =
            serde_json::from_str(r#"[{"account":"discord:1","items":[]}]"#).unwrap();
        let members = |state: &AppState, kept: &[KeptOrder], folder| {
            folder_members(state, kept, folder)
                .unwrap()
                .into_iter()
                .map(|server| server.id.clone())
                .collect::<Vec<_>>()
        };
        assert!(arrange(
            &state,
            &mut kept,
            "discord:10",
            "discord-folder:9",
            Drop::Into,
        ));
        assert_eq!(
            ordered(&state, &kept),
            [
                "discord:20",
                "discord:30",
                "discord:40",
                "discord:50",
                "discord:10"
            ]
        );
        assert!(reorder(
            &state,
            &mut kept,
            "discord:10",
            "discord:30",
            false
        ));
        assert_eq!(
            members(&state, &kept, "discord-folder:7"),
            ["discord:20", "discord:10", "discord:30"]
        );
        assert!(reorder(
            &state,
            &mut kept,
            "discord:10",
            "discord-folder:7",
            false,
        ));
        assert!(arrange(
            &state,
            &mut kept,
            "discord:10",
            "discord:40",
            Drop::Into,
        ));
        let local = groups(&state, active(&state, &kept))
            .into_iter()
            .find_map(|group| {
                group
                    .folder
                    .filter(|folder| folder.id.starts_with(LOCAL_FOLDER))
            })
            .unwrap();
        assert_eq!(
            members(&state, &kept, &local.id),
            ["discord:40", "discord:10"]
        );
        let restored: Vec<KeptOrder> =
            serde_json::from_slice(&serde_json::to_vec(&kept).unwrap()).unwrap();
        assert_eq!(
            members(&state, &restored, &local.id),
            ["discord:40", "discord:10"]
        );
        assert!(state.servers[0].folder.is_none());
        state.discord_user = Some("2".into());
        assert!(members(&state, &restored, &local.id).is_empty());
    }

    #[test]
    fn server_rail_order_real_drag_moves_servers_and_folders_without_navigation() {
        use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
        use slint::platform::{PointerEventButton, WindowEvent};
        use std::ops::ControlFlow;
        slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
            i_slint_backend_testing::TestingBackendOptions {
                mock_time: true,
                threading: false,
                renderer_name: Some("skia".into()),
            },
        )))
        .unwrap();
        let directory = tempfile::tempdir().unwrap();
        let window = yapfast::window().unwrap();
        let adapter = Adapter::new(
            Arc::new(BackgroundRuntime::new().unwrap()),
            directory.path().into(),
            &window,
        )
        .unwrap();
        bind_callbacks(&window, &adapter);
        {
            let mut adapter = adapter.borrow_mut();
            adapter.app.state = fixture();
            adapter
                .layout
                .open_folders
                .insert("discord-folder:7".into());
            adapter.show_sidebar(&window);
        }
        Layout::default().apply_appearance(&window);
        title_bar::show(&window, Some(false));
        window.global::<ClientStyle>().set_interface_motion(false);
        window.set_workspace(true);
        window.set_trusted(true);
        window.show().unwrap();
        window
            .window()
            .set_size(slint::LogicalSize::new(800., 600.));
        let navigated = Rc::new(RefCell::new(0));
        let count = navigated.clone();
        window.on_navigate_server(move |_| *count.borrow_mut() += 1);
        fn settle(window: &YapfastWindow) {
            for _ in 0..3 {
                window.window().take_snapshot().unwrap();
                i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(40));
                slint::platform::update_timers_and_animations();
            }
        }
        fn point(window: &YapfastWindow, name: &str, offset: f32) -> slint::LogicalPosition {
            let inner = i_slint_core::window::WindowInner::from_pub(window.window());
            let item = ItemRc::new_root(inner.component())
                .visit_descendants(|item| {
                    if item.is_visible()
                        && item
                            .accessible_string_property(AccessibleStringProperty::Label)
                            .is_some_and(|label| {
                                label == name
                                    || label.starts_with(&format!("{name}, "))
                                    || label.starts_with(&format!("{name} folder,"))
                            })
                    {
                        ControlFlow::Break(item.clone())
                    } else {
                        ControlFlow::Continue(())
                    }
                })
                .unwrap_or_else(|| panic!("missing rail item {name}"));
            let geometry = item.geometry();
            let point = item.map_to_window(geometry.center());
            slint::LogicalPosition::new(point.x, point.y + offset)
        }
        fn drag(window: &YapfastWindow, from: &str, to: &str, after: bool) {
            let start = point(window, from, 0.);
            let end = point(window, to, if after { 12. } else { -12. });
            window
                .window()
                .dispatch_event(WindowEvent::PointerMoved { position: start });
            window.window().dispatch_event(WindowEvent::PointerPressed {
                position: start,
                button: PointerEventButton::Left,
            });
            window.window().dispatch_event(WindowEvent::PointerMoved {
                position: slint::LogicalPosition::new(start.x, start.y + 7.),
            });
            settle(window);
            window
                .window()
                .dispatch_event(WindowEvent::PointerMoved { position: end });
            settle(window);
            window
                .window()
                .dispatch_event(WindowEvent::PointerReleased {
                    position: end,
                    button: PointerEventButton::Left,
                });
            settle(window);
        }
        let rows = || {
            window
                .get_servers()
                .iter()
                .filter(|row| !row.id.is_empty())
                .map(|row| row.id.to_string())
                .collect::<Vec<_>>()
        };
        settle(&window);
        drag(&window, "Alpha", "Delta", true);
        assert_eq!(
            rows(),
            [
                "discord-folder:7",
                "discord:20",
                "discord:30",
                "discord:40",
                "discord:10"
            ]
        );
        drag(&window, "Tools", "Alpha", true);
        assert_eq!(
            rows(),
            [
                "discord:40",
                "discord:10",
                "discord-folder:7",
                "discord:20",
                "discord:30"
            ]
        );
        drag(&window, "Bravo", "Charlie", true);
        assert_eq!(
            rows(),
            [
                "discord:40",
                "discord:10",
                "discord-folder:7",
                "discord:30",
                "discord:20"
            ]
        );
        assert_eq!(*navigated.borrow(), 0, "dragging never clicks a server");
        let saved = Layout::read(directory.path());
        assert_eq!(
            ordered(&fixture(), &saved.server_orders),
            ["discord:40", "discord:10", "discord:30", "discord:20"]
        );
        // A model/account change while a button is held cancels the old drag.
        let start = point(&window, "Delta", 0.);
        let end = point(&window, "Alpha", 12.);
        window.window().dispatch_event(WindowEvent::PointerPressed {
            position: start,
            button: PointerEventButton::Left,
        });
        window
            .window()
            .dispatch_event(WindowEvent::PointerMoved { position: end });
        settle(&window);
        {
            let mut adapter = adapter.borrow_mut();
            adapter.app.state.discord_user = Some("2".into());
            adapter.sidebar = None;
            adapter.show_sidebar(&window);
        }
        settle(&window);
        window
            .window()
            .dispatch_event(WindowEvent::PointerReleased {
                position: end,
                button: PointerEventButton::Left,
            });
        settle(&window);
        assert_eq!(
            adapter.borrow().layout.server_orders.len(),
            1,
            "old drag cannot write the next account"
        );
        assert_eq!(
            rows(),
            [
                "discord:10",
                "discord-folder:7",
                "discord:20",
                "discord:30",
                "discord:40"
            ]
        );
    }
}
