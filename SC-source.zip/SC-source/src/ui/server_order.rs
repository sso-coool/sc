//! Device-local rail arrangement. Incoming folder membership remains intact.
use super::*;

const MAX_ACCOUNTS: usize = 8;
const MAX_ITEMS: usize = 2048;

#[derive(Clone, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(default)]
pub(super) struct KeptOrder {
    account: String,
    items: Vec<String>,
}

fn valid(value: &str) -> bool {
    !value.is_empty() && value.len() <= 256 && !value.chars().any(char::is_control)
}

pub(super) fn tidy(accounts: &mut Vec<KeptOrder>) {
    let mut seen = HashSet::new();
    accounts.reverse();
    accounts.retain_mut(|entry| {
        if !valid(&entry.account)
            || seen.len() >= MAX_ACCOUNTS
            || !seen.insert(entry.account.clone())
        {
            return false;
        }
        let mut ids = HashSet::new();
        entry
            .items
            .retain(|id| ids.len() < MAX_ITEMS && valid(id) && ids.insert(id.clone()));
        true
    });
    accounts.reverse();
}

fn account(state: &AppState) -> Option<String> {
    if state.preview {
        return None;
    }
    state
        .discord_user
        .as_deref()
        .filter(|id| {
            !id.is_empty() && id.len() <= 20 && id.bytes().all(|byte| byte.is_ascii_digit())
        })
        .map(|id| format!("discord:{id}"))
        .or_else(|| {
            state
                .account
                .as_deref()
                .filter(|id| id.starts_with('@') && valid(id))
                .map(|id| format!("matrix:{id}"))
        })
}

pub(super) fn context(state: &AppState) -> String {
    format!(
        "{}|{}",
        account(state).unwrap_or_default(),
        state.reset_version
    )
}

pub(super) fn active<'a>(state: &AppState, accounts: &'a [KeptOrder]) -> &'a [String] {
    let Some(account) = account(state) else {
        return &[];
    };
    accounts
        .iter()
        .find(|entry| entry.account == account)
        .map_or(&[], |entry| entry.items.as_slice())
}

/// Stable order at both levels; new/unlisted keys retain their incoming order.
pub(super) fn servers<'a>(
    state: &'a AppState,
    order: &[String],
) -> Vec<&'a yapfast_core::chat::ChatServer> {
    if order.is_empty() {
        return state.servers.iter().map(AsRef::as_ref).collect();
    }
    let rank: HashMap<&str, usize> = order
        .iter()
        .enumerate()
        .map(|(at, id)| (id.as_str(), at))
        .collect();
    let position = |id: &str| rank.get(id).copied().unwrap_or(usize::MAX);
    let mut groups: Vec<Vec<&yapfast_core::chat::ChatServer>> = Vec::new();
    for server in &state.servers {
        if server.folder.is_some()
            && groups
                .last()
                .is_some_and(|group| group[0].folder == server.folder)
        {
            groups.last_mut().unwrap().push(server);
        } else {
            groups.push(vec![server]);
        }
    }
    groups.sort_by_key(|group| {
        position(
            group[0]
                .folder
                .as_ref()
                .map_or(group[0].id.as_str(), |folder| folder.id.as_str()),
        )
    });
    for group in &mut groups {
        if group[0].folder.is_some() {
            group.sort_by_key(|server| position(&server.id));
        }
    }
    groups.into_iter().flatten().collect()
}

pub(super) fn reorder(
    state: &AppState,
    accounts: &mut Vec<KeptOrder>,
    source: &str,
    target: &str,
    after: bool,
) -> bool {
    let Some(account) = account(state) else {
        return false;
    };
    if source == target || !valid(source) || !valid(target) {
        return false;
    }
    let ordered = servers(state, active(state, accounts));
    let mut nodes: Vec<(&str, &str)> = Vec::new();
    for server in &ordered {
        if let Some(folder) = &server.folder {
            if !nodes.iter().any(|(id, _)| *id == folder.id) {
                nodes.push((&folder.id, ""));
            }
            nodes.push((&server.id, &folder.id));
        } else {
            nodes.push((&server.id, ""));
        }
    }
    let Some((_, parent)) = nodes.iter().find(|(id, _)| *id == source) else {
        return false;
    };
    if !nodes
        .iter()
        .any(|(id, group)| *id == target && group == parent)
    {
        return false;
    }
    let mut siblings: Vec<String> = nodes
        .iter()
        .filter(|(_, group)| group == parent)
        .map(|(id, _)| (*id).to_owned())
        .collect();
    let before = siblings.clone();
    siblings.retain(|id| id != source);
    let at = siblings.iter().position(|id| id == target).unwrap() + usize::from(after);
    siblings.insert(at, source.to_owned());
    if siblings == before || siblings.len() > MAX_ITEMS {
        return false;
    }
    let mut entry = accounts
        .iter()
        .find(|entry| entry.account == account)
        .cloned()
        .unwrap_or_else(|| KeptOrder {
            account: account.clone(),
            items: vec![],
        });
    entry.items.retain(|id| !siblings.contains(id));
    entry.items.extend(siblings);
    // Keep the most recent arrangement if old departed servers filled the cap.
    if entry.items.len() > MAX_ITEMS {
        entry.items.drain(..entry.items.len() - MAX_ITEMS);
    }
    accounts.retain(|entry| entry.account != account);
    accounts.push(entry);
    tidy(accounts);
    true
}

pub(super) fn bind(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    let state = adapter.clone();
    let weak = window.as_weak();
    window.on_reorder_server(move |source, target, after| {
        let Some(window) = weak.upgrade() else {
            return;
        };
        let mut adapter = state.borrow_mut();
        let Adapter { app, layout, .. } = &mut *adapter;
        if reorder(
            &app.state,
            &mut layout.server_orders,
            source.as_str(),
            target.as_str(),
            after,
        ) {
            adapter.layout.write(&adapter.root);
            adapter.sidebar = None;
            adapter.show_sidebar(&window);
        }
    });
}

#[cfg(test)]
mod tests {
    use super::*;
    use yapfast_core::chat::{ChatServer, ServerFolder};

    fn fixture() -> AppState {
        let folder = ServerFolder {
            id: "discord-folder:7".into(),
            name: Some("Tools".into()),
            color: None,
        };
        let mut state = AppState::default();
        state.discord_user = Some("1".into());
        state.servers = [
            ("10", "Alpha", None),
            ("20", "Bravo", Some(folder.clone())),
            ("30", "Charlie", Some(folder)),
            ("40", "Delta", None),
        ]
        .into_iter()
        .map(|(id, name, folder)| {
            Arc::new(ChatServer {
                id: format!("discord:{id}"),
                name: name.into(),
                folder,
                discord: true,
                ..Default::default()
            })
        })
        .collect();
        state
    }

    fn ordered(state: &AppState, kept: &[KeptOrder]) -> Vec<String> {
        servers(state, active(state, kept))
            .iter()
            .map(|server| server.id.clone())
            .collect()
    }

    #[test]
    fn server_rail_order_preserves_folders_membership_restart_and_accounts() {
        let mut state = fixture();
        let mut kept = vec![];
        assert!(reorder(&state, &mut kept, "discord:10", "discord:40", true));
        assert_eq!(
            ordered(&state, &kept),
            ["discord:20", "discord:30", "discord:40", "discord:10"]
        );
        assert!(reorder(&state, &mut kept, "discord:20", "discord:30", true));
        assert_eq!(
            ordered(&state, &kept),
            ["discord:30", "discord:20", "discord:40", "discord:10"]
        );
        assert!(
            !reorder(&state, &mut kept, "discord:20", "discord:10", false),
            "membership changes need a separate operation"
        );
        assert!(reorder(
            &state,
            &mut kept,
            "discord-folder:7",
            "discord:10",
            true
        ));
        assert_eq!(
            ordered(&state, &kept),
            ["discord:40", "discord:10", "discord:30", "discord:20"]
        );
        let restored: Vec<KeptOrder> =
            serde_json::from_slice(&serde_json::to_vec(&kept).unwrap()).unwrap();
        assert_eq!(ordered(&state, &restored), ordered(&state, &kept));
        state.discord_user = Some("2".into());
        assert_eq!(
            ordered(&state, &kept),
            ["discord:10", "discord:20", "discord:30", "discord:40"]
        );
        state.discord_user = Some("1".into());
        state.servers.push(Arc::new(ChatServer {
            id: "discord:50".into(),
            name: "New".into(),
            ..Default::default()
        }));
        assert_eq!(ordered(&state, &kept).last().unwrap(), "discord:50");
        state.preview = true;
        assert!(!reorder(
            &state,
            &mut kept,
            "discord:10",
            "discord:40",
            false
        ));
    }

    #[test]
    fn server_rail_order_storage_is_bounded_and_rejects_unknown_targets() {
        let state = fixture();
        let mut kept: Vec<KeptOrder> = (0..12)
            .map(|id| KeptOrder {
                account: format!("discord:{id}"),
                items: (0..3000).map(|id| format!("discord:{id}")).collect(),
            })
            .collect();
        tidy(&mut kept);
        assert_eq!(kept.len(), MAX_ACCOUNTS);
        assert!(kept.iter().all(|entry| entry.items.len() == MAX_ITEMS));
        let before = kept.clone();
        assert!(!reorder(
            &state,
            &mut kept,
            "discord:10",
            "not-present",
            true
        ));
        assert_eq!(kept, before);
    }

    #[test]
    fn server_rail_order_real_drag_moves_servers_and_folders_without_navigation() {
        use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
        use slint::platform::{PointerEventButton, WindowEvent};
        use std::ops::ControlFlow;
        slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
            i_slint_backend_testing::TestingBackendOptions {
                mock_time: true,
                threading: false,
                renderer_name: Some("skia".into()),
            },
        )))
        .unwrap();
        let directory = tempfile::tempdir().unwrap();
        let window = yapfast::window().unwrap();
        let adapter = Adapter::new(
            Arc::new(BackgroundRuntime::new().unwrap()),
            directory.path().into(),
            &window,
        )
        .unwrap();
        bind_callbacks(&window, &adapter);
        {
            let mut adapter = adapter.borrow_mut();
            adapter.app.state = fixture();
            adapter
                .layout
                .open_folders
                .insert("discord-folder:7".into());
            adapter.show_sidebar(&window);
        }
        Layout::default().apply_appearance(&window);
        title_bar::show(&window, Some(false));
        window.global::<ClientStyle>().set_interface_motion(false);
        window.set_workspace(true);
        window.set_trusted(true);
        window.show().unwrap();
        window
            .window()
            .set_size(slint::LogicalSize::new(800., 600.));
        let navigated = Rc::new(RefCell::new(0));
        let count = navigated.clone();
        window.on_navigate_server(move |_| *count.borrow_mut() += 1);
        fn settle(window: &YapfastWindow) {
            for _ in 0..3 {
                window.window().take_snapshot().unwrap();
                i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(40));
                slint::platform::update_timers_and_animations();
            }
        }
        fn point(window: &YapfastWindow, name: &str, offset: f32) -> slint::LogicalPosition {
            let inner = i_slint_core::window::WindowInner::from_pub(window.window());
            let item = ItemRc::new_root(inner.component())
                .visit_descendants(|item| {
                    if item.is_visible()
                        && item
                            .accessible_string_property(AccessibleStringProperty::Label)
                            .is_some_and(|label| {
                                label == name
                                    || label.starts_with(&format!("{name}, "))
                                    || label.starts_with(&format!("{name} folder,"))
                            })
                    {
                        ControlFlow::Break(item.clone())
                    } else {
                        ControlFlow::Continue(())
                    }
                })
                .unwrap_or_else(|| panic!("missing rail item {name}"));
            let geometry = item.geometry();
            let point = item.map_to_window(geometry.center());
            slint::LogicalPosition::new(point.x, point.y + offset)
        }
        fn drag(window: &YapfastWindow, from: &str, to: &str, after: bool) {
            let start = point(window, from, 0.);
            let end = point(window, to, if after { 12. } else { -12. });
            window
                .window()
                .dispatch_event(WindowEvent::PointerMoved { position: start });
            window.window().dispatch_event(WindowEvent::PointerPressed {
                position: start,
                button: PointerEventButton::Left,
            });
            window.window().dispatch_event(WindowEvent::PointerMoved {
                position: slint::LogicalPosition::new(start.x, start.y + 7.),
            });
            settle(window);
            window
                .window()
                .dispatch_event(WindowEvent::PointerMoved { position: end });
            settle(window);
            window
                .window()
                .dispatch_event(WindowEvent::PointerReleased {
                    position: end,
                    button: PointerEventButton::Left,
                });
            settle(window);
        }
        let rows = || {
            window
                .get_servers()
                .iter()
                .filter(|row| !row.id.is_empty())
                .map(|row| row.id.to_string())
                .collect::<Vec<_>>()
        };
        settle(&window);
        drag(&window, "Alpha", "Delta", true);
        assert_eq!(
            rows(),
            [
                "discord-folder:7",
                "discord:20",
                "discord:30",
                "discord:40",
                "discord:10"
            ]
        );
        drag(&window, "Tools", "Alpha", true);
        assert_eq!(
            rows(),
            [
                "discord:40",
                "discord:10",
                "discord-folder:7",
                "discord:20",
                "discord:30"
            ]
        );
        drag(&window, "Bravo", "Charlie", true);
        assert_eq!(
            rows(),
            [
                "discord:40",
                "discord:10",
                "discord-folder:7",
                "discord:30",
                "discord:20"
            ]
        );
        assert_eq!(*navigated.borrow(), 0, "dragging never clicks a server");
        let saved = Layout::read(directory.path());
        assert_eq!(
            ordered(&fixture(), &saved.server_orders),
            ["discord:40", "discord:10", "discord:30", "discord:20"]
        );
        // A model/account change while a button is held cancels the old drag.
        let start = point(&window, "Delta", 0.);
        let end = point(&window, "Alpha", 12.);
        window.window().dispatch_event(WindowEvent::PointerPressed {
            position: start,
            button: PointerEventButton::Left,
        });
        window
            .window()
            .dispatch_event(WindowEvent::PointerMoved { position: end });
        settle(&window);
        {
            let mut adapter = adapter.borrow_mut();
            adapter.app.state.discord_user = Some("2".into());
            adapter.sidebar = None;
            adapter.show_sidebar(&window);
        }
        settle(&window);
        window
            .window()
            .dispatch_event(WindowEvent::PointerReleased {
                position: end,
                button: PointerEventButton::Left,
            });
        settle(&window);
        assert_eq!(
            adapter.borrow().layout.server_orders.len(),
            1,
            "old drag cannot write the next account"
        );
        assert_eq!(
            rows(),
            [
                "discord:10",
                "discord-folder:7",
                "discord:20",
                "discord:30",
                "discord:40"
            ]
        );
    }
}
