//! Native preview and editing of a file in the current composer.

use std::{fs::File, io::BufReader};

use image::{ImageEncoder, ImageReader, Rgba, RgbaImage, codecs::png::PngEncoder};
use yapfast_core::application::StagedAttachmentTarget;

use super::*;

const MAX_PIXELS: u64 = 16_000_000;
const PREVIEW_EDGE: u32 = 1536;
const UNDO_BYTES: usize = 48 * 1024 * 1024;
const UNDO_STEPS: usize = 8;
type Point = (f32, f32);
type Segment = (Point, Point);

pub(super) struct Editor {
    target: StagedAttachmentTarget,
    generation: Rc<()>,
    source: Option<Arc<RgbaImage>>,
    current: Option<Arc<RgbaImage>>,
    history: Vec<Arc<RgbaImage>>,
    stroke: Vec<Segment>,
}

pub(super) fn bind(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    let weak = Rc::downgrade(adapter);
    window.on_attachment_tile_action(move |source, index, action| {
        let (Some(adapter), Ok(index)) = (weak.upgrade(), usize::try_from(index)) else {
            return;
        };
        let mut adapter = adapter.borrow_mut();
        let Some(window) = adapter.window.upgrade() else {
            return;
        };
        if !(0..=2).contains(&source) {
            return;
        }
        let Some(target) = adapter.app.staged_attachment_for_edit(source == 1, index) else {
            return;
        };
        let can_spoil = if source == 1 {
            adapter.app.state.aside_can_mark_spoilers()
        } else {
            adapter
                .app
                .state
                .selected_room()
                .is_some_and(|room| room.capabilities.spoilers)
        };
        window.set_attachment_can_spoil(can_spoil);
        match action {
            0 if target.file().image => open(&mut adapter, &window, target, false),
            1 => open(&mut adapter, &window, target, true),
            2 if can_spoil => {
                let file = target.file();
                let (name, description, spoiler) = (
                    file.name.clone(),
                    file.description.clone().unwrap_or_default(),
                    !file.spoiler,
                );
                match adapter.app.save_staged_attachment_edit(
                    &target,
                    name,
                    description,
                    spoiler,
                    None,
                ) {
                    Ok(()) => adapter.refresh(&window),
                    Err(error) => {
                        open(&mut adapter, &window, target, true);
                        window.set_attachment_error(error.into());
                    }
                }
            }
            _ => {}
        }
    });

    let weak = Rc::downgrade(adapter);
    window.on_attachment_action(move |action, name, description, spoiler| {
        let Some(adapter) = weak.upgrade() else {
            return;
        };
        let mut adapter = adapter.borrow_mut();
        let (Some(window), Some(editor)) =
            (adapter.window.upgrade(), &mut adapter.attachment_editor)
        else {
            return;
        };
        if action == 0 {
            close(&mut adapter, &window);
            return;
        }
        if action == 2 {
            window.set_attachment_modify(true);
            return;
        }
        if window.get_attachment_loading() || !window.get_attachment_modify() {
            return;
        }
        match action {
            1 => save(
                &mut adapter,
                &window,
                name.into(),
                description.into(),
                spoiler,
            ),
            3 => {
                if let Some(source) = editor.source.clone() {
                    editor.history.clear();
                    update_image(&mut adapter, &window, move |_| source, false);
                }
            }
            4 => {
                if let Some(previous) = editor.history.pop() {
                    update_image(&mut adapter, &window, move |_| previous, false);
                }
            }
            _ => {}
        }
    });

    let weak = Rc::downgrade(adapter);
    window.on_attachment_edit_region(move |action, x1, y1, x2, y2| {
        let Some(adapter) = weak.upgrade() else {
            return;
        };
        let mut adapter = adapter.borrow_mut();
        let (Some(window), Some(editor)) =
            (adapter.window.upgrade(), &mut adapter.attachment_editor)
        else {
            return;
        };
        if window.get_attachment_loading()
            || !window.get_attachment_modify()
            || editor.current.is_none()
            || ![x1, y1, x2, y2].into_iter().all(f32::is_finite)
        {
            return;
        }
        let segment = (
            (x1.clamp(0., 1.), y1.clamp(0., 1.)),
            (x2.clamp(0., 1.), y2.clamp(0., 1.)),
        );
        match action {
            0 if (x1 - x2).abs() > 0.003 && (y1 - y2).abs() > 0.003 => {
                update_image(
                    &mut adapter,
                    &window,
                    move |image| Arc::new(crop(image, segment)),
                    true,
                );
            }
            1 if editor.stroke.len() < 8192 => editor.stroke.push(segment),
            2 => {
                editor.stroke.clear();
                editor.stroke.push((segment.0, segment.0));
            }
            3 => {
                let mut stroke = std::mem::take(&mut editor.stroke);
                if stroke.is_empty() {
                    stroke.push(segment);
                }
                update_image(
                    &mut adapter,
                    &window,
                    move |image| Arc::new(draw(image, &stroke)),
                    true,
                );
            }
            _ => {}
        }
    });
}

fn open(
    adapter: &mut Adapter,
    window: &YapfastWindow,
    target: StagedAttachmentTarget,
    modify: bool,
) {
    let file = target.file();
    let path = file.image.then(|| file.path.clone());
    window.set_attachment_name(file.name.as_str().into());
    window.set_attachment_description(file.description.as_deref().unwrap_or_default().into());
    window.set_attachment_spoiler(file.spoiler);
    window.set_attachment_error(SharedString::default());
    window.set_attachment_picture(slint::Image::default());
    window.set_attachment_has_picture(false);
    window.set_attachment_edited(false);
    window.set_attachment_can_undo(false);
    window.set_attachment_loading(path.is_some());
    window.set_attachment_modify(modify);
    window.set_attachment_open(true);
    adapter.attachment_editor = Some(Editor {
        target,
        generation: Rc::new(()),
        source: None,
        current: None,
        history: Vec::new(),
        stroke: vec![],
    });
    if let Some(path) = path {
        editor_task(
            adapter,
            move || {
                let image = Arc::new(read(&path)?);
                Ok((image.clone(), preview(&image)))
            },
            |adapter, window, (image, preview)| {
                if let Some(editor) = &mut adapter.attachment_editor {
                    editor.source = Some(image.clone());
                    editor.current = Some(image);
                    show_picture(window, preview);
                }
            },
        );
    }
}

fn close(adapter: &mut Adapter, window: &YapfastWindow) {
    adapter.attachment_editor = None;
    window.set_attachment_open(false);
    window.set_attachment_picture(slint::Image::default());
}

fn update_image(
    adapter: &mut Adapter,
    window: &YapfastWindow,
    edit: impl FnOnce(&RgbaImage) -> Arc<RgbaImage> + Send + 'static,
    remember: bool,
) {
    let Some(original) = adapter
        .attachment_editor
        .as_ref()
        .and_then(|editor| editor.current.clone())
    else {
        return;
    };
    window.set_attachment_loading(true);
    window.set_attachment_error(SharedString::default());
    editor_task(
        adapter,
        move || {
            let edited = edit(&original);
            let preview = preview(&edited);
            Ok((edited, preview))
        },
        move |adapter, window, (edited, preview)| {
            if let Some(editor) = &mut adapter.attachment_editor {
                if let Some(previous) = editor.current.replace(edited.clone())
                    && remember
                {
                    editor.history.push(previous);
                    limit_history(&mut editor.history);
                }
                let edited = editor
                    .source
                    .as_ref()
                    .is_some_and(|source| !Arc::ptr_eq(source, &edited));
                window.set_attachment_edited(edited);
                window.set_attachment_can_undo(!editor.history.is_empty());
                show_picture(window, preview);
            }
        },
    );
}

fn limit_history(history: &mut Vec<Arc<RgbaImage>>) {
    while history.len() > 1
        && (history.len() > UNDO_STEPS
            || history
                .iter()
                .map(|image| image.as_raw().len())
                .sum::<usize>()
                > UNDO_BYTES)
    {
        history.remove(0);
    }
}

fn save(
    adapter: &mut Adapter,
    window: &YapfastWindow,
    name: String,
    description: String,
    spoiler: bool,
) {
    if window.get_attachment_edited()
        && let Some(image) = adapter
            .attachment_editor
            .as_ref()
            .and_then(|editor| editor.current.clone())
    {
        window.set_attachment_loading(true);
        editor_task(
            adapter,
            move || {
                let mut data = Vec::new();
                PngEncoder::new(&mut data)
                    .write_image(
                        &image,
                        image.width(),
                        image.height(),
                        image::ExtendedColorType::Rgba8,
                    )
                    .map_err(|error| format!("Couldn't save the edited image: {error}"))?;
                Ok(data)
            },
            move |adapter, window, data| {
                commit(adapter, window, name, description, spoiler, Some(data))
            },
        );
    } else {
        commit(adapter, window, name, description, spoiler, None);
    }
}

fn commit(
    adapter: &mut Adapter,
    window: &YapfastWindow,
    name: String,
    description: String,
    spoiler: bool,
    data: Option<Vec<u8>>,
) {
    if let Some(editor) = &adapter.attachment_editor {
        match adapter.app.save_staged_attachment_edit(
            &editor.target,
            name,
            description,
            spoiler,
            data,
        ) {
            Ok(()) => {
                close(adapter, window);
                adapter.refresh(window);
            }
            Err(error) => window.set_attachment_error(error.into()),
        }
    }
}

fn editor_task<T: Send + 'static>(
    adapter: &Adapter,
    work: impl FnOnce() -> Result<T, String> + Send + 'static,
    complete: impl FnOnce(&mut Adapter, &YapfastWindow, T) + 'static,
) {
    let Some(editor) = &adapter.attachment_editor else {
        return;
    };
    let generation = editor.generation.clone();
    let weak = adapter.weak.clone();
    let work = adapter.runtime.spawn_blocking(work);
    let task = slint::spawn_local(async move {
        let result = work
            .await
            .unwrap_or_else(|_| Err("Couldn't process the attachment.".into()));
        let Some(adapter) = weak.upgrade() else {
            return;
        };
        let mut adapter = adapter.borrow_mut();
        if !adapter
            .attachment_editor
            .as_ref()
            .is_some_and(|editor| Rc::ptr_eq(&editor.generation, &generation))
        {
            return;
        }
        let Some(window) = adapter.window.upgrade() else {
            return;
        };
        window.set_attachment_loading(false);
        match result {
            Ok(value) => complete(&mut adapter, &window, value),
            Err(error) => window.set_attachment_error(error.into()),
        }
    });
    if let Err(error) = task {
        if let Some(window) = adapter.window.upgrade() {
            window.set_attachment_loading(false);
            window.set_attachment_error("Couldn't start the attachment editor.".into());
        }
        tracing::warn!(%error, "could not start attachment editor");
    }
}

fn read(path: &std::path::Path) -> Result<RgbaImage, String> {
    let failure = |error| format!("Couldn't open the image: {error}");
    let file = File::open(path).map_err(failure)?;
    let mut reader = ImageReader::new(BufReader::new(file))
        .with_guessed_format()
        .map_err(failure)?;
    let mut limits = image::Limits::default();
    limits.max_image_width = Some(8192);
    limits.max_image_height = Some(8192);
    limits.max_alloc = Some(128 * 1024 * 1024);
    reader.limits(limits);
    let decoder = reader
        .into_decoder()
        .map_err(|error| format!("Couldn't open the image: {error}"))?;
    use image::ImageDecoder;
    let (width, height) = decoder.dimensions();
    if u64::from(width) * u64::from(height) > MAX_PIXELS {
        return Err("This image is too large for the attachment editor.".into());
    }
    image::DynamicImage::from_decoder(decoder)
        .map(|image| image.into_rgba8())
        .map_err(|error| format!("Couldn't open the image: {error}"))
}

fn preview(image: &RgbaImage) -> RgbaImage {
    let edge = image.width().max(image.height());
    if edge <= PREVIEW_EDGE {
        return image.clone();
    }
    let scaled =
        |side: u32| ((u64::from(side) * u64::from(PREVIEW_EDGE) / u64::from(edge)) as u32).max(1);
    image::imageops::resize(
        image,
        scaled(image.width()),
        scaled(image.height()),
        image::imageops::FilterType::Triangle,
    )
}

fn show_picture(window: &YapfastWindow, image: RgbaImage) {
    let pixels = slint::SharedPixelBuffer::<slint::Rgba8Pixel>::clone_from_slice(
        image.as_raw(),
        image.width(),
        image.height(),
    );
    window.set_attachment_picture(slint::Image::from_rgba8(pixels));
    window.set_attachment_has_picture(true);
}

fn crop(image: &RgbaImage, ((x1, y1), (x2, y2)): Segment) -> RgbaImage {
    let low = |a: f32, b: f32, pixels: u32| (a.min(b) * pixels as f32).floor() as u32;
    let high = |a: f32, b: f32, pixels: u32| (a.max(b) * pixels as f32).ceil() as u32;
    let left = low(x1, x2, image.width()).min(image.width() - 1);
    let top = low(y1, y2, image.height()).min(image.height() - 1);
    let right = high(x1, x2, image.width()).clamp(left + 1, image.width());
    let bottom = high(y1, y2, image.height()).clamp(top + 1, image.height());
    image::imageops::crop_imm(image, left, top, right - left, bottom - top).to_image()
}

fn draw(image: &RgbaImage, stroke: &[Segment]) -> RgbaImage {
    let mut edited = image.clone();
    let radius = (image.width().min(image.height()) / 160).clamp(2, 20) as i32;
    let width = image.width() as i32;
    let height = image.height() as i32;
    let pixel = |at: f32, side: i32| (at * (side - 1) as f32).round() as i32;
    for &((x1, y1), (x2, y2)) in stroke {
        let (start_x, start_y) = (pixel(x1, width), pixel(y1, height));
        let (dx, dy) = (pixel(x2, width) - start_x, pixel(y2, height) - start_y);
        let steps = ((dx.abs().max(dy.abs()) + radius - 1) / radius).max(1);
        for i in 0..=steps {
            let (center_x, center_y) = (start_x + dx * i / steps, start_y + dy * i / steps);
            for y in (center_y - radius).max(0)..=(center_y + radius).min(height - 1) {
                for x in (center_x - radius).max(0)..=(center_x + radius).min(width - 1) {
                    if (x - center_x).pow(2) + (y - center_y).pow(2) <= radius.pow(2) {
                        edited.put_pixel(x as u32, y as u32, Rgba([255, 84, 96, 255]));
                    }
                }
            }
        }
    }
    edited
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn attachment_undo_is_bounded_and_pops_the_most_recent_states() {
        let mut history = (0..12)
            .map(|value| Arc::new(RgbaImage::from_pixel(1, 1, Rgba([value, 0, 0, 255]))))
            .collect();
        limit_history(&mut history);
        assert_eq!(history.len(), UNDO_STEPS);
        assert_eq!(history.pop().unwrap().get_pixel(0, 0).0[0], 11);
        assert_eq!(history.pop().unwrap().get_pixel(0, 0).0[0], 10);
    }

    #[test]
    fn attachment_crop_uses_full_pixel_coordinates_in_either_drag_direction() {
        let image = RgbaImage::from_fn(8, 4, |x, y| Rgba([x as u8, y as u8, 0, 255]));
        let result = crop(&image, ((0.75, 1.), (0.25, 0.25)));
        assert_eq!(result.dimensions(), (4, 3));
        assert_eq!(*result.get_pixel(0, 0), Rgba([2, 1, 0, 255]));
        assert_eq!(*result.get_pixel(3, 2), Rgba([5, 3, 0, 255]));
    }

    #[test]
    fn attachment_pen_connects_segments_without_changing_original_pixels() {
        let image = RgbaImage::new(20, 20);
        let edited = draw(&image, &[((0., 0.), (0.5, 0.5)), ((0.5, 0.5), (1., 0.5))]);
        assert_eq!(image.get_pixel(10, 10).0, [0; 4]);
        assert_eq!(edited.get_pixel(0, 0).0, [255, 84, 96, 255]);
        assert_eq!(edited.get_pixel(19, 10).0, [255, 84, 96, 255]);
        assert_eq!(edited.get_pixel(0, 19).0, [0; 4]);
    }
}
