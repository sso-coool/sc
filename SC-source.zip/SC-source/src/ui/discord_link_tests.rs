//! Native compact links keep their destination, accessible caption and source.
#![cfg(feature = "discord")]
use super::*;
use i_slint_core::{item_tree::ItemRc, items::StyledTextItem, styled_text::get_raw_text};
use slint::platform::{PointerEventButton, WindowEvent};
use std::ops::ControlFlow;
use yapfast_core::yapfast_discord::{
    marked::MarkedServer,
    ready,
    service::{Snapshot, Status},
};

#[test]
fn card_mentions_native_embed_fields_and_component_blocks_keep_click_targets() {
    use yapfast_core::{
        chat::{Card, CardRow, Embed, EmbedField},
        mention::{Mentioned, Target},
    };
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let window = yapfast::window().unwrap();
    window.set_workspace(true);
    window.set_room_selected(true);
    window.set_room_ready(true);
    window.set_trusted(true);
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<PictureStore>().on_request(|_| {});
    let opened = Rc::new(RefCell::new(Vec::<String>::new()));
    let clicks = opened.clone();
    window.on_open_link(move |link| clicks.borrow_mut().push(link.to_string()));
    window.show().unwrap();
    window
        .window()
        .set_size(slint::LogicalSize::new(800., 600.));
    let mentions = |text: &str| {
        [
            ("@Member", Target::User("2".into())),
            ("#ticket", Target::Channel("discord:10:30".into())),
        ]
        .into_iter()
        .filter_map(|(caption, target)| {
            text.find(caption).map(|at| Mentioned {
                text: caption.into(),
                target,
                color: None,
                at: vec![at],
            })
        })
        .collect::<Vec<_>>()
    };
    for case in 0..6 {
        let text = match case {
            1 => "## Route\n> @Member in #ticket",
            3 => "### Route\n@Member in #ticket",
            5 => "```text\n@Member in #ticket\n```",
            _ => "@Member in #ticket",
        };
        let tagged = if case == 4 { vec![] } else { mentions(text) };
        let mut message = ChatMessage {
            item: format!("card:{case}"),
            author: "Bot".into(),
            bot: true,
            ..Default::default()
        };
        match case {
            2 => message.embeds.push(Embed {
                fields: vec![EmbedField {
                    name: "#ticket".into(),
                    name_mentions: mentions("#ticket"),
                    value: "> @Member".into(),
                    mentions: mentions("> @Member"),
                    ..Default::default()
                }],
                ..Default::default()
            }),
            3 | 5 => message.cards.push(Card {
                rows: vec![CardRow::Text {
                    text: text.into(),
                    mentions: tagged,
                    beside: None,
                }],
                ..Default::default()
            }),
            _ => message.embeds.push(Embed {
                description: text.into(),
                description_mentions: tagged,
                ..Default::default()
            }),
        }
        window.set_messages(ModelRc::new(VecModel::from(vec![message_row(
            &message,
            &HashSet::new(),
        )])));
        let _ = window.window().take_snapshot().unwrap();
        i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(300));
        slint::platform::update_timers_and_animations();
        let _ = window.window().take_snapshot().unwrap();
        let inner = i_slint_core::window::WindowInner::from_pub(window.window());
        let mut items = vec![];
        let _: Option<()> = ItemRc::new_root(inner.component()).visit_descendants(|item| {
            if item.is_visible()
                && item.downcast::<StyledTextItem>().is_some_and(|text| {
                    let styled = StyledTextItem::FIELD_OFFSETS
                        .text()
                        .apply_pin(text.as_pin_ref());
                    let rendered = styled.get();
                    let raw = get_raw_text(&rendered);
                    raw.contains("@Member") || raw.contains("#ticket")
                })
            {
                items.push(item.clone());
            }
            ControlFlow::Continue(())
        });
        assert!(!items.is_empty(), "mention text renders in case {case}");
        let mut found = std::collections::BTreeMap::new();
        for item in items {
            let geometry = item.geometry();
            let at = item.map_to_window(geometry.origin);
            for y in (4..geometry.height().max(5.) as i32).step_by(6) {
                for x in (4..geometry.width().min(400.).max(5.) as i32).step_by(6) {
                    let position = slint::LogicalPosition::new(at.x + x as f32, at.y + y as f32);
                    window
                        .window()
                        .dispatch_event(WindowEvent::PointerMoved { position });
                    window.window().dispatch_event(WindowEvent::PointerPressed {
                        position,
                        button: PointerEventButton::Right,
                    });
                    if let Some(link) = i_slint_core::yapfast_selection::pressed_link_at(
                        i_slint_core::lengths::LogicalPoint::new(position.x, position.y),
                    ) {
                        found.entry(link.to_string()).or_insert(position);
                    }
                    window
                        .window()
                        .dispatch_event(WindowEvent::PointerReleased {
                            position,
                            button: PointerEventButton::Right,
                        });
                    inner.close_all_popups();
                }
            }
        }
        if case == 4 || case == 5 {
            assert!(
                found.is_empty(),
                "literal names and fenced code stay unlinked: {case}"
            );
        } else {
            for link in ["yapfast:user/2", "yapfast:channel/discord:10:30"] {
                let position = *found
                    .get(link)
                    .unwrap_or_else(|| panic!("missing {link} in case {case}: {found:?}"));
                let before = opened.borrow().len();
                i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(600));
                slint::platform::update_timers_and_animations();
                window.window().dispatch_event(WindowEvent::PointerPressed {
                    position,
                    button: PointerEventButton::Left,
                });
                window
                    .window()
                    .dispatch_event(WindowEvent::PointerReleased {
                        position,
                        button: PointerEventButton::Left,
                    });
                assert_eq!(opened.borrow().len(), before + 1, "case {case}: {link}");
                assert_eq!(opened.borrow().last().map(String::as_str), Some(link));
            }
        }
    }
    window.hide().unwrap();
}

fn app() -> Application {
    let mut app = Application::default();
    let server = ready::server(&serde_json::json!({
        "id":"10", "owner_id":"1", "properties":{"name":"Example server"},
        "roles":[{"id":"10","permissions":"66560"}],
        "channels":[{"id":"21","type":0,"name":"general"}]
    }))
    .unwrap();
    app.apply(Event::Discord(Arc::new(Snapshot {
        status: Status::Online,
        user_id: Some("1".into()),
        servers: vec![MarkedServer::from(server)],
        ..Default::default()
    })));
    app
}

#[test]
fn discord_pills_native_body_and_embed_preserve_click_and_copy_link_targets() {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let window = yapfast::window().unwrap();
    window.set_workspace(true);
    window.set_room_selected(true);
    window.set_room_ready(true);
    window.set_trusted(true);
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<PictureStore>().on_request(|_| {});
    let channel = "https://discord.com/channels/10/21";
    let jump = "https://discord.com/channels/10/21/100?jump=1#reply";
    let message = ChatMessage {
        item: "review:jump-link".into(),
        author: "Example bot".into(),
        sender: "review:bot".into(),
        bot: true,
        formatted: true,
        body: channel.into(),
        embeds: vec![yapfast_core::chat::Embed {
            description: jump.into(),
            ..Default::default()
        }],
        ..Default::default()
    };
    let app = app();
    let row = message_row_in(Some(&app.state), &message, &HashSet::new(), None);
    assert_eq!(message.body, channel);
    assert_eq!(message.embeds[0].description, jump);
    window.set_messages(ModelRc::new(VecModel::from(vec![row])));
    let opened = Rc::new(RefCell::new(Vec::new()));
    let output = opened.clone();
    window.on_open_link(move |link| output.borrow_mut().push(link.to_string()));
    window
        .window()
        .set_size(slint::LogicalSize::new(800., 600.));
    window.show().unwrap();
    window.window().take_snapshot().unwrap();
    i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(300));
    slint::platform::update_timers_and_animations();
    window.window().take_snapshot().unwrap();
    for (caption, destination) in [("#general", channel), ("Example server › ↗ Message", jump)]
    {
        let inner = i_slint_core::window::WindowInner::from_pub(window.window());
        let item = ItemRc::new_root(inner.component())
            .visit_descendants(|item| {
                if item.is_visible()
                    && item.downcast::<StyledTextItem>().is_some_and(|text| {
                        let styled = StyledTextItem::FIELD_OFFSETS
                            .text()
                            .apply_pin(text.as_pin_ref());
                        get_raw_text(&styled.get()) == caption
                    })
                {
                    ControlFlow::Break(item.clone())
                } else {
                    ControlFlow::Continue(())
                }
            })
            .unwrap_or_else(|| panic!("missing rendered compact link: {caption}"));
        // A StyledText fills its column; target the start of its actual first line.
        let at = item.map_to_window(item.geometry().origin);
        let geometry = item.geometry();
        let mut hit = None;
        for y in [0.5, 0.3, 0.7] {
            for x in [8., 16., 28., 40.] {
                let position = slint::LogicalPosition::new(at.x + x, at.y + geometry.height() * y);
                window
                    .window()
                    .dispatch_event(WindowEvent::PointerMoved { position });
                window.window().dispatch_event(WindowEvent::PointerPressed {
                    position,
                    button: PointerEventButton::Right,
                });
                let copied = i_slint_core::yapfast_selection::pressed_link_at(
                    i_slint_core::lengths::LogicalPoint::new(position.x, position.y),
                );
                window
                    .window()
                    .dispatch_event(WindowEvent::PointerReleased {
                        position,
                        button: PointerEventButton::Right,
                    });
                inner.close_all_popups();
                if copied.as_deref() == Some(destination) {
                    hit = Some(position);
                    break;
                }
            }
            if hit.is_some() {
                break;
            }
        }
        let position = hit.unwrap_or_else(|| {
            panic!("missing copyable link in {caption} at {at:?}, {geometry:?}")
        });
        let previous_count = opened.borrow().len();
        i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(600));
        slint::platform::update_timers_and_animations();
        window
            .window()
            .dispatch_event(WindowEvent::PointerMoved { position });
        window.window().dispatch_event(WindowEvent::PointerPressed {
            position,
            button: PointerEventButton::Left,
        });
        window
            .window()
            .dispatch_event(WindowEvent::PointerReleased {
                position,
                button: PointerEventButton::Left,
            });
        assert_eq!(opened.borrow().len(), previous_count + 1, "click {caption}");
        assert_eq!(
            opened.borrow().last().map(String::as_str),
            Some(destination)
        );
        i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(600));
        slint::platform::update_timers_and_animations();
    }
    if let Some(dir) = std::env::var_os("SC_REVIEW_DIR") {
        let frame = window.window().take_snapshot().unwrap();
        std::fs::create_dir_all(&dir).unwrap();
        image::save_buffer(
            std::path::Path::new(&dir).join("discord-link-pills800.png"),
            frame.as_bytes(),
            frame.width(),
            frame.height(),
            image::ColorType::Rgba8,
        )
        .unwrap();
    }
    window.hide().unwrap();
}

#[test]
fn discord_pills_unknown_locked_and_long_names_remain_safe() {
    i_slint_backend_testing::init_no_event_loop();
    let _window = yapfast::window().unwrap();
    let mut app = app();
    let message = ChatMessage {
        formatted: true,
        body: "<https://discord.com/channels/10/21/100>".into(),
        ..Default::default()
    };
    let text = |state: &AppState| {
        let row = message_row_in(Some(state), &message, &HashSet::new(), None);
        i_slint_core::styled_text::get_raw_text(&row.styled).into_owned()
    };
    assert_eq!(text(&app.state), "Example server › ↗ Message");
    Arc::make_mut(&mut app.state.servers[0]).name = "x".repeat(500);
    assert!(text(&app.state).chars().count() <= 45);
    Arc::make_mut(&mut app.state.rooms[0]).locked = true;
    assert_eq!(text(&app.state), "↗ Message");
    assert_eq!(text(&AppState::default()), "↗ Message");
}
