//! Profile effects use synthetic pixels and native pointer events, never a CDN.
use super::*;
use i_slint_core::{accessibility::AccessibleStringProperty, item_tree::ItemRc};
use slint::platform::WindowEvent;
use std::ops::ControlFlow;

fn image(color: [u8; 3]) -> slint::Image {
    let mut pixels = slint::SharedPixelBuffer::<slint::Rgba8Pixel>::new(64, 160);
    pixels
        .make_mut_slice()
        .fill(slint::Rgba8Pixel::new(color[0], color[1], color[2], 255));
    slint::Image::from_rgba8(pixels)
}

fn fixture() -> YapfastWindow {
    slint::platform::set_platform(Box::new(i_slint_backend_testing::TestingBackend::new(
        i_slint_backend_testing::TestingBackendOptions {
            mock_time: true,
            threading: false,
            renderer_name: Some("skia".into()),
        },
    )))
    .unwrap();
    let window = yapfast::window().unwrap();
    Layout::default().apply_appearance(&window);
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<Motion>().set_playing(true);
    window.global::<Motion>().set_never(false);
    window.global::<PictureStore>().on_request(|_| {});
    window.global::<PictureStore>().on_animated(|url| url);
    window
        .global::<PictureStore>()
        .on_picture(|url, _| match url.as_str() {
            "test:effect" => image([240, 16, 32]),
            "test:still" => image([16, 32, 240]),
            _ => slint::Image::default(),
        });
    window.global::<PictureStore>().on_frames(|url, _| {
        if url == "test:effect" {
            ModelRc::new(VecModel::from(vec![
                image([240, 16, 32]),
                image([16, 240, 32]),
            ]))
        } else {
            ModelRc::default()
        }
    });
    window
        .global::<PictureStore>()
        .on_delays(|_, _| ModelRc::new(VecModel::from(vec![41, 41])));
    window.global::<PictureStore>().on_plays(|_, _| 0);
    window.on_profile_tab_opened(|_| {});
    window.set_workspace(true);
    window.set_trusted(true);
    window.set_profile(ProfileData {
        id: "900".into(),
        name: "Effect test".into(),
        initial: "E".into(),
        effect_still: "test:still".into(),
        effect_end: 205,
        effect_loops: true,
        effect_layers: ModelRc::new(VecModel::from(vec![EffectLayer {
            url: "test:effect".into(),
            duration: 205,
            looped: true,
            ..Default::default()
        }])),
        ..Default::default()
    });
    window.set_profile_open(true);
    window.show().unwrap();
    window
        .window()
        .set_size(slint::LogicalSize::new(1120., 760.));
    window
}

fn advance(window: &YapfastWindow, ticks: usize) {
    for _ in 0..ticks {
        i_slint_backend_testing::mock_elapsed_time(Duration::from_millis(42));
        slint::platform::update_timers_and_animations();
        let _ = window.window().take_snapshot().unwrap();
    }
}

#[track_caller]
fn assert_color(window: &YapfastWindow, channel: usize) {
    let frame = window.window().take_snapshot().unwrap();
    let colored = frame
        .as_bytes()
        .chunks_exact(4)
        .filter(|pixel| {
            pixel[channel] > 220
                && (0..3)
                    .filter(|&other| other != channel)
                    .all(|other| pixel[other] < 45)
        })
        .count();
    assert!(
        colored > 10_000,
        "effect channel {channel} must be visible; found {colored} pixels"
    );
}

fn hover(window: &YapfastWindow) {
    let inner = i_slint_core::window::WindowInner::from_pub(window.window());
    let item = ItemRc::new_root(inner.component())
        .visit_descendants(|item| {
            if item.is_visible()
                && item
                    .accessible_string_property(AccessibleStringProperty::Label)
                    .as_deref()
                    == Some("Effect test's profile")
            {
                ControlFlow::Break(item.clone())
            } else {
                ControlFlow::Continue(())
            }
        })
        .expect("profile card is visible");
    let point = item.map_to_window(item.geometry().center());
    window.window().dispatch_event(WindowEvent::PointerMoved {
        position: slint::LogicalPosition::new(point.x, point.y),
    });
}

#[test]
fn profile_effect_plays_once_on_open_not_hover_and_reopens_for_a_fresh_pass() {
    let window = fixture();
    assert_color(&window, 0); // Opening plays without the pointer ever entering.
    advance(&window, 3);
    assert_color(&window, 1); // An infinitely looping APNG holds its final frame.
    advance(&window, 4);
    assert_color(&window, 2); // Even a looping layer ends at its first-pass duration.
    for _ in 0..3 {
        hover(&window);
        advance(&window, 1);
        assert_color(&window, 2);
        window.window().dispatch_event(WindowEvent::PointerExited);
        advance(&window, 1);
        assert_color(&window, 2);
    }
    // Updating other profile fields keeps the same layers and does not replay.
    let mut profile = window.get_profile();
    profile.pronouns = "they/them".into();
    window.set_profile(profile);
    assert_color(&window, 2);
    // Explicitly closing and reopening, including during popup lifetime, replays.
    window.set_profile_open(false);
    let _ = window.window().take_snapshot().unwrap();
    window.set_profile_open(true);
    assert_color(&window, 0);
    advance(&window, 7);
    assert_color(&window, 2);
    let mut profile = window.get_profile();
    profile.id = "901".into();
    window.set_profile(profile);
    assert_color(&window, 0);
    window.hide().unwrap();
}

#[test]
fn profile_effect_full_profile_obeys_motion_and_finishes_after_resuming() {
    let window = fixture();
    window.set_profile_large(true);
    assert_color(&window, 0);
    window.global::<Motion>().set_playing(false);
    advance(&window, 8);
    assert_color(&window, 2);
    window.global::<Motion>().set_playing(true);
    assert_color(&window, 0);
    advance(&window, 8);
    assert_color(&window, 2);
    window.global::<Motion>().set_playing(false);
    window.global::<Motion>().set_playing(true);
    hover(&window);
    assert_color(&window, 2);
    window.hide().unwrap();
}

#[cfg(feature = "discord")]
#[test]
fn profile_editor_context_keeps_the_card_server_and_global_entry_separate() {
    use slint::platform::PointerEventButton;
    use yapfast_core::yapfast_discord::{
        marked::MarkedServer,
        ready::{self, permission},
        service::{Snapshot, Status},
    };
    let window = fixture();
    let directory = tempfile::tempdir().unwrap();
    let adapter = Adapter::new(
        Arc::new(BackgroundRuntime::new().unwrap()),
        directory.path().into(),
        &window,
    )
    .unwrap();
    bind_callbacks(&window, &adapter);
    window.global::<ClientStyle>().set_interface_motion(false);
    window.global::<PictureStore>().on_request(|_| {});
    let commands = Rc::new(RefCell::new(vec![]));
    {
        let mut adapter = adapter.borrow_mut();
        adapter.backend_commands = Some(commands.clone());
        let server = |id: &str, channel: &str| {
            MarkedServer::from(ready::server(&serde_json::json!({
            "id": id, "owner_id": "1", "properties": {"name": format!("Server {id}")},
            "roles": [{"id": id, "name": "@everyone", "permissions": (permission::VIEW_CHANNEL | permission::READ_MESSAGE_HISTORY | permission::CHANGE_NICKNAME).to_string()}],
            "channels": [{"id": channel, "type": 0, "name": "general"}]
        })).unwrap())
        };
        adapter.app.apply(Event::Discord(Arc::new(Snapshot {
            status: Status::Online,
            user_id: Some("1".into()),
            servers: vec![server("10", "11"), server("20", "21")],
            ..Default::default()
        })));
        adapter
            .app
            .dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
        adapter
            .app
            .dispatch(Action::SelectRoom("discord:10:11".into()));
        adapter.app.dispatch(Action::ShowProfile {
            user: "1".into(),
            large: false,
        });
        assert_eq!(
            adapter
                .app
                .state
                .profile
                .as_ref()
                .unwrap()
                .context_room
                .as_deref(),
            Some("discord:10:11")
        );
        // A retained card must never silently retarget the newly selected server.
        adapter.app.state.selected = Some("discord:20:21".into());
        adapter.refresh(&window);
    }
    window.set_workspace(true);
    window.set_trusted(true);
    assert_eq!(window.get_profile().edit_server, "discord:10");
    let click = |label: &str| {
        let _ = window.window().take_snapshot().unwrap();
        let inner = i_slint_core::window::WindowInner::from_pub(window.window());
        let item = ItemRc::new_root(inner.component())
            .visit_descendants(|item| {
                if item.is_visible()
                    && item
                        .accessible_string_property(AccessibleStringProperty::Label)
                        .as_deref()
                        == Some(label)
                {
                    ControlFlow::Break(item.clone())
                } else {
                    ControlFlow::Continue(())
                }
            })
            .unwrap_or_else(|| panic!("missing profile action: {label}"));
        let point = item.map_to_window(item.geometry().center());
        let position = slint::LogicalPosition::new(point.x, point.y);
        window
            .window()
            .dispatch_event(WindowEvent::PointerMoved { position });
        window.window().dispatch_event(WindowEvent::PointerPressed {
            position,
            button: PointerEventButton::Left,
        });
        window
            .window()
            .dispatch_event(WindowEvent::PointerReleased {
                position,
                button: PointerEventButton::Left,
            });
    };
    click("Edit Server Profile");
    {
        let adapter = adapter.borrow();
        let editor = adapter
            .app
            .state
            .profile_editor
            .as_ref()
            .expect("server editor opened");
        assert_eq!(editor.server.as_deref(), Some("discord:10"));
        assert!(!editor.saving, "opening an editor never submits changes");
        assert!(commands.borrow().iter().any(|command| matches!(command,
            Command::Discord(yapfast_core::chat::DiscordCommand::OwnProfile { server: Some(server) }) if server == "discord:10"
        )));
    }
    {
        let mut adapter = adapter.borrow_mut();
        adapter.app.dispatch(Action::CloseProfileEditor);
        adapter.app.state.profile = Some(yapfast_core::application::ProfileView {
            profile: yapfast_core::chat::Profile {
                id: "1".into(),
                name: "Own profile".into(),
                ..Default::default()
            },
            context_room: Some("discord:@me:99".into()),
            ..Default::default()
        });
        adapter.refresh(&window);
    }
    window.set_workspace(true);
    window.set_trusted(true);
    assert!(window.get_profile().edit_server.is_empty());
    click("Edit Profile");
    let adapter = adapter.borrow();
    let editor = adapter
        .app
        .state
        .profile_editor
        .as_ref()
        .expect("main editor opened");
    assert!(editor.server.is_none());
    assert!(!editor.saving);
    assert!(commands.borrow().iter().any(|command| matches!(
        command,
        Command::Discord(yapfast_core::chat::DiscordCommand::OwnProfile { server: None })
    )));
    window.hide().unwrap();
}
