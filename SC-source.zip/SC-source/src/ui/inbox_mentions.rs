//! Discord's recent mentions in the desktop Inbox.

use super::*;
use yapfast_core::chat::SearchHit;

pub(super) fn bind(window: &YapfastWindow, adapter: &Rc<RefCell<Adapter>>) {
    let controls = window.global::<InboxMentions>();
    let state = adapter.clone();
    let weak = window.as_weak();
    controls.on_load(move || {
        if let Some(window) = weak.upgrade() {
            load(&mut state.borrow_mut(), &window);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    controls.on_load_more(move || {
        if let Some(window) = weak.upgrade().filter(is_open) {
            state
                .borrow_mut()
                .action(&window, Action::MoreInboxMentions);
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    controls.on_jump(move |room, item| {
        let Some(window) = weak.upgrade().filter(is_open) else {
            return;
        };
        let mut adapter = state.borrow_mut();
        if can_jump(&adapter.app.state, &room, &item) {
            window.set_inbox_open(false);
            adapter.action(
                &window,
                Action::JumpInRoom {
                    room: room.into(),
                    item: item.into(),
                },
            );
        }
    });
    let state = adapter.clone();
    let weak = window.as_weak();
    controls.on_dismiss(move |item| {
        if let Some(window) = weak.upgrade().filter(is_open) {
            state
                .borrow_mut()
                .action(&window, Action::DismissInboxMention(item.into()));
        }
    });
}

fn is_open(window: &YapfastWindow) -> bool {
    window.get_inbox_open() && window.get_inbox_tab() == 1
}

fn current_server(state: &AppState) -> Option<&str> {
    match &state.navigation {
        Navigation::Server(id) if discord::parse_server(id).is_some() => Some(id),
        _ => None,
    }
}

pub(super) fn load(adapter: &mut Adapter, window: &YapfastWindow) {
    let state = &adapter.app.state;
    if is_open(window) && !state.preview && state.discord_user.is_some() {
        let controls = window.global::<InboxMentions>();
        let guild = if controls.get_include_all_servers() {
            None
        } else {
            current_server(state).map(str::to_owned)
        };
        adapter.action(
            window,
            Action::LoadInboxMentions {
                include_everyone: controls.get_include_everyone(),
                include_roles: controls.get_include_roles(),
                guild,
            },
        );
    } else {
        adapter.refresh(window);
    }
}

fn can_jump(state: &AppState, room: &str, item: &str) -> bool {
    state.inbox_mentions_available()
        && state.inbox_mentions.messages.iter().any(|hit| {
            hit.room == room && hit.message.item == item && state.inbox_mention_visible(hit)
        })
}

pub(super) fn show(adapter: &mut Adapter, window: &YapfastWindow) {
    let state = &adapter.app.state;
    let controls = window.global::<InboxMentions>();
    let available = !state.preview && state.discord_user.is_some();
    controls.set_available(available);
    controls.set_current_server(current_server(state).is_some());
    if !is_open(window) || !available {
        update_model(&adapter.models.inbox_mentions, Vec::new());
        return;
    }

    let inbox = &state.inbox_mentions;
    let online = state.inbox_mentions_available();
    controls.set_loading(online && inbox.loading);
    controls.set_more(online && inbox.has_more);
    controls.set_error(if online {
        inbox.error.as_deref().unwrap_or_default().into()
    } else {
        "Reconnect to Discord to see your mentions.".into()
    });
    let mut previous_room: Option<&str> = None;
    let rows = inbox
        .messages
        .iter()
        .filter(|hit| online && state.inbox_mention_visible(hit))
        .map(|hit| {
            let starts_channel = previous_room != Some(hit.room.as_str());
            previous_room = Some(&hit.room);
            mention_row(state, hit, starts_channel, adapter.layout.twelve_hour_clock)
        })
        .collect();
    update_model(&adapter.models.inbox_mentions, rows);
}

fn mention_row(
    state: &AppState,
    hit: &SearchHit,
    starts_channel: bool,
    twelve_hour: bool,
) -> InboxMentionRow {
    let room = state.rooms.iter().find(|room| room.id == hit.room);
    let guild = discord::parse_room(&hit.room)
        .map(|(guild, _)| guild)
        .unwrap_or(discord::DM_GUILD);
    let direct = guild == discord::DM_GUILD;
    let server = (!direct)
        .then(|| discord::server_id(guild))
        .and_then(|id| state.servers.iter().find(|server| server.id == id));
    let channel = match room {
        Some(room) if room.direct => room.name.clone(),
        Some(room) => format!("#{}", room.name),
        None if direct => "Direct Message".into(),
        None => "Thread or channel".into(),
    };
    let place = server.map_or("", |server| server.name.as_str());
    let icon = room
        .filter(|room| room.direct)
        .and_then(|room| room.avatar.as_deref())
        .or_else(|| server.and_then(|server| server.icon.as_deref()))
        .unwrap_or_default();
    // The Inbox can be narrower than the search sidebar, beside the avatar.
    let mut found = inbox_found_row(&hit.message, twelve_hour, 230);
    found.room = hit.room.as_str().into();
    InboxMentionRow {
        found,
        channel: channel.as_str().into(),
        server: place.into(),
        server_icon: icon.into(),
        server_initial: initial(if direct { &channel } else { place }),
        server_tint: tint(server.map_or(hit.room.as_str(), |server| server.id.as_str())),
        starts_channel,
        dismissing: state
            .inbox_mentions
            .dismissing
            .contains_key(&hit.message.item),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use i_slint_core::styled_text::get_raw_text;
    use yapfast_core::chat::Embed;

    #[test]
    fn inbox_row_keeps_exact_route_and_hides_spoiler_text_in_a_card() {
        let state = Application::default().state;
        let hit = SearchHit {
            room: "discord:101:202".into(),
            message: ChatMessage {
                id: "d:303".into(),
                item: "d:303".into(),
                author: "Sender".into(),
                embeds: vec![Embed {
                    description: "Look here ||classified||.".into(),
                    ..Default::default()
                }],
                ..Default::default()
            },
        };
        let row = mention_row(&state, &hit, true, false);
        assert_eq!(row.found.room, "discord:101:202");
        assert_eq!(row.found.item, "d:303");
        assert_eq!(row.found.author, "Sender");
        assert!(row.found.has_body);
        let text = get_raw_text(&row.found.styled);
        assert!(text.contains("Look here"));
        assert!(!text.contains("classified"));
    }
}
