//! The Windows release channel. Checking is read-only; only a user action
//! starts the embedded bootstrapper and asks the running client to exit.
use std::path::Path;

const API: &str = "https://api.github.com/repos/sso-coool/sc/releases/latest";
pub const RELEASES: &str = "https://github.com/sso-coool/sc/releases";
const ZIP: &str = "SC-windows-x64.zip";

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Release {
    pub tag: String,
    pub notes: String,
    pub bytes: u64,
}

fn version(tag: &str) -> Option<[u16; 4]> {
    let mut fields = tag.strip_prefix('v').unwrap_or(tag).split('.');
    let mut next = || {
        let part = fields.next()?;
        if part.is_empty()
            || !part.bytes().all(|b| b.is_ascii_digit())
            || (part.len() > 1 && part.starts_with('0'))
        {
            return None;
        }
        part.parse().ok()
    };
    let version = [next()?, next()?, next()?, next()?];
    fields.next().is_none().then_some(version)
}

fn offer(body: &[u8], installed: [u16; 4]) -> Result<Option<Release>, String> {
    #[derive(serde::Deserialize)]
    struct ListedRelease {
        tag_name: String,
        draft: bool,
        prerelease: bool,
        body: Option<String>,
        assets: Vec<Asset>,
    }
    #[derive(serde::Deserialize)]
    struct Asset {
        name: String,
        browser_download_url: String,
        state: String,
        size: u64,
        digest: Option<String>,
    }
    let listed: ListedRelease = serde_json::from_slice(body)
        .map_err(|_| "GitHub returned unreadable release information.")?;
    if listed.draft || listed.prerelease {
        return Ok(None);
    }
    let tag = listed.tag_name;
    let Some(newest) = version(&tag) else {
        return Err("GitHub's latest release needs a four-part S;C version.".into());
    };
    if newest <= installed {
        return Ok(None);
    }
    let expected = |name: &str| format!("{RELEASES}/download/{tag}/{name}");
    let uploaded = |name: &str| {
        let mut matching = listed.assets.iter().filter(|asset| asset.name == name);
        let asset = matching.next()?;
        (matching.next().is_none()
            && asset.state == "uploaded"
            && asset.size > 0
            && asset.browser_download_url == expected(name))
        .then_some(asset)
    };
    let bytes = uploaded(ZIP)
        .filter(|asset| {
            asset.size <= (1 << 30)
                && (asset
                    .digest
                    .as_deref()
                    .and_then(|d| d.strip_prefix("sha256:"))
                    .is_some_and(|hash| {
                        hash.len() == 64 && hash.bytes().all(|b| b.is_ascii_hexdigit())
                    })
                    || uploaded("SC-SHA256SUMS.txt").is_some())
        })
        .map_or(0, |asset| asset.size);
    if bytes == 0 {
        return Err("The latest release is missing a verified Windows package.".into());
    }
    Ok(Some(Release {
        tag,
        bytes,
        notes: listed.body.unwrap_or_default().chars().take(4000).collect(),
    }))
}

pub async fn check() -> Result<Option<Release>, String> {
    let installed = version(crate::build_info::current().version())
        .ok_or("This build doesn't have a Windows release version.")?;
    let _ = rustls::crypto::aws_lc_rs::default_provider().install_default();
    let client = reqwest::Client::builder()
        .user_agent("SC-Desktop-Updater/1")
        .https_only(true)
        .redirect(reqwest::redirect::Policy::none())
        .timeout(std::time::Duration::from_secs(20))
        .build()
        .map_err(|_| "Couldn't start the update check.")?;
    let mut response = client
        .get(API)
        .header("Accept", "application/vnd.github+json")
        .send()
        .await
        .and_then(|response| response.error_for_status())
        .map_err(|_| "Couldn't reach S;C releases on GitHub. Try again later.")?;
    let mut body = Vec::new();
    while let Some(chunk) = response
        .chunk()
        .await
        .map_err(|_| "Couldn't read release information.")?
    {
        if body.len() + chunk.len() > 512 * 1024 {
            return Err("GitHub returned too much release information.".into());
        }
        body.extend_from_slice(&chunk);
    }
    offer(&body, installed)
}

pub fn page(release: &Release) -> String {
    format!("{RELEASES}/tag/{}", release.tag)
}

fn within(path: &Path, dir: &Path) -> bool {
    // Windows paths may differ in ASCII case; compare components, so SC2
    // doesn't count as a child of SC. The helper validates again on Windows.
    let mut parts = path.components();
    dir.components().all(|parent| {
        parts
            .next()
            .is_some_and(|part| part.as_os_str().eq_ignore_ascii_case(parent.as_os_str()))
    })
}

pub fn install_directory(profile: &Path) -> Result<std::path::PathBuf, String> {
    if !cfg!(all(windows, target_arch = "x86_64")) {
        return Err("Use the release page on this platform.".into());
    }
    let exe = std::env::current_exe().map_err(|_| "Couldn't find the S;C executable.")?;
    let dir = exe
        .parent()
        .ok_or("Couldn't find the S;C installation folder.")?;
    if !exe
        .file_name()
        .is_some_and(|name| name.eq_ignore_ascii_case("SC.exe"))
        || !dir.join("BUILD.json").is_file()
    {
        return Err("This copy can be updated from the release page.".into());
    }
    let own_files = [
        "SC.exe",
        "BUILD.json",
        "SC.ico",
        "LICENSE.txt",
        "THIRD-PARTY.json",
        "SOURCE.txt",
        "README.txt",
        "SC-INSTALL.json",
        "licenses",
    ];
    if !dir
        .read_dir()
        .map_err(|_| "Couldn't read the S;C folder.")?
        .all(|entry| {
            entry.is_ok_and(|entry| {
                let name = entry.file_name();
                own_files
                    .iter()
                    .any(|known| name.eq_ignore_ascii_case(known))
                    || (name.eq_ignore_ascii_case("vencord-companion")
                        && entry.file_type().is_ok_and(|kind| kind.is_dir()))
            })
        })
    {
        return Err("Keep S;C in its own folder, or update from the release page.".into());
    }
    let resolved_dir = dir
        .canonicalize()
        .map_err(|_| "Couldn't open the S;C folder.")?;
    let resolved_profile = profile
        .canonicalize()
        .map_err(|_| "Couldn't open the S;C profile folder.")?;
    if within(&resolved_profile, &resolved_dir) {
        return Err(
            "This profile is inside the app folder. Use the release page to update safely.".into(),
        );
    }
    Ok(dir.to_path_buf())
}

pub struct Prepared {
    #[cfg(windows)]
    child: std::process::Child,
    #[cfg(windows)]
    scratch: tempfile::TempDir,
    #[cfg(windows)]
    _output: std::io::BufReader<std::process::ChildStdout>,
}

impl Prepared {
    pub fn finish(self) -> std::io::Result<()> {
        #[cfg(windows)]
        {
            use std::io::Write;
            let Self {
                mut child,
                scratch,
                _output,
            } = self;
            child
                .stdin
                .take()
                .ok_or_else(|| std::io::Error::other("Updater closed its input"))?
                .write_all(b"SC-UPDATE-COMMIT\r\n")?;
            // The helper now owns cleanup; it runs after this app exits.
            let _ = scratch.keep();
        }
        Ok(())
    }
}

pub fn stage(tag: &str, profile: &Path) -> Result<Prepared, String> {
    #[cfg(not(windows))]
    {
        let _ = (tag, profile);
        Err("Use the release page on this platform.".into())
    }
    #[cfg(windows)]
    {
        use std::{
            io::{BufRead, BufReader},
            os::windows::process::CommandExt,
            process::{Command, Stdio},
        };
        let dir = install_directory(profile)?;
        let fail = |_: std::io::Error| "Couldn't start the S;C update helper.";
        let scratch = tempfile::Builder::new()
            .prefix("sc-app-update-")
            .tempdir()
            .map_err(fail)?;
        let script = scratch.path().join("Invoke-SCAppUpdate.ps1");
        std::fs::write(
            &script,
            include_bytes!("../packaging/windows/sc-update/Invoke-SCAppUpdate.ps1"),
        )
        .map_err(fail)?;
        std::fs::write(
            scratch.path().join("SC.Update.psm1"),
            include_bytes!("../packaging/windows/sc-update/SC.Update.psm1"),
        )
        .map_err(fail)?;
        let powershell = std::env::var_os("SystemRoot")
            .map(std::path::PathBuf::from)
            .ok_or("Couldn't find Windows PowerShell.")?
            .join(r"System32\WindowsPowerShell\v1.0\powershell.exe");
        // Do not keep Tokio's blocking pool alive on application shutdown: a
        // user can still quit normally during a slow download. Closing our
        // pipes ensures the helper cannot commit without this app's response.
        let mut child = Command::new(powershell)
            .args([
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "RemoteSigned",
                "-File",
            ])
            .arg(script)
            .arg("-InstallDirectory")
            .arg(&dir)
            .arg("-DataDirectory")
            .arg(profile)
            .args(["-Tag", tag, "-AppPid", &std::process::id().to_string()])
            .current_dir(dir.parent().ok_or("The app needs a dedicated folder.")?)
            .creation_flags(0x0800_0000)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .spawn()
            .map_err(fail)?;
        let mut stdout = BufReader::new(child.stdout.take().expect("piped stdout"));
        let mut line = String::new();
        while stdout.read_line(&mut line).unwrap_or(0) != 0 {
            if line.trim() == "SC-UPDATE-READY" {
                return Ok(Prepared {
                    child,
                    scratch,
                    _output: stdout,
                });
            }
            line.clear();
        }
        let _ = child.wait();
        Err("The update couldn't be verified or staged. Try again, or use the release page.".into())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn metadata(tag: &str, prerelease: bool, asset_url: &str, digest: &str) -> Vec<u8> {
        serde_json::to_vec(&serde_json::json!({
            "tag_name": tag, "draft": false, "prerelease": prerelease, "body": "Updates",
            "assets": [{"name": ZIP, "browser_download_url": asset_url, "digest": digest, "state": "uploaded", "size": 10}]
        })).unwrap()
    }

    #[test]
    fn sc_update_only_offers_newer_stable_verified_windows_releases() {
        let tag = "v0.3.0.10";
        let url = format!("{RELEASES}/download/{tag}/{ZIP}");
        let hash = format!("sha256:{}", "a".repeat(64));
        let valid = metadata(tag, false, &url, &hash);
        assert_eq!(offer(&valid, [0, 3, 0, 9]).unwrap().unwrap().tag, tag);
        assert_eq!(offer(&valid, [0, 3, 0, 10]).unwrap(), None);
        assert_eq!(offer(&valid, [0, 3, 0, 11]).unwrap(), None);
        assert_eq!(
            offer(&metadata(tag, true, &url, &hash), [0; 4]).unwrap(),
            None
        );
        assert!(
            offer(
                &metadata(tag, false, "https://example.org/file.zip", &hash),
                [0; 4]
            )
            .is_err()
        );
        assert!(offer(&metadata(tag, false, &url, "invalid"), [0; 4]).is_err());
        assert!(offer(&metadata("v0.3.0.7-rc", false, &url, &hash), [0; 4]).is_err());
    }
}
