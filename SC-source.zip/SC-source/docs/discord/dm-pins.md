# Pinned DMs

The DM sidebar's context menu offers **Pin DM** and **Unpin DM**. These pin the
conversation, not a message. Pinned one-to-one and group DMs appear once under
**Pinned DMs**, before **Direct Messages**; both sections remain virtualized and
filterable. The Favorites star is a separate collection across servers and DMs.

Pin membership already supplied by Discord's private notification settings is
imported automatically. `USER_GUILD_SETTINGS` with `guild_id: null` describes
private channels; a channel override's `FAVORITED` bit (`1 << 11`) is the existing
pin flag. Missing private settings is different from an explicit empty pin set.
The read-only projection caches at most 200 valid channel IDs and shares its
`Arc` while unchanged; it creates no requests or polling. This snapshot exposes
membership, not a separate manually chosen order. Locally pinned DMs retain the
order in which they were pinned, followed by incoming cloud pins.

Menu actions say **On this device**. They do not write Discord settings. An
explicit local unpin overrides an incoming cloud pin, so it does not return on
the next gateway refresh. Pinning it again clears that local override. Each of
at most eight accounts stores up to 200 local pin IDs and 200 recent unpin
overrides in `layout.json`. No DM text, person name, token or avatar is saved.
Sign-out and account changes clear the previous account's active pins before
rendering the new list. Old unscoped pins are migrated only when an ID matches a
current readable DM; migration does not assign other accounts' unknown IDs.

The `pinned_dm` UI tests exercise real menu callbacks, section ordering,
unpinning, persisted restart state, identity/reset isolation, import merging,
local overrides and bounds. Protocol/core tests cover incoming private override
snapshots, unchanged sharing, explicit empty data and unlinking. Native preview
frames verify both headings at minimum and regular window sizes. Tests use
synthetic data and never query the signed-in account.

References: [user guild settings and private overrides](https://docs.discord.food/resources/user-settings#user-guild-settings-object),
[Discord's desktop pin announcement](https://discord.com/blog/adding-the-discord-updates-you-want-to-see).
