# Activities

S;C offers **Activities in Discord web** from a readable Discord channel's
composer menu, the connected voice dock, and the call controls when there is
room for the extra button. The native dialog names the destination and opens
that exact channel on `https://discord.com` only after explicit confirmation.
The call entry uses the connected call's room, even when another chat is selected.

In Discord web, use the channel's App Launcher to start an Activity or join one
already running. Discord handles app permissions, authorization and availability.
The browser uses its own login; S;C never transfers an account token into the URL.
Opening the page does not disconnect S;C. Joining voice in the browser may move
the call there. Cancel and Escape do not open a page.

This is a browser handoff, not an embedded Activities runtime. Discord Activities
are web applications hosted in an iframe and integrated through the Embedded App
SDK. S;C does not currently render those apps, list live Activity sessions, issue
Activity invitations, or synchronize embedded app state. Presence cards are not
treated as proof that a joinable embedded session exists.

Only known, readable Discord rooms with canonical numeric channel IDs are linked.
The callback rechecks account, selected/call room and access before opening; a
changed account, lost room, disconnected call or withdrawn access cancels the
pending destination. No polling, new API endpoint, activity cache or background
browser process is introduced.

Tests use fake rooms and an injected browser opener to cover room targeting,
unchanged voice state, double activation, cancellation, account changes and
invalid destinations. A separate offscreen fixture checks dialog controls at
800×600 and 1120×760. Actual Activity authorization and playback in Discord web
remain a live-service check.

References: [Discord Activities overview](https://docs.discord.com/developers/activities/overview)
and [Using Apps on Discord](https://support.discord.com/hc/en-us/articles/21334461140375-Using-Apps-on-Discord).
