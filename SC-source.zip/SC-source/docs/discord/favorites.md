# Favorite channels and DMs

The star in the server rail opens a local Favorites collection across servers,
direct messages, group DMs, readable voice channels, forums and known readable
threads. Right-click a channel, DM or thread to add or remove it. The collection supports named categories,
collapse, keyboard-accessible context menus, moving into or out of a category,
and moving within a group. Removing a category keeps its channels.
Thread favorites resolve only while the thread is known and readable; storing
its ID does not fetch an unknown thread or grant access to a private one.

Appearance's **Show Favorites** switch hides the rail entry without deleting
the collection. This is separate from emoji and GIF favorites and from existing
per-server pinned channels.

## Import and storage

The Discord gateway's already-received PreloadedUserSettings field 15 is read
using the public extracted protobuf schema. There is no Favorites endpoint,
polling, settings encoder, or cloud write. Unknown protobuf fields are left
alone. Missing or malformed Favorites data leaves the latest known snapshot
unchanged; an explicitly empty field replaces that snapshot with an empty one.
The incoming snapshot is shared with an `Arc` and is not persisted separately.

An account's first received snapshot is imported once, including category names,
positions, nicknames, collapsed state and its initial visibility preference.
**Import from Discord** merges subsequently received entries on request. It
deduplicates stable channel IDs, preserves local edits and never removes local
entries. Explicit import can restore a shortcut removed locally if it remains
in Discord's snapshot. The pane states **Edits stay on this device**: changing
this collection does not update Discord or other clients.

`channel-favorites.json` in the existing application data directory keeps at
most eight account collections with 200 entries each, including categories.
Names are bounded to 128 characters, reads to 4 MiB, and writes replace the file
atomically. No messages, credentials, ordinary channel names, avatars or command
arguments are stored. Only imported aliases and locally named categories carry
labels. Preview uses a separate in-memory collection and never writes it.

Sign-out/account changes close the pane and clear its rows, editor and menu.
Display and navigation resolve each shortcut against the current readable room
list, so stale shortcuts cannot grant access. Unavailable channels are labelled
generically and remain removable. Threads are excluded from new local shortcuts.
The virtual list materializes visible rows, reuses the existing bounded image
store for visible DM avatars and drops the row model when hidden. It adds no
timers or background requests.

## Checks

The `channel_favorites` tests cover decoder wire shape and bounds, partial
snapshot semantics, shared core projection, local account isolation, restart,
category operations and limits, merge/deduplication, permission changes and real
native callbacks. Offscreen review covers the pane at the app's supported
minimum and regular window sizes. No signed-in account is queried by tests.

References: [Discord Favorites FAQ](https://support.discord.com/hc/en-us/articles/38810584460439-Favorites-FAQ),
[public extracted settings schema](https://github.com/discord-userdoccers/discord-protos/blob/master/discord_protos/discord_users/v1/PreloadedUserSettings.proto).
