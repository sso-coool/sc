# Threads

## Thread menus and editing

The channel list and a thread's main or side-panel More menu offer only actions
the current account may perform. Active threads can be closed, renamed and given
an inactivity duration by their creator or a moderator. Locking, slowmode and
deletion require Manage Threads. Private threads offer **Anyone can invite**
when the account may change it. Archived threads offer **Reopen thread** first;
reopening a locked thread requires a moderator. Closing a thread keeps its
conversation visible.

**Edit thread** opens a compact native dialog for its name, inactivity duration
and, for moderators, slowmode. Cancel leaves the thread unchanged. **Delete
thread** opens a separate confirmation; opening or cancelling it never deletes
anything. The controls wait while saving and show a returned error. Core checks
permissions again when applying an action, and account/request correlation keeps
late responses out of another account or thread. No background polling is added.

Readable known threads can be added to the local Favorites collection. Their
shortcut remains subject to current access checks; a deleted, inaccessible or
not-yet-loaded thread is not resolved by its saved ID. Favorites appears next to
Mark as read when that row is present. Developer Mode names the thread's copy
action **Copy Thread ID**. Native menus cap their height to the window and scroll
to keyboard-selected rows, including in an 800px window.


## Thread member sidebar

A thread opened as the main conversation subscribes to its own joined-member
roster with gateway opcode 37 (`subscriptions[guild].thread_member_lists`).
`THREAD_MEMBER_LIST_UPDATE` supplies the authoritative current members; its entries
contain `user_id`, a nested guild `member`, and optional `presence`.
`THREAD_MEMBERS_UPDATE` adds/removes members, and `THREAD_MEMBER_UPDATE` updates this
account. This is the user-account gateway route. The REST List Thread Members
endpoint is not used because it is unavailable to user accounts.

The loading/error state never substitutes the parent's channel readers or old
message authors. A thread beside a channel does not replace the main channel's
member panel. Results must match the active thread and guild; the application
also checks the linked account and current readable room before displaying them.
The one visible roster is discarded on disconnect and leaving the thread, never
saved to disk, and bounded at 1,000 displayed members. Its subscription is removed
when another main conversation is selected. There is no polling.

These are joined thread members, not a promise that nobody else has access:
moderators with Manage Threads may access private threads without joining, and
public thread readers may also not have joined.

Contract references: [user thread subscriptions](https://discord.neko.wtf/threads/),
[bulk subscription fields](https://github.com/dolfies/discord.py-self/blob/master/discord/types/gateway.py),
[thread member payload](https://github.com/dolfies/discord.py-self/blob/master/discord/types/threads.py),
and [Discord thread permission model](https://docs.discord.food/topics/threads).
