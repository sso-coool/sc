# Discord parity status

| Workflow | What S;C does | Remaining gap |
| --- | --- | --- |
| Spotify Listen Along | Shows an incoming listening invite with a button that opens the original message in Discord. Search and pins label invites that have no text. | Starting a group, joining from a live profile, and syncing playback still use Discord. |
| Activities | Opens the right channel in Discord web from the composer or call controls, after confirmation. | No embedded apps, live session list, or Activity invites inside S;C. |
| Favorite channels and DMs | Shows the latest Favorites received from Discord and keeps a separate editable list on this device. | Local edits do not sync back to Discord. |
| Quick Switcher | Shows previous channels and mentions; a matching friend can be opened even if there is no existing DM. | Discord's full ranking and app search are not reproduced. |
| Detached video | The pop-out stretches the whole camera or shared screen to the window by default. **Preserve ratio** keeps the original shape with bars as needed. | The switch applies to the open pop-out only. |
| Server onboarding and membership screening | Opens the official Discord flow when the server requires it. | No native application and screening forms. |
| Bot forms | Supports ordinary Discord component modals and file fields. | Iframe app modals still require Discord. |
| Server folders and privacy | Displays collapsible folders, supports Mark Read, and saves drag order by account on this device. | Syncing rail order, moving servers between folders, editing folders, and per-server DM, message-request, and activity privacy controls. |
| Forum and media browsing | Loads and filters posts in a list. | Native gallery layout and stepping between neighboring embed images. |
| Soundboard and push-to-talk | Uses the available soundboard and supports a push-to-talk binding. | Server sound management, modifier combinations, and multiple bindings. |

These are confirmed gaps, not a complete feature inventory. The browser handoffs
use known channel or message destinations and open only on an explicit action.
They add no embedded browser to the resident S;C process.

See [Spotify](people.md#listening-to-spotify), [Activities](activities.md),
[Favorites](favorites.md), and [other remaining work](README.md#later).
