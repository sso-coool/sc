# S;C personal build

S;C is a personal native client based on Yapfast, pinned initially to upstream
commit `ac3412e76784c9337f2ee85f0cabf48f0fa7edd2`. It uses the existing Rust,
Slint and Skia architecture, Discord protocol implementation and OS credential
store. The customisation does not introduce a web view or a separate service.

## Presentation

- The S;C sunset skyline replaces the window, taskbar, tray, sign-in and home
  icons. Its PNG is embedded once; tray images for normal and unread states are
  prepared at tray creation rather than per frame.
- The app's visible name is S;C. Existing data-directory, protocol and credential
  identifiers are preserved so the signed-in session remains compatible.
- Midnight is the default palette. Themes also includes Discord, Ocean, Ember
  and Frost, the original palettes, and the native custom colour editor.
- The custom title bar uses a subtle static gradient and focus accent, with
  normal native move, resize, minimise, maximise and close behaviour.
- **Settings > Appearance > Auto Resize** is on by default. At the minimum
  800px window width, the native channel sidebar narrows to at
  most 240px and the member list to 180px, keeping both visible and leaving
  room for messages and bot controls. Their saved widths return at 1120px;
  resizing the window does not save these temporary display widths.
  The search field also narrows, and the floating stream preview scales at
  16:9 within the chat instead of covering the member roster. Turning Auto
  Resize off restores the chosen pane widths and original 320px preview.
- Embed sizing and profile layout changes are documented alongside their
  features. GIFs, stickers and supported profile animations remain available.
- Animated custom emoji keep their existing frame decoder and bounded cache.
  Pausing playback now also stops the polling timer after pending decodes
  finish; focus, settings and newly shown emoji restart it when needed.
- Suggestion popups, the composer, embeds, bot forms and profiles use a
  consistent set of rounded corners. Keyboard-selected command and emoji
  rows scroll into view, including in narrow windows.
- Slash suggestions combine name relevance with bounded recent/frequent
  usage, isolated by account. Only command identities and counts are saved;
  arguments are excluded. Emoji search understands Discord aliases, natural
  names and small typos, with favorites/frequent use breaking matching ties.
- The command chip above an app response loads its read-only option details
  on hover. These are kept temporarily in memory, never in recommendation
  history or layout settings. Unavailable details leave the command name
  visible; clicking the chip prepares a new command without executing it.
- Windows 11 rounds the actual outer window using the desktop compositor.
  Maximized, snapped and fullscreen windows retain the system's normal edges;
  older Windows keeps its existing frame. This adds no rendering loop.
- Appearance includes Compact, Default and Spacious interface density, an
  Enhanced surfaces toggle and a separate Interface transitions toggle.
  Every option persists locally and applies without restarting. Media animation
  retains its separate focused/always/never setting.
- Civic and Civic Night translate [America.gov](https://america.gov/)'s clean
  ink-and-porcelain contrast, low-contrast borders and restrained surface depth
  into native palettes. Only public CSS was used as a design reference; no
  webpage, photographs or remote fonts are loaded by the client.
- Display-name motion is optional and hover-triggered. Supported native
  approximations run only while the app is focused and the existing animation
  and cosmetic preferences permit them. Names without an existing hover source
  stay still. No per-name timer or background decoder was added.
- Pasted, dropped and selected files fill a slash command's attachment options.
  The existing thumbnail tray previews the actual option files; removing a
  preview clears its option. File counts and size limits are checked before a
  batch changes the draft. Clipboard reads and file dialogs ignore stale drafts.
- Voice input and output explicitly offer System default, including the quick
  device menus. That choice stores no fixed device id and uses the existing
  Windows default-device following behavior.
- Link buttons offer Open Link and Copy Link on right-click in messages,
  threads and search results. A right-click does not execute a bot action;
  action buttons without a URL do not invent one.
- Favorite channels and DMs use a dedicated rail star, optional categories,
  reordering and an Appearance visibility switch. Import reads received
  Discord favorites; edits remain local and isolated by account. Collections
  are bounded to 200 items and eight accounts, and hidden panes release their
  rendered rows. No polling or cloud settings writes are introduced.
- Empty optional command arguments stay absent when Enter submits the draft.
  Arrow navigation, Tab or clicking explicitly chooses a suggestion; required
  arguments retain their validation and required files retain their picker.
- The Friends screen includes a searchable Blocked tab with the existing
  unblock action, reusing received relationship data and lazy avatar loading.
- Partial text selections restore custom emoji names for the clipboard;
  copied text no longer exposes private font glyphs. This leaves text shaping,
  selection offsets and normal text-input editing unchanged.

## Local build and updates

This is a local source build, not an official Discord or Yapfast release.
Keep the upstream licence and notices with it. Upstream updates need a rebuild
with these changes reapplied; replacing the executable with an upstream release
does not preserve the custom layout. Ordinary settings and edited palettes are
stored in the existing local application-data directory.

The skyline icon was generated from the user's reference with the built-in
image generation tool, then packaged into standard Windows icon sizes. The
original generated PNG and prompt are retained with the task's deliverables.

## Verification boundaries

Use the linked-stack smoke test, theme and layout checks, and local fake-server
interaction tests before installing a new build. Fake-server tests validate
request handling without transmitting messages through the user's account.
They cannot certify every third-party bot, every media device, or every future
Discord protocol change. This client remains unofficial.
