[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$Repository = 'sso-coool/sc',
    [string]$InstallDirectory = (Join-Path $env:LOCALAPPDATA 'Programs\SC'),
    [ValidateRange(1,168)][int]$EveryHours = 6,
    [switch]$RestartWhenRunning, [switch]$Disable
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SC.Update.psm1') -Force
$Repository = Assert-SCRepository $Repository
$taskName = 'SC Update Check'
if ($Disable) {
    if ($PSCmdlet.ShouldProcess($taskName, 'Disable automatic updates')) { Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue }
    return
}
# This mode is intentionally distinct: it can interrupt an active S;C call.
if ($RestartWhenRunning) { Write-Warning 'Automatic restart is enabled. New releases can close S;C and interrupt active calls.' }
$updater = Join-Path $env:LOCALAPPDATA 'Programs\SC-Updater'
$runner = Join-Path $updater 'Update-SC.ps1'
$quotedInstall = [IO.Path]::GetFullPath($InstallDirectory)
if ($quotedInstall.Contains('"') -or $quotedInstall -match '[\r\n]') { throw 'Invalid installation directory.' }
$arguments = '-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + $runner + '" -Repository "' + $Repository + '" -InstallDirectory "' + $quotedInstall + '" -Background'
if ($RestartWhenRunning) { $arguments += ' -Restart' }
if ($PSCmdlet.ShouldProcess($taskName, "Register a per-user release check every $EveryHours hours")) {
    if (Test-Path -LiteralPath $updater) {
        if ((Get-Item -LiteralPath $updater -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Updater directory must not be a junction or symlink.' }
    }
    [IO.Directory]::CreateDirectory($updater) | Out-Null
    foreach ($name in @('SC.Update.psm1','Install-SC.ps1','Update-SC.ps1','Start-SC.ps1','Enable-SCUpdates.ps1')) {
        $source = Join-Path $PSScriptRoot $name; $destination = Join-Path $updater $name
        if ([IO.Path]::GetFullPath($source) -ne [IO.Path]::GetFullPath($destination)) { Copy-Item -LiteralPath $source -Destination $destination -Force }
    }
    $user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    $action = New-ScheduledTaskAction -Execute (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') -Argument $arguments
    $trigger = New-ScheduledTaskTrigger -Once -At ((Get-Date).AddMinutes(5)) -RepetitionInterval (New-TimeSpan -Hours $EveryHours)
    $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 15) -Hidden
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
    Write-Output "Automatic checks enabled. Task: $taskName. No background resident process."
}
