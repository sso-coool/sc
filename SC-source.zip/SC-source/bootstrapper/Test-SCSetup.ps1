[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$Setup,
    [Parameter(Mandatory)][string]$OutputDirectory,
    [switch]$VerifyLiveDownload
)
$ErrorActionPreference = 'Stop'
$scInput = (Resolve-Path -LiteralPath $Setup).Path
$scOutput = [IO.Path]::GetFullPath($OutputDirectory)
[IO.Directory]::CreateDirectory($scOutput) | Out-Null
$scSelfReport = Join-Path $scOutput 'wizard-self-test.json'
if (Test-Path -LiteralPath $scSelfReport) { Remove-Item -LiteralPath $scSelfReport -Force }
$scProcess = Start-Process -FilePath $scInput -ArgumentList ('--self-test "' + $scSelfReport + '"') -PassThru -WindowStyle Hidden
try {
    if (!$scProcess.WaitForExit(30000)) { $scProcess.Kill(); throw 'Setup self-test timed out.' }
    if ($scProcess.ExitCode -ne 0) { throw "Setup self-test failed with exit code $($scProcess.ExitCode)." }
} finally { $scProcess.Dispose() }
$null = Get-Content -LiteralPath $scSelfReport -Raw | ConvertFrom-Json

$scPayload = [Reflection.Assembly]::Load([IO.File]::ReadAllBytes($scInput))
$scVersion = [Diagnostics.FileVersionInfo]::GetVersionInfo($scInput)
$scResources = @('Install-SC.ps1','SC.Update.psm1','WizardBridge.ps1','LICENSE.txt')
$scSandbox = Join-Path ([IO.Path]::GetTempPath()) ('sc-setup-check-' + [guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($scSandbox) | Out-Null
$scPaths = @()
try {
    foreach ($scFilename in $scResources) {
        $scResource = $scPayload.GetManifestResourceStream('SC.Bootstrap.' + $scFilename)
        if ($null -eq $scResource) { throw "Setup is missing $scFilename." }
        $scPath = Join-Path $scSandbox $scFilename
        $scPaths += $scPath
        $scFile = [IO.File]::Open($scPath, [IO.FileMode]::CreateNew)
        try { $scResource.CopyTo($scFile) } finally { $scFile.Dispose(); $scResource.Dispose() }
        $scOriginal = if ($scFilename -eq 'WizardBridge.ps1') {
            Join-Path $PSScriptRoot "wizard/$scFilename"
        } else { Join-Path $PSScriptRoot $scFilename }
        if ((Get-FileHash -LiteralPath $scOriginal).Hash -ne (Get-FileHash -LiteralPath $scPath).Hash) {
            throw "Setup's $scFilename does not match the corresponding source."
        }
    }
    $scInstall = Join-Path $scSandbox "Install with spaces"
    $scRequest = Join-Path $scSandbox 'request.json'
    $scPaths += $scRequest
    $scBeforeSC = @(Get-Process -Name SC -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id | Sort-Object)
    $scBeforeDiscord = @(Get-Process -Name Discord -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id | Sort-Object)
    $scBeforeLinks = @([Environment]::GetFolderPath('Desktop'),(Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs')) |
        ForEach-Object { $scLink = Join-Path $_ 'S;C.lnk'; if (Test-Path -LiteralPath $scLink) { (Get-FileHash -LiteralPath $scLink).Hash } else { '<absent>' } }
    if ($VerifyLiveDownload) {
        $scRequestData = [ordered]@{
            operation = 'Install'; installDirectory = $scInstall
            desktopShortcut = $false; startMenuShortcut = $false; restart = $false
        }
        [IO.File]::WriteAllText($scRequest, ($scRequestData | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false)))
        $scWindowsPowerShell = Join-Path ([Environment]::SystemDirectory) 'WindowsPowerShell/v1.0/powershell.exe'
        $scBridgeLog = Join-Path $scOutput 'wizard-live-test.log'
        & $scWindowsPowerShell -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $scSandbox 'WizardBridge.ps1') -RequestFile $scRequest *> $scBridgeLog
        if ($LASTEXITCODE -ne 0) { throw "Setup's embedded installer failed; see $scBridgeLog." }
        if (!(Test-Path -LiteralPath (Join-Path $scInstall 'SC.exe'))) { throw 'Setup did not install the executable.' }
        Import-Module (Join-Path $scSandbox 'SC.Update.psm1') -Force
        try {
            $scExecutableHash = Test-SCPackage $scInstall
            $scInstalledVersion = (Get-SCExecutableVersion $scInstall).ToString()
        } finally { Remove-Module SC.Update -ErrorAction SilentlyContinue }
        $scScAfter = @(Get-Process -Name SC -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id | Sort-Object)
        $scDiscordAfter = @(Get-Process -Name Discord -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id | Sort-Object)
        $scLinksAfter = @([Environment]::GetFolderPath('Desktop'),(Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs')) |
            ForEach-Object { $scLink = Join-Path $_ 'S;C.lnk'; if (Test-Path -LiteralPath $scLink) { (Get-FileHash -LiteralPath $scLink).Hash } else { '<absent>' } }
        if (($scBeforeSC -join ',') -ne ($scScAfter -join ',') -or ($scBeforeDiscord -join ',') -ne ($scDiscordAfter -join ',')) { throw 'An existing app process changed during the isolated install.' }
        if (($scBeforeLinks -join ',') -ne ($scLinksAfter -join ',')) { throw 'The isolated check unexpectedly changed an existing shortcut.' }
    }
    $scResult = [ordered]@{
        exit_code = 0; sha256 = (Get-FileHash -LiteralPath $scInput).Hash.ToLowerInvariant()
        setup_file_version = $scVersion.FileVersion; self_test = $true
        embedded_source_matches = $true; verified_install = [bool]$VerifyLiveDownload
        isolated_install_version = if ($VerifyLiveDownload) { $scInstalledVersion } else { $null }
        isolated_install_sha256 = if ($VerifyLiveDownload) { $scExecutableHash } else { $null }
        existing_app_processes_unchanged = if ($VerifyLiveDownload) { $true } else { $null }
    }
    $scResult | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $scOutput 'wizard-proof.json') -Encoding UTF8
    [pscustomobject]$scResult
} finally {
    $scTempCheck = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\') + '\'
    $scChecked = (Resolve-Path -LiteralPath $scSandbox).Path
    if (!$scChecked.StartsWith($scTempCheck, [StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetFileName($scChecked) -notmatch '^sc-setup-check-[0-9a-f]{32}$') {
        throw 'Refusing to clean an unrecognized test directory.'
    }
    Remove-Item -LiteralPath $scChecked -Recurse -Force
}
