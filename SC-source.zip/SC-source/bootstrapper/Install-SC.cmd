@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-SC.ps1" %*
exit /b %errorlevel%
