[CmdletBinding()]
param([Parameter(Mandatory = $true)][string]$RequestFile)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
function Send-SetupResult([string]$Kind, [string]$Message, [string]$Status = '', [string]$Tag = '') {
    $value = @{ kind = $Kind; message = $Message; status = $Status; tag = $Tag }
    [Console]::Out.WriteLine('SC_SETUP:' + ($value | ConvertTo-Json -Compress))
}
try {
    if ((Get-Item -LiteralPath $RequestFile).Length -gt 16384) { throw 'Setup request is too large.' }
    $request = Get-Content -LiteralPath $RequestFile -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($request.operation -notin @('Install', 'Launch')) { throw 'Unknown setup operation.' }
    if ($request.installDirectory -isnot [string] -or [string]::IsNullOrWhiteSpace($request.installDirectory)) { throw 'Choose an installation folder.' }
    if ($request.operation -eq 'Install') {
        foreach ($name in @('restart', 'desktopShortcut', 'startMenuShortcut')) {
            if ($request.$name -isnot [bool]) { throw 'Invalid setup option.' }
        }
        Send-SetupResult 'progress' 'Checking the latest release, downloading, and verifying S;C…'
        $options = @{
            Repository = 'sso-coool/sc'; InstallDirectory = $request.installDirectory
            Restart = $request.restart; Launch = $false
            DesktopShortcut = $request.desktopShortcut; StartMenuShortcut = $request.startMenuShortcut
        }
        $result = & (Join-Path $PSScriptRoot 'Install-SC.ps1') @options
        if (!$result -or $result.Status -notin @('Installed', 'Current')) { throw 'Setup did not return a verified installation.' }
        Send-SetupResult 'result' 'S;C is ready.' $result.Status $result.Tag
    } else {
        Send-SetupResult 'progress' 'Verifying and opening S;C…'
        Import-Module (Join-Path $PSScriptRoot 'SC.Update.psm1') -Force
        Start-SCInstalled -Directory $request.installDirectory -VerifyStartup
        Send-SetupResult 'result' 'S;C opened.' 'Launched'
    }
    exit 0
} catch {
    $message = $_.Exception.Message
    if ($message.Length -gt 2000) { $message = $message.Substring(0, 2000) }
    Send-SetupResult 'error' $message
    exit 1
}
