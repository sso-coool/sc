// S;C setup UI. The embedded, independently tested bootstrapper owns installation.
// No administrator rights, scheduled tasks, shell command interpolation or resident updater.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Forms;

[assembly: AssemblyTitle("S;C Setup")]
[assembly: AssemblyDescription("Verified per-user installer for S;C")]
[assembly: AssemblyCompany("S;C contributors")]
[assembly: AssemblyProduct("S;C Setup")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

internal static class SetupProgram {
    internal static readonly string[] Payloads = { "Install-SC.ps1", "SC.Update.psm1", "WizardBridge.ps1", "LICENSE.txt" };
    internal static readonly JavaScriptSerializer Json = new JavaScriptSerializer { MaxJsonLength = 65536 };

    [STAThread]
    private static int Main(string[] args) {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        if (args.Length == 2 && args[0] == "--self-test") return SelfTest(args[1]);
        if (args.Length != 0) return 2;
        try { Application.Run(new SetupForm()); return 0; }
        catch (Exception error) { MessageBox.Show(error.Message, "S;C Setup", MessageBoxButtons.OK, MessageBoxIcon.Error); return 1; }
    }

    internal static string ReadPayload(string name) {
        using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("SC.Bootstrap." + name)) {
            if (stream == null || stream.Length == 0 || stream.Length > 2097152) throw new InvalidDataException("Setup is missing a required component: " + name);
            using (var reader = new StreamReader(stream, Encoding.UTF8, true)) return reader.ReadToEnd();
        }
    }

    internal static string Quote(string value) {
        // Windows CommandLineToArgvW quoting, not PowerShell source quoting.
        var output = new StringBuilder("\"");
        int slashes = 0;
        foreach (char character in value) {
            if (character == '\\') { slashes++; continue; }
            if (character == '"') { output.Append('\\', slashes * 2 + 1); output.Append('"'); }
            else { output.Append('\\', slashes); output.Append(character); }
            slashes = 0;
        }
        output.Append('\\', slashes * 2); output.Append('"');
        return output.ToString();
    }

    internal static Dictionary<string, object> Request(string operation, string directory, bool restart, bool desktop, bool startMenu) {
        return new Dictionary<string, object> {
            { "operation", operation }, { "installDirectory", directory },
            { "restart", restart }, { "desktopShortcut", desktop }, { "startMenuShortcut", startMenu }
        };
    }

    [DllImport("shell32.dll", SetLastError = true)] private static extern IntPtr CommandLineToArgvW([MarshalAs(UnmanagedType.LPWStr)] string command, out int count);
    [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr pointer);

    private static int SelfTest(string reportPath) {
        var checks = new List<string>();
        try {
            foreach (string name in Payloads) { ReadPayload(name); checks.Add("embedded " + name); }
            string[] values = { "", "C:\\A folder\\S;C", "C:\\日本語 & $(literal)\\", "quoted\"value", "C:\\trailing\\" };
            foreach (string value in values) {
                int count; IntPtr list = CommandLineToArgvW("setup.exe " + Quote(value), out count);
                if (list == IntPtr.Zero) throw new Exception("Windows argument parser failed.");
                try {
                    if (count != 2 || Marshal.PtrToStringUni(Marshal.ReadIntPtr(list, IntPtr.Size)) != value) throw new Exception("Argument quoting changed a path.");
                } finally { LocalFree(list); }
            }
            checks.Add("Windows argument quoting roundtrip");
            var request = Request("Install", values[2], false, true, true);
            var roundtrip = Json.Deserialize<Dictionary<string, object>>(Json.Serialize(request));
            if ((string)roundtrip["installDirectory"] != values[2] || (bool)roundtrip["restart"]) throw new Exception("Request roundtrip changed options.");
            checks.Add("JSON path and explicit restart options");
            using (var form = new SetupForm()) {
                if (form.Restart.Checked || !form.Desktop.Checked || !form.StartMenu.Checked) throw new Exception("Unexpected setup defaults.");
                if (form.InstallPath.Text != Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "SC")) throw new Exception("Unexpected default installation folder.");
                checks.Add("per-user defaults; restart opt-in; no scheduling controls");
                // A hidden top-level Form suppresses child creation. Render its
                // exact client layout in a native parking-window child instead;
                // no top-level window is shown or activated on the user's desktop.
                Control layout = form.Controls[0];
                form.Controls.Remove(layout);
                using (layout) {
                    layout.Dock = DockStyle.None; layout.Location = Point.Empty;
                    layout.Size = form.ClientSize; layout.BackColor = form.BackColor;
                    layout.Font = form.Font; layout.ForeColor = form.ForeColor;
                    RealizeHiddenLayout(layout);
                    using (var bitmap = new Bitmap(layout.Width, layout.Height)) {
                        layout.DrawToBitmap(bitmap, new Rectangle(Point.Empty, bitmap.Size));
                        bitmap.Save(Path.ChangeExtension(reportPath, ".png"), System.Drawing.Imaging.ImageFormat.Png);
                    }
                    foreach (Control control in new Control[] { form.InstallPath, form.Restart, form.Primary, form.CancelSetup }) {
                        Point point = Point.Empty; Control ancestor = control;
                        while (ancestor != layout && ancestor != null) { point.Offset(ancestor.Location); ancestor = ancestor.Parent; }
                        if (ancestor != layout || point.X < 0 || point.Y < 0 || point.X + control.Width > layout.Width + 1 || point.Y + control.Height > layout.Height + 1) throw new Exception("Setup control lies outside the form: " + control.Text);
                    }
                }
                checks.Add("hidden native form render and control bounds");
            }
            File.WriteAllText(reportPath, Json.Serialize(new { passed = true, checks = checks, network = false, installed = false, launched = false }), new UTF8Encoding(false));
            return 0;
        } catch (Exception error) {
            File.WriteAllText(reportPath, Json.Serialize(new { passed = false, checks = checks, error = error.Message }), new UTF8Encoding(false));
            return 1;
        }
    }

    private static void RealizeHiddenLayout(Control control) {
        control.CreateControl(); control.PerformLayout();
        foreach (Control child in control.Controls) RealizeHiddenLayout(child);
        control.PerformLayout();
    }
}

internal sealed class SetupForm : Form {
    internal readonly TextBox InstallPath = new TextBox();
    internal readonly CheckBox Restart = new CheckBox();
    internal readonly CheckBox Desktop = new CheckBox();
    internal readonly CheckBox StartMenu = new CheckBox();
    internal readonly Button Primary = new Button();
    internal readonly Button CancelSetup = new Button();
    private readonly Button browse = new Button();
    private readonly CheckBox launch = new CheckBox();
    private readonly Label status = new Label();
    private readonly Label explanation = new Label();
    private readonly ProgressBar progress = new ProgressBar();
    private readonly LinkLabel details = new LinkLabel();
    private readonly Color surface = Color.FromArgb(26, 26, 36);
    private readonly Color muted = Color.FromArgb(184, 183, 201);
    private readonly Color pink = Color.FromArgb(224, 73, 165);
    private bool busy, installed;
    private string scratch, errorDetails = "", installedDirectory;

    internal SetupForm() {
        Text = "S;C Setup"; ClientSize = new Size(640, 610); MinimumSize = new Size(656, 649);
        StartPosition = FormStartPosition.CenterScreen; MaximizeBox = false;
        BackColor = surface; ForeColor = Color.FromArgb(246, 245, 251);
        Font = new Font("Segoe UI", 10F); AutoScaleMode = AutoScaleMode.Dpi;
        try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Margin = Padding.Empty };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 90));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 126));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 66));
        Controls.Add(layout);
        var header = new Panel { Dock = DockStyle.Fill, Padding = new Padding(24, 16, 24, 12) };
        header.Paint += delegate(object sender, PaintEventArgs e) {
            using (var brush = new LinearGradientBrush(header.ClientRectangle, Color.FromArgb(49, 30, 68), Color.FromArgb(30, 31, 50), 0F)) e.Graphics.FillRectangle(brush, header.ClientRectangle);
        };
        var title = new Label { Text = "S;C", Font = new Font("Segoe UI", 25F, FontStyle.Bold), AutoSize = true, BackColor = Color.Transparent, Location = new Point(24, 10) };
        var subtitle = new Label { Text = "Your chat. A lighter home.", AutoSize = true, ForeColor = muted, BackColor = Color.Transparent, Location = new Point(26, 56) };
        header.Controls.Add(title); header.Controls.Add(subtitle); layout.Controls.Add(header, 0, 0);

        var body = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 9, Padding = new Padding(24, 16, 24, 4), Margin = Padding.Empty };
        foreach (int height in new int[] { 64, 23, 34, 16, 29, 29, 48, 30, 28 }) body.RowStyles.Add(new RowStyle(SizeType.Absolute, height));
        body.Controls.Add(new Label { Text = "Setup downloads and verifies the latest stable S;C release.\nS;C includes the Vencord companion, which uses a separate sign-in.\nThe companion opens when you choose it in Plugins.", Dock = DockStyle.Fill, AutoSize = false }, 0, 0);
        body.Controls.Add(new Label { Text = "Installation folder", ForeColor = muted, Dock = DockStyle.Fill }, 0, 1);
        var pathRow = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, Margin = Padding.Empty };
        pathRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); pathRow.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 90));
        InstallPath.Text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "SC");
        InstallPath.Dock = DockStyle.Fill; InstallPath.BackColor = Color.FromArgb(39, 39, 53); InstallPath.ForeColor = ForeColor; InstallPath.BorderStyle = BorderStyle.FixedSingle;
        InstallPath.AccessibleName = "Installation folder";
        StyleButton(browse, "Browse…", false); browse.Dock = DockStyle.Fill;
        browse.Click += delegate { using (var picker = new FolderBrowserDialog { Description = "Choose a dedicated folder for S;C", SelectedPath = InstallPath.Text }) if (picker.ShowDialog(this) == DialogResult.OK) InstallPath.Text = picker.SelectedPath; };
        pathRow.Controls.Add(InstallPath, 0, 0); pathRow.Controls.Add(browse, 1, 0); body.Controls.Add(pathRow, 0, 2);
        Desktop.Text = "Create a desktop shortcut"; Desktop.Checked = true; Desktop.Dock = DockStyle.Fill;
        StartMenu.Text = "Add S;C to the Start menu"; StartMenu.Checked = true; StartMenu.Dock = DockStyle.Fill;
        Restart.Text = "Allow setup to close and restart S;C if an update needs it\nThis may interrupt an active call. Discord stays open.";
        Restart.Checked = false; Restart.Dock = DockStyle.Fill;
        body.Controls.Add(Desktop, 0, 4); body.Controls.Add(StartMenu, 0, 5); body.Controls.Add(Restart, 0, 6);
        body.Controls.Add(new Label { Text = "Your account, messages and preferences stay in place.", ForeColor = muted, Dock = DockStyle.Fill }, 0, 7);
        var license = new LinkLabel { Text = "Open-source software · View license", LinkColor = Color.FromArgb(238, 147, 207), ActiveLinkColor = Color.White, Dock = DockStyle.Fill };
        license.LinkClicked += delegate { ShowText("S;C license", SetupProgram.ReadPayload("LICENSE.txt")); };
        body.Controls.Add(license, 0, 8); layout.Controls.Add(body, 0, 1);

        var state = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5, Padding = new Padding(24, 4, 24, 0), Margin = Padding.Empty };
        foreach (int height in new int[] { 24, 14, 38, 22, 24 }) state.RowStyles.Add(new RowStyle(SizeType.Absolute, height));
        status.Text = "Ready to install"; status.Dock = DockStyle.Fill; status.Font = new Font(Font, FontStyle.Bold);
        progress.Dock = DockStyle.Fill; progress.Visible = false; progress.MarqueeAnimationSpeed = 30;
        explanation.Text = "No administrator access or background service is required."; explanation.ForeColor = muted; explanation.Dock = DockStyle.Fill;
        details.Text = "Show details"; details.LinkColor = Color.FromArgb(238, 147, 207); details.Dock = DockStyle.Fill; details.Visible = false;
        details.LinkClicked += delegate { ShowText("Setup details", errorDetails); };
        launch.Text = "Open S;C when I click Finish"; launch.Checked = true; launch.Dock = DockStyle.Fill; launch.Visible = false;
        state.Controls.Add(status, 0, 0); state.Controls.Add(progress, 0, 1); state.Controls.Add(explanation, 0, 2); state.Controls.Add(details, 0, 3); state.Controls.Add(launch, 0, 4);
        layout.Controls.Add(state, 0, 2);
        var footer = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(21, 10, 21, 10), WrapContents = false };
        StyleButton(Primary, "Install S;C", true); StyleButton(CancelSetup, "Cancel", false);
        Primary.Size = new Size(140, 38); CancelSetup.Size = new Size(95, 38);
        footer.Controls.Add(Primary); footer.Controls.Add(CancelSetup); layout.Controls.Add(footer, 0, 3);
        AcceptButton = Primary; CancelButton = CancelSetup;
        Primary.Click += delegate { if (installed) { if (launch.Checked) BeginOperation("Launch"); else Close(); } else BeginOperation("Install"); };
        CancelSetup.Click += delegate { if (!busy) Close(); };
        FormClosing += delegate(object sender, FormClosingEventArgs e) { if (busy) { e.Cancel = true; explanation.Text = "Setup is finishing a verified operation. Please keep this window open."; } };
        FormClosed += delegate { Cleanup(); };
    }

    private void StyleButton(Button button, string text, bool primary) {
        button.Text = text; button.FlatStyle = FlatStyle.Flat; button.FlatAppearance.BorderSize = primary ? 0 : 1;
        button.FlatAppearance.BorderColor = Color.FromArgb(78, 73, 94); button.BackColor = primary ? pink : Color.FromArgb(40, 39, 53); button.ForeColor = Color.White;
        button.Cursor = Cursors.Hand; button.UseVisualStyleBackColor = false;
    }

    private void ShowText(string caption, string text) {
        using (var dialog = new Form { Text = caption, Size = new Size(640, 480), StartPosition = FormStartPosition.CenterParent, BackColor = surface, ForeColor = ForeColor, MinimizeBox = false, MaximizeBox = false }) {
            var content = new TextBox { Text = text.Replace("\n", Environment.NewLine), Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, BackColor = surface, ForeColor = ForeColor, Font = Font, BorderStyle = BorderStyle.None, Margin = new Padding(16) };
            dialog.Padding = new Padding(16); dialog.Controls.Add(content); dialog.ShowDialog(this);
        }
    }

    private void ExtractPayloads() {
        if (scratch != null) return;
        scratch = Path.Combine(Path.GetTempPath(), "SC-Setup-" + Guid.NewGuid().ToString("N"));
        try {
            Directory.CreateDirectory(scratch);
            foreach (string name in SetupProgram.Payloads) File.WriteAllText(Path.Combine(scratch, name), SetupProgram.ReadPayload(name), new UTF8Encoding(true));
        } catch { Cleanup(); scratch = null; throw; }
    }

    private void BeginOperation(string operation) {
        if (busy) return;
        try {
            if (operation == "Install") {
                string entered = InstallPath.Text.Trim();
                if (!Path.IsPathRooted(entered) || entered.IndexOfAny(new char[] { '\r', '\n', '\0' }) >= 0) throw new ArgumentException("Choose a full Windows installation folder.");
                installedDirectory = Path.GetFullPath(entered);
            }
            ExtractPayloads();
            string requestFile = Path.Combine(scratch, "request.json");
            File.WriteAllText(requestFile, SetupProgram.Json.Serialize(SetupProgram.Request(operation, installedDirectory, Restart.Checked, Desktop.Checked, StartMenu.Checked)), new UTF8Encoding(false));
            busy = true; Primary.Enabled = false; CancelSetup.Enabled = false;
            foreach (Control item in new Control[] { InstallPath, browse, Desktop, StartMenu, Restart, launch }) item.Enabled = false;
            details.Visible = false; status.ForeColor = ForeColor; progress.Visible = true; progress.Style = ProgressBarStyle.Marquee;
            status.Text = operation == "Install" ? "Installing S;C…" : "Opening S;C…";
            explanation.Text = "Downloads and checks may take a few minutes. Your session stays open unless you allowed a restart.";
            var worker = new BackgroundWorker();
            worker.DoWork += delegate(object sender, DoWorkEventArgs e) { e.Result = RunBridge(requestFile); };
            worker.RunWorkerCompleted += delegate(object sender, RunWorkerCompletedEventArgs e) {
                worker.Dispose(); busy = false; progress.Style = ProgressBarStyle.Blocks; progress.Visible = false;
                Primary.Enabled = true; CancelSetup.Enabled = true;
                if (e.Error != null) { Failed(e.Error.Message); return; }
                var result = (Dictionary<string, object>)e.Result;
                if ((string)result["kind"] != "result") { Failed((string)result["message"]); return; }
                if (operation == "Launch") { Close(); return; }
                installed = true; status.Text = (string)result["status"] == "Current" ? "S;C is already up to date" : "S;C is ready";
                string tag = (string)result["tag"];
                explanation.Text = (tag.Length > 0 ? tag + " · " : "") + "Installation verified. Click Finish when you’re ready.";
                Primary.Text = "Finish"; CancelSetup.Text = "Close"; launch.Visible = true; launch.Enabled = true;
            };
            worker.RunWorkerAsync();
        } catch (Exception error) { busy = false; Failed(error.Message); }
    }

    private void Failed(string message) {
        progress.Visible = false;
        if (message.IndexOf("run again with -Restart", StringComparison.OrdinalIgnoreCase) >= 0)
            message = "Close S;C and try again, or select “Allow setup to close and restart S;C” to let setup restart it. An active call may be interrupted.";
        errorDetails = message; details.Visible = true;
        status.Text = installed ? "S;C could not open" : "Setup could not finish"; status.ForeColor = Color.FromArgb(255, 140, 163);
        explanation.Text = message.Length <= 200 ? message : message.Substring(0, 197) + "…";
        Primary.Text = installed ? "Try opening again" : "Try again";
        Primary.Enabled = true; CancelSetup.Enabled = true; launch.Enabled = installed;
        foreach (Control item in new Control[] { InstallPath, browse, Desktop, StartMenu, Restart }) item.Enabled = !installed;
    }

    private Dictionary<string, object> RunBridge(string requestFile) {
        string executable = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe");
        var info = new ProcessStartInfo {
            FileName = executable,
            Arguments = "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File " + SetupProgram.Quote(Path.Combine(scratch, "WizardBridge.ps1")) + " -RequestFile " + SetupProgram.Quote(requestFile),
            WorkingDirectory = scratch, UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden,
            RedirectStandardOutput = true, RedirectStandardError = true, StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8
        };
        Dictionary<string, object> result = null;
        var errors = new StringBuilder(); var gate = new object();
        using (var process = new Process { StartInfo = info }) {
            process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e) {
                if (e.Data == null || !e.Data.StartsWith("SC_SETUP:", StringComparison.Ordinal) || e.Data.Length > 8192) return;
                try {
                    var value = SetupProgram.Json.Deserialize<Dictionary<string, object>>(e.Data.Substring(9));
                    string kind = (string)value["kind"];
                    if (kind == "result" || kind == "error") { lock (gate) result = value; }
                    else if (kind == "progress" && !IsDisposed) BeginInvoke((Action)delegate { if (!IsDisposed) explanation.Text = (string)value["message"]; });
                } catch (Exception) { /* Malformed output cannot be interpreted as success. */ }
            };
            process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e) { if (e.Data != null) lock (gate) { if (errors.Length < 2048) errors.AppendLine(e.Data.Substring(0, Math.Min(e.Data.Length, 512))); } };
            if (!process.Start()) throw new IOException("Could not start the bundled installer.");
            process.BeginOutputReadLine(); process.BeginErrorReadLine(); process.WaitForExit();
            lock (gate) {
                if (process.ExitCode == 0 && result != null && (string)result["kind"] == "result") return result;
                if (result != null && (string)result["kind"] == "error") return result;
                throw new IOException(errors.Length > 0 ? errors.ToString() : "The installer stopped before confirming success. Try again or view the setup scripts.");
            }
        }
    }

    private void Cleanup() {
        if (scratch == null || busy) return;
        try {
            string full = Path.GetFullPath(scratch);
            string prefix = Path.Combine(Path.GetTempPath(), "SC-Setup-");
            if (!full.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || full.Length != prefix.Length + 32) return;
            if ((File.GetAttributes(full) & FileAttributes.ReparsePoint) != 0) return;
            // Remove only our known flat payloads, never recurse into an unexpected tree.
            foreach (string name in SetupProgram.Payloads) File.Delete(Path.Combine(full, name));
            File.Delete(Path.Combine(full, "request.json")); Directory.Delete(full, false);
        } catch { /* A locked temporary helper is harmless and must not block Finish. */ }
    }
}
