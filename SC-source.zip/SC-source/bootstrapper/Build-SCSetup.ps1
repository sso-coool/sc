[CmdletBinding()]
param([string]$OutputDirectory = (Join-Path $PSScriptRoot 'dist'))

$ErrorActionPreference = 'Stop'
$scFramework = Join-Path ([Environment]::GetFolderPath('Windows')) 'Microsoft.NET\Framework64\v4.0.30319'
$scCompiler = Join-Path $scFramework 'csc.exe'
if (!(Test-Path -LiteralPath $scCompiler -PathType Leaf)) { throw 'The Windows .NET Framework 4.x compiler is required to build SC-Setup.exe.' }

$scWizard = Join-Path $PSScriptRoot 'wizard'
$scIcon = Join-Path $scWizard 'SC.ico'
$scManifest = Join-Path $scWizard 'app.manifest'
$scReferences = @('System.dll','System.Core.dll','System.Drawing.dll','System.Windows.Forms.dll','System.Web.Extensions.dll')
$scResources = @('Install-SC.ps1','SC.Update.psm1','LICENSE.txt')
$scOutput = [IO.Path]::GetFullPath($OutputDirectory)
[IO.Directory]::CreateDirectory($scOutput) | Out-Null
$scSetup = Join-Path $scOutput 'SC-Setup.exe'
# Compile beside the output, then replace the final file only after compilation succeeds.
$scStage = Join-Path $scOutput ('.sc-setup-' + [guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($scStage) | Out-Null
$scCandidate = Join-Path $scStage 'SC-Setup.exe'
$scArguments = @('/nologo','/target:winexe','/platform:x64','/optimize+','/debug-','/codepage:65001',
    "/out:$scCandidate", "/win32icon:$scIcon", "/win32manifest:$scManifest")
$scArguments += $scReferences | ForEach-Object { '/reference:' + (Join-Path $scFramework $_) }
$scArguments += $scResources | ForEach-Object { '/resource:' + (Join-Path $PSScriptRoot $_) + ',SC.Bootstrap.' + $_ }
$scArguments += '/resource:' + (Join-Path $scWizard 'WizardBridge.ps1') + ',SC.Bootstrap.WizardBridge.ps1'
$scArguments += Get-ChildItem -LiteralPath $scWizard -File -Filter '*.cs' | Sort-Object Name | ForEach-Object FullName
try {
    & $scCompiler @scArguments
    if ($LASTEXITCODE -ne 0) { throw 'Windows setup wizard did not compile.' }
    if (Test-Path -LiteralPath $scSetup) {
        $scOldSetup = Join-Path $scStage 'Previous.exe'
        [IO.File]::Replace($scCandidate, $scSetup, $scOldSetup)
        Remove-Item -LiteralPath $scOldSetup -Force
    } else {
        [IO.File]::Move($scCandidate, $scSetup)
    }
} finally {
    if (Test-Path -LiteralPath $scCandidate) { Remove-Item -LiteralPath $scCandidate -Force }
    [IO.Directory]::Delete($scStage)
}
Get-Item -LiteralPath $scSetup
