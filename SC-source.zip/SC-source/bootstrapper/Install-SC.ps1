[CmdletBinding()]
param(
    [string]$Repository = 'sso-coool/sc', [string]$Tag,
    [string]$InstallDirectory = (Join-Path $env:LOCALAPPDATA 'Programs\SC'),
    [switch]$Restart, [switch]$Launch, [switch]$DesktopShortcut, [switch]$StartMenuShortcut,
    [switch]$AutomaticUpdates, [switch]$RestartWhenRunning
)
$ErrorActionPreference = 'Stop'
if ($RestartWhenRunning -and !$AutomaticUpdates) { throw '-RestartWhenRunning requires -AutomaticUpdates.' }
Import-Module (Join-Path $PSScriptRoot 'SC.Update.psm1') -Force
Invoke-SCInstall -Repository $Repository -Tag $Tag -InstallDirectory $InstallDirectory -Restart:$Restart -Launch:$Launch -DesktopShortcut:$DesktopShortcut -StartMenuShortcut:$StartMenuShortcut
if ($AutomaticUpdates) {
    & (Join-Path $PSScriptRoot 'Enable-SCUpdates.ps1') -Repository $Repository -InstallDirectory $InstallDirectory -RestartWhenRunning:$RestartWhenRunning
}
