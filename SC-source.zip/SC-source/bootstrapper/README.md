# S;C Windows bootstrapper

On Windows 10/11 x64, download **SC-Setup.exe** and double-click it. The
wizard installs the latest stable S;C for your Windows user, adds a Start
menu shortcut by default, and offers a desktop shortcut and first launch.
It uses the same verified download and installation as the scripts below.
It only closes a running S;C if you select the restart option.
Bundled releases include the Vencord companion. Open it from **Plugins** in
S;C. It uses a separate Discord sign-in and its own profile.

Setup downloads the app from the project's GitHub Releases. An internet
connection is required. The setup executable is unsigned and does not
require administrator access. After installation, S;C's **Settings → About**
controls in-app update checks. Setup asks GitHub for its latest published
stable release each time you install. The setup executable does not pin an app
version.

If you are still on the first public release, **0.3.0.7**, you can skip
straight to the latest stable S;C. Quit S;C and run **SC-Setup.exe**, choosing
your existing install folder if you used a custom location. If you still
have the original bootstrapper, **Start-SC.cmd** or **Update-SC.ps1** can also
do the direct upgrade. From **0.3.0.8** onward, use **Settings → About → Check
now**. The update replaces the app files and leaves your profile settings in
their existing per-user location.

If you prefer the command-line scripts:

Extract the **whole** `SC-bootstrapper-windows.zip` before running a script. Requires Windows 10/11 x64 and Windows PowerShell 5.1 or later. No administrator access, service, resident updater, additional module, or global PATH change is needed.

The default repository is `sso-coool/sc`. Use `-Repository owner/repo` to select another repository deliberately; an existing installation cannot silently switch repositories. The repository must publish stable, numeric release tags such as `v0.3.0.7`, `SC-windows-x64.zip`, and `SC-SHA256SUMS.txt` (or a GitHub-provided SHA-256 asset digest). A commit or source-only release is not an application update.

## Install and launch

Run these commands in this extracted directory:

```powershell
.\Install-SC.ps1 -Repository sso-coool/sc -Launch
.\Start-SC.ps1
```

Installation defaults to `%LOCALAPPDATA%\Programs\SC`; `-InstallDirectory` selects a dedicated alternative directory. Optional `-DesktopShortcut` and `-StartMenuShortcut` create direct shortcuts to `SC.exe`. Those direct shortcuts do **not** perform a launch-time update check. Use `Start-SC.cmd` or `Start-SC.ps1` for that check; `-NoUpdateCheck` skips it.

`Start-SC.ps1` checks the latest stable release before launching. If S;C is already running, it defers the new version unless you pass `-Restart`. When a check fails, it can still open the verified installed version. An initial installation requires a successful download and verification.
An open companion defers all package replacement, including with `-Restart`.

```powershell
.\Update-SC.ps1                 # Install a new release while S;C is closed
.\Update-SC.ps1 -Restart        # Explicitly allow closing/restarting installed S;C
.\Install-SC.ps1 -Tag v0.3.0.7 # Explicit release selection; may downgrade
```

The `.cmd` convenience wrappers and scheduled checks use `-ExecutionPolicy Bypass` **for their PowerShell process only**, to run this unsigned script bundle on systems whose script policy otherwise prevents it. They do not change the machine/user execution policy, disable Defender, add exclusions, or change firewall settings. The direct `.ps1` commands above do not supply that override; use them under your existing script policy if preferred. Inspect the scripts before choosing either method. This bundle and the current personal S;C build are unsigned.

## Automatic checks (explicit opt-in)

```powershell
.\Enable-SCUpdates.ps1 -EveryHours 6
.\Enable-SCUpdates.ps1 -EveryHours 1 -RestartWhenRunning
.\Enable-SCUpdates.ps1 -Disable
```

The first command creates a current-user scheduled task, **SC Update Check**, with its first check in five minutes and subsequent checks at the selected interval. It runs only in the signed-in user's context, keeps a copy of the helper scripts in `%LOCALAPPDATA%\Programs\SC-Updater`, and installs updates when S;C is closed. It does not launch a previously closed app.

**`-RestartWhenRunning` explicitly permits automatic S;C restart and can interrupt active calls.** There is no call-state detector. Without that switch, checks defer while S;C is open. Nothing closes Discord. `-WhatIf` previews task registration without changing it. Installation can enable this mode with `-AutomaticUpdates`, optionally adding `-RestartWhenRunning`.

These are scheduled checks, not an immediate GitHub push notification. No updater process stays in memory between checks. Re-extract an updated bootstrapper bundle to update these helper scripts; the application release updater does not replace itself.

## Verification and recovery

- Downloads use the canonical GitHub releases API and approved GitHub HTTPS asset hosts. Redirects outside those hosts are refused.
- The ZIP must match the GitHub SHA-256 asset digest or the release checksum entry; both must agree when both exist. These hashes establish integrity relative to the selected repository, **not an independent publisher signature**.
- ZIP extraction rejects traversal, absolute paths, alternate streams, reserved device names, links, duplicate/case-colliding paths, and oversized archives. The extracted x64 PE executable must match `BUILD.json`.
- Bundled packages also verify the companion's manifest, launcher, complete file inventory, and Windows x64 executable before replacing the app.
- The release tag must match the executable's Windows FileVersion. Automatic downgrade checks read the installed PE even when no updater state exists. An explicit `-Tag` permits a deliberate downgrade.
- Updates stage on the installation volume, verify before stopping S;C, and use directory rename/backup with rollback. Only the process running that exact installed `SC.exe` can be stopped, and only with explicit restart permission.
- Requested launches must survive a short 2.5-second process-start check. A launch/verification failure restores the previous installation. This check does not verify Discord login, connectivity, or every app feature.
- One previous updater-owned installation is retained beside the current directory. Older marked backups are removed after a successful update; unrelated folders are not removed. To recover manually, quit S;C, retain the current folder, and rename the adjacent `SC.previous-...` folder back to `SC`.
- App preferences, account data, and OS credential storage are untouched. A per-installation lock prevents concurrent updater transactions.
- A bundled installation retains its companion on automatic updates. Choosing an explicit older `-Tag` can install a native-only version. The companion profile remains in `%LOCALAPPDATA%\SC\VencordCompanion\profile-v1`.

## Local validation

To build the wizard from its corresponding source on Windows:

```powershell
.\Build-SCSetup.ps1
```

The setup executable is written to `dist\SC-Setup.exe`. It uses the .NET
Framework already included with Windows. The source for the wizard and
its embedded installer is licensed under GPL-3.0-or-later.

```powershell
.\Test-SCBootstrapper.ps1
```

Tests use synthetic packages and injected failures. They do not access GitHub, sign in, stop real processes, launch S;C, or register a scheduled task. `TEST-RESULTS.json` records the latest local run. Live release downloading and actual Task Scheduler execution require validation after a suitable release exists.

Licensed GPL-3.0-or-later; see `LICENSE.txt`.
