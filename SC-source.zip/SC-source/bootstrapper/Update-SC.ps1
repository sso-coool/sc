[CmdletBinding()]
param(
    [string]$Repository = 'sso-coool/sc', [string]$Tag,
    [string]$InstallDirectory = (Join-Path $env:LOCALAPPDATA 'Programs\SC'),
    [switch]$Restart, [switch]$Background
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SC.Update.psm1') -Force
Invoke-SCInstall -Repository $Repository -Tag $Tag -InstallDirectory $InstallDirectory -Restart:$Restart -Background:$Background
