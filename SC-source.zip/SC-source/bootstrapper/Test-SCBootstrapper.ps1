# Local-only tests: synthetic files, no GitHub requests, process stops or tasks.
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SC.Update.psm1') -Force -DisableNameChecking
$script:Results = @()
$root = Join-Path $PSScriptRoot ('.tests-' + [guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($root) | Out-Null
function Assert($Condition, [string]$Message) { if (!$Condition) { throw $Message } }
function MustFail([scriptblock]$Action) { $failed=$false; try { & $Action | Out-Null } catch { $failed=$true }; Assert $failed 'Expected an operation to fail.' }
function Check([string]$Name, [scriptblock]$Action) {
    try { & $Action; $script:Results += [pscustomobject]@{name=$Name;passed=$true}; Write-Host "PASS $Name" }
    catch { $script:Results += [pscustomobject]@{name=$Name;passed=$false;error=$_.Exception.Message}; Write-Host "FAIL $Name : $($_.Exception.Message)" }
}
function Fixture([string]$Path, [byte]$Value) {
    [IO.Directory]::CreateDirectory($Path) | Out-Null
    $bytes = New-Object byte[] 256
    $bytes[0]=77; $bytes[1]=90; $bytes[60]=64; $bytes[64]=80; $bytes[65]=69; $bytes[68]=100; $bytes[69]=134; $bytes[255]=$Value
    $exe=Join-Path $Path 'SC.exe'; [IO.File]::WriteAllBytes($exe,$bytes)
    $hash=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
    [IO.File]::WriteAllText((Join-Path $Path 'BUILD.json'), (@{name='S;C';executable_sha256=$hash} | ConvertTo-Json))
    return $hash
}
function MakeZip([string]$Path, [array]$Entries) {
    $stream=[IO.File]::Open($Path,[IO.FileMode]::CreateNew)
    $zip=New-Object IO.Compression.ZipArchive($stream,[IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach($item in $Entries) {
            $entry=$zip.CreateEntry($item.name)
            if($null -ne $item.PSObject.Properties['attributes']) { $entry.ExternalAttributes=$item.attributes }
            $out=$entry.Open()
            try { $out.Write($item.bytes,0,$item.bytes.Length) } finally { $out.Dispose() }
        }
    } finally { $zip.Dispose(); $stream.Dispose() }
}
try {
    Check 'repository and HTTPS host validation' {
        Assert ((Assert-SCRepository 'sso-coool/sc') -eq 'sso-coool/sc') 'Valid repository failed.'
        foreach($bad in @('../bad','owner/../bad','https://github.com/a/b','owner/repo?x')) { MustFail { Assert-SCRepository $bad } }
        Assert-SCDownloadUri ([uri]'https://api.github.com/repos/sso-coool/sc/releases/latest') -Api
        foreach($bad in @('http://github.com/a','https://github.com.evil.test/a','https://evil@github.com/a','https://github.com:444/a','https://example.test/a')) { MustFail { Assert-SCDownloadUri ([uri]$bad) } }
    }
    Check 'exact checksum and canonical asset selection' {
        $hash='a'*64
        Assert ((Read-SCChecksum "$hash  SC-windows-x64.zip`n" 'SC-windows-x64.zip') -eq $hash) 'Checksum mismatch.'
        MustFail { Read-SCChecksum "$hash  SC-windows-x64.zip`n$hash  SC-windows-x64.zip`n" 'SC-windows-x64.zip' }
        MustFail { Read-SCChecksum "$hash  other.zip`n" 'SC-windows-x64.zip' }
        $release=[pscustomobject]@{tag_name='v0.3.0.6';assets=@([pscustomobject]@{name='SC-windows-x64.zip';browser_download_url='https://github.com/sso-coool/sc/releases/download/v0.3.0.6/SC-windows-x64.zip'})}
        Get-SCReleaseAsset $release 'SC-windows-x64.zip' 'sso-coool/sc' | Out-Null
        $release.assets[0].browser_download_url='https://github.com/other/sc/releases/download/v0.3.0.6/SC-windows-x64.zip'
        MustFail { Get-SCReleaseAsset $release 'SC-windows-x64.zip' 'sso-coool/sc' }
    }
    Check 'safe package extraction and executable hash' {
        $fixture=Join-Path $root 'fixture'; $hash=Fixture $fixture 1
        $zip=Join-Path $root 'good.zip'
        MakeZip $zip @([pscustomobject]@{name='SC-windows-x64/SC.exe';bytes=[IO.File]::ReadAllBytes((Join-Path $fixture 'SC.exe'))},[pscustomobject]@{name='SC-windows-x64/BUILD.json';bytes=[IO.File]::ReadAllBytes((Join-Path $fixture 'BUILD.json'))})
        $package=Expand-SCArchive $zip (Join-Path $root 'expanded')
        Assert ((Test-SCPackage $package) -eq $hash) 'Extracted package hash differs.'
        [IO.File]::AppendAllText((Join-Path $package 'SC.exe'),'tamper')
        MustFail { Test-SCPackage $package }
    }
    Check 'GitHub digest and checksum must agree and missing hashes fail closed' {
        $module=Get-Module SC.Update
        & $module {
            $script:OriginalDownload=(Get-Command Invoke-SCDownload).ScriptBlock
            $script:ChecksumText=('a'*64)+'  SC-windows-x64.zip'
            Set-Item Function:script:Invoke-SCDownload -Value { param($Uri,$Destination,$MaximumBytes) [IO.File]::WriteAllText($Destination,$script:ChecksumText) }
        }
        try {
            $asset=[pscustomobject]@{name='SC-windows-x64.zip';digest=('sha256:'+('a'*64));browser_download_url='https://github.com/sso-coool/sc/releases/download/v0.3.0.7/SC-windows-x64.zip'}
            $sum=[pscustomobject]@{name='SC-SHA256SUMS.txt';browser_download_url='https://github.com/sso-coool/sc/releases/download/v0.3.0.7/SC-SHA256SUMS.txt'}
            $release=[pscustomobject]@{tag_name='v0.3.0.7';assets=@($asset,$sum)}
            $scratch=Join-Path $root 'digests'; [IO.Directory]::CreateDirectory($scratch)|Out-Null
            $actual=& $module {param($r,$a,$p) Get-SCExpectedHash $r $a 'sso-coool/sc' $p} $release $asset $scratch
            Assert ($actual -eq ('a'*64)) 'Agreed digest failed.'
            & $module { $script:ChecksumText=('b'*64)+'  SC-windows-x64.zip' }
            MustFail { & $module {param($r,$a,$p) Get-SCExpectedHash $r $a 'sso-coool/sc' $p} $release $asset $scratch }
            $asset.digest=$null; $release.assets=@($asset)
            MustFail { & $module {param($r,$a,$p) Get-SCExpectedHash $r $a 'sso-coool/sc' $p} $release $asset $scratch }
        } finally { & $module {Set-Item Function:script:Invoke-SCDownload -Value $script:OriginalDownload} }
    }
    Check 'v0.3.0.7 matches PE version and existing newer installations cannot downgrade implicitly' {
        Assert-SCReleaseVersion 'v0.3.0.7' ([version]'0.3.0.7') ([version]'0.3.0.6')
        MustFail { Assert-SCReleaseVersion 'v0.3.0.7' ([version]'0.3.0.6') $null }
        MustFail { Assert-SCReleaseVersion 'v0.3.0.7' ([version]'0.3.0.7') ([version]'0.3.0.8') }
        Assert-SCReleaseVersion 'v0.3.0.7' ([version]'0.3.0.7') ([version]'0.3.0.8') -AllowDowngrade
        MustFail { Convert-SCTagVersion 'latest-preview' }
    }
    Check 'ZIP traversal absolute ADS device and duplicate paths rejected' {
        $badNames=@('../escape','/absolute','C:/absolute','..\escape','SC.exe:evil','NUL.txt','SC-windows-x64/../escape','SC-windows-x64/trailing.','SC-windows-x64/a?b')
        $i=0
        foreach($name in $badNames) {
            $i++; $zip=Join-Path $root "bad$i.zip"
            MakeZip $zip @([pscustomobject]@{name=$name;bytes=[byte[]]@(1)})
            MustFail { Expand-SCArchive $zip (Join-Path $root "bad$i") }
        }
        $zip=Join-Path $root 'duplicate.zip'
        MakeZip $zip @([pscustomobject]@{name='a';bytes=[byte[]]@(1)},[pscustomobject]@{name='A';bytes=[byte[]]@(2)})
        MustFail { Expand-SCArchive $zip (Join-Path $root 'duplicate') }
        Assert (!(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'escape'))) 'Traversal escaped the test directory.'
    }
    Check 'ZIP symbolic links rejected' {
        $zip=Join-Path $root 'link.zip'
        MakeZip $zip @([pscustomobject]@{name='link';bytes=[byte[]]@(1);attributes=-1610612736})
        MustFail { Expand-SCArchive $zip (Join-Path $root 'link') }
    }
    Check 'directory swap retains one verified rollback copy and leaves data alone' {
        $target=Join-Path $root 'Installed'; $oldHash=Fixture $target 2
        $data=Join-Path $root 'separate-user-data'; [IO.Directory]::CreateDirectory($data)|Out-Null
        [IO.File]::WriteAllText((Join-Path $data 'layout.json'),'unchanged')
        $stage=Join-Path $root 'Stage1'; $newHash=Fixture $stage 3
        $result=Set-SCPackage $stage $target ([pscustomobject]@{repository='sso-coool/sc'})
        Assert ((Test-SCPackage $target) -eq $newHash) 'New package not installed.'
        Assert ((Test-SCPackage $result.Backup) -eq $oldHash) 'Rollback copy does not match old package.'
        $stage=Join-Path $root 'Stage2'; Fixture $stage 4 | Out-Null
        $second=Set-SCPackage $stage $target ([pscustomobject]@{repository='sso-coool/sc'})
        Assert (!(Test-Path -LiteralPath $result.Backup)) 'Older owned rollback copy was not pruned.'
        Assert ((Test-SCPackage $second.Backup) -eq $newHash) 'Latest rollback copy was lost.'
        Assert ([IO.File]::ReadAllText((Join-Path $data 'layout.json')) -eq 'unchanged') 'User data changed.'
    }
    Check 'post-swap failure rolls back the original package' {
        $target=Join-Path $root 'RollbackTarget'; $oldHash=Fixture $target 5
        $stage=Join-Path $root 'RollbackStage'; Fixture $stage 6 | Out-Null
        $module=Get-Module SC.Update
        & $module { param($target)
            $script:OriginalTest=(Get-Command Test-SCPackage).ScriptBlock
            $script:FailTarget=$target
            Set-Item Function:script:Test-SCPackage -Value { param([string]$Directory)
                if($Directory -eq $script:FailTarget) { throw 'Injected verification failure after directory swap.' }
                & $script:OriginalTest $Directory
            }
        } $target
        try { MustFail { Set-SCPackage $stage $target ([pscustomobject]@{repository='sso-coool/sc'}) } }
        finally { & $module { Set-Item Function:script:Test-SCPackage -Value $script:OriginalTest } }
        Assert ((Test-SCPackage $target) -eq $oldHash) 'Rollback did not restore original package.'
    }
    Check 'concurrent update lock refuses before any network request' {
        $target=Join-Path $root 'Locked'; Fixture $target 7 | Out-Null
        $lock=[IO.File]::Open((Join-Path $root '.Locked.update.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
        try { MustFail { Invoke-SCInstall -Repository 'sso-coool/sc' -InstallDirectory $target } } finally { $lock.Dispose() }
    }
    Check 'failed requested startup rolls back and restarts the prior version' {
        $target=Join-Path $root 'StartRollback'; $oldHash=Fixture $target 8
        $stage=Join-Path $root 'StartStage'; Fixture $stage 9 | Out-Null
        $module=Get-Module SC.Update
        & $module {
            $script:OriginalStart=(Get-Command Start-SCInstalled).ScriptBlock; $script:Starts=0
            Set-Item Function:script:Start-SCInstalled -Value { param($Directory,[switch]$VerifyStartup)
                $script:Starts++; if($script:Starts -eq 1) {throw 'Injected startup failure.'}
            }
        }
        try {
            MustFail { Set-SCPackage $stage $target ([pscustomobject]@{repository='sso-coool/sc'}) -Launch }
            $starts=& $module { $script:Starts }
            Assert ($starts -eq 2) 'Prior version was not relaunched.'
        } finally { & $module { Set-Item Function:script:Start-SCInstalled -Value $script:OriginalStart } }
        Assert ((Test-SCPackage $target) -eq $oldHash) 'Startup failure did not restore the prior package.'
    }
    Check 'scheduler WhatIf creates no updater directory or scheduled task' {
        & (Join-Path $PSScriptRoot 'Enable-SCUpdates.ps1') -Repository 'sso-coool/sc' -InstallDirectory (Join-Path $root 'Scheduled') -WhatIf
    }
} finally {
    $report=[pscustomobject]@{passed=@($script:Results|Where-Object passed).Count;failed=@($script:Results|Where-Object {!$_.passed}).Count;tests=$script:Results;network_used=$false;real_processes_stopped=$false;tasks_registered=$false}
    [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'TEST-RESULTS.json'),($report|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
    if([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($root)) -ne [IO.Path]::GetFullPath($PSScriptRoot) -or [IO.Path]::GetFileName($root) -notlike '.tests-*') { throw 'Unsafe test cleanup path.' }
    Remove-Item -LiteralPath $root -Recurse -Force
}
if($report.failed) { exit 1 }
