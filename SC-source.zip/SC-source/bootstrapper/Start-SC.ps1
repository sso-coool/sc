[CmdletBinding()]
param(
    [string]$Repository = 'sso-coool/sc',
    [string]$InstallDirectory = (Join-Path $env:LOCALAPPDATA 'Programs\SC'),
    [switch]$Restart, [switch]$NoUpdateCheck
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SC.Update.psm1') -Force
if (!$NoUpdateCheck) {
    try { Invoke-SCInstall -Repository $Repository -InstallDirectory $InstallDirectory -Restart:$Restart -Launch -Background | Out-Host }
    catch {
        if (!(Test-Path -LiteralPath (Join-Path $InstallDirectory 'SC.exe'))) { throw }
        Write-Warning ('Update check did not complete; opening the verified installed version. ' + $_.Exception.Message)
    }
}
Start-SCInstalled $InstallDirectory -VerifyStartup
