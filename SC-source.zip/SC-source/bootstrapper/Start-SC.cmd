@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-SC.ps1" %*
exit /b %errorlevel%
