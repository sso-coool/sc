# S;C release installer. Windows PowerShell 5.1+, no external modules.
Set-StrictMode -Version 2
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$script:AssetName = 'SC-windows-x64.zip'
$script:ChecksumName = 'SC-SHA256SUMS.txt'

function Get-SCProperty($Object, [string]$Name, $Default = $null) {
    if ($null -ne $Object -and $null -ne $Object.PSObject.Properties[$Name]) { return $Object.$Name }
    return $Default
}
function Assert-SCRepository([string]$Repository) {
    if ($Repository -notmatch '^[A-Za-z0-9][A-Za-z0-9-]{0,38}/[A-Za-z0-9_.-]{1,100}$' -or
        ($Repository.Split('/')[1] -in @('.', '..'))) { throw 'Use a GitHub owner/repository name.' }
    return $Repository
}
function Assert-SCDownloadUri([uri]$Uri, [switch]$Api) {
    $hosts = @('github.com', 'api.github.com', 'release-assets.githubusercontent.com', 'objects.githubusercontent.com', 'github-releases.githubusercontent.com')
    if (!$Uri.IsAbsoluteUri -or $Uri.Scheme -ne 'https' -or $Uri.Port -ne 443 -or $Uri.UserInfo -or $Uri.Fragment -or
        $Uri.DnsSafeHost -notin $hosts -or ($Api -and $Uri.DnsSafeHost -ne 'api.github.com')) {
        throw 'Refusing a download outside the approved GitHub HTTPS hosts.'
    }
}
function Invoke-SCDownload([uri]$Uri, [string]$Destination, [long]$MaximumBytes) {
    for ($redirects = 0; $redirects -le 5; $redirects++) {
        Assert-SCDownloadUri $Uri
        $request = [Net.HttpWebRequest]::Create($Uri)
        $request.Method = 'GET'; $request.AllowAutoRedirect = $false
        $request.UserAgent = 'SC-Bootstrapper/1.0'
        $request.Accept = 'application/vnd.github+json'
        $request.Timeout = 30000; $request.ReadWriteTimeout = 30000
        $response = $request.GetResponse()
        try {
            $status = [int]$response.StatusCode
            if ($status -in @(301, 302, 303, 307, 308)) {
                $next = $response.Headers['Location']
                if (!$next) { throw 'GitHub returned an empty redirect.' }
                $Uri = [uri]::new($Uri, $next)
                continue
            }
            if ($status -ne 200 -or $response.ContentLength -gt $MaximumBytes) { throw 'Unexpected or oversized release download.' }
            $input = $response.GetResponseStream()
            $output = [IO.File]::Open($Destination, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
            try {
                $buffer = New-Object byte[] 65536
                [long]$total = 0
                while (($read = $input.Read($buffer, 0, $buffer.Length)) -gt 0) {
                    $total += $read
                    if ($total -gt $MaximumBytes) { throw 'Release download exceeded its size limit.' }
                    $output.Write($buffer, 0, $read)
                }
            } finally { $output.Dispose(); $input.Dispose() }
            return
        } finally { $response.Dispose() }
    }
    throw 'Too many GitHub download redirects.'
}
function Get-SCRelease([string]$Repository, [string]$Tag, [string]$Scratch) {
    $Repository = Assert-SCRepository $Repository
    if ($Tag -and $Tag -notmatch '^[A-Za-z0-9][A-Za-z0-9._+-]{0,127}$') { throw 'Invalid release tag.' }
    $suffix = if ($Tag) { 'tags/' + [uri]::EscapeDataString($Tag) } else { 'latest' }
    $uri = [uri]('https://api.github.com/repos/' + $Repository + '/releases/' + $suffix)
    Assert-SCDownloadUri $uri -Api
    $file = Join-Path $Scratch 'release.json'
    Invoke-SCDownload $uri $file 5242880
    $release = Get-Content -LiteralPath $file -Raw -Encoding UTF8 | ConvertFrom-Json
    if ((Get-SCProperty $release 'draft' $true) -or (Get-SCProperty $release 'prerelease' $true) -or
        (Get-SCProperty $release 'tag_name' '') -notmatch '^[A-Za-z0-9][A-Za-z0-9._+-]{0,127}$') {
        throw 'Only published stable GitHub releases are supported.'
    }
    return $release
}
function Get-SCReleaseAsset($Release, [string]$Name, [string]$Repository) {
    $assets = @((Get-SCProperty $Release 'assets' @()) | Where-Object { $_.name -ceq $Name })
    if ($assets.Count -ne 1) { throw "Release must contain exactly one $Name asset." }
    $asset = $assets[0]
    $uri = [uri]$asset.browser_download_url
    Assert-SCDownloadUri $uri
    $expected = '/' + $Repository + '/releases/download/' + [uri]::EscapeDataString($Release.tag_name) + '/' + $Name
    if ($uri.Host -ne 'github.com' -or $uri.AbsolutePath -cne $expected -or $uri.Query) { throw 'Release asset URL does not match its repository, tag and filename.' }
    return $asset
}
function Read-SCChecksum([string]$Text, [string]$AssetName) {
    $found = @()
    foreach ($line in ($Text -split '\r?\n')) {
        if ($line -match '^([a-fA-F0-9]{64})[ \t]+\*?([^\r\n]+)$' -and $Matches[2] -ceq $AssetName) { $found += $Matches[1].ToLowerInvariant() }
    }
    if ($found.Count -ne 1) { throw 'Checksum file must contain one exact entry for the release ZIP.' }
    return $found[0]
}
function Get-SCExpectedHash($Release, $Asset, [string]$Repository, [string]$Scratch) {
    $digest = Get-SCProperty $Asset 'digest' ''
    $apiHash = $null
    if ($digest) {
        if ($digest -notmatch '^sha256:([a-fA-F0-9]{64})$') { throw 'Unsupported GitHub asset digest.' }
        $apiHash = $Matches[1].ToLowerInvariant()
    }
    $sumAssets = @((Get-SCProperty $Release 'assets' @()) | Where-Object { $_.name -ceq $script:ChecksumName })
    $sumHash = $null
    if ($sumAssets.Count -gt 0) {
        $sums = Get-SCReleaseAsset $Release $script:ChecksumName $Repository
        $file = Join-Path $Scratch 'checksums.txt'
        Invoke-SCDownload ([uri]$sums.browser_download_url) $file 1048576
        $sumHash = Read-SCChecksum (Get-Content -LiteralPath $file -Raw -Encoding UTF8) $script:AssetName
    }
    if (!$apiHash -and !$sumHash) { throw 'Release has neither a SHA-256 API digest nor a checksum file.' }
    if ($apiHash -and $sumHash -and $apiHash -ne $sumHash) { throw 'GitHub digest and release checksum disagree.' }
    if ($apiHash) { return $apiHash }
    return $sumHash
}
function Assert-SCPlainPath([string]$Path) {
    $full = [IO.Path]::GetFullPath($Path)
    $current = $full
    while ($current) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Refusing a symlink or junction in the installation path.' }
        }
        $parent = [IO.Path]::GetDirectoryName($current)
        if ($parent -eq $current) { break }
        $current = $parent
    }
    return $full
}
function Assert-SCInstallDirectory([string]$Path) {
    $full = Assert-SCPlainPath $Path
    if ($full.TrimEnd('\') -eq [IO.Path]::GetPathRoot($full).TrimEnd('\') -or
        [IO.Path]::GetFileName($full.TrimEnd('\')).Length -lt 2) { throw 'Choose a dedicated S;C installation directory.' }
    $full = $full.TrimEnd('\')
    $companionProfile = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'SC\VencordCompanion\profile-v1'))
    if ($companionProfile -eq $full -or
        $companionProfile.StartsWith($full + '\', [StringComparison]::OrdinalIgnoreCase) -or
        $full.StartsWith($companionProfile + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Choose an installation folder separate from the Vencord companion profile.'
    }
    if (Test-Path -LiteralPath $full) {
        if (!(Test-Path -LiteralPath (Join-Path $full 'SC.exe') -PathType Leaf) -or !(Test-Path -LiteralPath (Join-Path $full 'BUILD.json') -PathType Leaf)) {
            throw 'Existing installation directory is not a recognized S;C package.'
        }
    }
    return $full
}
function Remove-SCScratch([string]$Path, [string]$Parent) {
    $full = Assert-SCPlainPath $Path
    $parentFull = Assert-SCPlainPath $Parent
    if ([IO.Path]::GetDirectoryName($full) -ne $parentFull -or [IO.Path]::GetFileName($full) -notlike '.sc-stage-*') { throw 'Refusing unsafe temporary-directory cleanup.' }
    if (Test-Path -LiteralPath $full) {
        Assert-SCTreeNoLinks $full
        Remove-Item -LiteralPath $full -Recurse -Force
    }
}
function Assert-SCTreeNoLinks([string]$Directory) {
    Assert-SCPlainPath $Directory | Out-Null
    $pending = New-Object 'System.Collections.Generic.Stack[string]'
    $pending.Push($Directory)
    while ($pending.Count) {
        foreach ($item in Get-ChildItem -LiteralPath $pending.Pop() -Force) {
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Refusing a tree containing reparse points.' }
            if ($item.PSIsContainer) { $pending.Push($item.FullName) }
        }
    }
}
function Clear-SCOldBackups([string]$Target, [string]$Keep) {
    $parent = [IO.Path]::GetDirectoryName($Target)
    $pattern = '^' + [regex]::Escape([IO.Path]::GetFileName($Target)) + '\.previous-\d{8}-\d{6}-[a-f0-9]{6}$'
    foreach ($backup in Get-ChildItem -LiteralPath $parent -Directory -Force) {
        if ($backup.FullName -eq $Keep -or $backup.Name -notmatch $pattern) { continue }
        $marker = Join-Path $backup.FullName 'SC-UPDATER-BACKUP.json'
        if (!(Test-Path -LiteralPath $marker -PathType Leaf)) { continue }
        Assert-SCTreeNoLinks $backup.FullName
        if ((Get-Item -LiteralPath $marker).Length -gt 4096) { continue }
        $record = Get-Content -LiteralPath $marker -Raw | ConvertFrom-Json
        if ((Get-SCProperty $record 'installation' '') -ne $Target) { continue }
        Test-SCPackage $backup.FullName | Out-Null
        Remove-Item -LiteralPath $backup.FullName -Recurse -Force
    }
}
function Expand-SCArchive([string]$Archive, [string]$Destination) {
    if (Test-Path -LiteralPath $Destination) { throw 'Extraction destination must be new.' }
    $root = (Assert-SCPlainPath $Destination).TrimEnd('\') + '\'
    [IO.Directory]::CreateDirectory($Destination) | Out-Null
    $zip = [IO.Compression.ZipFile]::OpenRead($Archive)
    try {
        if ($zip.Entries.Count -gt 10000) { throw 'Too many ZIP entries.' }
        $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
        [long]$total = 0
        foreach ($entry in $zip.Entries) {
            $name = $entry.FullName.Replace('\', '/')
            $parts = $name.TrimEnd('/').Split('/')
            $mode = ($entry.ExternalAttributes -shr 16) -band 61440
            if (!$name -or $name.StartsWith('/') -or $name.Contains(':') -or $mode -eq 40960 -or
                ($entry.ExternalAttributes -band 1024) -ne 0 -or $parts.Count -gt 32 -or
                @($parts | Where-Object { !$_ -or $_ -in @('.', '..') -or $_ -match '[. ]$|[\x00-\x1f<>"|?*]' -or $_ -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)' }).Count) {
                throw 'Unsafe ZIP entry path or link.'
            }
            $file = [IO.Path]::GetFullPath([IO.Path]::Combine($Destination, $name.Replace('/', '\')))
            if (!$file.StartsWith($root, [StringComparison]::OrdinalIgnoreCase) -or !$seen.Add($file.TrimEnd('\'))) { throw 'ZIP path escaped its destination or duplicated an entry.' }
            $total += $entry.Length
            if ($entry.Length -gt 536870912 -or $total -gt 1073741824) { throw 'Expanded ZIP exceeds its size limit.' }
            if ($name.EndsWith('/')) { [IO.Directory]::CreateDirectory($file) | Out-Null; continue }
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($file)) | Out-Null
            $input = $entry.Open(); $output = [IO.File]::Open($file, [IO.FileMode]::CreateNew)
            try {
                $buffer = New-Object byte[] 65536; [long]$written = 0
                while (($read = $input.Read($buffer, 0, $buffer.Length)) -gt 0) {
                    $written += $read
                    if ($written -gt $entry.Length) { throw 'ZIP entry exceeded its declared size.' }
                    $output.Write($buffer, 0, $read)
                }
                if ($written -ne $entry.Length) { throw 'Incomplete ZIP entry.' }
            } finally { $output.Dispose(); $input.Dispose() }
        }
    } finally { $zip.Dispose() }
    $package = if (Test-Path -LiteralPath (Join-Path $Destination 'SC.exe')) { $Destination } else { Join-Path $Destination 'SC-windows-x64' }
    Test-SCPackage $package | Out-Null
    return $package
}
function Assert-SCWindowsExecutable([string]$Path) {
    $stream = [IO.File]::OpenRead($Path); $reader = New-Object IO.BinaryReader($stream)
    try {
        if ($stream.Length -lt 128 -or $reader.ReadUInt16() -ne 23117) { throw 'Invalid Windows executable header.' }
        $stream.Position = 60; $pe = $reader.ReadUInt32()
        if ($pe -gt $stream.Length - 26) { throw 'Invalid Windows executable header.' }
        $stream.Position = $pe
        if ($reader.ReadUInt32() -ne 17744 -or $reader.ReadUInt16() -ne 34404) { throw 'Expected a Windows x64 executable.' }
    } finally { $reader.Dispose(); $stream.Dispose() }
}
function Assert-SCCompanion([string]$Directory, $Build) {
    $root = Join-Path $Directory 'vencord-companion'
    $components = Get-SCProperty $Build 'components'
    $component = Get-SCProperty $components 'vencord_companion'
    if (!$component) {
        if ($null -ne $components -or (Test-Path -LiteralPath $root)) { throw 'Invalid companion component declaration.' }
        return
    }

    $manifestHash = Get-SCProperty $component 'manifest_sha256' ''
    $launcherHash = Get-SCProperty $component 'launcher_sha256' ''
    if ((Get-SCProperty $component 'schema') -ne 1 -or $manifestHash -isnot [string] -or $launcherHash -isnot [string] -or
        $manifestHash -notmatch '^[a-fA-F0-9]{64}$' -or $launcherHash -notmatch '^[a-fA-F0-9]{64}$') {
        throw 'Invalid companion component declaration.'
    }
    $manifestFile = Join-Path $root 'companion-manifest.json'
    $launcher = Join-Path $root 'launch.ps1'
    foreach ($path in @($manifestFile, $launcher)) { Assert-SCPlainPath $path | Out-Null }
    if (!(Test-Path -LiteralPath $manifestFile -PathType Leaf) -or !(Test-Path -LiteralPath $launcher -PathType Leaf) -or
        (Get-Item -LiteralPath $manifestFile).Length -gt 2MB -or (Get-Item -LiteralPath $launcher).Length -gt 64KB -or
        (Get-FileHash -LiteralPath $manifestFile -Algorithm SHA256).Hash -ne $manifestHash -or
        (Get-FileHash -LiteralPath $launcher -Algorithm SHA256).Hash -ne $launcherHash) {
        throw 'Companion manifest or launcher hash does not match BUILD.json.'
    }

    $manifest = Get-Content -LiteralPath $manifestFile -Raw -Encoding UTF8 | ConvertFrom-Json
    $inventory = Get-SCProperty $manifest 'files'
    if ((Get-SCProperty $manifest 'schema') -ne 1 -or
        (Get-SCProperty $manifest 'kind') -cne 'sc-vencord-companion' -or
        (Get-SCProperty $manifest 'entrypoint') -cne 'runtime/SC-Vencord.exe' -or
        (Get-SCProperty $manifest 'profile') -cne 'SC/VencordCompanion/profile-v1' -or
        $inventory -isnot [pscustomobject]) {
        throw 'Invalid companion manifest.'
    }
    $files = @{}
    $directories = @{}
    [long]$total = 0
    foreach ($property in $inventory.PSObject.Properties) {
        $name = $property.Name
        $parts = $name.Split('/')
        if ($name -match '[\\:]' -or $parts.Count -gt 32 -or
            @($parts | Where-Object { !$_ -or $_ -in @('.', '..') -or $_ -match '[. ]$|[\x00-\x1f<>"|?*]' -or $_ -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)' }).Count -or
            $name -ieq 'companion-manifest.json' -or $files.ContainsKey($name)) {
            throw 'Unsafe or duplicate companion file path.'
        }
        $size = Get-SCProperty $property.Value 'size'
        $hash = Get-SCProperty $property.Value 'sha256' ''
        if (($size -isnot [int] -and $size -isnot [long]) -or $size -lt 0 -or $size -gt 512MB -or $hash -isnot [string] -or
            $hash -notmatch '^[a-fA-F0-9]{64}$' -or $files.Count -ge 6000) {
            throw 'Invalid companion file record.'
        }
        $total += $size
        if ($total -gt 1GB) { throw 'Companion inventory exceeds its size limit.' }
        $path = Assert-SCPlainPath (Join-Path $root $name)
        $item = Get-Item -LiteralPath $path -Force
        if ($item.PSIsContainer -or $item.Length -ne $size -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $hash) {
            throw 'Companion file does not match its manifest.'
        }
        $files[$name] = $true
        for ($parent = [IO.Path]::GetDirectoryName($path); $parent -ne $root; $parent = [IO.Path]::GetDirectoryName($parent)) {
            $directories[$parent] = $true
        }
    }
    foreach ($name in @('launch.ps1', 'runtime/SC-Vencord.exe', 'licenses/vencord-LICENSE', 'licenses/vesktop-LICENSE', 'sources/vencord-source.zip', 'sources/vesktop-source.zip')) {
        if (!$files.ContainsKey($name)) { throw 'Companion inventory is incomplete.' }
    }
    $pending = New-Object 'System.Collections.Generic.Stack[string]'
    $pending.Push($root)
    while ($pending.Count) {
        foreach ($item in Get-ChildItem -LiteralPath $pending.Pop() -Force) {
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Linked companion paths are not accepted.' }
            if ($item.PSIsContainer) {
                if (!$directories.ContainsKey($item.FullName)) { throw 'Unexpected directory in companion package.' }
                $pending.Push($item.FullName)
            } else {
                $relative = $item.FullName.Substring($root.Length + 1).Replace('\', '/')
                if ($relative -cne 'companion-manifest.json' -and !$files.ContainsKey($relative)) { throw 'Unexpected file in companion package.' }
            }
        }
    }
    Assert-SCWindowsExecutable (Join-Path $root 'runtime\SC-Vencord.exe')
}
function Test-SCPackage([string]$Directory) {
    $Directory = (Assert-SCPlainPath $Directory).TrimEnd('\')
    $manifestFile = Join-Path $Directory 'BUILD.json'; $exe = Join-Path $Directory 'SC.exe'
    Assert-SCPlainPath $manifestFile | Out-Null; Assert-SCPlainPath $exe | Out-Null
    if (!(Test-Path -LiteralPath $manifestFile -PathType Leaf) -or !(Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'Package is missing SC.exe or BUILD.json.' }
    if ((Get-Item -LiteralPath $manifestFile).Length -gt 1048576) { throw 'Oversized build manifest.' }
    $build = Get-Content -LiteralPath $manifestFile -Raw -Encoding UTF8 | ConvertFrom-Json
    $hash = Get-SCProperty $build 'executable_sha256' ''
    if ((Get-SCProperty $build 'name' '') -ne 'S;C' -or (Get-SCProperty $build 'temporary_diagnostic' $false) -or $hash -notmatch '^[a-fA-F0-9]{64}$') { throw 'Not a production S;C package.' }
    if ((Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash -ne $hash) { throw 'Executable does not match BUILD.json.' }
    Assert-SCWindowsExecutable $exe
    Assert-SCCompanion $Directory $build
    return $hash.ToLowerInvariant()
}
function Get-SCProcessesAtPath([string]$Path) {
    $exe = [IO.Path]::GetFullPath($Path)
    Get-Process -Name ([IO.Path]::GetFileNameWithoutExtension($exe)) -ErrorAction SilentlyContinue | Where-Object {
        try { $_.Path -and [IO.Path]::GetFullPath($_.Path).Equals($exe, [StringComparison]::OrdinalIgnoreCase) } catch { $false }
    }
}
function Get-SCInstalledProcesses([string]$Directory) {
    Get-SCProcessesAtPath (Join-Path $Directory 'SC.exe')
}
function Get-SCCompanionProcesses([string]$Directory) {
    Get-SCProcessesAtPath (Join-Path $Directory 'vencord-companion\runtime\SC-Vencord.exe')
}
function Convert-SCTagVersion([string]$Tag) {
    if ($Tag -notmatch '^v?(\d+\.\d+\.\d+(?:\.\d+)?)$') { throw 'Release tags must be numeric versions, for example v0.3.0.7.' }
    $version = [version]$Matches[1]
    return [version]::new($version.Major, $version.Minor, $version.Build, [Math]::Max(0, $version.Revision))
}
function Get-SCExecutableVersion([string]$Directory) {
    $file = [Diagnostics.FileVersionInfo]::GetVersionInfo((Join-Path $Directory 'SC.exe'))
    $version = [version]::new($file.FileMajorPart, $file.FileMinorPart, $file.FileBuildPart, $file.FilePrivatePart)
    if ($version -eq [version]'0.0.0.0') { throw 'Executable has no usable Windows FileVersion.' }
    return $version
}
function Assert-SCReleaseVersion([string]$Tag, [version]$PackageVersion, [version]$InstalledVersion, [switch]$AllowDowngrade) {
    $expected = Convert-SCTagVersion $Tag
    if ($PackageVersion -ne $expected) { throw 'Release tag does not match the executable Windows FileVersion.' }
    if ($InstalledVersion -and $PackageVersion -lt $InstalledVersion -and !$AllowDowngrade) { throw 'Refusing an automatic downgrade. Choose an explicit -Tag to install an older release.' }
}
function Assert-SCCompanionPreserved([string]$Package, [string]$Target, [switch]$AllowCompanionRemoval) {
    if (!$AllowCompanionRemoval -and
        (Test-Path -LiteralPath (Join-Path $Target 'vencord-companion')) -and
        !(Test-Path -LiteralPath (Join-Path $Package 'vencord-companion'))) {
        throw 'The selected release would remove the Vencord companion.'
    }
}
function Set-SCPackage([string]$Package, [string]$InstallDirectory, $State, [switch]$Restart, [switch]$Launch, [switch]$AllowCompanionRemoval) {
    $target = Assert-SCInstallDirectory $InstallDirectory
    $hash = Test-SCPackage $Package
    Assert-SCCompanionPreserved $Package $target -AllowCompanionRemoval:$AllowCompanionRemoval
    if (@(Get-SCCompanionProcesses $target).Count) { throw 'Close the Vencord companion before updating S;C.' }
    $running = @(Get-SCInstalledProcesses $target)
    if ($running.Count -and !$Restart) { throw 'S;C is running. Quit it, or explicitly pass -Restart.' }
    foreach ($process in $running) {
        $current = @(Get-SCInstalledProcesses $target | Where-Object { $_.Id -eq $process.Id })
        if ($current.Count) {
            $current[0].CloseMainWindow() | Out-Null
            if (!$current[0].WaitForExit(4000)) { Stop-Process -Id $current[0].Id -Force; $current[0].WaitForExit(10000) | Out-Null }
        }
    }
    $State | Add-Member -NotePropertyName executable_sha256 -NotePropertyValue $hash -Force
    [IO.File]::WriteAllText((Join-Path $Package 'SC-INSTALL.json'), ($State | ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false))
    $backup = $target + '.previous-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0, 6)
    $movedOld = $false; $movedNew = $false
    try {
        if (@(Get-SCCompanionProcesses $target).Count) { throw 'Close the Vencord companion before updating S;C.' }
        if (Test-Path -LiteralPath $target) {
            [IO.Directory]::Move($target, $backup); $movedOld = $true
            [IO.File]::WriteAllText((Join-Path $backup 'SC-UPDATER-BACKUP.json'), (@{installation=$target} | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
        }
        [IO.Directory]::Move($Package, $target); $movedNew = $true
        if ((Test-SCPackage $target) -ne $hash) { throw 'Installed executable verification failed.' }
        if ($Launch -or ($Restart -and $running.Count)) { Start-SCInstalled $target -VerifyStartup }
    } catch {
        if ($movedNew) { [IO.Directory]::Move($target, $Package) }
        if ($movedOld) {
            [IO.Directory]::Move($backup, $target)
            Remove-Item -LiteralPath (Join-Path $target 'SC-UPDATER-BACKUP.json') -ErrorAction SilentlyContinue
        }
        if (($running.Count -or $Launch) -and (Test-Path -LiteralPath (Join-Path $target 'SC.exe'))) { Start-SCInstalled $target -VerifyStartup }
        throw
    }
    try { Clear-SCOldBackups $target $backup } catch { Write-Warning 'The update succeeded, but an older rollback copy could not be cleaned up.' }
    return [pscustomobject]@{ Installed = $true; Directory = $target; Backup = $(if ($movedOld) { $backup } else { $null }); WasRunning = ($running.Count -gt 0); Hash = $hash }
}
function Start-SCInstalled([string]$Directory, [switch]$VerifyStartup) {
    Test-SCPackage $Directory | Out-Null
    if (@(Get-SCInstalledProcesses $Directory).Count -eq 0) {
        $process = Start-Process -FilePath (Join-Path $Directory 'SC.exe') -WorkingDirectory $Directory -PassThru
        if ($VerifyStartup -and $process.WaitForExit(2500) -and @(Get-SCInstalledProcesses $Directory).Count -eq 0) { throw 'S;C exited during the startup check.' }
        $process.Dispose()
    }
}
function New-SCShortcuts([string]$Directory, [switch]$Desktop, [switch]$StartMenu) {
    $folders = @()
    if ($Desktop) { $folders += [Environment]::GetFolderPath('Desktop') }
    if ($StartMenu) { $folders += Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs' }
    if (!$folders.Count) { return }
    $shell = New-Object -ComObject WScript.Shell
    try {
        foreach ($folder in $folders) {
            $link = $shell.CreateShortcut((Join-Path $folder 'S;C.lnk'))
            $link.TargetPath = Join-Path $Directory 'SC.exe'; $link.WorkingDirectory = $Directory
            $link.IconLocation = $link.TargetPath + ',0'; $link.Description = 'S;C native chat client'; $link.Save()
        }
    } finally { [Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell) | Out-Null }
}
function Invoke-SCInstall {
    [CmdletBinding()]
    param([string]$Repository = 'sso-coool/sc', [string]$Tag, [string]$InstallDirectory = (Join-Path $env:LOCALAPPDATA 'Programs\SC'),
          [switch]$Restart, [switch]$Launch, [switch]$Background, [switch]$DesktopShortcut, [switch]$StartMenuShortcut)
    $Repository = Assert-SCRepository $Repository
    $target = Assert-SCInstallDirectory $InstallDirectory
    $parent = [IO.Path]::GetDirectoryName($target)
    [IO.Directory]::CreateDirectory($parent) | Out-Null
    $stateFile = Join-Path $target 'SC-INSTALL.json'; $old = $null
    if (Test-Path -LiteralPath $stateFile) {
        $old = Get-Content -LiteralPath $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($old.repository -ne $Repository) { throw 'Installed S;C belongs to a different repository. Use a separate installation directory.' }
    }
    $scratch = Join-Path $parent ('.sc-stage-' + [guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($scratch) | Out-Null
    $lock = $null
    try {
        $lockFile = Join-Path $parent ('.' + [IO.Path]::GetFileName($target) + '.update.lock')
        Assert-SCPlainPath $lockFile | Out-Null
        try { $lock = [IO.File]::Open($lockFile, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None) }
        catch { throw 'Another S;C update is already running.' }
        if (Test-Path -LiteralPath $stateFile) {
            $old = Get-Content -LiteralPath $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($old.repository -ne $Repository) { throw 'Installed S;C belongs to a different repository.' }
        }
        $release = Get-SCRelease $Repository $Tag $scratch
        $releaseVersion = Convert-SCTagVersion $release.tag_name
        $installedVersion = $null
        if (Test-Path -LiteralPath (Join-Path $target 'SC.exe')) { $installedVersion = Get-SCExecutableVersion $target }
        Assert-SCReleaseVersion $release.tag_name $releaseVersion $installedVersion -AllowDowngrade:([bool]$Tag)
        $asset = Get-SCReleaseAsset $release $script:AssetName $Repository
        $expected = Get-SCExpectedHash $release $asset $Repository $scratch
        if ($old -and !$Tag -and [DateTimeOffset]$release.published_at -lt [DateTimeOffset]$old.published_at) { throw 'Latest release is older than the installed release; choose an explicit -Tag to downgrade.' }
        if ($old -and $old.archive_sha256 -eq $expected -and (Test-SCPackage $target) -eq $old.executable_sha256) {
            if ($Launch) { Start-SCInstalled $target -VerifyStartup }
            New-SCShortcuts $target -Desktop:$DesktopShortcut -StartMenu:$StartMenuShortcut
            return [pscustomobject]@{ Status = 'Current'; Tag = $release.tag_name; Directory = $target }
        }
        if (@(Get-SCCompanionProcesses $target).Count) {
            if ($Background) { return [pscustomobject]@{ Status = 'DeferredWhileRunning'; Tag = $release.tag_name; Directory = $target } }
            throw 'Close the Vencord companion before updating S;C.'
        }
        if (@(Get-SCInstalledProcesses $target).Count -and !$Restart) {
            if ($Background) { return [pscustomobject]@{ Status = 'DeferredWhileRunning'; Tag = $release.tag_name; Directory = $target } }
            throw 'An update is available. Quit S;C, or run again with -Restart.'
        }
        $zip = Join-Path $scratch $script:AssetName
        Invoke-SCDownload ([uri]$asset.browser_download_url) $zip 1073741824
        if ((Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash -ne $expected) { throw 'Release ZIP failed SHA-256 verification.' }
        $package = Expand-SCArchive $zip (Join-Path $scratch 'unpacked')
        Assert-SCReleaseVersion $release.tag_name (Get-SCExecutableVersion $package) $installedVersion -AllowDowngrade:([bool]$Tag)
        $allowCompanionRemoval = [bool]($Tag -and $installedVersion -and $releaseVersion -lt $installedVersion)
        Assert-SCCompanionPreserved $package $target -AllowCompanionRemoval:$allowCompanionRemoval
        $state = [pscustomobject]@{ repository = $Repository; tag = $release.tag_name; published_at = $release.published_at; archive_sha256 = $expected; installed_at = [DateTimeOffset]::UtcNow.ToString('o') }
        $result = Set-SCPackage $package $target $state -Restart:$Restart -Launch:$Launch -AllowCompanionRemoval:$allowCompanionRemoval
        New-SCShortcuts $target -Desktop:$DesktopShortcut -StartMenu:$StartMenuShortcut
        return [pscustomobject]@{ Status = 'Installed'; Tag = $release.tag_name; Directory = $target; Backup = $result.Backup }
    } finally { if ($lock) { $lock.Dispose() }; Remove-SCScratch $scratch $parent }
}
Export-ModuleMember -Function Assert-SCRepository,Assert-SCDownloadUri,Get-SCReleaseAsset,Read-SCChecksum,Expand-SCArchive,Test-SCPackage,Set-SCPackage,Start-SCInstalled,Invoke-SCInstall,Get-SCInstalledProcesses,Get-SCCompanionProcesses,Convert-SCTagVersion,Get-SCExecutableVersion,Assert-SCReleaseVersion
