[CmdletBinding()]
param([Parameter(Mandatory)][string]$OutputDirectory)

$ErrorActionPreference = 'Stop'
$scOutput = [IO.Path]::GetFullPath($OutputDirectory)
[IO.Directory]::CreateDirectory($scOutput) | Out-Null
$scSetup = & (Join-Path $PSScriptRoot 'Build-SCSetup.ps1') -OutputDirectory $scOutput
$scDownload = Join-Path $scOutput 'SC-bootstrapper-windows.zip'
$scStaging = Join-Path $scOutput ('.sc-bootstrapper-' + [guid]::NewGuid().ToString('N') + '.zip')
$scSourceFiles = @(
    'Install-SC.cmd','Install-SC.ps1','Start-SC.cmd','Start-SC.ps1','Update-SC.ps1',
    'Enable-SCUpdates.ps1','SC.Update.psm1','Build-SCSetup.ps1','Pack-SCBootstrapper.ps1',
    'Test-SCBootstrapper.ps1','Test-SCSetup.ps1','README.md','LICENSE.txt'
)
$scWizardFiles = Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'wizard') -File |
    Where-Object { $_.Extension -in @('.cs','.ps1','.manifest','.ico') } |
    Sort-Object Name
$scSourceFiles += $scWizardFiles | ForEach-Object { 'wizard/' + $_.Name }
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
try {
    $scZip = [IO.Compression.ZipFile]::Open($scStaging, [IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($scFile in $scSourceFiles) {
            $scPath = Join-Path $PSScriptRoot $scFile
            $null = [IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
                $scZip, $scPath, "SC-bootstrapper/$scFile", [IO.Compression.CompressionLevel]::Optimal)
        }
    } finally { $scZip.Dispose() }
    if (Test-Path -LiteralPath $scDownload) {
        $scPrevious = $scStaging + '.previous'
        [IO.File]::Replace($scStaging, $scDownload, $scPrevious)
        Remove-Item -LiteralPath $scPrevious -Force
    } else {
        [IO.File]::Move($scStaging, $scDownload)
    }
} finally {
    if (Test-Path -LiteralPath $scStaging) { Remove-Item -LiteralPath $scStaging -Force }
}
$scSetup
Get-Item -LiteralPath $scDownload
