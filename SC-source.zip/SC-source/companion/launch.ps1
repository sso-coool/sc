# SPDX-License-Identifier: GPL-3.0-or-later
# This script never accepts account tokens, URLs, custom runtimes or profile paths.
[CmdletBinding()]
param(
    [ValidatePattern('^[a-fA-F0-9]{64}$')][Parameter(Mandatory=$true)][string]$ExpectedManifestSha256,
    [switch]$Launch
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Get-Sha256([string]$File) {
    $stream = [IO.File]::OpenRead($File)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $algorithm.Dispose(); $stream.Dispose() }
}

function Assert-NoLinks([string]$Target) {
    $at = [System.IO.Path]::GetFullPath($Target)
    while ($at) {
        if (Test-Path -LiteralPath $at) {
            $item = Get-Item -LiteralPath $at -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Linked paths are not accepted.' }
        }
        $next = [IO.Path]::GetDirectoryName($at)
        if ($next -eq $at) { break }
        $at = $next
    }
}

$packageRoot = [IO.Path]::GetFullPath($PSScriptRoot)
Assert-NoLinks $packageRoot
$manifestPath = Join-Path $packageRoot 'companion-manifest.json'
if ((Get-Item -LiteralPath $manifestPath).Length -gt 2MB) { throw 'Companion manifest is too large.' }
$actualManifestHash = Get-Sha256 $manifestPath
if ($actualManifestHash -ne $ExpectedManifestSha256) { throw 'The companion manifest does not match the expected release.' }
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.schema -ne 1 -or $manifest.kind -ne 'sc-vencord-companion' -or $manifest.entrypoint -ne 'runtime/SC-Vencord.exe' -or $manifest.profile -ne 'SC/VencordCompanion/profile-v1') { throw 'Unsupported companion manifest.' }
$expected = @{}
$totalBytes = 0L
foreach ($property in $manifest.files.PSObject.Properties) {
    $relative = $property.Name
    if ($relative -match '[\\:]' -or $relative.StartsWith('/') -or $relative -match '(^|/)\.\.?(/|$)' -or $relative -match '[. ](/|$)') { throw 'Unsafe manifest path.' }
    if ($expected.ContainsKey($relative)) { throw 'Duplicate manifest path.' }
    $full = [IO.Path]::GetFullPath((Join-Path $packageRoot $relative))
    if (!$full.StartsWith($packageRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Path escapes package.' }
    Assert-NoLinks $full
    $file = Get-Item -LiteralPath $full -Force
    if ($file.PSIsContainer -or $file.Length -ne $property.Value.size -or $file.Length -gt 512MB) { throw 'Companion file size mismatch.' }
    $totalBytes += $file.Length
    if ($totalBytes -gt 1GB -or $expected.Count -ge 6000) { throw 'Companion inventory exceeds limits.' }
    if ((Get-Sha256 $full) -ne $property.Value.sha256) { throw 'Companion file hash mismatch.' }
    $expected[$relative] = $true
}
if ($expected.Count -gt 6000 -or !$expected.ContainsKey('runtime/SC-Vencord.exe') -or !$expected.ContainsKey('launch.ps1')) { throw 'Invalid companion inventory.' }
foreach ($file in Get-ChildItem -LiteralPath $packageRoot -Recurse -Force) {
    Assert-NoLinks $file.FullName
    if ($file.PSIsContainer) { continue }
    $relative = $file.FullName.Substring($packageRoot.Length + 1).Replace('\','/')
    if ($relative -ne 'companion-manifest.json' -and !$expected.ContainsKey($relative)) { throw 'Unexpected file in companion package.' }
}
if (!$Launch) {
    [pscustomobject]@{ verified = $true; files = $expected.Count; launched = $false; profile_modified = $false } | ConvertTo-Json -Compress
    exit 0
}

if (!$env:LOCALAPPDATA -or !$env:SystemRoot) { throw 'Windows user environment is unavailable.' }
$profileRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'SC\VencordCompanion\profile-v1'))
Assert-NoLinks $profileRoot
$profileMarker = Join-Path $profileRoot 'sc-companion-profile.json'
$marker = '{"schema":1,"kind":"sc-vencord-companion-profile"}'
if (Test-Path -LiteralPath $profileRoot) {
    if (!(Test-Path -LiteralPath $profileMarker) -and @(Get-ChildItem -LiteralPath $profileRoot -Force).Count -ne 0) { throw 'Refusing to reuse an existing unmarked profile.' }
    if (Test-Path -LiteralPath $profileMarker) {
        Assert-NoLinks $profileMarker
        if ((Get-Item -LiteralPath $profileMarker).Length -gt 1KB) { throw 'Invalid profile marker.' }
        $existing = Get-Content -LiteralPath $profileMarker -Raw | ConvertFrom-Json
        if ($existing.schema -ne 1 -or $existing.kind -ne 'sc-vencord-companion-profile') { throw 'Invalid profile marker.' }
    }
} else { New-Item -ItemType Directory -Path $profileRoot | Out-Null }
if (!(Test-Path -LiteralPath $profileMarker)) { [IO.File]::WriteAllText($profileMarker, $marker) }

$processInfo = New-Object System.Diagnostics.ProcessStartInfo
$processInfo.FileName = Join-Path $packageRoot 'runtime\SC-Vencord.exe'
$processInfo.WorkingDirectory = Join-Path $packageRoot 'runtime'
$processInfo.UseShellExecute = $false
$processInfo.CreateNoWindow = $true
$processInfo.EnvironmentVariables.Clear()
# Only OS paths required by Electron. Never inherit token/developer injection variables.
foreach ($name in @('SystemRoot','WINDIR','COMSPEC','APPDATA','LOCALAPPDATA','USERPROFILE','HOMEDRIVE','HOMEPATH','TEMP','TMP','PROCESSOR_ARCHITECTURE','NUMBER_OF_PROCESSORS')) {
    $value = [Environment]::GetEnvironmentVariable($name, 'Process')
    if ($value) { $processInfo.EnvironmentVariables[$name] = $value }
}
$processInfo.EnvironmentVariables['PATH'] = (Join-Path $env:SystemRoot 'System32') + ';' + $env:SystemRoot
$processInfo.EnvironmentVariables['VENCORD_USER_DATA_DIR'] = $profileRoot
$child = [Diagnostics.Process]::Start($processInfo)
[pscustomobject]@{ launched = $true; process_id = $child.Id; separate_login = $true } | ConvertTo-Json -Compress
