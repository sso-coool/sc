"""Synthetic package integration checks; no Electron, installer or network.
SPDX-License-Identifier: GPL-3.0-or-later
"""
import importlib.util
import json
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("sc_combined", HERE / "verify_combined.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
c = v.c


class CombinedTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.package = self.root / "candidate"
        self.companion = self.package / "vencord-companion"
        for name, value in {
            "runtime/SC-Vencord.exe": b"synthetic, never executed",
            "licenses/vencord-LICENSE": b"GPL-3.0-or-later",
            "licenses/vesktop-LICENSE": b"GPL-3.0-or-later",
            "sources/vencord-source.zip": b"synthetic corresponding source",
            "sources/vesktop-source.zip": b"synthetic corresponding source",
        }.items():
            path = self.companion / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(value)
        shutil.copyfile(HERE / "launch.ps1", self.companion / "launch.ps1")
        self.launcher = c.file_digest(self.companion / "launch.ps1")
        manifest = {"schema": 1, "kind": "sc-vencord-companion", "entrypoint": "runtime/SC-Vencord.exe",
                    "profile": "SC/VencordCompanion/profile-v1", "status": "built-not-runtime-validated",
                    "lock": c.LOCK, "files": c.inventory(self.companion)}
        c.write_json(self.companion / "companion-manifest.json", manifest)
        self.manifest = c.file_digest(self.companion / "companion-manifest.json")
        self.write_native()

    def tearDown(self):
        self.temporary.cleanup()

    def write_native(self, include_pins=True):
        # A PE-shaped file tests parsing only. It is never launched.
        data = bytearray(512)
        data[:2] = b"MZ"
        struct.pack_into("<I", data, 60, 128)
        data[128:134] = b"PE\0\0\x64\x86"
        if include_pins:
            data[256:320] = self.manifest.encode()
            data[320:384] = self.launcher.encode()
        (self.package / "SC.exe").write_bytes(data)
        self.native = c.file_digest(self.package / "SC.exe")

    def check(self):
        return v.verify(self.package, self.native, self.manifest, self.launcher)

    def test_combined_exact_pair_checks_without_claiming_installer_support(self):
        result = self.check()
        self.assertTrue(result["verified"])
        self.assertFalse(result["installer_ready"])
        self.assertFalse(result["update_compatible"])
        self.assertFalse(result["publish_ready"])
        self.assertFalse(result["native"]["build_record_present"])
        c.write_json(self.package / "BUILD.json", {"name": "S;C", "executable_sha256": self.native})
        self.assertTrue(self.check()["native"]["build_record_present"])
        c.write_json(self.package / "BUILD.json", {"name": "S;C", "executable_sha256": "0" * 64})
        with self.assertRaisesRegex(ValueError, "BUILD.json"):
            self.check()

    def test_swapped_or_unpinned_native_and_tampered_companion_fail(self):
        with self.assertRaisesRegex(ValueError, "trusted build hash"):
            v.verify(self.package, "0" * 64, self.manifest, self.launcher)
        self.write_native(include_pins=False)
        with self.assertRaisesRegex(ValueError, "compile-time companion pins"):
            self.check()
        self.write_native()
        (self.companion / "runtime/SC-Vencord.exe").write_bytes(b"changed")
        with self.assertRaisesRegex(ValueError, "altered, incomplete"):
            self.check()

    def test_profiles_extras_and_release_gate_fail_without_package_writes(self):
        (self.package / "profile").mkdir()
        with self.assertRaisesRegex(ValueError, "profile"):
            self.check()
        (self.package / "profile").rmdir()
        before = c.inventory(self.package)
        report = self.root / "readiness.json"
        args = [sys.executable, str(HERE / "verify_combined.py"), str(self.package),
                "--native-sha256", self.native, "--manifest-sha256", self.manifest,
                "--launcher-sha256", self.launcher]
        run = subprocess.run(args + ["--report", str(report), "--require-installer-ready"], capture_output=True, timeout=10)
        self.assertEqual(run.returncode, 1)
        self.assertIn(b"native-only", run.stderr)
        self.assertFalse(json.loads(report.read_text())["installer_ready"])
        self.assertEqual(before, c.inventory(self.package))
        # Normalize '..' before enforcing that reports live outside the seal.
        sneaky = self.root / "unused" / ".." / "candidate" / "report.json"
        run = subprocess.run(args + ["--report", str(sneaky)], capture_output=True, timeout=10)
        self.assertEqual(run.returncode, 1)
        self.assertIn(b"outside the sealed candidate", run.stderr)
        self.assertEqual(before, c.inventory(self.package))


if __name__ == "__main__":
    unittest.main()
