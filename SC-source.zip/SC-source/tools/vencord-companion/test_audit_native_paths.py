"""Synthetic signature/redaction checks; never reads a real account or binary.
SPDX-License-Identifier: GPL-3.0-or-later
"""
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("sc_native_path_audit", HERE / "audit_native_paths.py")
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


class AuditTests(unittest.TestCase):
    def test_known_values_read_only_path_environment_and_never_emit_values(self):
        class PathsOnly(dict):
            def get(self, key, default=None):
                if key not in {"USERPROFILE", "USERNAME", "TEMP", "TMP"}:
                    raise AssertionError("Unexpected environment lookup")
                return super().get(key, default)
        env = PathsOnly(USERPROFILE=r"C:\Users\SyntheticPerson", USERNAME="SyntheticPerson",
                        TEMP=r"C:\Users\SYNTH~1\Temp", TMP=r"C:\Users\SYNTH~1\Temp")
        known = a.known_values(env, [r"D:\Build\SyntheticWorkspace"])
        data = b"C:/Users/SyntheticPerson/src/file.rs D:/Build/SyntheticWorkspace/crate.rs C:\\Users\\SYNTH~1\\Temp\\file"
        result = a.scan(data, known)
        self.assertEqual(result["sha256"], hashlib.sha256(data).hexdigest())
        self.assertGreater(result["pattern_counts"]["host_profile_path"]["utf8_or_ascii"], 0)
        self.assertGreater(result["pattern_counts"]["absolute_build_path"]["utf8_or_ascii"], 0)
        self.assertGreater(result["pattern_counts"]["host_temp_path"]["utf8_or_ascii"], 0)
        rendered = json.dumps(result)
        for private in ("SyntheticPerson", "SYNTH~1", "SyntheticWorkspace", "C:/Users"):
            self.assertNotIn(private, rendered)

    def test_ascii_and_both_utf16_alignments_find_formats_without_echo(self):
        token = "ghp_" + "A" * 36  # Deliberately synthetic format, not a credential.
        text = r"C:\Users\OtherSynthetic\crate.rs " + token
        for data, encoding in ((text.encode(), "utf8_or_ascii"), (text.encode("utf-16le"), "utf16le"),
                               (b"!" + text.encode("utf-16le"), "utf16le")):
            result = a.scan(data, {})
            self.assertEqual(result["pattern_counts"]["github_token_format"][encoding], 1)
            self.assertGreater(result["pattern_counts"]["generic_windows_profile_path"][encoding], 0)
            self.assertNotIn(token, json.dumps(result))
            self.assertNotIn("OtherSynthetic", json.dumps(result))

    def test_public_pem_and_generic_headers_are_not_private_containers(self):
        body = base64.b64encode(b"0" + b"synthetic" * 8)
        public = b"-----BEGIN PUBLIC KEY-----\n" + body + b"\n-----END PUBLIC KEY-----"
        literal = b"-----BEGIN PRIVATE KEY-----"
        self.assertEqual(a.scan(public + literal, {})["pattern_counts"]["private_pem_container_format"]["utf8_or_ascii"], 0)
        private = b"-----BEGIN PRIVATE KEY-----\n" + body[:64] + b"\n" + body[64:] + b"\n-----END PRIVATE KEY-----"
        self.assertEqual(a.scan(private, {})["pattern_counts"]["private_pem_container_format"]["utf8_or_ascii"], 1)
        self.assertEqual(a.scan(b"!" + private.decode().encode("utf-16le"), {})["pattern_counts"]["private_pem_container_format"]["utf16le"], 1)

    def test_cli_refuses_non_pe_and_redacts_private_error_path(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "NeverPrintThisPrivateFile.txt"
            path.write_text("not a PE")
            result = subprocess.run([sys.executable, str(HERE / "audit_native_paths.py"), str(path)], capture_output=True, timeout=10)
            self.assertEqual(result.returncode, 2)
            self.assertNotIn(b"NeverPrintThisPrivateFile", result.stdout + result.stderr)
            self.assertNotIn(str(path.parent).encode(), result.stdout + result.stderr)
            self.assertEqual(json.loads(result.stdout)["error_count"], 1)
            # Positive PE-shaped input exercises the CLI without executing it.
            data = bytearray(256)
            data[:2] = b"MZ"
            struct.pack_into("<I", data, 60, 128)
            data[128:134] = b"PE\0\0\x64\x86"
            path.write_bytes(data)
            result = subprocess.run([sys.executable, str(HERE / "audit_native_paths.py"), str(path)], capture_output=True, timeout=10)
            self.assertEqual(result.returncode, 0)
            self.assertEqual(json.loads(result.stdout)["matched_categories"], 0)
            self.assertEqual(json.loads(result.stdout)["sha256"], hashlib.sha256(data).hexdigest())
            self.assertNotIn(str(path).encode(), result.stdout + result.stderr)


if __name__ == "__main__":
    unittest.main()
