# Combined Windows package preparation

`verify_combined.py` is a read-only local preparation check. It never installs,
updates, launches, downloads, deletes or edits the package. The existing pinned
companion's manifest and launcher are unchanged by this check.

Expected sibling layout:

```text
SC.exe
BUILD.json                 # required later by production installation
vencord-companion/
    companion-manifest.json
    launch.ps1
    runtime/SC-Vencord.exe
    licenses/...
    sources/...
```

Pass hashes from the trusted build record. The native executable must match its
expected hash and contain both expected compile-time companion pins. The latter
checks build configuration, not the implementation of the Rust launcher. An
executable hash calculated from an arbitrary file is not release provenance.
The verifier checks Windows x64 PE headers, exact sibling names, the companion's
complete hash inventory, licences and corresponding-source presence, and any
native `BUILD.json` supplied. It rejects links, package-contained profiles,
unrecognized root files and reports written inside the candidate. Memory and
file-count limits remain bounded; files are hashed in chunks.

```powershell
python tools/vencord-companion/verify_combined.py C:/build/combined `
  --native-sha256 <trusted-native-build-hash> `
  --manifest-sha256 <compile-time-companion-manifest-hash> `
  --launcher-sha256 <compile-time-launcher-hash> `
  --report C:/build/combined-check.json
```

This preview verifier reports package integrity only. Its
`--require-installer-ready` flag exits nonzero because the verifier itself
does not exercise installation or updates. See the production package
contract below for the separate installer verification.

## Separate local portable archive

`portable.py create` is a concrete packaging path for reviewing the paired
applications without extending the installer or updater. It takes the same
three expected hashes, verifies the candidate, and writes only a **new** ZIP
outside that candidate. It uses fixed timestamps, permissions and sorted entry
order. Repeated packaging of identical bytes on the same Python/zlib toolchain
produces identical ZIP bytes, independent of source file timestamps.

```powershell
python tools/vencord-companion/portable.py create `
  --candidate C:/build/combined --output C:/build/SC-combined-local-preview.zip `
  --native-sha256 <trusted-native-build-hash> `
  --manifest-sha256 <compile-time-companion-manifest-hash> `
  --launcher-sha256 <compile-time-launcher-hash>
python tools/vencord-companion/portable.py verify C:/build/SC-combined-local-preview.zip `
  --native-sha256 <trusted-native-build-hash> `
  --manifest-sha256 <compile-time-companion-manifest-hash> `
  --launcher-sha256 <compile-time-launcher-hash>
```

The archive contains `SC-windows-x64-local/` with the unchanged paired payload,
plus `SC-PORTABLE.json` and a local-preview notice beside it. The portable
manifest binds all payload hashes and both companion pins and explicitly says
that installer, update, runtime-validation and publication readiness are false.
The companion's own sealed manifest, launcher, licences and source ZIPs remain
byte-for-byte unchanged. The tool does not synthesize a production `BUILD.json`
or rewrite release assets, and does not claim native source/provenance review.

Before transferring a candidate outside the build machine, compile the native
binary with the release path mappings, then run `audit_native_paths.py` on that
exact executable. The scanner reports potential embedded paths and credential
formats without printing the matched text. Keep development outputs containing
build machine paths local. A clean scan is only one part of provenance review.

Verification reads the ZIP without extracting it. It rejects unsafe names,
links, duplicates/case collisions, encrypted files, changed or extra payload,
wrong compile-time pins, profile folders and oversized entries/archives. During
creation it hashes each file while streaming it and checks the source inventory
again afterward. Interrupted/failed outputs are retained for inspection; rerun
with a new output name. Never rename this local archive to `SC-windows-x64.zip`
or point the existing installer/updater at it.

## S;C 0.3.0.13 release packages

The combined Windows release includes the native client and companion in
`SC-windows-x64.zip`. The bootstrapper installs both together. A release
eligibility check in the native client accepts the companion directory
alongside the existing native files.

`BUILD.json` records schema 1 for `components.vencord_companion`, with
the companion manifest and launcher SHA-256 digests. The installer and
updater verify the component's complete inventory, package hashes and Windows
entry point before swapping the installation. Native S;C verifies its
compile-time manifest and launcher pins again before opening the companion.

Both programs live in the same replaceable directory. If the installed
companion is running, setup and the app updater require it to close first.
An update keeps both programs together through rollback. Once a combined
copy is installed, an ordinary update preserves the bundled companion.

The companion opens only when selected from the Plugins page. Its independent
login and settings live in `%LOCALAPPDATA%/SC/VencordCompanion/profile-v1`
outside the installation directory. Release packaging carries the exact patched
Vencord and Vesktop sources and their licences. The local portable verifier
above still produces only a preview and does not exercise installation.

## Native candidate privacy signature check

`audit_native_paths.py <workspace-candidate.exe> [--build-root <absolute-build-root>]`
reads exactly one regular Windows x64 PE, capped at 512 MiB. It never launches
the executable or reads profiles, settings, installed applications or environment
credential variables. Only the known profile/username/temp environment strings
and specified build roots are used as match inputs. Output contains category,
encoding and counts, never matching strings or filesystem paths. IO/argument
errors are redacted. Exit 0 means no configured patterns matched; exit 1 reports
matches; exit 2 means the scan did not complete.

The scanner checks known paths, generic user-profile paths, selected credential
formats and plausible complete private PEM containers in ASCII/UTF-8 and both
UTF-16LE alignments. Generic header literals and public PEM/certificates do not
count as private keys. False positives and unknown formats remain possible:
zero counts do not prove absence of secrets or private information, and this
scan is not a substitute for trusted build hashes or source provenance.
