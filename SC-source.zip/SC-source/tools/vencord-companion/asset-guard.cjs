// SPDX-License-Identifier: GPL-3.0-or-later
// Shared by the patched Vesktop loader and the offline Node tests.
"use strict";
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

function reject(message) { throw new Error("S;C companion assets: " + message); }
function checkDirectory(directory) {
    const absolute = path.resolve(directory);
    // Refuse junctions/symlinks at every level, not just the final file.
    for (let at = absolute; ; at = path.dirname(at)) {
        if (fs.lstatSync(at).isSymbolicLink()) reject("linked directory");
        if (path.dirname(at) === at) break;
    }
    if (fs.realpathSync(absolute).toLowerCase() !== absolute.toLowerCase()) reject("redirected directory");
    return absolute;
}
function readVerified(directory, pins, name) {
    const base = checkDirectory(directory);
    if (!Object.hasOwn(pins, name) || !/^[a-zA-Z0-9_.-]+$/.test(name)) reject("unlisted asset");
    const pin = pins[name];
    if (!Number.isSafeInteger(pin.size) || pin.size < 1 || pin.size > 16 * 1024 * 1024 || !/^[a-f0-9]{64}$/.test(pin.sha256)) reject("invalid pin");
    const file = path.join(base, name);
    const stat = fs.lstatSync(file);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.size !== pin.size) reject("invalid asset size or type");
    const data = fs.readFileSync(file);
    if (data.length !== pin.size || crypto.createHash("sha256").update(data).digest("hex") !== pin.sha256) reject("asset hash mismatch");
    return data;
}
function verifyAll(directory, pins) {
    const base = checkDirectory(directory);
    const names = Object.keys(pins).sort();
    if (names.length !== 5 || JSON.stringify(fs.readdirSync(base).sort()) !== JSON.stringify(names)) reject("unexpected asset inventory");
    for (const name of names) readVerified(base, pins, name);
    return true;
}
module.exports = { readVerified, verifyAll };
