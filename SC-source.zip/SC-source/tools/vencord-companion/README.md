# Pinned Vencord companion tooling

The companion runs official Vencord plugins in a separate Electron process with
its own Discord login. S;C opens it when you choose **Open companion** in the
Plugins page. The companion uses its own profile and adds Chromium memory while
open. Both processes run as the current Windows user.

The current tool has no network downloader. `prepare`, `stage`, `verify`, tests,
and the launcher's default verification mode are offline. Only an explicitly
requested `build --allow-dependency-downloads` invokes package-manager install
and build commands. It never launches Electron, installs an application,
publishes, signs, or uses a live account.

## What is implemented

- Exact SHA-256 pins for source archives at the commits in
  `upstream-lock.json`; unsafe archive paths, links, case aliases, Windows
  device names, oversize files and old output directories are rejected.
- Exact-anchor patches to upstream Vesktop. Packaged Vencord assets must match
  hashes embedded in the compiled main process. Missing, changed or extra
  assets fail closed. Preload/renderer IPC reads recheck their hashes.
- No latest-release download, repair download, updater check/install, custom
  Vencord directory override, first-run import, protocol-handler takeover,
  autostart, background RPC or tray residence. The loader uses
  `process.resourcesPath/sc-vencord`, never a mutable settings directory.
- The pinned Windows Vesktop target bundles 147 optional upstream plugins and
  Vencord's API/core modules. The lock records included sources, their Vencord
  display names, and excluded sources with reasons. Open **Settings → Plugins**
  in the companion to enable the included Vencord plugins.
- Native helper discovery admits DirectFileDownload and Translate. The main
  process checks that each call comes from a top-level Discord frame and that
  its plugin is enabled. VoiceMessages uses the web recorder in Vesktop.
  ShowConnections and SpotifyControls take their ordinary link paths.
  UserVoiceShow continues to require Discord's channel-view permission.
- An explicit build runner checks pinned Node and both pnpm versions, uses
  frozen lockfiles, disables Vencord's updater, records exact source/file
  inventories and generates the embedded Vencord asset pins before Vesktop is
  built. It does not auto-install Node/pnpm or accept a stock Vesktop binary.
- Staging keeps upstream licences and exact corresponding patched source ZIPs.
  A launcher checks every package file against a required, externally supplied
  manifest hash before starting. `-Launch` is mandatory to start anything.
  Its environment is restricted to OS paths plus the dedicated profile.
- The profile is fixed to `%LOCALAPPDATA%\SC\VencordCompanion\profile-v1`.
  Existing nonempty unmarked directories and junctions are rejected. Normal
  launches reuse only that companion's marked profile; closing it exits instead
  of leaving a tray process. Native S;C is independent.

## Reproduce preparation and checks

Obtain the two source ZIPs from the URLs in `upstream-lock.json` using a trusted
download process. This repository contains neither those archives nor binaries.
The archive hashes are mandatory; a moved/rewritten upstream archive needs a new
review, not a switch to turn verification off.

```powershell
python tools/vencord-companion/companion.py prepare `
  --vesktop-archive C:/build-inputs/vesktop.zip `
  --vencord-archive C:/build-inputs/vencord.zip `
  --output C:/build-work/sc-companion

python -m unittest discover -s tools/vencord-companion -p 'test_*.py' -v
# Optional real-source integration test, still offline and no runtime execution:
$env:SC_COMPANION_SOURCE_ARCHIVES = 'C:/build-inputs'
python -m unittest discover -s tools/vencord-companion -p 'test_*.py' -v
```

`prepared.json` records every before/after patch hash and the complete source
inventory. Build steps reject subsequent source edits or new source files.
The fixed timestamp is reproducibility input, not a claim about the release
date. Two independent builds still need comparison before reproducible bytes
can be claimed.

## Explicit local build and stage

Requires Windows x64, Node **v22.14.0**, Vencord's pnpm **12.15.0**, and Vesktop's
pnpm **12.16.1** already available as distinct executables. Downloading/installing
these tools is not part of this command. Dependency installs/build hooks execute
the pinned upstream source and locked dependencies; run them in a clean build
environment without credentials.

```powershell
python tools/vencord-companion/companion.py build `
  --workspace C:/build-work/sc-companion `
  --pnpm-vencord C:/build-tools/pnpm-12.15.0/pnpm.exe `
  --pnpm-vesktop C:/build-tools/pnpm-12.16.1/pnpm.exe `
  --allow-dependency-downloads

python tools/vencord-companion/companion.py stage `
  --workspace C:/build-work/sc-companion `
  --output C:/build-output/sc-companion-candidate
python tools/vencord-companion/companion.py verify C:/build-output/sc-companion-candidate
```

For a repo-local tool bootstrap, install each exact `pnpm` version under a
separate `npm --prefix` directory with `--ignore-scripts --no-audit --no-fund`.
Check its package-lock integrity against `upstream-lock.json`. On Windows x64,
pass the already-installed
`node_modules/@pnpm/exe.win32-x64/pnpm.exe` directly; this avoids a system-wide
install and the extensionless wrapper that needs pnpm's install script.

The staged manifest deliberately says `built-not-runtime-validated`. Integrity
verification is not a smoke test or signature. Do not distribute it until native
build, offline runtime startup/failure behavior, independent login, clean exit,
and update/installer handling have been verified. Build output directories must
be new: failed/old candidates are preserved rather than silently overwritten.

## Launch and package verification

The native application/installer must supply the manifest SHA-256 from trusted
release metadata, not calculate and blindly trust an arbitrary local manifest.
The launcher accepts no arbitrary executable, URL, token, profile or forwarded
arguments. Without `-Launch`, it verifies and exits without profile writes.

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:/SC-Companion/launch.ps1 `
  -ExpectedManifestSha256 <verified-release-manifest-sha256>
# Explicit user choice only, after the runtime validation described above:
# Add -Launch to the same command.
```

Provide both manifest and launcher hashes to the S;C build. Its companion
button checks the companion directory beside the executable. Hash verification
uses trusted build metadata and covers the packaged files before startup.

Discord still serves its web application remotely, so pinned local patches can
break when Discord changes. Upstream also excludes plugins by host (browser,
official desktop, Vesktop); no single host supports every catalog entry. The
prepared runtime is GPL-3.0-or-later, including the upstream notices. This tool
retains the copyright headers of modified upstream files and the source needed
to reproduce those changes.
