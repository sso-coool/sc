"""Portable local archive checks with synthetic PE-shaped files only.
SPDX-License-Identifier: GPL-3.0-or-later
"""
import importlib.util
import os
from pathlib import Path
import unittest
import zipfile

HERE = Path(__file__).resolve().parent


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, HERE / file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


p = load("sc_portable", "portable.py")
fixtures = load("sc_portable_fixtures", "test_combined.py")


class PortableTests(unittest.TestCase):
    def setUp(self):
        self.fixture = fixtures.CombinedTests()
        self.fixture.setUp()
        self.root = self.fixture.root
        self.candidate = self.fixture.package
        self.pins = self.fixture.native, self.fixture.manifest, self.fixture.launcher

    def tearDown(self):
        self.fixture.tearDown()

    def test_deterministic_archives_preserve_sealed_payload_and_external_pins(self):
        before = p.c.inventory(self.candidate)
        one, two = self.root / "one.zip", self.root / "two.zip"
        a = p.create(self.candidate, one, *self.pins)
        for file in self.candidate.rglob("*"):
            if file.is_file():
                os.utime(file, (1000000000, 1000000000))
        b = p.create(self.candidate, two, *self.pins)
        self.assertEqual(a["archive_sha256"], b["archive_sha256"])
        self.assertFalse(a["publish_ready"])
        self.assertFalse(a["update_compatible"])
        self.assertEqual(before, p.c.inventory(self.candidate))
        with zipfile.ZipFile(one) as z:
            for name in before:
                self.assertEqual(z.read(p.PREFIX + name), (self.candidate / name).read_bytes())
            self.assertIn(p.MANIFEST, z.namelist())
        with self.assertRaisesRegex(ValueError, "expected pins"):
            p.verify(one, "0" * 64, *self.pins[1:])

    def test_tampering_unknown_entries_and_traversal_are_rejected_without_extraction(self):
        source = self.root / "source.zip"
        p.create(self.candidate, source, *self.pins)
        for name, change in (("changed", "payload"), ("extra", "unexpected.js"), ("escape", "../outside")):
            target = self.root / (name + ".zip")
            with zipfile.ZipFile(source) as old, zipfile.ZipFile(target, "w") as new:
                for info in old.infolist():
                    data = old.read(info)
                    if change == "payload" and info.filename == p.PREFIX + "vencord-companion/runtime/SC-Vencord.exe":
                        data += b"changed"
                    new.writestr(info, data)
                if change != "payload":
                    new.writestr(p.entry(change), b"unreviewed")
            with self.assertRaises(ValueError):
                p.verify(target, *self.pins)
        self.assertFalse((self.root / "outside").exists())

    def test_existing_output_or_profile_in_candidate_is_never_packaged(self):
        archive = self.root / "keep.zip"
        archive.write_bytes(b"preserved candidate")
        with self.assertRaises(FileExistsError):
            p.create(self.candidate, archive, *self.pins)
        self.assertEqual(archive.read_bytes(), b"preserved candidate")
        with self.assertRaisesRegex(ValueError, "outside"):
            p.create(self.candidate, self.candidate / "inside.zip", *self.pins)
        (self.candidate / "profile").mkdir()
        with self.assertRaisesRegex(ValueError, "profile"):
            p.create(self.candidate, self.root / "bad.zip", *self.pins)
        self.assertFalse((self.root / "bad.zip").exists())


if __name__ == "__main__":
    unittest.main()
