#!/usr/bin/env python3
"""Bounded, read-only signature scan of one explicitly supplied native candidate.

Only category/count/encoding information and the scanned bytes' SHA-256 are
emitted. A clean scan is not proof that unknown credentials, private information
or malicious code are absent.
No account/profile files, environment credentials or other binaries are read.
SPDX-License-Identifier: GPL-3.0-or-later
"""
import argparse
import base64
import binascii
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import struct
import sys

MAX_BYTES = 512 * 1024 * 1024
SECRET_PATTERNS = {
    "github_token_format": rb"\b(?:gh[pousr]_[A-Za-z0-9]{30,255}|github_pat_[A-Za-z0-9_]{50,255})\b",
    "gitlab_token_format": rb"\bglpat-[A-Za-z0-9_-]{20,200}\b",
    "aws_access_key_format": rb"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b",
    "discord_token_format": rb"\b(?:mfa\.[A-Za-z0-9_-]{60,100}|[MNO][A-Za-z0-9_-]{19,31}\.[A-Za-z0-9_-]{6}\.[A-Za-z0-9_-]{27,110})\b",
    "openai_key_format": rb"\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{40,220}\b",
    "slack_token_format": rb"\bxox[baprs]-[A-Za-z0-9-]{24,250}\b",
}
WINDOWS_PROFILE = rb"(?i)[a-z]:[\\/]+users[\\/]+[^\\/\x00\r\n]{1,80}[\\/]"
UNIX_PROFILE = rb"/(?:home|Users)/[^/\x00\r\n]{1,80}/"
PRIVATE_PEM = (
    rb"-----BEGIN (?P<label>(?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY)-----\r?\n"
    rb"(?P<body>(?:[A-Za-z0-9+/]{1,80}={0,2}\r?\n){1,200})"
    rb"-----END (?P=label)-----"
)


def known_values(environment, build_roots):
    # Deliberately never enumerate the environment or read token/key variables.
    result = {
        "host_profile_path": [environment.get("USERPROFILE", "")],
        "host_username": [environment.get("USERNAME", "")],
        "host_temp_path": [environment.get("TEMP", ""), environment.get("TMP", "")],
        "absolute_build_path": [str(root) for root in build_roots],
    }
    return {kind: sorted({variant.casefold() for value in values if len(value) >= 3
                         for variant in (value, value.replace("\\", "/"), value.replace("/", "\\"))})
            for kind, values in result.items()}


def pem_count(data, wide=False):
    expression = PRIVATE_PEM.decode("ascii") if wide else PRIVATE_PEM
    count = 0
    for match in re.finditer(expression, data):
        body = match.group("body")
        if wide:
            body = body.encode("ascii")
        try:
            decoded = base64.b64decode(re.sub(rb"\s", b"", body), validate=True)
        except (ValueError, binascii.Error):
            continue
        # Generic header literals and public PEM/certificates do not count.
        # This checks a plausible container signature, not cryptographic validity.
        if len(decoded) >= 32 and (decoded.startswith(b"0") or decoded.startswith(b"openssh-key-v1\0")):
            count += 1
    return count


def scan(data, known):
    counts = {kind: {"utf8_or_ascii": 0, "utf16le": 0} for kind in
              (*known, "generic_windows_profile_path", "generic_unix_profile_path", *SECRET_PATTERNS, "private_pem_container_format")}
    lower = data.lower()
    for kind, values in known.items():
        counts[kind]["utf8_or_ascii"] = sum(lower.count(value.encode("utf-8")) for value in values)
    counts["generic_windows_profile_path"]["utf8_or_ascii"] = sum(1 for _ in re.finditer(WINDOWS_PROFILE, data))
    counts["generic_unix_profile_path"]["utf8_or_ascii"] = sum(1 for _ in re.finditer(UNIX_PROFILE, data))
    for kind, pattern in SECRET_PATTERNS.items():
        counts[kind]["utf8_or_ascii"] = sum(1 for _ in re.finditer(pattern, data))
    counts["private_pem_container_format"]["utf8_or_ascii"] = pem_count(data)
    del lower
    # Both starting alignments matter for PE sections. Process each separately
    # rather than retaining two decoded copies alongside the binary.
    for offset in (0, 1):
        wide = data[offset:].decode("utf-16le", errors="ignore")
        lower = wide.casefold()
        for kind, values in known.items():
            counts[kind]["utf16le"] += sum(lower.count(value) for value in values)
        del lower
        counts["generic_windows_profile_path"]["utf16le"] += sum(1 for _ in re.finditer(WINDOWS_PROFILE.decode("ascii"), wide))
        counts["generic_unix_profile_path"]["utf16le"] += sum(1 for _ in re.finditer(UNIX_PROFILE.decode("ascii"), wide))
        for kind, pattern in SECRET_PATTERNS.items():
            counts[kind]["utf16le"] += sum(1 for _ in re.finditer(pattern.decode("ascii"), wide))
        counts["private_pem_container_format"]["utf16le"] += pem_count(wide, wide=True)
        del wide
    return {"scanned_bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(), "pattern_counts": counts,
            "matched_categories": sum(any(row.values()) for row in counts.values()),
            "limitations": "Pattern counts only; zero matches do not prove absence of secrets or private data."}


def read_candidate(candidate):
    metadata = candidate.lstat()
    if not stat.S_ISREG(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode) or getattr(metadata, "st_file_attributes", 0) & 0x400:
        raise ValueError("not_regular_candidate")
    if not 128 <= metadata.st_size <= MAX_BYTES:
        raise ValueError("candidate_size_out_of_bounds")
    with candidate.open("rb") as source:
        opened = os.fstat(source.fileno())
        if (opened.st_ino, opened.st_size, opened.st_mtime_ns) != (metadata.st_ino, metadata.st_size, metadata.st_mtime_ns):
            raise ValueError("candidate_changed_before_read")
        header = source.read(64)
        if len(header) != 64 or header[:2] != b"MZ":
            raise ValueError("not_pe_candidate")
        offset = struct.unpack_from("<I", header, 60)[0]
        if offset > min(1024 * 1024, metadata.st_size - 26):
            raise ValueError("invalid_pe_header")
        source.seek(offset)
        if source.read(6) != b"PE\0\0\x64\x86":
            raise ValueError("not_windows_x64_candidate")
        source.seek(0)
        data = source.read(metadata.st_size + 1)
    after = candidate.lstat()
    if len(data) != metadata.st_size or (after.st_size, after.st_mtime_ns, after.st_ino) != (metadata.st_size, metadata.st_mtime_ns, metadata.st_ino):
        raise ValueError("candidate_changed_during_read")
    return data


class Parser(argparse.ArgumentParser):
    def error(self, message):
        # argparse's default includes offending argument values/paths.
        self.exit(2, "Invalid command line; use --help.\n")


def main():
    parser = Parser(prog="audit_native_paths.py", description=__doc__)
    parser.add_argument("candidate", type=Path, help="One final workspace candidate PE; never a profile or installed-app directory")
    parser.add_argument("--build-root", type=Path, action="append", default=[], help="Additional known absolute build path used for matching only; never traversed")
    args = parser.parse_args()
    try:
        roots = [Path(__file__).resolve().parents[2], *(Path(os.path.abspath(root)) for root in args.build_root)]
        known = known_values(os.environ, roots)
        result = scan(read_candidate(args.candidate), known)
    except Exception:
        # Do not print exception messages: IO errors can contain private paths.
        print(json.dumps({"error_count": 1, "scan_completed_count": 0}))
        return 2
    print(json.dumps(result, indent=2))
    return 1 if result["matched_categories"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
