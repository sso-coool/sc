// Rebuild src/ui/vencord_companion_metadata.json from a sealed companion directory.
// Usage: node generate-plugin-metadata.cjs <package> <manifest SHA-256> [--check]
const assert = require("node:assert/strict");
const { createHash, webcrypto } = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const rendererPath = "runtime/resources/sc-vencord/vencordDesktopRenderer.js";
const outputPath = path.resolve(__dirname, "../../src/ui/vencord_companion_metadata.json");
const sha256 = bytes => createHash("sha256").update(bytes).digest("hex");
const noop = () => {};

// The smoke harness supplies the renderer's startup environment. It never
// loads Discord's page, connects to a network, or opens the companion profile.
function loadRenderer(renderer, plugins) {
    const warnings = [];
    const storage = new Map();
    const node = {
        style: { setProperty: noop },
        append: noop,
        setAttribute: noop,
        classList: { add: noop, remove: noop, toggle: noop },
    };
    const sandbox = {
        console: {
            log: noop,
            debug: noop,
            info: noop,
            warn: (...args) => warnings.push(args),
            error: (...args) => warnings.push(args),
        },
        document: {
            addEventListener: noop,
            createElement: () => ({ ...node }),
            getElementById: () => null,
            querySelector: () => null,
            head: { ...node },
        },
        navigator: { userAgent: "Windows Vencord metadata", language: "en-US", platform: "Win32" },
        location: new URL("https://discord.com/app"),
        localStorage: {
            getItem: key => storage.get(key) ?? null,
            setItem: (key, value) => storage.set(key, value),
            removeItem: key => storage.delete(key),
        },
        sessionStorage: { getItem: () => null, setItem: noop, removeItem: noop },
        crypto: webcrypto,
        URL,
        URLSearchParams,
        TextEncoder,
        TextDecoder,
        setTimeout: noop,
        clearTimeout: noop,
        setInterval: noop,
        clearInterval: noop,
        addEventListener: noop,
        matchMedia: () => ({ matches: false, addEventListener: noop }),
        VesktopNative: { app: {} },
        VencordNative: {
            settings: { get: () => ({ plugins }), set: noop },
            themes: { getSystemValues: async () => ({}) },
            quickCss: {
                addChangeListener: noop,
                addThemeChangeListener: noop,
                get: async () => "",
            },
            native: { getRendererCss: async () => "", onRendererCssUpdate: noop },
            pluginHelpers: { DirectFileDownload: {}, Translate: {} },
        },
    };
    sandbox.window = sandbox;
    sandbox.self = sandbox;
    vm.runInNewContext(renderer, sandbox, { timeout: 4000, filename: "vencordDesktopRenderer.js" });
    const unresolved = warnings.flat().filter(warning => String(warning).includes("unresolved dependency"));
    assert.equal(unresolved.length, 0, unresolved.join("\n"));
    assert.ok(sandbox.Vencord?.Plugins?.plugins, "missing Vencord plugin registry");
    return sandbox.Vencord;
}

function dependencies(plugin) {
    // Pinned Vencord src/api/PluginManager.ts, initPluginManager. The manager
    // enables the APIs for these hooks without adding them to p.dependencies.
    const names = [...(plugin.dependencies ?? [])];
    if (plugin.commands?.length) names.push("CommandsAPI");
    if (plugin.onBeforeMessageEdit || plugin.onBeforeMessageSend || plugin.onMessageClick) {
        names.push("MessageEventsAPI");
    }
    if (plugin.chatBarButton) names.push("ChatInputButtonAPI");
    if (plugin.renderMemberListDecorator) names.push("MemberListDecoratorsAPI");
    if (plugin.renderMessageAccessory) names.push("MessageAccessoriesAPI");
    if (plugin.renderMessageDecoration) names.push("MessageDecorationsAPI");
    if (plugin.messagePopoverButton) names.push("MessagePopoverAPI");
    // BadgeAPI uses its own hook, which adds no dependency on another plugin.
    if (plugin.userProfileBadge && plugin.name !== "BadgeAPI") names.push("BadgeAPI");
    return [...new Set(names)];
}

function main(packageRoot, expectedManifest, mode) {
    assert(
        packageRoot && /^[0-9a-f]{64}$/i.test(expectedManifest) && [undefined, "--check"].includes(mode),
        "Usage: node generate-plugin-metadata.cjs <package> <manifest SHA-256> [--check]",
    );
    const manifestBytes = fs.readFileSync(path.join(packageRoot, "companion-manifest.json"));
    assert.equal(sha256(manifestBytes), expectedManifest.toLowerCase(), "companion manifest differs from release pin");
    const manifest = JSON.parse(manifestBytes);
    assert.equal(manifest.schema, 1);
    assert.equal(manifest.kind, "sc-vencord-companion");
    const lock = JSON.parse(fs.readFileSync(path.join(__dirname, "upstream-lock.json"), "utf8"));
    assert.deepEqual(manifest.lock, lock, "companion lock differs from source lock");
    const renderer = fs.readFileSync(path.join(packageRoot, rendererPath));
    const rendererHash = sha256(renderer);
    assert.deepEqual(manifest.files[rendererPath], { sha256: rendererHash, size: renderer.length });

    const code = renderer.toString("utf8");
    const upstream = loadRenderer(code, {});
    const registry = upstream.Plugins.plugins;
    const optional = new Set(Object.values(lock.plugins));
    for (const name of optional) {
        assert(Object.hasOwn(registry, name), "missing registry entry " + name);
    }

    const plugins = Object.fromEntries(Object.keys(registry).sort().map(name => {
        const plugin = registry[name];
        assert.equal(plugin.name, name);
        const required = plugin.required === true;
        const pluginDependencies = dependencies(plugin);
        for (const dependency of pluginDependencies) {
            assert(Object.hasOwn(registry, dependency), name + " has unresolved dependency " + dependency);
        }
        return [name, {
            // Pinned Vencord src/api/Settings.ts derives this default before
            // the manager enables APIs required by the current plugin choices.
            default_enabled: required || plugin.enabledByDefault === true,
            required,
            internal: !optional.has(name) || plugin.hidden === true,
            dependencies: pluginDependencies,
        }];
    }));

    // Exercise one direct patch and one implicit API in the packaged renderer.
    const enabled = loadRenderer(code, { BetterGifPicker: { enabled: true }, ClearURLs: { enabled: true } });
    assert(enabled.Plugins.isPluginEnabled("BetterGifPicker"));
    assert(enabled.WebpackPatcher.patches.some(patch => patch.plugin === "BetterGifPicker"));
    assert(!upstream.Plugins.isPluginEnabled("ClearURLs"));
    assert(enabled.Plugins.isPluginEnabled("MessageEventsAPI"));
    assert(plugins.ClearURLs.dependencies.includes("MessageEventsAPI"));

    const generated = JSON.stringify({
        schema: 1,
        renderer_sha256: rendererHash,
        plugins,
    }, null, 2) + "\n";
    if (mode === "--check") {
        assert.equal(fs.readFileSync(outputPath, "utf8"), generated, "companion plugin metadata needs regeneration");
    } else {
        fs.writeFileSync(outputPath, generated);
    }
    console.log(Object.keys(plugins).length + " plugins verified, including " + optional.size + " catalog entries");
}

main(...process.argv.slice(2));
