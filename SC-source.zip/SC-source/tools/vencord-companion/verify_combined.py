#!/usr/bin/env python3
"""Read-only gate for a native S;C candidate plus its pinned companion.

This is deliberately not an installer. It does not make the current native-only
updater compatible with companions or attest a public release build.
SPDX-License-Identifier: GPL-3.0-or-later
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import struct
import sys

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("sc_companion_packaging", HERE / "companion.py")
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)

ROOT_FILES = {"SC.exe", "BUILD.json", "SC.ico", "LICENSE.txt", "THIRD-PARTY.json", "SOURCE.txt", "README.txt"}
ROOT_DIRS = {"licenses", "vencord-companion"}
BLOCKERS = [
    "Native updater directory validation does not admit a companion.",
    "Installer and updater do not verify companion pins or preserve explicit component choice.",
    "Directory replacement does not coordinate a running companion or its rollback.",
    "The current release ZIP and setup wizard contain only the native component.",
    "Companion GUI/login/plugin compatibility has not been validated.",
]


def pin(value):
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value):
        c.fail("Expected pins must be lowercase SHA-256 values from the trusted build/release record")
    return value


def check_native(path, expected, manifest, launcher):
    size = c.regular(path).st_size
    if size < 128 or size > 512 * 1024 * 1024:
        c.fail("Native executable size is invalid")
    with path.open("rb") as stream:
        header = stream.read(64)
        if header[:2] != b"MZ":
            c.fail("Native entrypoint is not a PE executable")
        offset = struct.unpack_from("<I", header, 60)[0]
        if offset > size - 26:
            c.fail("Invalid native PE header offset")
        stream.seek(offset)
        if stream.read(6) != b"PE\0\0\x64\x86":
            c.fail("Native entrypoint is not Windows x64")
        stream.seek(0)
        found = set()
        tail = b""
        needles = {manifest.encode(), launcher.encode()}
        while block := stream.read(256 * 1024):
            data = tail + block
            found.update(needle for needle in needles if needle in data)
            tail = data[-63:]
    if found != needles:
        c.fail("Native executable does not contain both expected compile-time companion pins")
    if c.file_digest(path) != expected:
        c.fail("Native executable differs from the trusted build hash")
    return size


def verify(package, native_sha256, manifest_sha256, launcher_sha256):
    native_sha256, manifest_sha256, launcher_sha256 = map(pin, (native_sha256, manifest_sha256, launcher_sha256))
    c.no_links(package)
    children = list(package.iterdir())
    if len(children) > len(ROOT_FILES) + len(ROOT_DIRS):
        c.fail("Unexpected combined package root entries")
    for child in children:
        c.no_links(child)
        if child.is_dir():
            if child.name not in ROOT_DIRS:
                c.fail("Unrecognized directory or profile in combined package")
        elif child.name not in ROOT_FILES:
            c.fail("Unrecognized file in combined package")

    companion = package / "vencord-companion"
    manifest_path, launcher_path = companion / "companion-manifest.json", companion / "launch.ps1"
    if c.regular(manifest_path).st_size > 2 * 1024 * 1024 or c.regular(launcher_path).st_size > 64 * 1024:
        c.fail("Companion manifest/launcher size is invalid")
    if c.file_digest(manifest_path) != manifest_sha256 or c.file_digest(launcher_path) != launcher_sha256:
        c.fail("Companion manifest/launcher differ from the trusted native-build pins")
    result = c.verify(companion)
    manifest = json.loads(manifest_path.read_text())
    if manifest.get("profile") != "SC/VencordCompanion/profile-v1":
        c.fail("Companion profile is not the isolated fixed profile")
    files = manifest["files"]
    for required in ("licenses/vencord-LICENSE", "licenses/vesktop-LICENSE",
                     "sources/vencord-source.zip", "sources/vesktop-source.zip"):
        if required not in files:
            c.fail("Companion is missing its licence or corresponding source")
    if files.get("launch.ps1", {}).get("sha256") != launcher_sha256:
        c.fail("Companion manifest does not bind the expected launcher")
    native_size = check_native(package / "SC.exe", native_sha256, manifest_sha256, launcher_sha256)

    build = package / "BUILD.json"
    if build.exists():
        if c.regular(build).st_size > 1024 * 1024:
            c.fail("Oversized native build record")
        metadata = json.loads(build.read_text(encoding="utf-8-sig"))
        if metadata.get("name") != "S;C" or metadata.get("temporary_diagnostic") or metadata.get("executable_sha256") != native_sha256:
            c.fail("Native BUILD.json does not match the supplied production build hash")
    inventory = c.inventory(package)
    return {
        "schema": 1, "kind": "sc-combined-local-prepare-check", "verified": True,
        "native": {"entrypoint": "SC.exe", "sha256": native_sha256, "size": native_size,
                   "expected_pin_bytes_present": True, "build_record_present": build.is_file()},
        "companion": {"directory": "vencord-companion", "manifest_sha256": result["manifest_sha256"],
                      "launcher_sha256": launcher_sha256, "files": result["files"], "status": manifest.get("status")},
        "files": len(inventory), "bytes": sum(value["size"] for value in inventory.values()),
        "installer_ready": False, "update_compatible": False, "publish_ready": False,
        "remaining_contract_work": BLOCKERS, "installed": False, "launched": False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("package", type=Path)
    parser.add_argument("--native-sha256", required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--launcher-sha256", required=True)
    parser.add_argument("--report", type=Path, help="New report outside the candidate; never modifies package files")
    parser.add_argument("--require-installer-ready", action="store_true", help="Fail closed until installer/updater support exists")
    args = parser.parse_args()
    try:
        package = Path(os.path.abspath(args.package))
        result = verify(package, args.native_sha256, args.manifest_sha256, args.launcher_sha256)
        if args.report:
            report = Path(os.path.abspath(args.report))
            if report.is_relative_to(package):
                c.fail("Report must be outside the sealed candidate")
            c.no_links(report.parent)
            with report.open("x", encoding="utf-8") as output:
                output.write(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result, indent=2))
        if args.require_installer_ready:
            c.fail("Combined candidate verified, but current installer/updater contract is native-only")
    except (OSError, ValueError, KeyError, TypeError, struct.error) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
