"""Offline tests. No account, Discord connection, Electron or package install.
SPDX-License-Identifier: GPL-3.0-or-later
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile
import unittest
import zipfile

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("companion", HERE / "companion.py")
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)


class CompanionTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()

    def archive(self, paths):
        result = self.root / "source.zip"
        with zipfile.ZipFile(result, "w") as z:
            for name, data in paths:
                z.writestr(name, data)
        return result

    def test_archive_cannot_escape_collide_or_replace_existing_sources(self):
        for names in [[("root/../../outside", "bad")], [("root/a", "one"), ("root/A", "two")], [("root/CON.txt", "bad")], [("root/a:stream", "bad")]]:
            archive = self.archive(names)
            with self.assertRaises(ValueError):
                c.extract_archive(archive, c.digest(archive.read_bytes()), self.root / "out")
            self.assertFalse((self.root / "out").exists())
        good = self.archive([("root/LICENSE", "GPL"), ("root/src/file.ts", "export {};")])
        c.extract_archive(good, c.digest(good.read_bytes()), self.root / "good")
        self.assertEqual((self.root / "good/src/file.ts").read_text(), "export {};")
        with self.assertRaises(FileExistsError):
            c.extract_archive(good, c.digest(good.read_bytes()), self.root / "good")

    def test_archive_pin_and_symlink_are_enforced(self):
        archive = self.archive([("root/a", "a")])
        with self.assertRaises(ValueError):
            c.extract_archive(archive, "0" * 64, self.root / "bad")
        with zipfile.ZipFile(archive, "w") as z:
            entry = zipfile.ZipInfo("root/link")
            entry.create_system = 3
            entry.external_attr = (stat.S_IFLNK | 0o777) << 16
            z.writestr(entry, "../../outside")
        with self.assertRaises(ValueError):
            c.extract_archive(archive, c.digest(archive.read_bytes()), self.root / "bad")

    def test_workspace_dependency_outputs_are_not_corresponding_source(self):
        tree = self.root / "tree"
        (tree / "packages/example/node_modules/dependency").mkdir(parents=True)
        (tree / "static/dist").mkdir(parents=True)
        (tree / "LICENSE").write_text("GPL")
        (tree / "packages/example/package.json").write_text("{}")
        (tree / "packages/example/node_modules/dependency/native.node").write_bytes(b"locked dependency")
        (tree / "static/dist/game-detection-x64.node").write_bytes(b"generated dependency output")
        expected = {"LICENSE", "packages/example/package.json"}
        self.assertEqual(set(c.inventory(tree, build_tree=True)), expected)
        # Only named build products are excluded. Unreviewed files remain part
        # of the seal, and a staged runtime never uses the source exclusions.
        (tree / "static/dist/unreviewed.js").write_text("unexpected")
        self.assertIn("static/dist/unreviewed.js", c.inventory(tree, build_tree=True))
        self.assertIn("static/dist/game-detection-x64.node", c.inventory(tree))

    def package(self):
        package = self.root / "package"
        (package / "runtime").mkdir(parents=True)
        (package / "runtime/SC-Vencord.exe").write_bytes(b"MZ synthetic; never executed")
        shutil.copyfile(HERE / "launch.ps1", package / "launch.ps1")
        manifest = {"schema": 1, "kind": "sc-vencord-companion", "entrypoint": "runtime/SC-Vencord.exe", "profile": "SC/VencordCompanion/profile-v1", "lock": c.LOCK, "files": c.inventory(package)}
        c.write_json(package / "companion-manifest.json", manifest)
        return package

    def test_package_rejects_tampering_extras_and_wrong_entrypoint(self):
        package = self.package()
        self.assertTrue(c.verify(package)["verified"])
        extra = package / "unreviewed.js"
        extra.write_text("unexpected")
        with self.assertRaises(ValueError):
            c.verify(package)
        extra.unlink()
        (package / "runtime/SC-Vencord.exe").write_bytes(b"MZ changed")
        with self.assertRaises(ValueError):
            c.verify(package)

    @unittest.skipUnless(shutil.which("node"), "Node unavailable")
    def test_actual_runtime_guard_rejects_modified_missing_extra_assets(self):
        assets = self.root / "assets"
        assets.mkdir()
        for file in (*c.ASSETS, "package.json"):
            (assets / file).write_text("{}" if file == "package.json" else "// synthetic asset")
        pins = c.inventory(assets)
        (self.root / "pins.json").write_text(json.dumps(pins))
        script = '''const fs=require('node:fs');const g=require(process.argv[1]);const pins=JSON.parse(fs.readFileSync(process.argv[3]));g.verifyAll(process.argv[2],pins);g.readVerified(process.argv[2],pins,'../outside');'''
        # A traversal is rejected even after a valid inventory passes.
        result = subprocess.run(["node", "-e", script, str(HERE / "asset-guard.cjs"), str(assets), str(self.root / "pins.json")], capture_output=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn(b"unlisted asset", result.stderr)
        script = "const fs=require('node:fs');require(process.argv[1]).verifyAll(process.argv[2],JSON.parse(fs.readFileSync(process.argv[3])));"
        def check():
            return subprocess.run(["node", "-e", script, str(HERE / "asset-guard.cjs"), str(assets), str(self.root / "pins.json")], capture_output=True).returncode
        self.assertEqual(check(), 0)
        target = assets / c.ASSETS[0]
        original = target.read_bytes()
        target.write_bytes(b"x" * len(original))
        self.assertNotEqual(check(), 0)
        target.write_bytes(original)
        extra = assets / "unlisted.js"
        extra.write_text("bad")
        self.assertNotEqual(check(), 0)
        extra.unlink()
        target.unlink()
        self.assertNotEqual(check(), 0)

    @unittest.skipUnless(os.name == "nt", "Windows PowerShell verification")
    def test_windows_verify_only_does_not_launch_or_create_profile(self):
        package = self.package()
        expected = c.digest((package / "companion-manifest.json").read_bytes())
        env = dict(os.environ, LOCALAPPDATA=str(self.root / "empty-local-app-data"))
        command = ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(package / "launch.ps1"), "-ExpectedManifestSha256", expected]
        result = subprocess.run(command, env=env, text=True, capture_output=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertFalse(json.loads(result.stdout)["launched"])
        self.assertFalse(Path(env["LOCALAPPDATA"]).exists())
        command[-1] = "0" * 64
        self.assertNotEqual(subprocess.run(command, env=env, capture_output=True, timeout=30).returncode, 0)
        command[-1] = expected
        profile = Path(env["LOCALAPPDATA"]) / "SC/VencordCompanion/profile-v1"
        profile.mkdir(parents=True)
        (profile / "do-not-import.txt").write_text("synthetic existing profile")
        result = subprocess.run(command + ["-Launch"], env=env, text=True, capture_output=True, timeout=30)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Refusing to reuse an existing unmarked profile", result.stderr)
        self.assertFalse((profile / "sc-companion-profile.json").exists())

    def test_build_requires_explicit_download_permission(self):
        with self.assertRaises(ValueError):
            c.build(self.root, "pnpm", "pnpm", False)

    @unittest.skipUnless(os.environ.get("SC_COMPANION_SOURCE_ARCHIVES"), "pinned source archive audit is opt-in")
    def test_real_pinned_sources_prepare_and_reject_unreviewed_changes(self):
        archives = Path(os.environ["SC_COMPANION_SOURCE_ARCHIVES"])
        workspace = self.root / "prepared"
        c.prepare(archives / "vesktop.zip", archives / "vencord.zip", workspace)
        c.check_prepared(workspace)
        c.audit_policy(workspace)
        plugins = workspace / "vencord/src/plugins"
        self.assertEqual({p.name for p in plugins.iterdir()}, set(c.LOCK["plugins"]) | {"_api", "_core"})
        self.assertGreaterEqual(len(c.LOCK["plugins"]), 140)
        self.assertIn("clientTheme", c.LOCK["plugins"])
        self.assertIn("webScreenShareFixes.web", c.LOCK["plugins"])
        for name in c.LOCK["excluded_plugins"]:
            self.assertFalse((plugins / name).exists())
        self.assertFalse((plugins / "voiceMessages" / "native.ts").exists())
        self.assertIn("PermissionStore.can(PermissionsBits.VIEW_CHANNEL, channel)) return null",
                      (plugins / "userVoiceShow" / "components.tsx").read_text(encoding="utf-8"))
        ipc = workspace / "vencord/src/main/ipcPlugins.ts"
        original_ipc = ipc.read_text(encoding="utf-8")
        ipc.write_text(original_ipc.replace("frame.parent", "false"), encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "unguarded IPC"):
            c.audit_policy(workspace)
        ipc.write_text(original_ipc, encoding="utf-8")
        loader = (workspace / "vesktop/src/main/utils/vencordLoader.ts").read_text()
        self.assertIn("automatic downloads are disabled", loader)
        self.assertNotIn("fetchie", loader)
        main = (workspace / "vesktop/src/main/main.ts").read_text()
        self.assertNotIn('setAsDefaultProtocolClient("discord")', main)
        self.assertNotIn("createFirstLaunchTour();", main)
        guard_source = workspace / "vesktop/src/main/scAssetGuard.cjs"
        guard_source.write_text("module.exports = { verifyAll: () => true };")
        with self.assertRaises(ValueError):
            c.check_prepared(workspace)


if __name__ == "__main__":
    unittest.main()
