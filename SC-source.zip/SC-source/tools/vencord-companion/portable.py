#!/usr/bin/env python3
"""Create/verify an offline local portable candidate, never a release or installer.
SPDX-License-Identifier: GPL-3.0-or-later
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import struct
import sys
import zipfile

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("sc_combined_prepare", HERE / "verify_combined.py")
combined = importlib.util.module_from_spec(spec)
spec.loader.exec_module(combined)
c = combined.c
PREFIX = "SC-windows-x64-local/"
MANIFEST = "SC-PORTABLE.json"
README = b"""S;C combined LOCAL PREVIEW - not an installer or public release.

Extract the complete archive into a new dedicated folder. SC.exe is inside
SC-windows-x64-local. The optional Vencord companion uses a separate login and
opens only when explicitly requested. No account or profile is in this archive.
Do not merge it into an installed application or a user profile.

To review sample conversations in isolation, open PowerShell in
SC-windows-x64-local and run:
  .\\SC.exe --preview --data-dir (Join-Path $env:TEMP ('SC-Preview-' + [guid]::NewGuid()))
Starting SC.exe without these arguments uses your normal S;C profile, if you
have one. Exit the preview window when finished.

The current native-only updater/installer cannot update this combined layout.
Do not rename this file to the normal release ZIP or distribute it as verified
production software. GUI/login/plugin compatibility remains unvalidated.
The companion adds Electron/Chromium memory while running; no RAM claim is made.

SC-PORTABLE.json records exact payload hashes and the native/companion pairing.
Verify using trusted expected hashes; this self-contained manifest is not a
signature or independent release provenance. Corresponding companion sources
and licences are under vencord-companion/sources and licenses.
"""


def metadata(native, manifest, launcher, files):
    return {"schema": 1, "kind": "sc-combined-local-portable", "payload_root": PREFIX[:-1],
            "native_sha256": native, "companion_manifest_sha256": manifest,
            "companion_launcher_sha256": launcher, "companion_optional": True,
            "local_preview": True, "installer_ready": False, "update_compatible": False,
            "publish_ready": False, "runtime_validated": False, "files": files}


def entry(name):
    info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
    info.create_system = 0
    info.external_attr = 0x20
    info.compress_type = zipfile.ZIP_DEFLATED
    return info


def create(candidate, output, native, manifest, launcher):
    combined.verify(candidate, native, manifest, launcher)
    c.no_links(output.parent)
    if output.is_relative_to(candidate):
        c.fail("Portable output must be outside the sealed candidate")
    before = c.inventory(candidate)
    files = {PREFIX + name: value for name, value in before.items()}
    files["README.txt"] = {"size": len(README), "sha256": c.digest(README)}
    document = metadata(native, manifest, launcher, files)
    # Exclusive creation prevents accidental replacement of a previous candidate.
    with output.open("xb") as target, zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
        for name, expected in sorted(before.items()):
            source = candidate / name
            c.no_links(source)
            c.regular(source)
            digest, written = hashlib.sha256(), 0
            with source.open("rb") as incoming, zipped.open(entry(PREFIX + name), "w", force_zip64=True) as outgoing:
                while block := incoming.read(256 * 1024):
                    written += len(block)
                    if written > expected["size"]:
                        c.fail("Source file grew while portable archive was being written")
                    outgoing.write(block)
                    digest.update(block)
            if written != expected["size"] or digest.hexdigest() != expected["sha256"]:
                c.fail("Source changed while portable archive was being written")
        zipped.writestr(entry("README.txt"), README)
        zipped.writestr(entry(MANIFEST), c.json_bytes(document))
    if c.inventory(candidate) != before:
        c.fail("Combined source changed during packaging; incomplete candidate retained for inspection")
    return verify(output, native, manifest, launcher)


def safe_entry(info):
    c.safe_name(info.filename)
    if info.filename != "/".join(Path(info.filename).parts) or info.is_dir():
        c.fail("Portable archive paths must be canonical files")
    mode = info.external_attr >> 16
    if stat.S_ISLNK(mode) or (mode and not stat.S_ISREG(mode)) or info.external_attr & 0x400:
        c.fail("Portable archive contains a link or special file")
    if info.flag_bits & 1 or info.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
        c.fail("Unsupported encrypted/compressed portable entry")
    if info.file_size > 512 * 1024 * 1024:
        c.fail("Portable entry exceeds the file limit")


def read_json(zipped, name, limit=2 * 1024 * 1024):
    if zipped.getinfo(name).file_size > limit:
        c.fail("Oversized portable JSON")
    return json.loads(zipped.read(name))


def verify(archive, native, manifest, launcher):
    native, manifest, launcher = map(combined.pin, (native, manifest, launcher))
    c.no_links(archive)
    if c.regular(archive).st_size > c.MAX_TREE:
        c.fail("Portable archive exceeds size limit")
    with zipfile.ZipFile(archive) as zipped:
        entries = zipped.infolist()
        if len(entries) > 6500 or sum(i.file_size for i in entries) > c.MAX_TREE:
            c.fail("Portable archive exceeds inventory limits")
        for info in entries:
            safe_entry(info)
        names = {i.filename for i in entries}
        if len({name.casefold() for name in names}) != len(entries):
            c.fail("Duplicate or case-colliding portable entries")
        document = read_json(zipped, MANIFEST)
        if any(document.get(k) != value for k, value in metadata(native, manifest, launcher, {}).items() if k != "files"):
            c.fail("Portable manifest does not match expected pins/local-only contract")
        files = document.get("files")
        if not isinstance(files, dict) or names != {MANIFEST, *files}:
            c.fail("Portable inventory is missing files or contains extras")
        if files.get("README.txt") != {"size": len(README), "sha256": c.digest(README)}:
            c.fail("Portable preview notice is missing or changed")
        actual, found_pins = {}, set()
        needles = {manifest.encode(), launcher.encode()}
        for info in entries:
            if info.filename == MANIFEST:
                continue
            digest, written, tail = hashlib.sha256(), 0, b""
            with zipped.open(info) as source:
                while block := source.read(256 * 1024):
                    written += len(block)
                    if written > info.file_size:
                        c.fail("Portable entry exceeds declared size")
                    digest.update(block)
                    if info.filename == PREFIX + "SC.exe":
                        data = tail + block
                        found_pins.update(n for n in needles if n in data)
                        tail = data[-63:]
            actual[info.filename] = {"size": written, "sha256": digest.hexdigest()}
        if actual != files:
            c.fail("Portable payload hash/size mismatch")
        if found_pins != needles or files.get(PREFIX + "SC.exe", {}).get("sha256") != native:
            c.fail("Portable native executable/pins mismatch")
        with zipped.open(PREFIX + "SC.exe") as source:
            header = source.read(64)
            if len(header) != 64 or header[:2] != b"MZ":
                c.fail("Portable native executable is not PE")
            offset = struct.unpack_from("<I", header, 60)[0]
            if offset > files[PREFIX + "SC.exe"]["size"] - 26:
                c.fail("Portable native PE header is invalid")
            source.seek(offset)
            if source.read(6) != b"PE\0\0\x64\x86":
                c.fail("Portable native executable is not Windows x64")
        if PREFIX + "BUILD.json" in files:
            build = read_json(zipped, PREFIX + "BUILD.json", 1024 * 1024)
            if build.get("name") != "S;C" or build.get("temporary_diagnostic") or build.get("executable_sha256") != native:
                c.fail("Portable native BUILD.json does not match expected native build")
        cp = PREFIX + "vencord-companion/"
        if files.get(cp + "companion-manifest.json", {}).get("sha256") != manifest or files.get(cp + "launch.ps1", {}).get("sha256") != launcher:
            c.fail("Portable companion pins mismatch")
        cm = read_json(zipped, cp + "companion-manifest.json")
        if cm.get("schema") != 1 or cm.get("kind") != "sc-vencord-companion" or cm.get("lock") != c.LOCK or cm.get("entrypoint") != "runtime/SC-Vencord.exe" or cm.get("profile") != "SC/VencordCompanion/profile-v1":
            c.fail("Unexpected portable companion contract")
        contained = {name[len(cp):]: value for name, value in files.items() if name.startswith(cp) and name != cp + "companion-manifest.json"}
        if contained != cm.get("files"):
            c.fail("Portable companion inventory mismatch")
        for required in ("licenses/vencord-LICENSE", "licenses/vesktop-LICENSE", "sources/vencord-source.zip", "sources/vesktop-source.zip"):
            if required not in contained:
                c.fail("Portable companion is missing corresponding source/licence")
        for name in files:
            if name == "README.txt":
                continue
            if not name.startswith(PREFIX):
                c.fail("Unexpected portable payload root")
            rel = name[len(PREFIX):]
            if "/" in rel:
                if rel.split("/", 1)[0] not in combined.ROOT_DIRS:
                    c.fail("Unrecognized portable directory or bundled profile")
            elif rel not in combined.ROOT_FILES:
                c.fail("Unrecognized portable root file")
    return {"verified": True, "kind": "sc-combined-local-portable", "archive_sha256": c.file_digest(archive),
            "archive_bytes": archive.stat().st_size, "files": len(entries),
            "native_sha256": native, "companion_manifest_sha256": manifest, "companion_launcher_sha256": launcher,
            "local_preview": True, "installer_ready": False, "update_compatible": False, "publish_ready": False,
            "installed": False, "launched": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    make = sub.add_parser("create")
    make.add_argument("--candidate", type=Path, required=True)
    make.add_argument("--output", type=Path, required=True)
    check = sub.add_parser("verify")
    check.add_argument("archive", type=Path)
    for command in (make, check):
        for name in ("native", "manifest", "launcher"):
            command.add_argument(f"--{name}-sha256", required=True)
    args = parser.parse_args()
    try:
        pins = args.native_sha256, args.manifest_sha256, args.launcher_sha256
        if args.command == "create":
            result = create(Path(os.path.abspath(args.candidate)), Path(os.path.abspath(args.output)), *pins)
        else:
            result = verify(Path(os.path.abspath(args.archive)), *pins)
        print(json.dumps(result, indent=2))
    except (OSError, ValueError, KeyError, TypeError, struct.error, zipfile.BadZipFile) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
