#!/usr/bin/env python3
"""Offline preparation and explicit build/staging for the isolated companion.

No command downloads a runtime, opens Discord, logs in, or publishes anything.
Only `build --allow-dependency-downloads` runs pinned package build commands.
SPDX-License-Identifier: GPL-3.0-or-later
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
LOCK = json.loads((HERE / "upstream-lock.json").read_text())
ASSETS = ("vencordDesktopMain.js", "vencordDesktopPreload.js", "vencordDesktopRenderer.js", "vencordDesktopRenderer.css")
IGNORED_BUILD_ROOTS = {"node_modules", "dist", "release", ".git"}
MAX_ARCHIVE = 32 * 1024 * 1024
MAX_TREE = 1024 * 1024 * 1024
# Upstream's Windows build copies these locked dependency outputs into static/.
# They belong to the final runtime inventory, not corresponding source.
GENERATED_NATIVE_FILES = {"static/dist/game-detection-x64.node", "static/dist/game-detection-arm64.node"}


def fail(message):
    raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_digest(path):
    result = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(256 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2) + "\n").encode()


def write_json(path, value):
    path.write_bytes(json_bytes(value))


def safe_name(name):
    if not isinstance(name, str) or not name or "\\" in name or ":" in name:
        fail("invalid package path")
    bits = PurePosixPath(name).parts
    if name.startswith("/") or any(b in (".", "..") or b.endswith((".", " ")) for b in bits):
        fail("unsafe package path")
    if any(re.match(r"(?i)^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)", b) or any(ord(c) < 32 for c in b) for b in bits):
        fail("unsafe Windows package path")
    return name


def regular(path):
    entry = path.lstat()
    if not stat.S_ISREG(entry.st_mode) or stat.S_ISLNK(entry.st_mode) or getattr(entry, "st_file_attributes", 0) & 0x400:
        fail(f"not a regular file: {path.name}")
    return entry


def no_links(path):
    for part in (path, *path.parents):
        if part.exists() and (part.is_symlink() or getattr(part.lstat(), "st_file_attributes", 0) & 0x400):
            fail("linked paths are not accepted")


def inventory(root, *, build_tree=False):
    no_links(root)
    found = {}
    total = 0
    for base, directories, files in os.walk(root, followlinks=False):
        base = Path(base)
        if build_tree:
            # pnpm workspaces also create package-local dependency trees. These
            # are build inputs managed by the frozen lockfile, never source or
            # packaged runtime inventory. Do not traverse their junctions.
            directories[:] = [d for d in directories if d != "node_modules"
                              and not (base == root and d in IGNORED_BUILD_ROOTS)]
        for directory in directories:
            no_links(base / directory)
        for name in files:
            file = base / name
            rel = file.relative_to(root).as_posix()
            safe_name(rel)
            size = regular(file).st_size
            if build_tree and rel in GENERATED_NATIVE_FILES:
                continue
            total += size
            if size > 512 * 1024 * 1024 or total > MAX_TREE or len(found) >= 6000:
                fail("package inventory exceeds limits")
            found[rel] = {"size": size, "sha256": file_digest(file)}
    if len({name.casefold() for name in found}) != len(found):
        fail("case-colliding package paths")
    return dict(sorted(found.items()))


def extract_archive(archive, expected_hash, destination):
    if regular(archive).st_size > MAX_ARCHIVE or digest(archive.read_bytes()) != expected_hash:
        fail("source archive does not match the pinned commit archive")
    with zipfile.ZipFile(archive) as zipped:
        entries = zipped.infolist()
        if len(entries) > 12000 or sum(e.file_size for e in entries) > 128 * 1024 * 1024:
            fail("source archive exceeds limits")
        roots = {e.filename.split("/")[0] for e in entries}
        if len(roots) != 1:
            fail("archive must have one source root")
        seen = set()
        planned = []
        for entry in entries:
            safe_name(entry.filename.rstrip("/"))
            mode = entry.external_attr >> 16
            if stat.S_ISLNK(mode) or entry.flag_bits & 1:
                fail("linked/encrypted archive member")
            rel = entry.filename.partition("/")[2].rstrip("/")
            if not rel:
                continue
            safe_name(rel)
            if rel.casefold() in seen:
                fail("duplicate or case-colliding archive member")
            seen.add(rel.casefold())
            planned.append((entry, destination / rel))
        destination.mkdir()
        for entry, output in planned:
            if entry.is_dir():
                output.mkdir(parents=True, exist_ok=True)
            else:
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_bytes(zipped.read(entry))


def replace(root, file, before, after):
    path = root / file
    text = path.read_text(encoding="utf-8")
    if text.count(before) != 1:
        fail(f"upstream patch anchor changed: {file}")
    path.write_text(text.replace(before, after), encoding="utf-8", newline="\n")


def replace_module(root, file, body):
    path = root / file
    source = path.read_text(encoding="utf-8")
    # Retain upstream's copyright/SPDX header in modified files.
    header = source[:source.index("*/") + 2]
    path.write_text(header + "\n// Modified for the pinned S;C companion.\n" + body.strip() + "\n", encoding="utf-8", newline="\n")


def patch_sources(workspace):
    vencord, vesktop = workspace / "vencord", workspace / "vesktop"
    allowed = set(LOCK["plugins"])
    excluded = set(LOCK["excluded_plugins"])
    native = set(LOCK["native_plugins"])
    plugin_root = (vencord / "src/plugins").resolve()
    optional = {path.name for path in plugin_root.iterdir()} - {"_api", "_core", "index.ts"}
    if allowed & excluded or optional != allowed | excluded or not native <= allowed:
        fail("optional plugin sources do not match the lock")
    allow = json.dumps(sorted(allowed))
    replace(vencord, "scripts/build/common.mjs", 'const pluginDirs = ["plugins/_api", "plugins/_core", "plugins", "userplugins"];', 'const pluginDirs = ["plugins/_api", "plugins/_core", "plugins"];')
    replace(vencord, "scripts/build/common.mjs", 'const fileName = file.name;', f'const fileName = file.name;\n                    if (dir === "plugins" && !{allow}.includes(fileName)) continue;')
    replace(vencord, "scripts/build/build.mjs", 'const pluginDirs = ["plugins", "userplugins"];', 'const pluginDirs = ["plugins"];')
    natives = json.dumps(sorted(native))
    replace(vencord, "scripts/build/build.mjs", 'const fileName = file.name;', f'const fileName = file.name;\n                    if (!{natives}.includes(fileName)) continue;')
    for folder in sorted(excluded):
        path = plugin_root / folder
        resolved = path.resolve()
        if resolved.parent != plugin_root:
            fail("plugin path escaped source root")
        no_links(path)
        if path.is_dir():
            shutil.rmtree(path)
        else:
            path.unlink()

    # Native helpers are registered at process startup regardless of whether
    # their plugins are enabled. Keep a separate allowlist and gate invocations
    # to an enabled plugin in the top-level Discord renderer.
    ipc_plugins = "src/main/ipcPlugins.ts"
    replace(vencord, ipc_plugins, 'import PluginNatives from "~pluginNatives";',
            'import PluginNatives from "~pluginNatives";\nimport { RendererSettings } from "./settings";')
    replace(vencord, ipc_plugins, '        ipcMain.handle(key, method);', '''        ipcMain.handle(key, (event, ...args) => {
            const frame = event.senderFrame;
            const origin = frame?.url ? new URL(frame.url).origin : "";
            if (!frame || frame.parent || ![
                "https://discord.com", "https://canary.discord.com", "https://ptb.discord.com"
            ].includes(origin)) throw new Error("Plugin helper is available only in the main Discord frame");
            if (RendererSettings.store.plugins?.[plugin]?.enabled !== true)
                throw new Error("Plugin helper is available only while its plugin is enabled");
            return (method as (...args: any[]) => any)(event, ...args);
        });''')
    # The Vesktop renderer uses the web recorder. Keep only that source and
    # compile no unnecessary native recording file helper.
    replace(vencord, "src/plugins/voiceMessages/index.tsx",
            'import { VoiceRecorderDesktop } from "./DesktopRecorder";\n', '')
    replace(vencord, "src/plugins/voiceMessages/index.tsx",
            'const VoiceRecorder = IS_DISCORD_DESKTOP ? VoiceRecorderDesktop : VoiceRecorderWeb;',
            'const VoiceRecorder = VoiceRecorderWeb;')
    for path in ("DesktopRecorder.tsx", "native.ts"):
        (plugin_root / "voiceMessages" / path).unlink()

    # Preserve ordinary links and channel permissions in these integrations
    # when an optional cross-plugin dependency is outside the locked bundle.
    for path, target, binding in (
        ("showConnections/index.tsx", "openInApp", "OpenInAppPlugin"),
        ("spotifyControls/SpotifyStore.ts", "openInApp", "OpenInAppPlugin"),
        ("userVoiceShow/components.tsx", "showHiddenChannels", "ShowHiddenChannelsPlugin"),
    ):
        source = f"src/plugins/{path}"
        replace(vencord, source, 'import { isPluginEnabled } from "@api/PluginManager";\n', '')
        replace(vencord, source, f'import {binding} from "@plugins/{target}";\n', '')
    replace(vencord, "src/plugins/showConnections/index.tsx", '''                        onClick={e => {
                            if (isPluginEnabled(OpenInAppPlugin.name)) {
                                // handleLink will .preventDefault() if applicable
                                OpenInAppPlugin.handleLink(e.currentTarget, e);
                            }
                        }}
''', '')
    replace(vencord, "src/plugins/spotifyControls/SpotifyStore.ts",
            'settings.store.useSpotifyUris || isPluginEnabled(OpenInAppPlugin.name)', 'settings.store.useSpotifyUris')
    replace(vencord, "src/plugins/userVoiceShow/components.tsx",
            ' && !isPluginEnabled(ShowHiddenChannelsPlugin.name)', '')
    # No downloadable extension code, even if a copied settings file asks for it.
    replace_module(vencord, "src/main/utils/extensions.ts", 'export async function installExt(_id: string): Promise<never> { throw new Error("External extensions are unavailable in the pinned S;C companion"); }')
    replace_module(vencord, "src/main/updater/index.ts", '// Updates are delivered only as a new verified S;C companion package.\nexport {};')

    shutil.copyfile(HERE / "asset-guard.cjs", vesktop / "src/main/scAssetGuard.cjs")
    (vesktop / "src/main/scAssetPins.ts").write_text('export const SC_ASSET_PINS = {} as Record<string, { size: number; sha256: string }>;\n', encoding="utf-8")
    replace_module(vesktop, "src/main/vencordFilesDir.ts", 'import { join } from "path";\nexport const VENCORD_FILES_DIR = join(process.resourcesPath, "sc-vencord");')
    replace_module(vesktop, "src/main/utils/vencordLoader.ts", '''
import { resolve } from "path";
import { SC_ASSET_PINS } from "../scAssetPins";
import { VENCORD_FILES_DIR } from "../vencordFilesDir";
const guard = require("../scAssetGuard.cjs");
export function readVerifiedAsset(name: string): Buffer { return guard.readVerified(VENCORD_FILES_DIR, SC_ASSET_PINS, name); }
export async function isValidVencordInstall(dir: string): Promise<boolean> {
    if (resolve(dir) !== resolve(VENCORD_FILES_DIR)) return false;
    try { return guard.verifyAll(dir, SC_ASSET_PINS); } catch { return false; }
}
export async function downloadVencordFiles(): Promise<never> {
    throw new Error("S;C companion assets are missing or damaged. Obtain a new verified package; automatic downloads are disabled.");
}
''')
    replace_module(vesktop, "src/main/updater.ts", '''
import { IpcEvents } from "shared/IpcEvents";
import { handle } from "./utils/ipcWrappers";
handle(IpcEvents.UPDATER_IS_OUTDATED, () => false);
handle(IpcEvents.UPDATER_OPEN, () => { throw new Error("Updates require a verified S;C companion package"); });
''')
    replace(vesktop, "src/main/constants.ts", 'process.env.VENCORD_USER_DATA_DIR || (PORTABLE ? join(vesktopDir, "Data") : join(app.getPath("userData")));', '''join(app.getPath("localAppData" as any), "SC", "VencordCompanion", "profile-v1");''')
    # Electron has no localAppData named path: Windows LOCALAPPDATA must be
    # provided by the verified launcher and exactly match the dedicated path.
    replace(vesktop, "src/main/constants.ts", 'join(app.getPath("localAppData" as any), "SC", "VencordCompanion", "profile-v1");', '''join(process.env.LOCALAPPDATA || "", "SC", "VencordCompanion", "profile-v1");
if (process.platform !== "win32" || !process.env.LOCALAPPDATA || process.env.VENCORD_USER_DATA_DIR !== DATA_DIR)
    throw new Error("Start the S;C companion through its verified launcher");
app.setPath("userData", DATA_DIR);''')
    replace(vesktop, "src/main/main.ts", 'import "./rpc";', '// No background RPC server in the on-demand companion.')
    replace(vesktop, "src/main/main.ts", '    setAsDefaultProtocolClient("discord");', '    // Do not take over the installed Discord protocol handler.')
    replace(vesktop, "src/main/main.ts", '''    if (!Object.hasOwn(State.store, "firstLaunch")) {
        createFirstLaunchTour();
    } else {
        createWindows();
    }''', '    createWindows(); // Fresh independent login; never import another client profile.')
    replace(vesktop, "src/main/main.ts", 'app.setAppUserModelId("dev.vencord.vesktop")', 'app.setAppUserModelId("dev.sc.vencordcompanion")')
    replace(vesktop, "src/main/mainWindow.ts", 'label: "Force Update Vencord",', 'label: "Packaged Vencord (updates managed by S;C)",\n            enabled: false,')
    start = 'async function showStartupError(error: unknown) {'
    file = vesktop / "src/main/mainWindow.ts"
    body = file.read_text(encoding="utf-8")
    old = body[body.index(start):body.index('\nexport async function createWindows()', body.index(start))]
    replace(vesktop, "src/main/mainWindow.ts", old, '''async function showStartupError(error: unknown) {
    await dialog.showMessageBox({ type: "error", message: "S;C companion cannot start", detail: String(error), buttons: ["Quit"] });
    app.exit(1);
}
''')
    replace(vesktop, "src/main/mainWindow.ts", '            updateSplashMessage("Downloading Vencord...");\n            await downloadVencordFiles();', '            throw new Error("Packaged Vencord integrity check failed; automatic repair is disabled");')
    replace(vesktop, "src/main/ipc.ts", 'import { isValidVencordInstall } from "./utils/vencordLoader";', 'import { readVerifiedAsset } from "./utils/vencordLoader";')
    for name in ASSETS[:3]:
        if name == ASSETS[0]:
            continue
        replace(vesktop, "src/main/ipc.ts", f'readFileSync(join(VENCORD_FILES_DIR, "{name}"), "utf-8")', f'readVerifiedAsset("{name}").toString("utf-8")')
    ipc = (vesktop / "src/main/ipc.ts").read_text(encoding="utf-8")
    begin = ipc.index('handle(IpcEvents.SELECT_VENCORD_DIR,')
    end = ipc.index('\nhandle(IpcEvents.SET_BADGE_COUNT', begin)
    replace(vesktop, "src/main/ipc.ts", ipc[begin:end], 'handle(IpcEvents.SELECT_VENCORD_DIR, () => "invalid");\n')
    replace(vesktop, "src/main/ipc.ts", 'handleSync(IpcEvents.IS_USING_CUSTOM_VENCORD_DIR, () => !!State.store.vencordDir);', 'handleSync(IpcEvents.IS_USING_CUSTOM_VENCORD_DIR, () => false);')
    replace(vesktop, "src/main/ipc.ts", 'handle(IpcEvents.ENABLE_AUTOSTART, autoStart.enable);', 'handle(IpcEvents.ENABLE_AUTOSTART, () => { throw new Error("S;C companion runs only on demand"); });')
    policy = '{ tray: false, minimizeToTray: false, arRPC: false, openLinksWithElectron: false, autoStartMinimized: false }'
    replace(vesktop, "src/main/ipc.ts", '    Settings.setData(settings, path);', f'    Object.assign(settings, {policy});\n    Settings.setData(settings);')
    replace(vesktop, "src/main/settings.ts", '    const store = new SettingsStore(settings);', f'    if (file === SETTINGS_FILE) Object.assign(settings, {policy});\n    const store = new SettingsStore(settings);')
    package_file = vesktop / "package.json"
    package = json.loads(package_file.read_text())
    package["build"]["appId"] = "dev.sc.vencordcompanion"
    package["build"]["productName"] = "S;C Vencord Companion"
    package["build"]["executableName"] = "SC-Vencord"
    package["build"].pop("protocols", None)
    write_json(package_file, package)


def source_inventory(workspace):
    return {name: inventory(workspace / name, build_tree=True) for name in ("vencord", "vesktop")}


def prepare(vesktop_archive, vencord_archive, output):
    if output.exists():
        fail("output must be a new directory; existing candidates are never overwritten")
    no_links(output.parent)
    # Check both first, so a wrong second archive cannot leave a half-prepared tree.
    for name, path in (("vesktop", vesktop_archive), ("vencord", vencord_archive)):
        if regular(path).st_size > MAX_ARCHIVE or digest(path.read_bytes()) != LOCK[name]["sha256"]:
            fail(f"{name} source archive hash mismatch")
    output.mkdir()
    extract_archive(vesktop_archive, LOCK["vesktop"]["sha256"], output / "vesktop")
    extract_archive(vencord_archive, LOCK["vencord"]["sha256"], output / "vencord")
    original = source_inventory(output)
    patch_sources(output)
    modified = source_inventory(output)
    proof = {"schema": 1, "lock": LOCK, "tool_sha256": digest(Path(__file__).read_bytes()),
             "asset_guard_sha256": digest((HERE / "asset-guard.cjs").read_bytes()),
             "sources": modified, "patches": {name: {p: {"before": original[name].get(p), "after": modified[name].get(p)}
              for p in sorted(original[name].keys() | modified[name].keys()) if original[name].get(p) != modified[name].get(p)} for name in modified}}
    write_json(output / "prepared.json", proof)
    return {"prepared": str(output), "source_manifest_sha256": digest((output / "prepared.json").read_bytes()),
            "plugins": list(LOCK["plugins"].values()), "runtime_built": False}


def check_prepared(workspace):
    proof = json.loads((workspace / "prepared.json").read_text())
    if proof["lock"] != LOCK or source_inventory(workspace) != proof["sources"]:
        fail("prepared sources changed or do not match this lock")
    if any((workspace / name / "src/userplugins").exists() for name in ("vencord",)):
        fail("userplugins are forbidden")
    return proof


def audit_policy(workspace):
    """Check load/update surfaces before any package manager is allowed to run."""
    vencord, vesktop = workspace / "vencord", workspace / "vesktop"
    plugins = vencord / "src/plugins"
    optional = {path.name for path in plugins.iterdir()} - {"_api", "_core", "index.ts"}
    allowed = set(LOCK["plugins"])
    if optional != allowed:
        fail("unexpected or missing optional plugin source")
    for file in ("scripts/build/common.mjs", "scripts/build/build.mjs"):
        text = (vencord / file).read_text(encoding="utf-8")
        if re.search(r'const pluginDirs = .*"userplugins"', text):
            fail("user plugin build path enabled")
        expected = LOCK["native_plugins"] if file.endswith("/build.mjs") else LOCK["plugins"]
        if f"!{json.dumps(sorted(expected))}.includes(fileName)" not in text:
            fail("build discovery differs from the pinned plugin list")
    natives = {
        folder for folder in optional
        if any((plugins / folder / name).is_file() for name in ("native.ts", "native/index.ts"))
    }
    if natives != set(LOCK["native_plugins"]):
        fail("unexpected or missing plugin native helper")
    ipc_plugins = (vencord / "src/main/ipcPlugins.ts").read_text(encoding="utf-8")
    if "frame.parent" not in ipc_plugins or "RendererSettings.store.plugins?.[plugin]?.enabled !== true" not in ipc_plugins:
        fail("plugin native helper has unguarded IPC")
    for file in ("src/main/utils/vencordLoader.ts", "src/main/updater.ts"):
        text = (vesktop / file).read_text(encoding="utf-8")
        if any(token in text for token in ("fetchie(", "downloadFile(", "checkForUpdates(", "/releases/latest")):
            fail("unreviewed automatic code download")
    if "State.store.vencordDir" in (vesktop / "src/main/vencordFilesDir.ts").read_text():
        fail("custom runtime override enabled")
    # Direct optional-plugin imports bypass the glob. Refuse dangling imports
    # after pruning, instead of silently adding another plugin to satisfy one.
    for file in (vencord / "src").rglob("*"):
        if file.suffix not in (".ts", ".tsx"):
            continue
        for target in re.findall(r'from\s+[\"\']@plugins/([^\"\']+)', file.read_text(encoding="utf-8")):
            if target.split("/")[0] not in allowed | {"_api", "_core", "index.ts"}:
                fail("unreviewed direct optional-plugin import")


def run(command, cwd, env, log):
    with log.open("ab") as output:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=1800, check=False)
    if result.returncode:
        fail(f"build step failed; see {log.name}")


def build(workspace, pnpm_vencord, pnpm_vesktop, allow_downloads):
    if os.name != "nt" or not allow_downloads:
        fail("Windows build requires explicit --allow-dependency-downloads; runtime is never launched")
    proof = check_prepared(workspace)
    audit_policy(workspace)
    if subprocess.check_output(["node", "--version"], text=True).strip() != LOCK["node"]:
        fail("Node version does not match upstream-lock.json")
    for name, executable in (("vencord", pnpm_vencord), ("vesktop", pnpm_vesktop)):
        if subprocess.check_output([executable, "--version"], text=True).strip() != LOCK[name]["package_manager"]:
            fail(f"{name} requires its pinned pnpm version; no automatic tool installation")
    env = dict(os.environ)
    for key in list(env):
        if key.startswith(("VENCORD_", "NODE_", "ELECTRON_", "CSC_", "WIN_CSC_")) or key in ("GITHUB_TOKEN", "GH_TOKEN"):
            env.pop(key)
    env.update(SOURCE_DATE_EPOCH=LOCK["source_date_epoch"], VENCORD_HASH=LOCK["vencord"]["commit"],
               VENCORD_REMOTE="Vendicated/Vencord", CSC_IDENTITY_AUTO_DISCOVERY="false",
               ELECTRON_CACHE=str(workspace.parent / ".electron-cache"),
               ELECTRON_BUILDER_CACHE=str(workspace.parent / ".electron-builder-cache"))
    log = workspace / "build.log"
    for name, pnpm in (("vencord", pnpm_vencord), ("vesktop", pnpm_vesktop)):
        run([pnpm, "install", "--frozen-lockfile", "--store-dir", str(workspace.parent / ".pnpm-store")], workspace / name, env, log)
    check_prepared(workspace)
    run([pnpm_vencord, "build", "--standalone", "--disable-updater"], workspace / "vencord", env, log)
    check_prepared(workspace)
    asset_dir = workspace / "assets"
    asset_dir.mkdir()
    for name in ASSETS:
        source = workspace / "vencord/dist" / name
        if not 0 < regular(source).st_size <= 16 * 1024 * 1024:
            fail("unexpected Vencord build asset")
        shutil.copyfile(source, asset_dir / name)
    (asset_dir / "package.json").write_text("{}\n", encoding="utf-8")
    pins = inventory(asset_dir)
    pins_source = workspace / "vesktop/src/main/scAssetPins.ts"
    pins_source.write_text("export const SC_ASSET_PINS = " + json.dumps(pins, sort_keys=True) + " as Record<string, { size: number; sha256: string }>;\n", encoding="utf-8")
    proof["sources"]["vesktop"]["src/main/scAssetPins.ts"] = {"size": pins_source.stat().st_size, "sha256": digest(pins_source.read_bytes())}
    write_json(workspace / "prepared-built.json", proof)
    run([pnpm_vesktop, "build"], workspace / "vesktop", env, log)
    run([pnpm_vesktop, "exec", "electron-builder", "--dir", "--win", "--x64", "--publish", "never"], workspace / "vesktop", env, log)
    if source_inventory(workspace) != proof["sources"]:
        fail("source changed during runtime build")
    runtimes = list((workspace / "vesktop").glob("dist/win-unpacked/SC-Vencord.exe"))
    if len(runtimes) != 1:
        fail("expected one Windows x64 unpacked runtime")
    runtime = runtimes[0].parent
    shutil.copytree(asset_dir, runtime / "resources/sc-vencord")
    notices = runtime / "resources/sc-notices/vencord"
    notices.mkdir(parents=True)
    for notice in (workspace / "vencord/dist").glob("*.LEGAL.txt"):
        shutil.copyfile(notice, notices / notice.name)
    receipt = {"schema": 1, "lock": LOCK, "sources": proof["sources"], "files": inventory(runtime),
               "runtime_directory": str(runtime), "runtime_tested": False}
    write_json(workspace / "build-receipt.json", receipt)
    return {"build_receipt": str(workspace / "build-receipt.json"), "runtime_tested": False}


def stage(workspace, output):
    receipt = json.loads((workspace / "build-receipt.json").read_text())
    runtime = Path(receipt["runtime_directory"])
    if receipt["lock"] != LOCK or source_inventory(workspace) != receipt["sources"] or inventory(runtime) != receipt["files"]:
        fail("build receipt does not match sources/runtime")
    if output.exists():
        fail("staged output must not exist")
    no_links(output.parent)
    output.mkdir()
    shutil.copytree(runtime, output / "runtime")
    shutil.copyfile(HERE / "launch.ps1", output / "launch.ps1")
    notices = output / "licenses"
    notices.mkdir()
    for name in ("vencord", "vesktop"):
        shutil.copyfile(workspace / name / "LICENSE", notices / (name + "-LICENSE"))
    sources = output / "sources"
    sources.mkdir()
    # Supply the exact corresponding patched sources; dependency lockfiles and
    # upstream notices are preserved. No node_modules, user settings or binaries.
    for name in ("vencord", "vesktop"):
        with zipfile.ZipFile(sources / (name + "-source.zip"), "w", zipfile.ZIP_DEFLATED) as archive:
            for path in receipt["sources"][name]:
                archive.write(workspace / name / path, path)
    shutil.copytree(HERE, sources / "companion-tools", ignore=shutil.ignore_patterns("__pycache__"))
    manifest = {"schema": 1, "kind": "sc-vencord-companion", "status": "built-not-runtime-validated",
                "entrypoint": "runtime/SC-Vencord.exe", "profile": "SC/VencordCompanion/profile-v1",
                "lock": LOCK, "files": inventory(output)}
    write_json(output / "companion-manifest.json", manifest)
    return verify(output)


def verify(package):
    manifest_path = package / "companion-manifest.json"
    if regular(manifest_path).st_size > 2 * 1024 * 1024:
        fail("manifest too large")
    manifest = json.loads(manifest_path.read_text())
    if manifest.get("schema") != 1 or manifest.get("kind") != "sc-vencord-companion" or manifest.get("lock") != LOCK:
        fail("unsupported companion manifest")
    actual = inventory(package)
    actual.pop("companion-manifest.json")
    if actual != manifest.get("files") or manifest.get("entrypoint") != "runtime/SC-Vencord.exe":
        fail("companion package is altered, incomplete, or contains extra files")
    return {"verified": True, "manifest_sha256": digest(manifest_path.read_bytes()), "files": len(actual),
            "runtime_tested": False, "installed": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--vesktop-archive", type=Path, required=True)
    p.add_argument("--vencord-archive", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("build")
    p.add_argument("--workspace", type=Path, required=True)
    p.add_argument("--pnpm-vencord", required=True)
    p.add_argument("--pnpm-vesktop", required=True)
    p.add_argument("--allow-dependency-downloads", action="store_true")
    p = sub.add_parser("stage")
    p.add_argument("--workspace", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p = sub.add_parser("verify")
    p.add_argument("package", type=Path)
    args = parser.parse_args()
    try:
        if args.command == "prepare": result = prepare(args.vesktop_archive.resolve(), args.vencord_archive.resolve(), Path(os.path.abspath(args.output)))
        elif args.command == "build": result = build(args.workspace.resolve(), args.pnpm_vencord, args.pnpm_vesktop, args.allow_dependency_downloads)
        elif args.command == "stage": result = stage(args.workspace.resolve(), Path(os.path.abspath(args.output)))
        else: result = verify(args.package.resolve())
        print(json.dumps(result, indent=2))
    except (ValueError, OSError, KeyError, zipfile.BadZipFile, subprocess.SubprocessError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
