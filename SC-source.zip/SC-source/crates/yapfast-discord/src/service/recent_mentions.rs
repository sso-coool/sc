//! One page of the authenticated account's Inbox Mentions.

use super::*;
use crate::{api::RECENT_MENTIONS_PAGE, ready::Access};
use std::collections::BTreeMap;

pub const RECENT_MENTION_AGE: Duration = Duration::from_secs(7 * 24 * 60 * 60);

pub struct RecentMentions {
    /// Each message paired with its actual guild ID, or `PRIVATE` for a DM.
    pub messages: Vec<(String, Message)>,
    pub before: Option<u64>,
}

impl Snapshot {
    /// Checks what the gateway currently knows about a mention from the
    /// authenticated feed. An archived thread may be absent from that index.
    pub fn may_see_recent_mention(&self, guild: &str, channel: &str) -> bool {
        if guild == PRIVATE {
            return self
                .conversations
                .iter()
                .any(|dm| dm.id == channel && !dm.request && !dm.spam);
        }
        let Some(server) = self.servers.iter().find(|server| server.id == guild) else {
            return false;
        };
        let Some(channel) = server.channels().find(|entry| entry.id == channel) else {
            return true;
        };
        channel.marks.access != Access::Hidden
            && (server.roles.is_empty()
                || self.user_id.as_deref().is_some_and(|user| {
                    server.channel_permissions(channel.channel, user, &server.marks.roles)
                        & ready::permission::READ_MESSAGE_HISTORY
                        != 0
                }))
    }
}

impl Discord {
    pub async fn recent_mentions(
        &self,
        guild: Option<&str>,
        include_everyone: bool,
        include_roles: bool,
        before: Option<u64>,
    ) -> Result<RecentMentions> {
        let values = self
            .api
            .recent_mentions(guild, include_everyone, include_roles, before)
            .await?;
        let snapshot = self.snapshots.borrow().clone();
        let (before, by_guild) = recent_page(&snapshot, guild, before, values, now_ms());
        let mut messages: Vec<_> = by_guild
            .into_iter()
            .flat_map(|(guild, values)| {
                let (messages, _) = self.learn(&guild, &values, false);
                messages
                    .into_iter()
                    .map(move |message| (guild.clone(), message))
            })
            .collect();
        // Sorting by snowflake keeps messages sent in the same second in order.
        messages.sort_unstable_by_key(|(_, message)| {
            std::cmp::Reverse(message.id.parse::<u64>().unwrap_or_default())
        });
        Ok(RecentMentions { messages, before })
    }

    pub async fn dismiss_mention(&self, message: u64) -> Result<()> {
        self.api.dismiss_mention(message).await
    }
}

fn recent_page(
    snapshot: &Snapshot,
    guild: Option<&str>,
    before: Option<u64>,
    values: Vec<Value>,
    now: u64,
) -> (Option<u64>, BTreeMap<String, Vec<Value>>) {
    let full = values.len() >= RECENT_MENTIONS_PAGE;
    let oldest = now.saturating_sub(RECENT_MENTION_AGE.as_millis() as u64);
    let mut next = None;
    let mut by_guild: BTreeMap<String, Vec<Value>> = BTreeMap::new();
    let mut seen = HashSet::new();
    for value in values {
        let Some(raw) = value["id"].as_str() else {
            continue;
        };
        let Ok(id) = raw.parse::<u64>() else { continue };
        if id == 0 || before.is_some_and(|before| id >= before) {
            continue;
        }
        // Advance past every server result, even an inaccessible channel that
        // is omitted locally. Stop as soon as the page extends past a week.
        next = Some(next.map_or(id, |known: u64| known.min(id)));
        if message::snowflake_ms(raw) < oldest || !seen.insert(id) {
            continue;
        }
        if let Some(guild) = mention_guild(snapshot, guild, &value) {
            by_guild.entry(guild.to_owned()).or_default().push(value);
        }
    }
    let before = next.filter(|id| full && *id > message::snowflake_at(oldest));
    (before, by_guild)
}

fn mention_guild<'a>(
    snapshot: &'a Snapshot,
    scope: Option<&str>,
    value: &Value,
) -> Option<&'a str> {
    let channel = value["channel_id"].as_str()?;
    channel.parse::<u64>().ok().filter(|id| *id > 0)?;
    let author = value["author"]["id"].as_str()?;
    if snapshot
        .blocked
        .iter()
        .chain(snapshot.ignored.iter())
        .any(|id| id == author)
    {
        return None;
    }

    let known = snapshot
        .servers
        .iter()
        .find(|server| server.channel(channel).is_some());
    let reported = value["guild_id"].as_str();
    if let (Some(known), Some(reported)) = (known, reported)
        && known.id != reported
    {
        return None;
    }
    if let Some(guild) = reported
        .or_else(|| known.map(|server| server.id.as_str()))
        .or(scope)
    {
        if scope.is_some_and(|scope| scope != guild) {
            return None;
        }
        return snapshot
            .servers
            .iter()
            .find(|server| server.id == guild)
            .filter(|_| snapshot.may_see_recent_mention(guild, channel))
            .map(|server| server.id.as_str());
    }
    snapshot
        .may_see_recent_mention(PRIVATE, channel)
        .then_some(PRIVATE)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn recent_mentions_route_by_channel_and_drop_unavailable_or_old_messages() {
        let now = 1_800_000_000_000;
        let id = |age| message::snowflake_at(now - age).to_string();
        let value = |id: String, room: &str, guild: Option<&str>, author: &str| {
            let mut value = json!({"id": id, "channel_id": room, "author": {"id": author}});
            if let Some(guild) = guild {
                value["guild_id"] = json!(guild);
            }
            value
        };
        let server = Server {
            id: "10".into(),
            text_channels: vec![
                ready::Channel {
                    id: "11".into(),
                    ..Default::default()
                },
                ready::Channel {
                    id: "12".into(),
                    ..Default::default()
                },
            ],
            ..Default::default()
        };
        let snapshot = Snapshot {
            user_id: Some("50".into()),
            servers: vec![crate::marked::MarkedServer::marked(
                server,
                Default::default(),
                |channel| crate::marked::ChannelMarks {
                    access: if channel.id == "12" {
                        Access::Hidden
                    } else {
                        Access::Join
                    },
                    ..Default::default()
                },
            )],
            conversations: vec![
                Arc::new(Conversation {
                    id: "21".into(),
                    ..Default::default()
                }),
                Arc::new(Conversation {
                    id: "22".into(),
                    request: true,
                    ..Default::default()
                }),
            ],
            blocked: Arc::from(["77".to_owned()]),
            ..Default::default()
        };
        let (before, page) = recent_page(
            &snapshot,
            None,
            None,
            vec![
                value(id(1), "11", None, "60"),
                value(id(2), "12", Some("10"), "60"),
                value(id(3), "13", Some("10"), "60"),
                value(id(4), "21", None, "60"),
                value(id(5), "22", None, "60"),
                value(id(6), "21", None, "77"),
                value(
                    id(RECENT_MENTION_AGE.as_millis() as u64 + 1),
                    "11",
                    Some("10"),
                    "60",
                ),
            ],
            now,
        );
        assert_eq!(before, None);
        assert_eq!(
            page["10"]
                .iter()
                .map(|value| value["id"].as_str().unwrap())
                .collect::<Vec<_>>(),
            vec![id(1), id(3)]
        );
        assert_eq!(page[PRIVATE][0]["id"].as_str(), Some(id(4).as_str()));

        let values = (1..=RECENT_MENTIONS_PAGE)
            .map(|age| value(id(age as u64), "12", Some("10"), "60"))
            .collect();
        let (before, page) = recent_page(&snapshot, Some("10"), None, values, now);
        assert_eq!(before, id(RECENT_MENTIONS_PAGE as u64).parse().ok());
        assert!(
            page.is_empty(),
            "inaccessible rows still advance the cursor"
        );
    }
}
