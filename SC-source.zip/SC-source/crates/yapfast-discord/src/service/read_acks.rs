//! Ordered acknowledgements: normal reads coalesce for a second; manual
//! rewinds cancel queued reads and follow any write already running.
//! One retained future is polled by the session; no worker or idle polling.
use crate::api::{ACK_BULK_LIMIT, Api};
use anyhow::Result;
use futures_util::future::BoxFuture;
use std::{
    collections::{HashMap, VecDeque},
    pin::Pin,
    sync::Arc,
};
use tokio::{
    sync::oneshot,
    time::{Duration, Instant, Sleep},
};

const ACK_DELAY: Duration = Duration::from_secs(1);
const MANUAL_LIMIT: usize = 32;

#[derive(Clone, Debug, PartialEq, Eq)]
enum Write {
    Local,
    Read(Vec<(String, String)>),
    Unread {
        channel: String,
        message: u64,
        mentions: u64,
    },
}

pub(super) struct UnreadDone {
    pub channel: String,
    pub message: u64,
    pub mentions: u64,
    pub received: u64,
    pub sync: bool,
    pub reply: oneshot::Sender<Result<Option<u64>>>,
    pub result: Result<()>,
}

type Writer = Arc<dyn Fn(Write) -> BoxFuture<'static, Result<()>> + Send + Sync>;
type Running = BoxFuture<'static, Option<UnreadDone>>;

pub(super) struct ReadAcks {
    write: Writer,
    waiting: HashMap<String, String>,
    manuals: VecDeque<UnreadDone>,
    // The session can cancel its select without losing the active write.
    running: Option<Running>,
    manual_channel: Option<String>,
    at: Pin<Box<Sleep>>,
}

impl ReadAcks {
    pub(super) fn new(api: Arc<Api>) -> Self {
        Self::with_writer(Arc::new(move |write| {
            let api = api.clone();
            Box::pin(async move {
                match write {
                    Write::Local => Ok(()),
                    Write::Unread {
                        channel,
                        message,
                        mentions,
                    } => {
                        api.ack_unread(&channel, &message.to_string(), mentions)
                            .await
                    }
                    Write::Read(reads) => {
                        if let [(channel, message)] = reads.as_slice() {
                            api.ack(channel, message).await
                        } else {
                            for batch in reads.chunks(ACK_BULK_LIMIT) {
                                api.ack_bulk(batch).await?;
                            }
                            Ok(())
                        }
                    }
                }
            })
        }))
    }

    fn with_writer(write: Writer) -> Self {
        Self {
            write,
            waiting: HashMap::new(),
            manuals: VecDeque::new(),
            running: None,
            manual_channel: None,
            at: Box::pin(tokio::time::sleep(ACK_DELAY)),
        }
    }

    pub(super) fn read(&mut self, channel: String, message: String) {
        if self.manual_channel.as_deref() == Some(&channel)
            || self
                .manuals
                .iter()
                .any(|pending| pending.channel == channel)
        {
            return;
        }
        if self.waiting.is_empty() {
            self.at.as_mut().reset(Instant::now() + ACK_DELAY);
        }
        self.waiting.insert(channel, message);
    }

    pub(super) fn unread(&mut self, pending: UnreadDone) {
        if self.manuals.len() >= MANUAL_LIMIT {
            let _ = pending.reply.send(Err(anyhow::anyhow!(
                "Too many unread changes are waiting. Try again shortly."
            )));
            return;
        }
        self.waiting.remove(&pending.channel);
        self.manuals.push_back(pending);
    }

    pub(super) fn waiting(&self) -> bool {
        !self.waiting.is_empty() || !self.manuals.is_empty() || self.running.is_some()
    }

    pub(super) fn can_unread(&self) -> bool {
        self.manuals.len() < MANUAL_LIMIT
    }

    pub(super) async fn send_when_due(&mut self) -> Option<UnreadDone> {
        if self.running.is_none() {
            if let Some(mut pending) = self.manuals.pop_front() {
                self.manual_channel = Some(pending.channel.clone());
                let write = (self.write)(if pending.sync {
                    Write::Unread {
                        channel: pending.channel.clone(),
                        message: pending.message,
                        mentions: pending.mentions,
                    }
                } else {
                    Write::Local
                });
                self.running = Some(Box::pin(async move {
                    pending.result = write.await;
                    Some(pending)
                }));
            } else {
                self.at.as_mut().await;
                let write = (self.write)(Write::Read(self.waiting.drain().collect()));
                self.running = Some(Box::pin(async move {
                    if write.await.is_err() {
                        tracing::warn!("could not mark Discord channels read");
                    }
                    None
                }));
            }
        }
        let done = self.running.as_mut().unwrap().await;
        self.running = None;
        self.manual_channel = None;
        done
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;

    fn pending(channel: &str, message: u64) -> UnreadDone {
        let (reply, _) = oneshot::channel();
        UnreadDone {
            channel: channel.into(),
            message,
            mentions: 2,
            received: 0,
            sync: true,
            reply,
            result: Ok(()),
        }
    }

    #[tokio::test]
    async fn manual_unread_cancels_waiting_read_and_keeps_other_channels() {
        let writes = Arc::new(Mutex::new(vec![]));
        let seen = writes.clone();
        let mut acks = ReadAcks::with_writer(Arc::new(move |write| {
            seen.lock().unwrap().push(write);
            Box::pin(async { Ok(()) })
        }));
        acks.read("10".into(), "100".into());
        acks.read("20".into(), "200".into());
        acks.unread(pending("10", 49));
        acks.read("10".into(), "100".into());
        let done = acks.send_when_due().await.unwrap();
        assert_eq!(done.message, 49);
        acks.at.as_mut().reset(Instant::now());
        assert!(acks.send_when_due().await.is_none());
        assert_eq!(
            *writes.lock().unwrap(),
            vec![
                Write::Unread {
                    channel: "10".into(),
                    message: 49,
                    mentions: 2
                },
                Write::Read(vec![("20".into(), "200".into())])
            ]
        );
        assert!(!acks.waiting());
    }

    #[tokio::test]
    async fn manual_unread_waits_for_inflight_ack_across_select_cancellation() {
        let writes = Arc::new(Mutex::new(vec![]));
        let gate = Arc::new(tokio::sync::Notify::new());
        let (seen, release) = (writes.clone(), gate.clone());
        let mut acks = ReadAcks::with_writer(Arc::new(move |write| {
            let first = matches!(write, Write::Read(_));
            seen.lock().unwrap().push(write);
            let release = release.clone();
            Box::pin(async move {
                if first {
                    release.notified().await;
                }
                Ok(())
            })
        }));
        acks.read("10".into(), "100".into());
        acks.at.as_mut().reset(Instant::now());
        assert!(
            tokio::time::timeout(Duration::from_millis(10), acks.send_when_due())
                .await
                .is_err()
        );
        acks.unread(pending("10", 49));
        assert_eq!(writes.lock().unwrap().len(), 1);
        gate.notify_one();
        assert!(acks.send_when_due().await.is_none());
        assert!(acks.send_when_due().await.unwrap().result.is_ok());
        assert!(matches!(
            &writes.lock().unwrap()[1],
            Write::Unread { message: 49, .. }
        ));
        assert!(!acks.waiting());
    }

    #[tokio::test]
    async fn manual_unread_local_only_cancels_sync_batch_without_http() {
        let writes = Arc::new(Mutex::new(vec![]));
        let seen = writes.clone();
        let mut acks = ReadAcks::with_writer(Arc::new(move |write| {
            seen.lock().unwrap().push(write);
            Box::pin(async { Ok(()) })
        }));
        acks.read("10".into(), "100".into());
        let mut local = pending("10", 49);
        local.sync = false;
        acks.unread(local);
        assert!(acks.send_when_due().await.unwrap().result.is_ok());
        assert_eq!(*writes.lock().unwrap(), vec![Write::Local]);
        assert!(!acks.waiting());
    }
}
