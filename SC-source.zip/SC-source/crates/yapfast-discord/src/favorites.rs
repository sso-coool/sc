//! Read-only import of the Favorites pseudo-guild in PreloadedUserSettings.
//! Field numbers come from Discord's extracted client protobuf:
//! <https://github.com/discord-userdoccers/discord-protos/blob/master/discord_protos/discord_users/v1/PreloadedUserSettings.proto>.
//! No encoder or cloud mutation is provided. Unknown fields are ignored.

use crate::settings::{Field, fields, message};
use base64::Engine;

const FAVORITES: u64 = 15;
pub const MAX_CHANNELS: usize = 200;
const MAX_NAME: usize = 128;
// The documented maximum serialized settings payload, checked before decoding.
const MAX_ENCODED: usize = 5_242_880;

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Favorites {
    pub channels: Vec<FavoriteChannel>,
    pub muted: bool,
    pub visible: Option<bool>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FavoriteKind {
    Reference,
    Category,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct FavoriteChannel {
    pub id: String,
    pub nickname: String,
    pub kind: FavoriteKind,
    pub position: u32,
    /// "0" means no parent category.
    pub parent: String,
    pub channel_type: Option<u32>,
    pub collapsed: bool,
}

/// Absent/malformed Favorites leaves the previous value unchanged. An
/// explicitly empty top-level field is a known empty collection. Discord
/// replaces whole top-level settings fields, including their subfields.
pub fn read(encoded: &str) -> Option<Favorites> {
    if encoded.len() > MAX_ENCODED {
        return None;
    }
    let data = base64::engine::general_purpose::STANDARD
        .decode(encoded)
        .ok()?;
    if !valid_message(&data) {
        return None;
    }
    let favorites = message(&data, FAVORITES)?;
    if !valid_message(favorites) {
        return None;
    }
    let mut result = Favorites::default();
    for (number, value) in fields(favorites) {
        match (number, value) {
            (1, Field::Bytes(entry)) if result.channels.len() < MAX_CHANNELS => {
                if let Some(channel) = channel(entry) {
                    if let Some(kept) = result
                        .channels
                        .iter_mut()
                        .find(|kept| kept.id == channel.id)
                    {
                        *kept = channel;
                    } else {
                        result.channels.push(channel);
                    }
                }
            }
            (2, Field::Varint(muted)) => result.muted = muted != 0,
            (3, Field::Bytes(wrapper)) if valid_message(wrapper) => {
                result.visible = Some(
                    fields(wrapper)
                        .find_map(|(number, value)| match (number, value) {
                            (1, Field::Varint(value)) => Some(value != 0),
                            _ => None,
                        })
                        .unwrap_or(false),
                );
            }
            _ => {}
        }
    }
    result
        .channels
        .sort_by(|a, b| a.position.cmp(&b.position).then_with(|| a.id.cmp(&b.id)));
    Some(result)
}

fn channel(entry: &[u8]) -> Option<FavoriteChannel> {
    if !valid_message(entry) {
        return None;
    }
    let mut id = None;
    let mut value = None;
    for (number, field) in fields(entry) {
        match (number, field) {
            (1, Field::Fixed64(key)) if key != 0 => id = Some(key),
            (2, Field::Bytes(bytes)) => value = Some(bytes),
            _ => {}
        }
    }
    let value = value?;
    if !valid_message(value) {
        return None;
    }
    let mut nickname = String::new();
    let mut kind = None;
    let mut position = 0;
    let mut parent = 0;
    let mut channel_type = None;
    let mut collapsed = false;
    for (number, field) in fields(value) {
        match (number, field) {
            (1, Field::Bytes(name)) => {
                nickname = std::str::from_utf8(name)
                    .ok()?
                    .chars()
                    .filter(|c| !c.is_control())
                    .take(MAX_NAME)
                    .collect()
            }
            (2, Field::Varint(value)) => {
                kind = match value {
                    1 => Some(FavoriteKind::Reference),
                    2 => Some(FavoriteKind::Category),
                    _ => None,
                }
            }
            (3, Field::Varint(value)) => position = u32::try_from(value).ok()?,
            (4, Field::Fixed64(value)) => parent = value,
            (5, Field::Bytes(wrapper)) if valid_message(wrapper) => {
                channel_type = Some(
                    fields(wrapper)
                        .find_map(|(number, field)| match (number, field) {
                            (1, Field::Varint(value)) => u32::try_from(value).ok(),
                            _ => None,
                        })
                        .unwrap_or(0),
                );
            }
            (6, Field::Varint(value)) => collapsed = value != 0,
            _ => {}
        }
    }
    Some(FavoriteChannel {
        id: id?.to_string(),
        nickname,
        kind: kind?,
        position,
        parent: parent.to_string(),
        channel_type,
        collapsed,
    })
}

/// The shared field iterator intentionally reads a valid prefix. Favorites
/// must not interpret a truncated payload as a deliberate empty collection.
fn valid_message(mut data: &[u8]) -> bool {
    fn varint(data: &mut &[u8]) -> Option<u64> {
        let mut value = 0;
        for shift in (0..64).step_by(7) {
            let (&byte, rest) = data.split_first()?;
            *data = rest;
            if shift == 63 && byte > 1 {
                return None;
            }
            value |= u64::from(byte & 127) << shift;
            if byte & 128 == 0 {
                return Some(value);
            }
        }
        None
    }
    while !data.is_empty() {
        let Some(key) = varint(&mut data).filter(|key| *key >> 3 != 0) else {
            return false;
        };
        let length = match key & 7 {
            0 => {
                if varint(&mut data).is_none() {
                    return false;
                }
                continue;
            }
            1 => 8,
            2 => match varint(&mut data).and_then(|n| usize::try_from(n).ok()) {
                Some(n) => n,
                None => return false,
            },
            5 => 4,
            _ => return false,
        };
        let Some(rest) = data.get(length..) else {
            return false;
        };
        data = rest;
    }
    true
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::settings::{put_bytes, put_field, put_fixed64};

    fn entry(id: u64, kind: u64, name: &str, position: u64, parent: u64) -> Vec<u8> {
        let mut value = vec![];
        put_bytes(&mut value, 1, name.as_bytes());
        put_field(&mut value, 2, &Field::Varint(kind));
        put_field(&mut value, 3, &Field::Varint(position));
        put_fixed64(&mut value, 4, parent);
        let mut wrapper = vec![];
        put_field(&mut wrapper, 1, &Field::Varint(3));
        put_bytes(&mut value, 5, &wrapper);
        put_field(&mut value, 6, &Field::Varint(1));
        let mut entry = vec![];
        put_fixed64(&mut entry, 1, id);
        put_bytes(&mut entry, 2, &value);
        entry
    }
    fn encoded(favorites: &[u8]) -> String {
        let mut proto = vec![];
        put_bytes(&mut proto, FAVORITES, favorites);
        base64::engine::general_purpose::STANDARD.encode(proto)
    }

    #[test]
    fn channel_favorites_reads_categories_references_and_wrappers() {
        let mut bytes = vec![];
        put_bytes(&mut bytes, 1, &entry(22, 1, "My group", 2, 10));
        put_bytes(&mut bytes, 1, &entry(10, 2, "People", 1, 0));
        put_field(&mut bytes, 2, &Field::Varint(1));
        put_bytes(&mut bytes, 3, &[]); // present false BoolValue
        put_field(&mut bytes, 8, &Field::Varint(1)); // a newer setting, ignored
        let favorites = read(&encoded(&bytes)).unwrap();
        assert!(favorites.muted);
        assert_eq!(favorites.visible, Some(false));
        assert_eq!(favorites.channels[0].kind, FavoriteKind::Category);
        assert_eq!(
            favorites.channels[1],
            FavoriteChannel {
                id: "22".into(),
                nickname: "My group".into(),
                kind: FavoriteKind::Reference,
                position: 2,
                parent: "10".into(),
                channel_type: Some(3),
                collapsed: true,
            }
        );
    }

    #[test]
    fn channel_favorites_distinguishes_empty_absent_and_malformed_updates() {
        assert_eq!(read(&encoded(&[])), Some(Favorites::default()));
        assert_eq!(read(""), None);
        assert_eq!(read("invalid base64"), None);
        assert_eq!(read(&encoded(&[10, 5, 1])), None);
        assert!(!valid_message(&[0]));
        assert!(!valid_message(&[
            8, 255, 255, 255, 255, 255, 255, 255, 255, 255, 2
        ]));
        let mut other = vec![];
        put_bytes(&mut other, 11, &[]);
        assert_eq!(
            read(&base64::engine::general_purpose::STANDARD.encode(other)),
            None
        );
    }

    #[test]
    fn channel_favorites_bounds_names_entries_and_skips_unknown_kinds() {
        let mut bytes = vec![];
        put_bytes(&mut bytes, 1, &entry(0, 1, "no id", 0, 0));
        put_bytes(&mut bytes, 1, &entry(999, 99, "new kind", 0, 0));
        for id in 1..=250 {
            put_bytes(&mut bytes, 1, &entry(id, 1, &"🦀\n".repeat(150), id, 0));
        }
        let favorites = read(&encoded(&bytes)).unwrap();
        assert_eq!(favorites.channels.len(), MAX_CHANNELS);
        assert_eq!(favorites.channels[0].nickname.chars().count(), MAX_NAME);
        assert!(!favorites.channels[0].nickname.contains('\n'));
        assert_eq!(favorites.channels.last().unwrap().id, "200");
    }
}
