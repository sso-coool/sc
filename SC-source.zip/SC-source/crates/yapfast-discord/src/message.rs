//! Discord messages as Yapfast shows them. Parsing keeps the raw content, and
//! rendering replaces mentions with the names known when it runs, so names
//! learned later show on messages already loaded.

use std::{
    collections::{HashMap, HashSet},
    sync::{
        Arc, Mutex,
        atomic::{AtomicU64, Ordering::Relaxed},
    },
};

use serde_json::Value;

use crate::{
    collectibles::{self, Nameplate, Plate, Style},
    components::{self, Card},
    embed::{self, Embed},
    marked::ServerMarks,
    ready::{self, Server},
};

/// Discord counts from the first second of 2015.
pub(crate) const DISCORD_EPOCH_MS: u64 = 1_420_070_400_000;

const DEFAULT: u64 = 0;
const RECIPIENT_ADD: u64 = 1;
const RECIPIENT_REMOVE: u64 = 2;
const CALL: u64 = 3;
const CHANNEL_NAME_CHANGE: u64 = 4;
const PINNED: u64 = 6;
const MEMBER_JOIN: u64 = 7;
const THREAD_CREATED: u64 = 18;
const REPLY: u64 = 19;
const CHAT_INPUT_COMMAND: u64 = 20;
const THREAD_STARTER_MESSAGE: u64 = 21;
const CONTEXT_MENU_COMMAND: u64 = 23;
const POLL_RESULT: u64 = 46;

/// The reference of a forward, which carries a copy of the message it
/// forwards in `message_snapshots`.
const FORWARD: u64 = 1;

/// The key of `authorizing_integration_owners` for an app installed on a
/// user's account rather than in a server.
const USER_INSTALL: &str = "1";

/// The message flag that hides its embeds.
const SUPPRESS_EMBEDS: u64 = 1 << 2;
/// The message flag of an app's answer only the person who used the app
/// sees, which Discord keeps out of the channel's history.
pub const EPHEMERAL: u64 = 1 << 6;
/// The message flag of an app's answer still to come: the app is
/// "thinking".
pub const LOADING: u64 = 1 << 7;
/// The message flag of a voice message, whose only attachment is its
/// recording.
const IS_VOICE_MESSAGE: u64 = 1 << 13;
/// The most of a voice message's waveform Discord sends: a byte for each
/// point.
const WAVEFORM_POINTS: usize = 256;
/// The message flags Discord's client forwards a message with: crossposts,
/// hidden embeds, threads, @silent, voice messages, forwards and the like,
/// but not ephemeral or loading messages, or flags it doesn't know.
const FORWARDABLE_FLAGS: u64 = 1 << 0
    | 1 << 1
    | SUPPRESS_EMBEDS
    | 1 << 4
    | 1 << 5
    | 1 << 8
    | 1 << 9
    | 1 << 10
    | 1 << 12
    | IS_VOICE_MESSAGE
    | 1 << 14
    | 1 << 15
    | 1 << 19
    | 1 << 20;

/// Missing sticker formats default to PNG.
const STICKER_PNG: u64 = 1;
/// The size Discord shows stickers at.
use crate::stickers::MESSAGE_SIZE as STICKER_SIZE;

/// The attachment flag that marks a spoiler.
pub(crate) const IS_SPOILER: u64 = 1 << 3;
/// The flag of an attachment, or an embed's picture, that moves.
const IS_ANIMATED: u64 = 1 << 5;

/// Whether an attachment or an embed's picture moves: Discord marks it
/// animated, or it's a GIF.
pub(crate) fn animated(media: &Value) -> bool {
    media["flags"].as_u64().unwrap_or_default() & IS_ANIMATED != 0
        || media["content_type"].as_str() == Some("image/gif")
}

/// A page of a channel's history, oldest first.
#[derive(Debug)]
pub struct Page {
    /// The messages Yapfast shows, which may be fewer than Discord sent.
    pub messages: Vec<Message>,
    /// The snowflake of the oldest message Discord sent, shown or not;
    /// earlier history is before it.
    pub oldest: Option<u64>,
    /// Discord sent a whole page, so there may be more beyond it: before
    /// it, or for a page after a snowflake, after it. For a page around a
    /// snowflake, the half before it was whole.
    pub full: bool,
    /// A page around a snowflake reaches the channel's newest message: the
    /// half from the snowflake on wasn't whole.
    pub newest: bool,
}

#[derive(Clone, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct Message {
    pub id: String,
    pub channel_id: String,
    #[serde(default)]
    pub application_id: Option<String>,
    #[serde(default)]
    pub flags: u64,
    /// The client's nonce, on messages this account sent.
    pub nonce: Option<String>,
    pub author_id: String,
    /// The author's name from the message itself, used until a better one is known.
    pub author: String,
    /// The author is a bot or webhook, which Discord tags.
    #[serde(default)]
    pub bot: bool,
    /// Discord Markdown with mentions still as `<@id>`.
    pub content: String,
    /// Shown after the author's name instead of content on system messages.
    pub system: Option<String>,
    /// What such a notice tells of, which its icon and links show.
    #[serde(default)]
    pub notice: Option<Notice>,
    pub edited: bool,
    pub reply: Option<Reply>,
    /// Its files, then its embeds' pictures.
    pub attachments: Vec<Attachment>,
    pub embeds: Vec<Embed>,
    /// Its buttons and menus, or for a message of components alone, all it
    /// shows; their pictures and files are among `attachments`.
    #[serde(default)]
    pub components: Vec<Card>,
    pub reactions: Vec<Reaction>,
    /// Content can be edited by its author: an ordinary message or reply.
    pub editable: bool,
    /// Who it mentions, by user id, including the author of the message it
    /// replies to when the reply pings them.
    #[serde(default)]
    pub mentions: Vec<String>,
    /// The roles it mentions, by id, as Discord counts them: only those the
    /// author may mention.
    #[serde(default)]
    pub mention_roles: Vec<String>,
    /// It mentions @everyone or @here, and its author may.
    #[serde(default)]
    pub mention_everyone: bool,
    /// The thread started from it, or that a notice of one names.
    #[serde(default)]
    pub thread: Option<ThreadLink>,
    /// Among its channel's pinned messages.
    #[serde(default)]
    pub pinned: bool,
    /// Forwarded from another message, whose content, files and embeds it
    /// shows as its own.
    #[serde(default)]
    pub forwarded: bool,
    /// Discord message activity type 3: an invitation to listen together.
    /// A partial message update may leave the activity field out.
    #[serde(default)]
    pub listen_invite: Option<bool>,
    /// Can be forwarded, as Discord's client decides from the message
    /// alone: written, and without a poll, a call or an activity.
    #[serde(default)]
    pub forwardable: bool,
    /// Discord disallows deleting it, as with certain system messages and a
    /// thread's first message, which shows the one it was started from.
    #[serde(default)]
    pub undeletable: bool,
    /// Who ran the command it answers, for an app installed on their
    /// account, who may delete it as their own.
    #[serde(default)]
    pub invoker: Option<String>,
    /// The interaction it answers: whose, and the command they used.
    #[serde(default)]
    pub interaction: Option<Interaction>,
    /// The poll it asks, if it's one.
    #[serde(default)]
    pub poll: Option<Poll>,
    /// An app's answer only this account sees ([`EPHEMERAL`]): it isn't in
    /// the channel's history, and it's never kept on disk.
    #[serde(default)]
    pub ephemeral: bool,
    /// An app's answer still to come ([`LOADING`]), shown as the app
    /// thinking until Discord updates it.
    #[serde(default)]
    pub loading: bool,
    /// What a voice message's recording, its first attachment, sounds like.
    #[serde(default)]
    pub voice: Option<VoiceMessage>,
}

/// The interaction an app's message answers, from its
/// `interaction_metadata`, or the deprecated `interaction` without it.
#[derive(Clone, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct Interaction {
    /// The id INTERACTION_CREATE gave it.
    pub id: String,
    /// The named slash command that opened a modal, distinct from its submission.
    #[serde(default)]
    pub command_interaction_id: Option<String>,
    /// A follow-up's original response, in this same channel.
    #[serde(default)]
    pub original_response_message_id: Option<String>,
    /// Who used it, by id and the name the interaction carries.
    pub user_id: String,
    pub user: String,
    /// Guild and user installation owners identified by Discord.
    #[serde(default)]
    pub installation_guild_id: Option<String>,
    #[serde(default)]
    pub installation_user_id: Option<String>,
    /// Submitted command options supplied inline for this message.
    #[serde(skip)]
    pub data: Option<Arc<Value>>,
    /// The command used, with its subcommands' names, as `ban user`: for a
    /// form's answer, the command that opened the form. None for a button
    /// or a menu.
    pub name: Option<String>,
    /// [`CHAT_INPUT`], [`USER_COMMAND`] or [`MESSAGE_COMMAND`].
    pub command_type: Option<u64>,
    /// The person a user command was used on, by id and name.
    pub target_user: Option<(String, String)>,
    /// The message a message command was used on.
    pub target_message_id: Option<String>,
    /// The message whose button or menu was used.
    pub interacted_message_id: Option<String>,
}

/// An application command's `command_type`: a slash command.
pub const CHAT_INPUT: u64 = 1;
/// One used on a person, from their menu.
pub const USER_COMMAND: u64 = 2;
/// One used on a message, from its menu.
pub const MESSAGE_COMMAND: u64 = 3;

/// The interaction types whose metadata names what was used.
const APPLICATION_COMMAND: u64 = 2;
const MODAL_SUBMIT: u64 = 5;

impl Interaction {
    fn of(value: &Value) -> Option<Self> {
        let legacy = &value["interaction"];
        let metadata = match &value["interaction_metadata"] {
            Value::Object(_) => &value["interaction_metadata"],
            _ => legacy,
        };
        // A form's answer names the command, or the button, that opened it.
        let used = match metadata["triggering_interaction_metadata"] {
            Value::Object(_) if metadata["type"].as_u64() == Some(MODAL_SUBMIT) => {
                &metadata["triggering_interaction_metadata"]
            }
            _ => metadata,
        };
        let user = &metadata["user"];
        let id = |value: &Value| value.as_str().map(str::to_owned);
        let source_type = used["type"].as_u64();
        let source_id = used["id"]
            .as_str()
            .filter(|id| valid_interaction_snowflake(id));
        // The modern object may omit the command name and type. Older
        // payloads can include the legacy object alongside it.
        let matching_legacy = legacy.as_object().is_some()
            && source_id.is_some()
            && source_id == legacy["id"].as_str()
            && legacy["type"]
                .as_u64()
                .is_none_or(|kind| kind == APPLICATION_COMMAND);
        let command_type = used["command_type"].as_u64().or_else(|| {
            if source_type != Some(APPLICATION_COMMAND) {
                return None;
            }
            if used["target_user"]["id"].is_string() {
                return Some(USER_COMMAND);
            }
            if used["target_message_id"].is_string() {
                return Some(MESSAGE_COMMAND);
            }
            // A targetless application command normally comes from chat
            // input. A context-menu response without its target is ambiguous.
            (value["type"].as_u64() != Some(CONTEXT_MENU_COMMAND)).then_some(CHAT_INPUT)
        });
        let named = |metadata: &Value| id(&metadata["name"]).filter(|name| !name.is_empty());
        let name = if source_type.is_none_or(|kind| kind == APPLICATION_COMMAND) {
            named(used).or_else(|| matching_legacy.then(|| named(legacy)).flatten())
        } else {
            None
        };
        let owners = &metadata["authorizing_integration_owners"];
        let owner = |kind: &str| {
            owners[kind]
                .as_str()
                .filter(|id| valid_interaction_snowflake(id))
                .map(str::to_owned)
        };
        Some(Self {
            id: metadata["id"].as_str()?.to_owned(),
            command_interaction_id: source_id
                .filter(|source| Some(*source) != metadata["id"].as_str())
                .map(str::to_owned),
            original_response_message_id: used["original_response_message_id"]
                .as_str()
                .filter(|source| valid_interaction_snowflake(source))
                .map(str::to_owned),
            user_id: id(&user["id"]).unwrap_or_default(),
            user: ready::display_name(user)
                .unwrap_or("Discord user")
                .to_owned(),
            installation_guild_id: owner("0"),
            installation_user_id: owner("1"),
            data: value
                .get("interaction_data")
                .filter(|data| command_type == Some(CHAT_INPUT) && data.is_object())
                .cloned()
                .map(Arc::new),
            name,
            command_type,
            target_user: id(&used["target_user"]["id"]).map(|target| {
                let name = ready::display_name(&used["target_user"]).unwrap_or("Discord user");
                (target, name.to_owned())
            }),
            target_message_id: id(&used["target_message_id"]),
            interacted_message_id: id(&used["interacted_message_id"]),
        })
    }
}

fn valid_interaction_snowflake(id: &str) -> bool {
    !id.is_empty()
        && id.len() <= 20
        && id.bytes().all(|byte| byte.is_ascii_digit())
        && id.parse::<u64>().is_ok_and(|id| id != 0)
}

/// A voice message's recording as Discord describes it, to show before it's
/// downloaded.
#[derive(Clone, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct VoiceMessage {
    /// How long it plays, in milliseconds.
    pub duration_ms: u64,
    /// How loud it is along its length: up to 256 points from 0 to 255.
    pub waveform: Arc<[u8]>,
}

impl VoiceMessage {
    /// A voice message's recording, from its message's flags and its first
    /// attachment's `duration_secs` and base64 `waveform`.
    fn of(message: &Value) -> Option<Self> {
        use base64::Engine;
        if message["flags"].as_u64().unwrap_or_default() & IS_VOICE_MESSAGE == 0 {
            return None;
        }
        let recording = &message["attachments"][0];
        let seconds = recording["duration_secs"].as_f64().unwrap_or_default();
        let mut waveform = recording["waveform"]
            .as_str()
            .and_then(|waveform| {
                base64::engine::general_purpose::STANDARD
                    .decode(waveform)
                    .ok()
            })
            .unwrap_or_default();
        waveform.truncate(WAVEFORM_POINTS);
        Some(Self {
            duration_ms: (seconds.max(0.0) * 1000.0).round() as u64,
            waveform: waveform.into(),
        })
    }
}

/// A message's poll, its votes as Discord counted them when the message
/// came, with those that came live since.
#[derive(Clone, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct Poll {
    pub question: String,
    pub answers: Vec<PollAnswer>,
    /// When it closes, in Unix milliseconds.
    pub expiry: Option<u64>,
    /// One may pick several answers.
    pub multiselect: bool,
    /// The message carried the votes; without them they aren't known,
    /// rather than none.
    pub counted: bool,
    /// Discord counted the votes for the last time, once it closed.
    pub finalized: bool,
}

#[derive(Clone, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct PollAnswer {
    pub id: u64,
    pub text: String,
    /// Its emoji as a reaction's key: the emoji itself, or `:name:` for a
    /// custom one, whose id follows.
    pub emoji: Option<(String, Option<String>)>,
    pub votes: usize,
    /// This account voted for it.
    pub me: bool,
}

impl Poll {
    /// A message's `poll` object.
    fn of(poll: &Value) -> Option<Self> {
        let counts = poll["results"]["answer_counts"].as_array();
        let answers = poll["answers"]
            .as_array()?
            .iter()
            .filter_map(|answer| {
                let id = answer["answer_id"].as_u64()?;
                let media = &answer["poll_media"];
                let count = counts
                    .into_iter()
                    .flatten()
                    .find(|count| count["id"].as_u64() == Some(id));
                let emoji = &media["emoji"];
                Some(PollAnswer {
                    id,
                    text: media["text"].as_str().unwrap_or_default().to_owned(),
                    emoji: match (emoji["id"].as_str(), emoji["name"].as_str()) {
                        // Discord's client sends a custom one without its name.
                        (Some(id), name) => Some((
                            format!(":{}:", name.filter(|name| !name.is_empty()).unwrap_or(id)),
                            Some(id.to_owned()),
                        )),
                        (None, Some(name)) if !name.is_empty() => Some((name.to_owned(), None)),
                        _ => None,
                    },
                    votes: count.and_then(|count| count["count"].as_u64()).unwrap_or(0) as usize,
                    me: count.and_then(|count| count["me_voted"].as_bool()) == Some(true),
                })
            })
            .collect();
        Some(Self {
            question: poll["question"]["text"].as_str()?.to_owned(),
            answers,
            expiry: poll["expiry"].as_str().and_then(iso_ms),
            multiselect: poll["allow_multiselect"].as_bool().unwrap_or(false),
            counted: poll["results"].is_object(),
            finalized: poll["results"]["is_finalized"].as_bool().unwrap_or(false),
        })
    }

    /// Whether it no longer takes votes at `now`, in Unix milliseconds.
    pub fn closed(&self, now: u64) -> bool {
        self.finalized || self.expiry.is_some_and(|expiry| expiry <= now)
    }
}

/// A thread a message leads to, as the message carried it; the thread as
/// Yapfast knows it now, if it does, is newer.
#[derive(Clone, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct ThreadLink {
    pub id: String,
    pub name: String,
    /// Its messages after the first.
    pub messages: u64,
    pub archived: bool,
}

impl ThreadLink {
    /// A thread's channel object.
    fn of(thread: &Value) -> Option<Self> {
        Some(Self {
            id: thread["id"].as_str()?.to_owned(),
            name: thread["name"].as_str().unwrap_or_default().to_owned(),
            messages: thread["message_count"].as_u64().unwrap_or_default(),
            archived: thread["thread_metadata"]["archived"]
                .as_bool()
                .unwrap_or(false),
        })
    }
}

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum Reply {
    Message {
        /// The original message's id.
        id: String,
        author_id: String,
        author: String,
        content: String,
    },
    Deleted,
    /// Discord didn't look the original up, as in the MESSAGE_UPDATE that
    /// brings a link's preview: it may well still be there.
    Unknown {
        /// The original's id, in the reply's channel, empty when Discord
        /// didn't name it.
        id: String,
    },
}

impl Reply {
    /// The quote of an original message as Discord sends it.
    pub fn of(original: &Value) -> Self {
        Self::Message {
            id: original["id"].as_str().unwrap_or_default().into(),
            author_id: original["author"]["id"].as_str().unwrap_or_default().into(),
            author: author_name(original).into(),
            content: original["content"].as_str().unwrap_or_default().into(),
        }
    }

    /// The quote of an original message already parsed.
    pub fn quoting(original: &Message) -> Self {
        Self::Message {
            id: original.id.clone(),
            author_id: original.author_id.clone(),
            author: original.author.clone(),
            content: original.content.clone(),
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct Attachment {
    pub name: String,
    pub size: Option<u64>,
    pub url: Arc<str>,
    pub image: bool,
    /// The image's width and height.
    pub dimensions: Option<(u32, u32)>,
    /// The image scaled down by Discord's media proxy, for previews.
    pub preview_url: Option<String>,
    /// The image scaled down to fit the viewer, by the same proxy.
    pub view_url: Option<String>,
    /// A still picture to show when the preview, a video, can't be shown:
    /// a Tenor or Giphy GIF's first frame.
    #[serde(default)]
    pub still_url: Option<String>,
    /// A video that plays in place of the picture, which is its poster: an
    /// attached video, or a link's through the media proxy.
    #[serde(default)]
    pub video_url: Option<String>,
    /// The address a GIF or moving picture linked on its own was sent as,
    /// which Discord's client keeps it among the favourites by: a GIF's page,
    /// or the picture's own address.
    #[serde(default, alias = "page_url")]
    pub link_url: Option<Arc<str>>,
    /// It moves: Discord marks it animated, or it's a GIF.
    #[serde(default)]
    pub animated: bool,
    pub shown: Shown,
    /// Marked as a spoiler: by a name starting `SPOILER_`, or by its flags.
    pub spoiler: bool,
    /// Its alt text, which a screen reader reads in place of the picture.
    #[serde(default)]
    pub description: Option<String>,
}

/// Where a message's picture shows.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum Shown {
    /// With the message's attached files and images.
    #[default]
    Message,
    /// Large, in the embed at this index.
    Embed(usize),
    /// Small, beside the text of the embed at this index.
    Thumbnail(usize),
    /// Large, as the poster of the video embed at this index.
    Poster(usize),
    /// On its own, without a frame: a sticker.
    Sticker,
    /// In the component row with this slot: [`crate::components::Row::Media`]
    /// or a section's thumbnail.
    Component(usize),
}

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct Reaction {
    /// What Yapfast shows: the emoji itself, or `:name:` for a custom one.
    pub key: String,
    /// What Discord's API takes: the emoji itself, or `name:id`.
    pub emoji: String,
    pub count: usize,
    pub me: bool,
}

impl Message {
    /// Whether the sender suppressed link previews on this message.
    pub fn embeds_suppressed(&self) -> bool {
        self.flags & SUPPRESS_EMBEDS != 0
    }

    /// Whether it calls on this account, `me`, as Discord highlights it: by
    /// name, through one of its roles in a server it has `marks` in, or
    /// with @everyone or @here, unless its notification settings there
    /// suppress those; or as a reply to its message. Its own messages never
    /// do.
    pub fn mentions_me(&self, me: &str, marks: Option<&ServerMarks>) -> bool {
        self.names_me(me, marks) || self.replies_to(me)
    }

    /// Whether it calls on `me` other than by replying: by name, a role or
    /// @everyone, as [`Self::mentions_me`] says. A reply that pings puts
    /// the author it replies to in `mentions` too, so for them only their
    /// name in its text counts.
    pub fn names_me(&self, me: &str, marks: Option<&ServerMarks>) -> bool {
        if self.author_id == me {
            return false;
        }
        let named = self.mentions.iter().any(|user| user == me)
            && (!self.replies_to(me)
                || self.content.contains(&format!("<@{me}>"))
                || self.content.contains(&format!("<@!{me}>")));
        let everyone = self.mention_everyone && marks.is_some_and(|marks| !marks.suppress_everyone);
        let role = marks.is_some_and(|marks| {
            !marks.suppress_roles
                && self
                    .mention_roles
                    .iter()
                    .any(|role| marks.roles.contains(role))
        });
        named || everyone || role
    }

    /// Whether it replies to a message of `me`'s, not being its own.
    pub fn replies_to(&self, me: &str) -> bool {
        self.author_id != me
            && matches!(&self.reply, Some(Reply::Message { author_id, .. }) if author_id == me)
    }

    /// Seconds since the Unix epoch, from the message's snowflake.
    pub fn timestamp(&self) -> u64 {
        snowflake_ms(&self.id) / 1000
    }

    pub fn order(&self) -> u64 {
        self.id.parse().unwrap_or_default()
    }

    /// Adds or removes this account's or someone else's reaction. This
    /// account's reaction counts once: adding it again, or removing it when
    /// it isn't there, changes nothing, as clicks faster than the gateway
    /// can bring such events.
    pub fn react(&mut self, key: &str, emoji: &str, me: bool, added: bool) {
        match self
            .reactions
            .iter()
            .position(|reaction| reaction.key == key)
        {
            Some(index) => {
                let reaction = &mut self.reactions[index];
                if me && reaction.me == added {
                    return;
                }
                if added {
                    reaction.count += 1;
                    reaction.me |= me;
                } else {
                    reaction.count = reaction.count.saturating_sub(1);
                    reaction.me &= !me;
                    if reaction.count == 0 {
                        self.reactions.remove(index);
                    }
                }
            }
            None if added => self.reactions.push(Reaction {
                key: key.to_owned(),
                emoji: emoji.to_owned(),
                count: 1,
                me,
            }),
            None => {}
        }
    }

    /// Adds or removes this account's or someone else's vote for `answer`.
    pub fn vote(&mut self, answer: u64, me: bool, added: bool) {
        let Some(answer) = self
            .poll
            .as_mut()
            .and_then(|poll| poll.answers.iter_mut().find(|known| known.id == answer))
        else {
            return;
        };
        if added {
            answer.votes += 1;
            answer.me |= me;
        } else {
            answer.votes = answer.votes.saturating_sub(1);
            answer.me &= !me;
        }
    }
}

pub fn snowflake_ms(id: &str) -> u64 {
    id.parse::<u64>()
        .map_or(0, |id| (id >> 22) + DISCORD_EPOCH_MS)
}

/// The smallest snowflake at a time in Unix milliseconds.
pub fn snowflake_at(ms: u64) -> u64 {
    ms.saturating_sub(DISCORD_EPOCH_MS) << 22
}

/// Unix milliseconds of an ISO 8601 time as Discord writes them, such as
/// `2026-10-06T14:05:00.123000+00:00`.
pub fn iso_ms(text: &str) -> Option<u64> {
    let number = |range: std::ops::Range<usize>| text.get(range)?.parse::<i64>().ok();
    let (year, month, day) = (number(0..4)?, number(5..7)?, number(8..10)?);
    let (hour, minute, second) = (number(11..13)?, number(14..16)?, number(17..19)?);
    let rest = text.get(19..)?;
    let (fraction, zone) = match rest.strip_prefix('.') {
        Some(rest) => {
            let digits = rest
                .find(|c: char| !c.is_ascii_digit())
                .unwrap_or(rest.len());
            let millis = format!("{:0<3}", &rest[..digits.min(3)]);
            (millis.parse::<i64>().ok()?, &rest[digits..])
        }
        None => (0, rest),
    };
    let offset = match zone {
        "" | "Z" => 0,
        zone => {
            let sign = if zone.starts_with('-') { -1 } else { 1 };
            let hours: i64 = zone.get(1..3)?.parse().ok()?;
            let minutes: i64 = zone.get(4..6)?.parse().ok()?;
            sign * (hours * 60 + minutes) * 60
        }
    };
    // Howard Hinnant's days-from-civil algorithm.
    let y = if month <= 2 { year - 1 } else { year };
    let era = y.div_euclid(400);
    let yoe = y.rem_euclid(400);
    let mp = (month + 9) % 12;
    let doy = (153 * mp + 2) / 5 + day - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    let days = era * 146_097 + doe - 719_468;
    let seconds = days * 86_400 + hour * 3600 + minute * 60 + second - offset;
    u64::try_from(seconds * 1000 + fraction).ok()
}

/// A nonce like the official client's: a snowflake for the current time.
pub fn nonce() -> String {
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64;
    ((now.saturating_sub(DISCORD_EPOCH_MS)) << 22).to_string()
}

/// How long a call lasted, as Discord says it.
fn lasted(ms: u64) -> String {
    let minutes = (ms + 30_000) / 60_000;
    match minutes {
        0 => "a few seconds".into(),
        1 => "a minute".into(),
        2..45 => format!("{minutes} minutes"),
        45..90 => "an hour".into(),
        _ => format!("{} hours", (minutes + 30) / 60),
    }
}

/// Whether a message of this kind was written, by a person or by an app
/// answering one's command, rather than a notice such as a join or a pin.
pub(crate) fn written(kind: u64) -> bool {
    matches!(
        kind,
        DEFAULT | REPLY | CHAT_INPUT_COMMAND | CONTEXT_MENU_COMMAND
    )
}

/// What a notice in place of a message tells of, as Discord's client marks
/// it with an icon and links.
#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum Notice {
    /// Its author pinned a message, by id, which the notice links to.
    Pinned(Option<String>),
    Joined,
    RecipientChanged {
        added: bool,
        user: Option<String>,
        name: String,
    },
    ChannelRenamed,
    ThreadStarted,
    Call,
    PollResult,
}

/// A message object, from the API or the gateway. Kinds Yapfast doesn't show,
/// such as boosts, give `None`.
pub fn parse(value: &Value) -> Option<Message> {
    let kind = value["type"].as_u64().unwrap_or(DEFAULT);
    // A thread's first message shows the one it was started from, as
    // Discord's client does.
    if kind == THREAD_STARTER_MESSAGE {
        let original = &value["referenced_message"];
        if !original.is_object() {
            return None;
        }
        let mut message = parse(original)?;
        message.id = value["id"].as_str()?.into();
        message.channel_id = value["channel_id"].as_str().unwrap_or_default().into();
        message.nonce = None;
        message.editable = false;
        message.forwardable = false;
        message.listen_invite = Some(false);
        message.undeletable = true;
        message.invoker = None;
        if let Some(interaction) = &mut message.interaction {
            interaction.data = None;
        }
        message.thread = None;
        return Some(message);
    }
    let recipient = matches!(kind, RECIPIENT_ADD | RECIPIENT_REMOVE)
        .then(|| recipient_change(value, kind == RECIPIENT_ADD));
    let system = match kind {
        kind if written(kind) => None,
        RECIPIENT_ADD | RECIPIENT_REMOVE => recipient.as_ref().map(|(_, text)| text.clone()),
        CHANNEL_NAME_CHANGE => Some(
            value["content"]
                .as_str()
                .filter(|name| !name.trim().is_empty())
                .map_or_else(
                    || "changed the channel name.".into(),
                    |name| format!("changed the channel name: {name}"),
                ),
        ),
        THREAD_CREATED => Some(format!(
            "started a thread: {}.",
            value["content"].as_str().unwrap_or_default()
        )),
        MEMBER_JOIN => Some("joined the server.".to_owned()),
        // Its author is the poll's.
        POLL_RESULT => Some(poll_result(&value["embeds"][0])),
        PINNED => Some("pinned a message.".to_owned()),
        // Discord updates it with when the call ended.
        CALL => Some(
            match value["call"]["ended_timestamp"].as_str().and_then(iso_ms) {
                Some(ended) => {
                    let started = value["id"].as_str().map_or(ended, snowflake_ms);
                    format!(
                        "started a call that lasted {}.",
                        lasted(ended.saturating_sub(started))
                    )
                }
                None => "started a call.".to_owned(),
            },
        ),
        _ => return None,
    };
    let author = &value["author"];
    // A forward's own content is empty: what it shows is the copy of the
    // original it carries.
    let forwarded = value["message_reference"]["type"].as_u64() == Some(FORWARD);
    let shown = match &value["message_snapshots"][0]["message"] {
        snapshot @ Value::Object(_) if forwarded => snapshot,
        _ => value,
    };
    let shown_flags = shown["flags"].as_u64().unwrap_or_default();
    let components_v2 = shown_flags & components::IS_COMPONENTS_V2 != 0;
    // `null` says the original was deleted; no field at all says nothing.
    // An app's answer to a command used on a message quotes that message,
    // and one to a button or menu the message that has it, when Discord
    // doesn't make it a reply itself. A type 23 answer that names a message
    // replies to it even without the metadata saying it's a message
    // command's (docs.discord.food gives `referenced_message` for type 23).
    let interaction = Interaction::of(value);
    let quoted = interaction
        .as_ref()
        .and_then(|interaction| interaction_quotes(value, interaction));
    let replies = kind == REPLY
        || quoted.is_some()
        || (kind == CONTEXT_MENU_COMMAND && value["message_reference"]["message_id"].is_string());
    let reply = replies.then(|| match value.get("referenced_message") {
        Some(original @ Value::Object(_)) => Reply::of(original),
        Some(_) => Reply::Deleted,
        None => Reply::Unknown {
            id: value["message_reference"]["message_id"]
                .as_str()
                .or(quoted.as_deref())
                .unwrap_or_default()
                .into(),
        },
    });
    // Components V2 shows files only where its components place them.
    let mut attachments = shown["attachments"]
        .as_array()
        .filter(|_| !components_v2)
        .into_iter()
        .flatten()
        .filter_map(|attachment| {
            let kind = attachment["content_type"].as_str().unwrap_or_default();
            let image = kind.starts_with("image/");
            // The media proxy makes a video's poster from its first frame.
            let video = kind.starts_with("video/");
            let url: Arc<str> = attachment["url"].as_str()?.into();
            let name = attachment["filename"].as_str()?;
            Some(Attachment {
                name: name.into(),
                size: attachment["size"].as_u64(),
                image,
                dimensions: (image || video)
                    .then(|| {
                        let side = |name: &str| u32::try_from(attachment[name].as_u64()?).ok();
                        Some((side("width")?, side("height")?))
                    })
                    .flatten(),
                preview_url: (image || video)
                    .then(|| scaled_url(attachment, PREVIEW_WIDTH, PREVIEW_HEIGHT, image))
                    .flatten(),
                view_url: image
                    .then(|| scaled_url(attachment, VIEW_WIDTH, VIEW_HEIGHT, true))
                    .flatten(),
                video_url: video.then(|| url.to_string()),
                link_url: None,
                animated: image && animated(attachment),
                url,
                still_url: None,
                shown: Shown::Message,
                spoiler: name.starts_with("SPOILER_")
                    || attachment["flags"].as_u64().unwrap_or_default() & IS_SPOILER != 0,
                description: alt_text(&attachment["description"]),
            })
        })
        .collect::<Vec<_>>();
    let reactions = value["reactions"]
        .as_array()
        .into_iter()
        .flatten()
        .filter_map(|reaction| {
            let (key, emoji) = emoji(&reaction["emoji"])?;
            Some(Reaction {
                key,
                emoji,
                count: reaction["count"].as_u64().unwrap_or(1) as usize,
                me: reaction["me"].as_bool().unwrap_or(false),
            })
        })
        .collect();
    let mut content = if components_v2 {
        String::new()
    } else {
        shown["content"].as_str().unwrap_or_default().to_owned()
    };
    let embeds = if !components_v2 && shown_flags & SUPPRESS_EMBEDS == 0 {
        embed::parse(&shown["embeds"])
    } else {
        embed::parse(&Value::Null)
    };
    if embeds.hides.iter().any(|link| link == content.trim()) {
        content.clear();
    }
    let components = components::parse(&shown["components"]);
    // A link in a spoiler spoils its preview too.
    let spoiled = spoils_links(&content);
    attachments.extend(embeds.pictures.into_iter().map(|mut picture| {
        picture.spoiler |= spoiled;
        picture
    }));
    // All sticker formats use the picture pipeline, including Lottie JSON.
    for sticker in shown["sticker_items"]
        .as_array()
        .filter(|_| !components_v2)
        .into_iter()
        .flatten()
    {
        let (Some(id), Some(name)) = (sticker["id"].as_str(), sticker["name"].as_str()) else {
            continue;
        };
        let format = sticker["format_type"].as_u64().unwrap_or(STICKER_PNG);
        let url = ready::sticker(id, format);
        attachments.push(Attachment {
            name: name.into(),
            size: None,
            url: url.as_str().into(),
            image: true,
            dimensions: Some((STICKER_SIZE, STICKER_SIZE)),
            preview_url: Some(url.clone()),
            view_url: Some(url),
            still_url: None,
            video_url: None,
            link_url: None,
            animated: false,
            shown: Shown::Sticker,
            spoiler: false,
            description: None,
        });
    }
    attachments.extend(components.media);
    Some(Message {
        id: value["id"].as_str()?.into(),
        channel_id: value["channel_id"].as_str().unwrap_or_default().into(),
        application_id: value["application_id"].as_str().map(str::to_owned),
        flags: value["flags"].as_u64().unwrap_or_default(),
        nonce: match &value["nonce"] {
            Value::String(nonce) => Some(nonce.clone()),
            Value::Number(nonce) => Some(nonce.to_string()),
            _ => None,
        },
        author_id: author["id"].as_str()?.into(),
        author: author_name(value).into(),
        bot: author["bot"].as_bool().unwrap_or(false),
        content,
        notice: system.as_ref().and_then(|_| match kind {
            RECIPIENT_ADD | RECIPIENT_REMOVE => recipient.map(|(notice, _)| notice),
            CHANNEL_NAME_CHANGE => Some(Notice::ChannelRenamed),
            PINNED => Some(Notice::Pinned(
                value["message_reference"]["message_id"]
                    .as_str()
                    .map(str::to_owned),
            )),
            MEMBER_JOIN => Some(Notice::Joined),
            THREAD_CREATED => Some(Notice::ThreadStarted),
            CALL => Some(Notice::Call),
            POLL_RESULT => Some(Notice::PollResult),
            _ => None,
        }),
        system,
        edited: value["edited_timestamp"].is_string(),
        reply,
        attachments,
        embeds: embeds.embeds,
        components: components.cards,
        reactions,
        // A poll's question and answers stay as they were sent.
        editable: matches!(kind, DEFAULT | REPLY) && !forwarded && value["poll"].is_null(),
        // The recipient of an add/remove is part of the system notice, not
        // a message mention that should highlight the row.
        mentions: if matches!(kind, RECIPIENT_ADD | RECIPIENT_REMOVE) {
            vec![]
        } else {
            ids(&value["mentions"], |user| user["id"].as_str())
        },
        mention_roles: ids(&value["mention_roles"], Value::as_str),
        mention_everyone: value["mention_everyone"].as_bool().unwrap_or(false),
        thread: match kind {
            // The notice names the thread in its reference, and its name
            // in its content.
            THREAD_CREATED => {
                value["message_reference"]["channel_id"]
                    .as_str()
                    .map(|id| ThreadLink {
                        id: id.to_owned(),
                        name: value["content"].as_str().unwrap_or_default().to_owned(),
                        ..Default::default()
                    })
            }
            // A forum post's first message has the post's id, and links
            // to no thread but the one it's in.
            _ => ThreadLink::of(&value["thread"])
                .filter(|thread| value["channel_id"].as_str() != Some(thread.id.as_str())),
        },
        pinned: value["pinned"].as_bool().unwrap_or(false),
        forwarded,
        listen_invite: value
            .get("activity")
            .map(|activity| written(kind) && !forwarded && activity["type"].as_u64() == Some(3)),
        forwardable: written(kind)
            && value["flags"].as_u64().unwrap_or_default() & !FORWARDABLE_FLAGS == 0
            && [
                "poll",
                "call",
                "activity",
                "activity_instance",
                "shared_client_theme",
            ]
            .iter()
            .all(|field| value[*field].is_null()),
        undeletable: matches!(
            kind,
            CALL | RECIPIENT_ADD | RECIPIENT_REMOVE | CHANNEL_NAME_CHANGE
        ),
        invoker: invoker(&value["interaction_metadata"]),
        interaction,
        poll: if components_v2 {
            None
        } else {
            Poll::of(&shown["poll"])
        },
        ephemeral: value["flags"].as_u64().unwrap_or_default() & EPHEMERAL != 0,
        loading: value["flags"].as_u64().unwrap_or_default() & LOADING != 0,
        voice: VoiceMessage::of(shown),
    })
}

fn recipient_change(value: &Value, added: bool) -> (Notice, String) {
    let target = &value["mentions"][0];
    let user = target["id"]
        .as_str()
        .filter(|id| {
            id.bytes().all(|b| b.is_ascii_digit()) && id.parse::<u64>().is_ok_and(|id| id != 0)
        })
        .map(str::to_owned);
    let name = target["member"]["nick"]
        .as_str()
        .filter(|name| !name.trim().is_empty())
        .or_else(|| ready::display_name(target).filter(|name| !name.trim().is_empty()))
        .unwrap_or("a member")
        .to_owned();
    let place = if value["guild_id"].is_string() {
        "thread"
    } else {
        "group"
    };
    let (verb, preposition) = if added {
        ("added", "to")
    } else {
        ("removed", "from")
    };
    let text = format!("{verb} {name} {preposition} the {place}.");
    (Notice::RecipientChanged { added, user, name }, text)
}

/// The message an app's answer to a message command, a button or a menu
/// quotes: the one it was used on, which a context menu command's answer
/// references, or the one with the button, unless that's the answer itself,
/// which the button updated.
fn interaction_quotes(value: &Value, interaction: &Interaction) -> Option<String> {
    let id = value["id"].as_str();
    if value["type"].as_u64() == Some(CONTEXT_MENU_COMMAND)
        && interaction.command_type == Some(MESSAGE_COMMAND)
    {
        return value["message_reference"]["message_id"]
            .as_str()
            .or(interaction.target_message_id.as_deref())
            .map(str::to_owned);
    }
    interaction
        .interacted_message_id
        .clone()
        .filter(|interacted| Some(interacted.as_str()) != id)
}

/// Who ran the command an app's message answers, when the app answered
/// as installed on their account alone, as Discord's client lets them
/// delete it.
fn invoker(interaction: &Value) -> Option<String> {
    let owners = interaction["authorizing_integration_owners"].as_object()?;
    if owners.len() != 1 || !owners.contains_key(USER_INSTALL) {
        return None;
    }
    interaction["user"]["id"].as_str().map(str::to_owned)
}

/// The notice of a closed poll, from the fields of its embed, said after
/// its author's name as Discord's client says it: "'s poll … has closed."
fn poll_result(embed: &Value) -> String {
    let field = |name: &str| {
        embed["fields"]
            .as_array()
            .into_iter()
            .flatten()
            .find(|field| field["name"] == name)
            .and_then(|field| field["value"].as_str())
    };
    let question = field("poll_question_text").unwrap_or_default();
    let total = field("total_votes").and_then(|votes| votes.parse::<u64>().ok());
    let winner = match (field("victor_answer_text"), field("victor_answer_votes")) {
        (Some(text), Some(votes)) => {
            let votes: u64 = votes.parse().unwrap_or_default();
            let emoji = field("victor_answer_emoji_name")
                .filter(|name| !name.is_empty() && field("victor_answer_emoji_id").is_none())
                .map(|name| format!("{name} "))
                .unwrap_or_default();
            let share = total
                .filter(|total| *total > 0)
                .map(|total| format!(" ({}%)", (votes * 100 + total / 2) / total))
                .unwrap_or_default();
            format!(
                "Winning answer: {emoji}{text}, {}{share}.",
                votes_text(votes)
            )
        }
        _ => "There was no winner.".to_owned(),
    };
    format!("'s poll \u{201c}{question}\u{201d} has closed. {winner}")
}

/// "1 vote", "3 votes".
pub fn votes_text(votes: u64) -> String {
    if votes == 1 {
        "1 vote".to_owned()
    } else {
        format!("{votes} votes")
    }
}

/// The ids `id` finds in a list.
fn ids<'a>(list: &'a Value, id: impl Fn(&'a Value) -> Option<&'a str>) -> Vec<String> {
    list.as_array()
        .into_iter()
        .flatten()
        .filter_map(id)
        .map(str::to_owned)
        .collect()
}

/// Whether a spoiler in `content` holds a link.
fn spoils_links(content: &str) -> bool {
    let parts: Vec<&str> = content.split("||").collect();
    let pairs = parts.len().saturating_sub(1) / 2;
    parts
        .iter()
        .skip(1)
        .step_by(2)
        .take(pairs)
        .any(|inside| inside.contains("http"))
}

/// The size Yapfast shows image previews at, at most: Discord's own cap for
/// an attached picture, scaled by its aspect ratio.
pub const PREVIEW_WIDTH: u64 = 550;
pub const PREVIEW_HEIGHT: u64 = 400;

/// The image viewer's largest size.
pub const VIEW_WIDTH: u64 = 1920;
pub const VIEW_HEIGHT: u64 = 1200;

/// Asks Discord's media proxy for the image fitted into `max_width` by
/// `max_height` and never enlarged, as the official client does, so a phone
/// photo doesn't download in full. It comes as WebP, but a GIF stays a GIF,
/// so it moves. With `animated`, as Discord's client asks, an animated
/// picture, such as an AVIF, comes as an animated WebP rather than its first
/// frame; a video's poster asks without, for its first frame alone.
/// Alt text Discord gave a picture or file, when it has any.
pub(crate) fn alt_text(description: &Value) -> Option<String> {
    description
        .as_str()
        .map(str::trim)
        .filter(|text| !text.is_empty())
        .map(str::to_owned)
}

pub(crate) fn scaled_url(
    attachment: &Value,
    max_width: u64,
    max_height: u64,
    animated: bool,
) -> Option<String> {
    let url = attachment["proxy_url"].as_str()?;
    let (width, height) = (
        attachment["width"].as_u64()?,
        attachment["height"].as_u64()?,
    );
    if width == 0 || height == 0 {
        return None;
    }
    let scale = f64::min(
        1.0,
        f64::min(
            max_width as f64 / width as f64,
            max_height as f64 / height as f64,
        ),
    );
    let fit = |side: u64| ((side as f64 * scale).round() as u64).max(1);
    let separator = if url.contains('?') { '&' } else { '?' };
    let gif = attachment["content_type"].as_str() == Some("image/gif")
        || url
            .split('?')
            .next()
            .is_some_and(|path| path.ends_with(".gif"));
    let format = match (gif, animated) {
        (true, _) => "",
        (false, true) => "animated=true&format=webp&",
        (false, false) => "format=webp&",
    };
    Some(format!(
        "{url}{separator}{format}width={}&height={}",
        fit(width),
        fit(height)
    ))
}

/// A custom emoji a message shows: in its text as `<:name:id>`, or `<a:name:id>`
/// when animated, or as a reaction.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct CustomEmoji {
    pub name: String,
    pub id: String,
    pub animated: bool,
}

/// The custom emoji in a message's text, each once, in order.
pub fn custom_emoji(content: &str) -> Vec<CustomEmoji> {
    let mut found: Vec<CustomEmoji> = Vec::new();
    let mut rest = content;
    while let Some(start) = rest.find('<') {
        rest = &rest[start + 1..];
        let Some(end) = rest.find('>') else {
            break;
        };
        if let Some((name, id, animated)) = custom_emoji_tag(&rest[..end])
            && !found.iter().any(|known| known.id == id)
        {
            found.push(CustomEmoji {
                name: name.to_owned(),
                id: id.to_owned(),
                animated,
            });
        }
    }
    found
}

/// Parses the inside of a Discord custom emoji tag, with its exact CDN ID.
pub fn custom_emoji_tag(tag: &str) -> Option<(&str, &str, bool)> {
    let (animated, emoji) = match tag.strip_prefix("a:") {
        Some(emoji) => (true, emoji),
        None => (false, tag.strip_prefix(':')?),
    };
    let (name, id) = emoji.split_once(':')?;
    (!name.is_empty() && !name.contains('<') && !id.is_empty()
        && id.bytes().all(|byte| byte.is_ascii_digit()))
        .then_some((name, id, animated))
}

/// A reaction's emoji object as Yapfast's key and the API's form.
pub fn emoji(emoji: &Value) -> Option<(String, String)> {
    let name = emoji["name"].as_str()?;
    Some(match emoji["id"].as_str() {
        Some(id) => (format!(":{name}:"), format!("{name}:{id}")),
        None => (name.to_owned(), name.to_owned()),
    })
}

/// The name a message shows for its author: the server nickname it carries,
/// else the display name or username.
fn author_name(message: &Value) -> &str {
    message["member"]["nick"]
        .as_str()
        .or_else(|| ready::display_name(&message["author"]))
        .unwrap_or("Discord user")
}

/// Whether a user object is one of Discord's own accounts: the `system` user,
/// or one with the SYSTEM public flag (1 << 12).
pub fn is_official(user: &Value) -> bool {
    user["system"].as_bool() == Some(true)
        || user["public_flags"]
            .as_u64()
            .is_some_and(|flags| flags & (1 << 12) != 0)
}

/// The server tag someone wears beside their name, as Discord's `primary_guild`
/// gives it: up to four characters from a server they chose to represent,
/// with that server's badge.
#[derive(Clone, Debug, PartialEq, Eq, Hash, serde::Serialize, serde::Deserialize)]
pub struct Tag {
    pub text: Arc<str>,
    /// The address of the picture of the server's tag badge, when it has one.
    pub badge: Option<Arc<str>>,
}

impl Tag {
    /// A user object's `primary_guild`; none for a person who doesn't wear
    /// it, who turned it off, whose server has no tag, or who hasn't taken up
    /// their server's changed tag yet, for whom `identity_enabled` is null.
    pub fn parse(primary: &Value) -> Option<Self> {
        if primary["identity_enabled"].as_bool() != Some(true) {
            return None;
        }
        let guild = primary["identity_guild_id"]
            .as_str()
            .filter(|g| id(g).is_some())?;
        let text = primary["tag"]
            .as_str()
            .map(str::trim)
            .filter(|t| !t.is_empty())?;
        Some(Self {
            text: text.into(),
            badge: primary["badge"]
                .as_str()
                .filter(|hash| !hash.is_empty())
                .map(|hash| ready::guild_tag_badge(guild, hash).into()),
        })
    }
}

/// [`Names`] as saved to disk, where maps keyed by server and user become
/// lists.
#[derive(Default, serde::Serialize, serde::Deserialize)]
pub struct SavedNames {
    users: Vec<(String, String)>,
    nicknames: Vec<(String, String, String)>,
    members: Vec<(String, String)>,
    avatars: Vec<(String, String)>,
    member_avatars: Vec<(String, String, String)>,
    roles: Vec<(String, String, Vec<String>)>,
    #[serde(default)]
    usernames: Vec<(String, String)>,
    #[serde(default)]
    bots: Vec<String>,
    /// Each person's tag: user id, text and badge address.
    #[serde(default)]
    tags: Vec<(String, Arc<str>, Option<Arc<str>>)>,
    /// Avatar decorations' SKUs by user id.
    #[serde(default)]
    decorations: Vec<(String, String)>,
    /// Nameplates by user id: their SKU and palette.
    #[serde(default)]
    nameplates: Vec<(String, String, String)>,
    /// The same as members of a server, by server and user id.
    #[serde(default)]
    member_decorations: Vec<(String, String, String)>,
    #[serde(default)]
    member_nameplates: Vec<(String, String, String, String)>,
    /// Display name styles, by user id and by server and user id.
    #[serde(default)]
    styles: Vec<(String, Style)>,
    #[serde(default)]
    member_styles: Vec<(String, String, Style)>,
}

/// [`Names`] serialized as [`SavedNames`]; see [`Names::saving`].
pub struct SavingNames<'a>(&'a Names);

impl serde::Serialize for SavingNames<'_> {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        use serde::ser::SerializeStruct;
        /// A list serialized from the iterator its function makes.
        struct List<F>(F);
        impl<F: Fn() -> I, I: Iterator<Item: serde::Serialize>> serde::Serialize for List<F> {
            fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
                serializer.collect_seq((self.0)())
            }
        }
        let names = self.0;
        let mut saved = serializer.serialize_struct("SavedNames", 15)?;
        saved.serialize_field(
            "users",
            &List(|| names.users.iter().map(|(user, name)| (Text(*user), name))),
        )?;
        saved.serialize_field(
            "nicknames",
            &List(|| {
                names
                    .nicknames
                    .iter()
                    .map(|((guild, user), nick)| (Text(*guild), Text(*user), nick))
            }),
        )?;
        saved.serialize_field(
            "members",
            &List(|| {
                names
                    .members
                    .iter()
                    .map(|(guild, user)| (Text(*guild), Text(*user)))
            }),
        )?;
        saved.serialize_field(
            "avatars",
            &List(|| names.avatars.iter().map(|(user, hash)| (Text(*user), hash))),
        )?;
        saved.serialize_field(
            "member_avatars",
            &List(|| {
                names
                    .member_avatars
                    .iter()
                    .map(|((guild, user), avatar)| (Text(*guild), Text(*user), avatar))
            }),
        )?;
        saved.serialize_field(
            "roles",
            &List(|| {
                names
                    .roles
                    .iter()
                    .map(|((guild, user), roles)| (Text(*guild), Text(*user), roles))
            }),
        )?;
        saved.serialize_field(
            "usernames",
            &List(|| {
                names
                    .usernames
                    .iter()
                    .map(|(user, name)| (Text(*user), name))
            }),
        )?;
        saved.serialize_field("bots", &List(|| names.bots.iter().copied().map(Text)))?;
        saved.serialize_field(
            "tags",
            &List(|| {
                names
                    .tags
                    .iter()
                    .map(|(user, tag)| (Text(*user), &tag.text, &tag.badge))
            }),
        )?;
        saved.serialize_field(
            "decorations",
            &List(|| {
                names
                    .decorations
                    .iter()
                    .map(|(user, sku)| (Text(*user), Text(*sku)))
            }),
        )?;
        saved.serialize_field(
            "nameplates",
            &List(|| {
                names
                    .nameplates
                    .iter()
                    .map(|(user, plate)| (Text(*user), Text(plate.sku), plate.palette_name()))
            }),
        )?;
        saved.serialize_field(
            "member_decorations",
            &List(|| {
                names
                    .member_decorations
                    .iter()
                    .map(|((guild, user), sku)| (Text(*guild), Text(*user), Text(*sku)))
            }),
        )?;
        saved.serialize_field(
            "member_nameplates",
            &List(|| {
                names
                    .member_nameplates
                    .iter()
                    .map(|((guild, user), plate)| {
                        (
                            Text(*guild),
                            Text(*user),
                            Text(plate.sku),
                            plate.palette_name(),
                        )
                    })
            }),
        )?;
        saved.serialize_field(
            "styles",
            &List(|| {
                names
                    .styles
                    .iter()
                    .map(|(user, style)| (Text(*user), style))
            }),
        )?;
        saved.serialize_field(
            "member_styles",
            &List(|| {
                names
                    .member_styles
                    .iter()
                    .map(|((guild, user), style)| (Text(*guild), Text(*user), style))
            }),
        )?;
        saved.end()
    }
}

/// A Discord id, a snowflake, as [`Names`] keeps people and servers by:
/// eight bytes, where its text takes 24 and an allocation of its own.
type Id = u64;

fn id(text: &str) -> Option<Id> {
    text.parse().ok()
}

/// A server's and a member's ids.
fn member_key(guild: &str, user: &str) -> Option<(Id, Id)> {
    Some((id(guild)?, id(user)?))
}

/// An id saved as the text Discord sends it as, as the file always had it.
struct Text(Id);

impl serde::Serialize for Text {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        serializer.collect_str(&self.0)
    }
}

/// Who is who, learned from the gateway and from messages.
#[derive(Default)]
pub struct Names {
    /// Display names by user id.
    users: HashMap<Id, String>,
    /// Usernames by user id, such as `ann` for Ann.
    usernames: HashMap<Id, String>,
    /// The bots and apps among them, which nobody invites to a server.
    bots: HashSet<Id>,
    /// Server nicknames by server and user id.
    nicknames: HashMap<(Id, Id), String>,
    /// Members whose server profile is known, with or without a nickname.
    members: HashSet<(Id, Id)>,
    /// Avatar hashes by user id, of those who set one.
    avatars: HashMap<Id, String>,
    /// The server tags of those who wear one, by user id.
    tags: HashMap<Id, Tag>,
    /// Discord's own accounts, such as the one that sends its official
    /// messages, which a DM list marks.
    officials: HashSet<Id>,
    /// Server avatar hashes by server and user id.
    member_avatars: HashMap<(Id, Id), String>,
    /// The SKUs of the avatar decorations people equip, by user id.
    decorations: HashMap<Id, Id>,
    /// The nameplates people equip, by user id.
    nameplates: HashMap<Id, Plate>,
    /// What a member equips for one server alone, which shows there in place
    /// of what they equip everywhere, by server and user id.
    member_decorations: HashMap<(Id, Id), Id>,
    member_nameplates: HashMap<(Id, Id), Plate>,
    /// Display name styles, of those who have one, everywhere and per server.
    styles: HashMap<Id, Style>,
    member_styles: HashMap<(Id, Id), Style>,
    /// The addresses of collectibles' pictures by SKU, one for all who wear
    /// it and every message and row that shows them. The shop's size bounds it.
    collectible_pictures: Mutex<HashMap<Id, Arc<str>>>,
    /// Members' roles by server and user id, for the colour of their name.
    /// Member lists and the core share each, rather than copying it.
    roles: HashMap<(Id, Id), Arc<[String]>>,
    /// When members' timeouts end, in Unix milliseconds, by server and user
    /// id: only those timed out, while Yapfast runs.
    timeouts: HashMap<(Id, Id), u64>,
    /// Since when members have boosted their server, in Unix milliseconds,
    /// by server and user id: only those boosting it, while Yapfast runs.
    boosts: HashMap<(Id, Id), u64>,
    /// A member's guild join time, in Unix milliseconds, when Discord gave it.
    joined: HashMap<(Id, Id), u64>,
    /// Changes whenever a name, avatar or role of someone known changes, so
    /// what was shown with them can tell it's out of date. Someone new
    /// changes nothing shown, which was rendered after learning them.
    version: u64,
    /// When each person was last learned or looked up, by user id, counted
    /// in `ticks`; those not seen for longest go first once there are too
    /// many. Looking up only reads, so these count atomically.
    seen: HashMap<Id, AtomicU64>,
    ticks: AtomicU64,
}

/// People whose names are kept, at most. Yapfast shows the authors of the
/// channels it keeps, 41 of up to 200 messages each, and 40 member lists of
/// 100 rows; every message Discord sends from any server teaches it one
/// more. One person in one server, with two roles, takes about 260 bytes.
const KEPT_PEOPLE: usize = 20_000;

/// Sets `key` to `value`, or removes it for none; whether that changed it.
fn changed<K: std::hash::Hash + Eq, V: PartialEq>(
    map: &mut HashMap<K, V>,
    key: K,
    value: Option<V>,
) -> bool {
    match value {
        Some(value) if map.get(&key) == Some(&value) => false,
        Some(value) => {
            map.insert(key, value);
            true
        }
        None => map.remove(&key).is_some(),
    }
}

impl Names {
    /// These names as [`SavedNames`], serialized straight from the maps
    /// rather than from a copy of them: 20,000 people take 17 MiB.
    pub fn saving(&self) -> SavingNames<'_> {
        SavingNames(self)
    }

    pub fn restore(saved: SavedNames) -> Self {
        let keyed = |list: Vec<(String, String, String)>| {
            list.into_iter()
                .filter_map(|(guild, user, value)| Some((member_key(&guild, &user)?, value)))
                .collect()
        };
        let by_user = |list: Vec<(String, String)>| {
            list.into_iter()
                .filter_map(|(user, value)| Some((id(&user)?, value)))
                .collect()
        };
        let mut names = Self {
            users: by_user(saved.users),
            nicknames: keyed(saved.nicknames),
            members: saved
                .members
                .iter()
                .filter_map(|(guild, user)| member_key(guild, user))
                .collect(),
            avatars: by_user(saved.avatars),
            member_avatars: keyed(saved.member_avatars),
            roles: saved
                .roles
                .into_iter()
                .filter_map(|(guild, user, roles)| Some((member_key(&guild, &user)?, roles.into())))
                .collect(),
            usernames: by_user(saved.usernames),
            bots: saved.bots.iter().filter_map(|user| id(user)).collect(),
            tags: saved
                .tags
                .into_iter()
                .filter_map(|(user, text, badge)| Some((id(&user)?, Tag { text, badge })))
                .collect(),
            decorations: saved
                .decorations
                .iter()
                .filter_map(|(user, sku)| Some((id(user)?, id(sku)?)))
                .collect(),
            nameplates: saved
                .nameplates
                .iter()
                .filter_map(|(user, sku, palette)| {
                    Some((id(user)?, Plate::restore(id(sku)?, palette)))
                })
                .collect(),
            member_decorations: saved
                .member_decorations
                .iter()
                .filter_map(|(guild, user, sku)| Some((member_key(guild, user)?, id(sku)?)))
                .collect(),
            member_nameplates: saved
                .member_nameplates
                .iter()
                .filter_map(|(guild, user, sku, palette)| {
                    Some((member_key(guild, user)?, Plate::restore(id(sku)?, palette)))
                })
                .collect(),
            styles: saved
                .styles
                .into_iter()
                .filter_map(|(user, style)| Some((id(&user)?, style)))
                .collect(),
            member_styles: saved
                .member_styles
                .into_iter()
                .filter_map(|(guild, user, style)| Some((member_key(&guild, &user)?, style)))
                .collect(),
            ..Self::default()
        };
        // Those kept from before go before anyone learned since.
        let people: HashSet<Id> = names
            .users
            .keys()
            .chain(names.avatars.keys())
            .chain(names.usernames.keys())
            .chain(names.members.iter().map(|(_, user)| user))
            .copied()
            .collect();
        names.seen = people
            .into_iter()
            .zip(1..)
            .map(|(user, at)| (user, AtomicU64::new(at)))
            .collect();
        names.ticks = AtomicU64::new(names.seen.len() as u64);
        if names.seen.len() > KEPT_PEOPLE {
            names.forget();
        }
        names
    }

    /// Notes that `user` was looked up just now; whether they were known.
    fn touch(&self, user: Id) -> bool {
        let Some(at) = self.seen.get(&user) else {
            return false;
        };
        at.store(self.ticks.fetch_add(1, Relaxed) + 1, Relaxed);
        true
    }

    /// Notes that `user` was learned just now, and forgets the quarter of
    /// people not seen for longest once there are too many; whether they
    /// were known before.
    fn saw(&mut self, user: Id) -> bool {
        if self.touch(user) {
            return true;
        }
        let now = self.ticks.fetch_add(1, Relaxed) + 1;
        self.seen.insert(user, AtomicU64::new(now));
        if self.seen.len() > KEPT_PEOPLE {
            self.forget();
        }
        false
    }

    /// Forgets the quarter of people not seen for longest. What was shown
    /// with them stays as it was, so the version stays.
    fn forget(&mut self) {
        let mut times: Vec<u64> = self.seen.values().map(|at| at.load(Relaxed)).collect();
        let quarter = times.len() / 4;
        let (_, &mut until, _) = times.select_nth_unstable(quarter);
        self.seen.retain(|_, at| *at.get_mut() > until);
        let seen = &self.seen;
        self.users.retain(|user, _| seen.contains_key(user));
        self.usernames.retain(|user, _| seen.contains_key(user));
        self.bots.retain(|user| seen.contains_key(user));
        self.officials.retain(|user| seen.contains_key(user));
        self.avatars.retain(|user, _| seen.contains_key(user));
        self.tags.retain(|user, _| seen.contains_key(user));
        self.decorations.retain(|user, _| seen.contains_key(user));
        self.nameplates.retain(|user, _| seen.contains_key(user));
        self.styles.retain(|user, _| seen.contains_key(user));
        self.member_decorations
            .retain(|(_, user), _| seen.contains_key(user));
        self.member_nameplates
            .retain(|(_, user), _| seen.contains_key(user));
        self.member_styles
            .retain(|(_, user), _| seen.contains_key(user));
        self.nicknames
            .retain(|(_, user), _| seen.contains_key(user));
        self.members.retain(|(_, user)| seen.contains_key(user));
        self.member_avatars
            .retain(|(_, user), _| seen.contains_key(user));
        self.roles.retain(|(_, user), _| seen.contains_key(user));
        self.timeouts.retain(|(_, user), _| seen.contains_key(user));
        self.boosts.retain(|(_, user), _| seen.contains_key(user));
        self.joined.retain(|(_, user), _| seen.contains_key(user));
    }

    /// Changes whenever what [`Names::name`], [`Names::avatar`],
    /// [`Names::roles`] or [`Names::render`] give may have.
    pub fn version(&self) -> u64 {
        self.version
    }

    pub fn learn_user(&mut self, user: &Value) {
        let Some(id) = user["id"].as_str().and_then(id) else {
            return;
        };
        let known = self.saw(id);
        let mut learned = false;
        if let Some(name) = ready::display_name(user) {
            learned |= changed(&mut self.users, id, Some(name.to_owned()));
        }
        if let Some(username) = user["username"].as_str() {
            self.usernames.insert(id, username.to_owned());
        }
        // Partial user objects leave both out.
        if user.get("system").is_some() || user.get("public_flags").is_some() {
            if is_official(user) {
                self.officials.insert(id);
            } else {
                self.officials.remove(&id);
            }
        }
        // Partial user objects leave it out.
        match user["bot"].as_bool() {
            Some(true) => {
                self.bots.insert(id);
            }
            Some(false) => {
                self.bots.remove(&id);
            }
            None => {}
        }
        // Partial user objects leave the avatar out; null removes it.
        match user.get("avatar") {
            Some(Value::String(hash)) => {
                learned |= changed(&mut self.avatars, id, Some(hash.clone()));
            }
            Some(Value::Null) => learned |= changed(&mut self.avatars, id, None),
            _ => {}
        }
        // Partial user objects leave the tag out; null takes it away, and
        // so does turning it off.
        match user.get("primary_guild") {
            Some(primary @ Value::Object(_)) => {
                learned |= changed(&mut self.tags, id, Tag::parse(primary));
            }
            Some(Value::Null) => learned |= changed(&mut self.tags, id, None),
            _ => {}
        }
        // Partial user objects leave both out; null, or nothing equipped,
        // removes them.
        if let Some(data) = user.get("avatar_decoration_data") {
            learned |= changed(
                &mut self.decorations,
                id,
                collectibles::decoration_sku(data),
            );
        }
        if let Some(equipped) = user.get("collectibles") {
            let plate = Plate::parse(&equipped["nameplate"]);
            learned |= changed(&mut self.nameplates, id, plate);
        }
        if let Some(style) = user.get("display_name_styles") {
            learned |= changed(&mut self.styles, id, Style::parse(style));
        }
        self.version += u64::from(known && learned);
    }

    /// Learns a member object; its user id is in `user` or `user_id`.
    pub fn learn_member(&mut self, guild: &str, member: &Value) {
        let user = member["user_id"]
            .as_str()
            .or_else(|| member["user"]["id"].as_str())
            .and_then(id);
        let known = user.is_some_and(|user| self.seen.contains_key(&user));
        self.learn_user(&member["user"]);
        let (Some(user), Some(guild)) = (user, id(guild)) else {
            return;
        };
        self.saw(user);
        let key = (guild, user);
        let nick = member["nick"].as_str().map(str::to_owned);
        let mut learned = changed(&mut self.nicknames, key, nick);
        let avatar = member["avatar"].as_str().map(str::to_owned);
        learned |= changed(&mut self.member_avatars, key, avatar);
        // Some member objects leave the roles out.
        if let Some(roles) = member["roles"].as_array() {
            let roles: Arc<[String]> = roles
                .iter()
                .filter_map(|role| role.as_str().map(str::to_owned))
                .collect();
            learned |= changed(&mut self.roles, key, Some(roles));
        }
        // What they equip for this server alone, which is there when they do
        // and null when they don't; a member object that leaves them out says
        // nothing.
        if let Some(data) = member.get("avatar_decoration_data") {
            learned |= changed(
                &mut self.member_decorations,
                key,
                collectibles::decoration_sku(data),
            );
        }
        if let Some(equipped) = member.get("collectibles") {
            let plate = Plate::parse(&equipped["nameplate"]);
            learned |= changed(&mut self.member_nameplates, key, plate);
        }
        if let Some(style) = member.get("display_name_styles") {
            learned |= changed(&mut self.member_styles, key, Style::parse(style));
        }
        // Present when known, null when they aren't timed out; a time past
        // is a timeout that ended.
        if let Some(until) = member.get("communication_disabled_until") {
            let until = until.as_str().and_then(iso_ms);
            changed(&mut self.timeouts, key, until);
        }
        // Present when known, null when they don't boost it.
        if let Some(since) = member.get("premium_since") {
            let since = since.as_str().and_then(iso_ms);
            changed(&mut self.boosts, key, since);
        }
        // History and partial member objects may predate a later rejoin.
        // A guild member removal explicitly forgets the old membership.
        if let Some(joined) = member["joined_at"].as_str().and_then(iso_ms)
            && self.joined.get(&key).is_none_or(|known| joined > *known)
        {
            learned |= changed(&mut self.joined, key, Some(joined));
        }
        self.members.insert(key);
        self.version += u64::from(known && learned);
    }

    /// Forgets what's known of someone as a member of a server they left,
    /// were kicked from or banned from.
    pub fn forget_member(&mut self, guild: &str, user: &str) {
        let Some(key) = member_key(guild, user) else {
            return;
        };
        let learned = self.nicknames.remove(&key).is_some()
            | self.member_avatars.remove(&key).is_some()
            | self.roles.remove(&key).is_some()
            | self.member_decorations.remove(&key).is_some()
            | self.member_nameplates.remove(&key).is_some()
            | self.member_styles.remove(&key).is_some()
            | self.joined.remove(&key).is_some();
        self.timeouts.remove(&key);
        self.boosts.remove(&key);
        self.members.remove(&key);
        self.version += u64::from(learned);
    }

    /// When a member's timeout ends, in Unix milliseconds, if they're timed
    /// out as far as Yapfast knows; it may have ended already.
    pub fn timed_out_until(&self, guild: &str, user: &str) -> Option<u64> {
        self.timeouts.get(&member_key(guild, user)?).copied()
    }

    /// Since when a member has boosted their server, in Unix milliseconds,
    /// if they do as far as Yapfast knows.
    pub fn boosting_since(&self, guild: &str, user: &str) -> Option<u64> {
        self.boosts.get(&member_key(guild, user)?).copied()
    }

    /// When Discord says the user joined this guild, in Unix milliseconds.
    pub fn joined_at(&self, guild: &str, user: &str) -> Option<u64> {
        self.joined.get(&member_key(guild, user)?).copied()
    }

    /// The members known to hold `role` in a server, by user id.
    pub fn members_with_role(&self, guild: &str, role: &str) -> Vec<String> {
        let Some(guild) = id(guild) else {
            return Vec::new();
        };
        let mut members: Vec<String> = self
            .roles
            .iter()
            .filter(|((server, _), roles)| {
                *server == guild && roles.iter().any(|held| held == role)
            })
            .map(|((_, user), _)| user.to_string())
            .collect();
        members.sort();
        members
    }

    /// Names of members already learned in this guild, including users with no
    /// nickname. Names learned in other guilds cannot supply candidates here.
    pub fn known_guild_members<'a>(
        &'a self,
        guild: &str,
    ) -> impl Iterator<Item = (u64, &'a str, Option<&'a str>)> + use<'a> {
        let guild = id(guild);
        self.members.iter().filter_map(move |&(server, user)| {
            if Some(server) != guild {
                return None;
            }
            let username = self.usernames.get(&user).map(String::as_str);
            let name = self
                .nicknames
                .get(&(server, user))
                .or_else(|| self.users.get(&user))
                .map(String::as_str)
                .or(username)?;
            Some((user, name, username))
        })
    }

    /// A member's roles in a server, as far as they're known.
    pub fn roles(&self, guild: &str, user: &str) -> &[String] {
        self.shared(guild, user).map_or(&[], |roles| roles)
    }

    /// A member's roles in a server, as far as they're known, shared rather
    /// than copied; none when they aren't known.
    pub fn shared_roles(&self, guild: &str, user: &str) -> Option<Arc<[String]>> {
        self.shared(guild, user).cloned()
    }

    fn shared(&self, guild: &str, user: &str) -> Option<&Arc<[String]>> {
        let key = member_key(guild, user)?;
        self.touch(key.1);
        self.roles.get(&key)
    }

    /// Learns the author and the mentioned users of a message object, and
    /// those of the message it replies to.
    pub fn learn_message(&mut self, guild: Option<&str>, message: &Value) {
        self.learn_user(&message["author"]);
        // Discord doesn't nest a reply's original inside the original.
        if message["referenced_message"].is_object() {
            self.learn_message(guild, &message["referenced_message"]);
        }
        if let (Some(guild), Value::Object(member)) = (guild, &message["member"]) {
            let mut member = Value::Object(member.clone());
            member["user"] = message["author"].clone();
            self.learn_member(guild, &member);
        }
        for user in message["mentions"].as_array().into_iter().flatten() {
            self.learn_user(user);
            if let (Some(guild), Value::Object(member)) = (guild, &user["member"]) {
                let mut member = Value::Object(member.clone());
                member["user"] = user.clone();
                self.learn_member(guild, &member);
            }
        }
    }

    /// Whether a user is a bot or an app, as far as it's known.
    pub fn is_bot(&self, user: &str) -> bool {
        id(user).is_some_and(|user| self.bots.contains(&user))
    }

    pub fn knows_member(&self, guild: &str, user: &str) -> bool {
        member_key(guild, user).is_some_and(|key| self.members.contains(&key))
    }

    /// Known users whose name starts with `query`, or has a later word that does,
    /// by id; any letter case.
    pub fn find_users(&self, query: &str) -> Vec<String> {
        let query = query.to_lowercase();
        let mut found: Vec<(bool, &String, String)> = self
            .users
            .iter()
            .filter_map(|(id, name)| {
                let lower = name.to_lowercase();
                let starts = lower.starts_with(&query);
                let later = lower
                    .split_whitespace()
                    .skip(1)
                    .any(|word| word.starts_with(&query));
                (starts || later).then(|| (!starts, name, id.to_string()))
            })
            .collect();
        found.sort();
        found.into_iter().map(|(_, _, id)| id).collect()
    }

    /// A user's display name or username, outside any server.
    pub fn user_name(&self, user: &str) -> Option<&str> {
        let user = id(user)?;
        self.touch(user);
        self.users.get(&user).map(String::as_str)
    }

    /// A user's username, such as `ann`.
    pub fn username(&self, user: &str) -> Option<&str> {
        self.usernames.get(&id(user)?).map(String::as_str)
    }

    /// A member's nickname in a server, when they set one.
    pub fn nickname(&self, guild: &str, user: &str) -> Option<&str> {
        self.nicknames
            .get(&member_key(guild, user)?)
            .map(String::as_str)
    }

    pub fn name(&self, guild: &str, user: &str) -> Option<&str> {
        let user_id = id(user)?;
        self.touch(user_id);
        id(guild)
            .and_then(|guild| self.nicknames.get(&(guild, user_id)))
            .or_else(|| self.users.get(&user_id))
            .map(String::as_str)
    }

    /// The address of the avatar Discord shows for a user: their server
    /// avatar in `guild`, else their own, else a default one.
    pub fn avatar(&self, guild: Option<&str>, user: &str) -> String {
        let user_id = id(user);
        if let Some(user_id) = user_id {
            self.touch(user_id);
        }
        if let Some(guild) = guild
            && let Some(hash) =
                member_key(guild, user).and_then(|key| self.member_avatars.get(&key))
        {
            return ready::member_avatar(guild, user, hash);
        }
        let hash = user_id.and_then(|user| self.avatars.get(&user));
        ready::avatar(user, hash.map(String::as_str))
    }

    /// Whether a user is one of Discord's own accounts.
    pub fn is_official(&self, user: &str) -> bool {
        id(user).is_some_and(|user| self.officials.contains(&user))
    }

    /// The server tag a user wears beside their name, if they do.
    pub fn server_tag(&self, user: &str) -> Option<&Tag> {
        let user = id(user)?;
        self.touch(user);
        self.tags.get(&user)
    }

    /// The address of the decoration a user wears around their avatar: the
    /// one they set for `guild` where they have one, else their own.
    pub fn decoration(&self, guild: Option<&str>, user: &str) -> Option<Arc<str>> {
        Some(self.collectible_picture(self.decoration_sku(guild, user)?))
    }

    /// The SKU behind [`Self::decoration`], which says when it changes
    /// without making the address.
    pub fn decoration_sku(&self, guild: Option<&str>, user: &str) -> Option<Id> {
        let user_id = id(user)?;
        self.touch(user_id);
        guild
            .and_then(|guild| member_key(guild, user))
            .and_then(|key| self.member_decorations.get(&key))
            .or_else(|| self.decorations.get(&user_id))
            .copied()
    }

    fn collectible_picture(&self, sku: Id) -> Arc<str> {
        self.collectible_pictures
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .entry(sku)
            .or_insert_with(|| collectibles::picture(sku).into())
            .clone()
    }

    /// The nameplate a user equips, in `guild` or everywhere.
    pub fn nameplate(&self, guild: Option<&str>, user: &str) -> Option<Nameplate> {
        let plate = self.plate(guild, user)?;
        Some(plate.shown(self.collectible_picture(plate.sku)))
    }

    /// What [`Self::nameplate`] shows, which says when it changes without
    /// making the address.
    pub fn plate(&self, guild: Option<&str>, user: &str) -> Option<Plate> {
        let user_id = id(user)?;
        self.touch(user_id);
        guild
            .and_then(|guild| member_key(guild, user))
            .and_then(|key| self.member_nameplates.get(&key))
            .or_else(|| self.nameplates.get(&user_id))
            .copied()
    }

    /// The display name style a user draws their name with, in `guild` or
    /// everywhere.
    pub fn style(&self, guild: Option<&str>, user: &str) -> Option<Style> {
        let user_id = id(user)?;
        self.touch(user_id);
        guild
            .and_then(|guild| member_key(guild, user))
            .and_then(|key| self.member_styles.get(&key))
            .or_else(|| self.styles.get(&user_id))
            .copied()
    }

    /// The avatar hash [`Self::avatar`] makes a user's address from outside
    /// servers; none for one who set none.
    pub fn avatar_hash(&self, user: &str) -> Option<&str> {
        let user = id(user)?;
        self.touch(user);
        self.avatars.get(&user).map(String::as_str)
    }

    /// Discord Markdown for Yapfast: mentions, custom emoji and timestamps
    /// become text.
    pub fn render(&self, server: Option<&Server>, content: &str) -> String {
        self.render_tags(server, content, false, |_, _, _| {})
    }

    /// [`Names::render`], with the users and roles the message mentions:
    /// each with the text it shows for them and where that text starts, each
    /// time, as Discord's client draws a mention where its tag was, and
    /// where `@everyone` or `@here` is.
    pub fn render_mentions(
        &self,
        server: Option<&Server>,
        content: &str,
    ) -> (String, Vec<Mention>) {
        self.render_mention_tags(server, content, false)
    }

    /// As in `render_mentions`, preserving custom emoji tags for image rendering.
    pub fn render_rich_mentions(
        &self,
        server: Option<&Server>,
        content: &str,
    ) -> (String, Vec<Mention>) {
        self.render_mention_tags(server, content, true)
    }

    fn render_mention_tags(
        &self,
        server: Option<&Server>,
        content: &str,
        keep_emoji: bool,
    ) -> (String, Vec<Mention>) {
        let mut mentions: Vec<Mention> = Vec::new();
        let rendered = self.render_tags(server, content, keep_emoji, |tag, at, text| {
            let target = if tag == "@everyone" || tag == "@here" {
                MentionTarget::Everyone
            } else if let Some(id) = tag.strip_prefix("@&") {
                MentionTarget::Role(id.to_owned())
            } else if let Some(id) = tag.strip_prefix("@!").or_else(|| tag.strip_prefix('@')) {
                MentionTarget::User(id.to_owned())
            } else if let Some(id) = tag.strip_prefix('#') {
                // One the server doesn't list shows as `#channel`, and opens nothing.
                if server.is_none_or(|server| server.channel_name(id).is_none()) {
                    return;
                }
                MentionTarget::Channel(id.to_owned())
            } else {
                return;
            };
            match mentions
                .iter_mut()
                .find(|known| known.target == target && known.text == text)
            {
                Some(known) => known.at.push(at),
                None => mentions.push(Mention {
                    text: text.to_owned(),
                    target,
                    at: vec![at],
                }),
            }
        });
        (rendered, mentions)
    }

    /// [`Names::render`], telling `rendered` of each tag shown as text: the
    /// tag, where its text starts and the text. `@everyone` and `@here` are
    /// tags of their own, as Discord's client finds them anywhere but after
    /// a backslash.
    fn render_tags(
        &self,
        server: Option<&Server>,
        content: &str,
        keep_emoji: bool,
        mut rendered_tag: impl FnMut(&str, usize, &str),
    ) -> String {
        let guild = server.map_or("", |server| server.id.as_str());
        let mut rendered = String::with_capacity(content.len());
        let mut rest = content;
        while let Some(start) = rest.find('<') {
            push_text(&mut rendered, &rest[..start], &mut rendered_tag);
            rest = &rest[start..];
            let Some(end) = rest.find('>') else {
                break;
            };
            let tag = &rest[1..end];
            if keep_emoji && custom_emoji_tag(tag).is_some() {
                rendered.push_str(&rest[..=end]);
                rest = &rest[end + 1..];
                continue;
            }
            match self.tag(server, guild, tag) {
                Some(text) => {
                    rendered_tag(tag, rendered.len(), &text);
                    rendered.push_str(&text);
                    rest = &rest[end + 1..];
                }
                None => {
                    rendered.push('<');
                    rest = &rest[1..];
                }
            }
        }
        push_text(&mut rendered, rest, &mut rendered_tag);
        rendered
    }

    fn tag(&self, server: Option<&Server>, guild: &str, tag: &str) -> Option<String> {
        let digits = |id: &str| !id.is_empty() && id.bytes().all(|byte| byte.is_ascii_digit());
        if let Some(id) = tag.strip_prefix("@&") {
            digits(id).then(|| {
                let name = server.and_then(|server| server.role_names.get(id));
                format!("@{}", name.map_or("role", String::as_str))
            })
        } else if let Some(id) = tag.strip_prefix("@!").or_else(|| tag.strip_prefix('@')) {
            digits(id).then(|| format!("@{}", self.name(guild, id).unwrap_or("Discord user")))
        } else if let Some(id) = tag.strip_prefix('#') {
            digits(id).then(|| {
                // Anyone who may start a thread names it, and the name
                // shows inside others' Markdown: it's escaped to show as
                // typed.
                let name = server.and_then(|server| server.channel_name(id));
                format!("#{}", escape_markdown(name.unwrap_or("channel")))
            })
        } else if let Some((name, _, _)) = custom_emoji_tag(tag) {
            Some(format!(":{name}:"))
        } else if let Some(time) = tag.strip_prefix("t:") {
            timestamp_tag(time)
        } else {
            None
        }
    }
}

/// Pushes text outside tags onto `rendered`, telling `rendered_tag` of each
/// `@everyone` and `@here` in it that no backslash escapes.
fn push_text(rendered: &mut String, text: &str, rendered_tag: &mut impl FnMut(&str, usize, &str)) {
    for (at, _) in text.match_indices('@') {
        let escaped = text[..at]
            .bytes()
            .rev()
            .take_while(|&byte| byte == b'\\')
            .count()
            % 2
            == 1;
        let group = ["@everyone", "@here"]
            .into_iter()
            .find(|group| text[at..].starts_with(group));
        if let Some(group) = group
            && !escaped
        {
            rendered_tag(group, rendered.len() + at, group);
        }
    }
    rendered.push_str(text);
}

/// Someone or something a message mentions, as [`Names::render_mentions`]
/// finds them.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Mention {
    /// The text the message shows for them, such as `@Ann`.
    pub text: String,
    pub target: MentionTarget,
    /// Where the text starts in the rendered message, a byte offset each
    /// time it mentions them.
    pub at: Vec<usize>,
}

/// Who a [`Mention`] is of.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum MentionTarget {
    /// A user, by id.
    User(String),
    /// A role, by id.
    Role(String),
    /// A channel of the server the message is in, by id.
    Channel(String),
    /// `@everyone` or `@here`.
    Everyone,
}

/// `text` with Markdown's punctuation escaped by backslashes.
fn escape_markdown(text: &str) -> String {
    let mut escaped = String::with_capacity(text.len() + 8);
    for character in text.chars() {
        if character.is_ascii_punctuation() {
            escaped.push('\\');
        }
        escaped.push(character);
    }
    escaped
}

/// `text` with each `<t:SECONDS>` or `<t:SECONDS:STYLE>` written as the
/// time it names, as [`Names::render`] writes them in messages; for text
/// that isn't rendered otherwise, such as a bio being written.
pub fn render_timestamps(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    let mut rest = text;
    while let Some(start) = rest.find("<t:") {
        out.push_str(&rest[..start]);
        let tag = &rest[start + 3..];
        let parsed = tag
            .find('>')
            .and_then(|end| Some((timestamp_tag(&tag[..end])?, end)));
        match parsed {
            Some((time, end)) => {
                out.push_str(&time);
                rest = &tag[end + 1..];
            }
            None => {
                out.push_str("<t:");
                rest = tag;
            }
        }
    }
    out.push_str(rest);
    out
}

/// A timestamp tag's inside, `SECONDS` or `SECONDS:STYLE`, as the time it
/// names; none for anything else, which Discord's client shows as written:
/// another style, or a time it can't place.
fn timestamp_tag(tag: &str) -> Option<String> {
    let mut parts = tag.split(':');
    let seconds = parts.next()?;
    let digits = seconds.strip_prefix('-').unwrap_or(seconds);
    if digits.is_empty() || digits.len() > 17 || !digits.bytes().all(|b| b.is_ascii_digit()) {
        return None;
    }
    let seconds = seconds.parse::<i64>().ok()?;
    chrono::DateTime::from_timestamp(seconds, 0)?;
    let style = parts.next();
    if style
        .is_some_and(|style| !matches!(style, "t" | "T" | "d" | "D" | "f" | "F" | "s" | "S" | "R"))
    {
        return None;
    }
    parts.next().is_none().then(|| timestamp(seconds, style))
}

/// How `<t:…>` timestamps write times and dates, as the app's settings
/// say: on a 12-hour clock or not, and a date's short and long forms, as
/// chrono formats such as `%d/%m/%Y` and `%-d %B %Y`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct TimestampFormat {
    pub twelve_hour: bool,
    pub short_date: &'static str,
    pub long_date: &'static str,
}

impl TimestampFormat {
    /// Until the app says otherwise: day first, on a 24-hour clock.
    const DEFAULT: Self = Self {
        twelve_hour: false,
        short_date: "%d/%m/%Y",
        long_date: "%-d %B %Y",
    };
}

static TIMESTAMP_FORMAT: std::sync::RwLock<TimestampFormat> =
    std::sync::RwLock::new(TimestampFormat::DEFAULT);

/// Writes `<t:…>` timestamps in `format` from now on; the UI sets it at
/// start and when the clock or date format setting changes.
pub fn set_timestamp_format(format: TimestampFormat) {
    *TIMESTAMP_FORMAT
        .write()
        .unwrap_or_else(std::sync::PoisonError::into_inner) = format;
}

/// A `<t:SECONDS:STYLE>` timestamp in the local time zone, as Discord's
/// client shows each style, here with dates day first on a 24-hour clock:
/// `t` 14:05, `T` 14:05:09, `d` 06/10/2026, `D` 6 October 2026, `f` (and no
/// style) 6 October 2026 14:05, `F` Tuesday, 6 October 2026 14:05, `s`
/// 06/10/2026 14:05, `S` 06/10/2026 14:05:09, `R` 3 hours ago. Messages
/// render once, so `R` says how long ago it was when the message arrived.
fn timestamp(seconds: i64, style: Option<&str>) -> String {
    let format = *TIMESTAMP_FORMAT
        .read()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    timestamp_at(seconds, style, chrono::Local::now().timestamp(), format)
}

fn timestamp_at(seconds: i64, style: Option<&str>, now: i64, format: TimestampFormat) -> String {
    let at = local(seconds);
    // Discord's client writes them in moment's LT, LTS, L, LL, LLL and
    // LLLL, in the user's locale.
    let (time, time_seconds) = if format.twelve_hour {
        ("%-I:%M %p", "%-I:%M:%S %p")
    } else {
        ("%H:%M", "%H:%M:%S")
    };
    let TimestampFormat {
        short_date,
        long_date,
        ..
    } = format;
    let pattern = match style {
        Some("t") => time.to_owned(),
        Some("T") => time_seconds.to_owned(),
        Some("d") => short_date.to_owned(),
        Some("D") => long_date.to_owned(),
        Some("F") => format!("%A, {long_date} {time}"),
        Some("s") => format!("{short_date} {time}"),
        Some("S") => format!("{short_date} {time_seconds}"),
        Some("R") => return relative(seconds - now),
        _ => format!("{long_date} {time}"),
    };
    at.format(&pattern).to_string()
}

/// `seconds` from now in Discord's words: `in 5 minutes`, `2 days ago`.
/// Discord's client asks moment's `fromNow` with its thresholds for seconds
/// and minutes moved up, so minutes count to 59 and seconds don't show:
/// each unit is rounded, and the next one starts where that rounds to its
/// threshold.
fn relative(seconds: i64) -> String {
    let span = seconds.unsigned_abs() as f64;
    let days = span / 86_400.0;
    // moment's lengths of a month and a year, in days.
    let rounded = |units: f64| units.round() as u64;
    let (minutes, hours, whole_days) =
        (rounded(span / 60.0), rounded(span / 3600.0), rounded(days));
    let (months, years) = (rounded(days / 30.436_875), rounded(days / 365.242_5));
    let words = if rounded(span) < 60 {
        "a few seconds".to_owned()
    } else if minutes <= 1 {
        "a minute".to_owned()
    } else if minutes < 60 {
        format!("{minutes} minutes")
    } else if hours <= 1 {
        "an hour".to_owned()
    } else if hours < 22 {
        format!("{hours} hours")
    } else if whole_days <= 1 {
        "a day".to_owned()
    } else if whole_days < 26 {
        format!("{whole_days} days")
    } else if months <= 1 {
        "a month".to_owned()
    } else if months < 11 {
        format!("{months} months")
    } else if years <= 1 {
        "a year".to_owned()
    } else {
        format!("{years} years")
    };
    if seconds >= 0 {
        format!("in {words}")
    } else {
        format!("{words} ago")
    }
}

/// A day in Unix milliseconds as profiles show it, in the local time zone: `6 Oct 2026`.
pub fn date(ms: u64) -> String {
    local(i64::try_from(ms / 1000).unwrap_or(i64::MAX))
        .format("%-d %b %Y")
        .to_string()
}

fn local(seconds: i64) -> chrono::DateTime<chrono::Local> {
    chrono::DateTime::from_timestamp(seconds, 0)
        .unwrap_or_default()
        .with_timezone(&chrono::Local)
}

#[cfg(test)]
mod tests {
    #[test]
    fn command_details_inline_gateway_options_never_serialize() {
        let message = super::parse(&serde_json::json!({
            "id": "50", "channel_id": "40", "type": 20,
            "author": {"id": "70", "username": "Recipe Bot"},
            "interaction_metadata": {
                "id": "80", "type": 2, "user": {"id": "90", "username": "Author"},
                "authorizing_integration_owners": {"0": "0", "1": "90"}
            },
            "interaction_data": {
                "id": "80", "name": "recipe",
                "options": [{"type": 3, "name": "text", "value": "transient option"}]
            }
        }))
        .unwrap();
        let interaction = message.interaction.as_ref().unwrap();
        assert_eq!(interaction.user_id, "90");
        assert_eq!(interaction.installation_guild_id, None);
        assert_eq!(interaction.installation_user_id.as_deref(), Some("90"));
        assert_eq!(
            interaction.data.as_deref().unwrap()["options"][0]["value"],
            "transient option"
        );
        let stored = serde_json::to_string(&message).unwrap();
        assert!(!stored.contains("transient option"));
        let restored: super::Message = serde_json::from_str(&stored).unwrap();
        assert!(restored.interaction.unwrap().data.is_none());
    }

    use serde_json::json;

    use super::*;

    #[test]
    fn a_pin_notice_links_to_the_message_pinned() {
        let notice = parse(&json!({
            "id": "5", "channel_id": "1", "type": 6, "content": "",
            "author": {"id": "2", "username": "bob"},
            "message_reference": {"channel_id": "1", "message_id": "4"},
        }))
        .unwrap();
        assert_eq!(notice.system.as_deref(), Some("pinned a message."));
        assert_eq!(notice.notice, Some(Notice::Pinned(Some("4".into()))));
        let joined = parse(&json!({
            "id": "6", "channel_id": "1", "type": 7, "content": "",
            "author": {"id": "2", "username": "bob"},
        }))
        .unwrap();
        assert_eq!(joined.notice, Some(Notice::Joined));
    }

    #[test]
    fn recipient_notices_keep_the_actor_and_target_without_ping_or_modification() {
        let added = parse(&json!({
            "id": "500", "channel_id": "30", "guild_id": "10", "type": 1,
            "author": {"id": "2", "username": "alice"},
            "mentions": [{"id": "3", "username": "bob", "member": {"nick": "Bob the Chef"}}]
        }))
        .unwrap();
        assert_eq!(added.author_id, "2");
        assert_eq!(
            added.system.as_deref(),
            Some("added Bob the Chef to the thread.")
        );
        assert_eq!(
            added.notice,
            Some(Notice::RecipientChanged {
                added: true,
                user: Some("3".into()),
                name: "Bob the Chef".into(),
            })
        );
        assert!(added.mentions.is_empty());
        assert!(added.undeletable && !added.editable && !added.forwardable);
        let removed = parse(&json!({
            "id": "501", "channel_id": "30", "type": 2,
            "author": {"id": "2", "username": "alice"},
            "mentions": [{"id": "3", "username": "bob", "global_name": "Bob"}]
        }))
        .unwrap();
        assert_eq!(
            removed.system.as_deref(),
            Some("removed Bob from the group.")
        );
        assert_eq!(
            removed.notice,
            Some(Notice::RecipientChanged {
                added: false,
                user: Some("3".into()),
                name: "Bob".into(),
            })
        );
        assert!(removed.mentions.is_empty());
        assert!(removed.undeletable && !removed.editable && !removed.forwardable);
        assert_eq!(
            serde_json::from_value::<Message>(serde_json::to_value(&removed).unwrap()).unwrap(),
            removed
        );
    }

    #[test]
    fn rename_notices_keep_the_name_from_when_it_changed() {
        let notice = parse(&json!({
            "id": "502", "channel_id": "30", "type": 4,
            "author": {"id": "2", "username": "alice"}, "content": "Weekend plans [2]",
        }))
        .unwrap();
        assert_eq!(notice.notice, Some(Notice::ChannelRenamed));
        assert_eq!(notice.content, "Weekend plans [2]");
        assert_eq!(
            notice.system.as_deref(),
            Some("changed the channel name: Weekend plans [2]")
        );
        assert!(notice.undeletable && !notice.editable && !notice.forwardable);
    }

    #[test]
    fn links_threads_and_shows_a_threads_first_message() {
        let started = parse(&json!({"id": "500", "type": 0, "channel_id": "11",
            "author": {"id": "2", "username": "bob"}, "content": "Who's in?",
            "thread": {"id": "500", "type": 11, "name": "Saturday", "message_count": 4,
                       "thread_metadata": {"archived": true}}}))
        .unwrap();
        assert_eq!(
            started.thread,
            Some(ThreadLink {
                id: "500".into(),
                name: "Saturday".into(),
                messages: 4,
                archived: true,
            })
        );
        let notice = parse(&json!({"id": "600", "type": 18, "channel_id": "11",
            "author": {"id": "2", "username": "bob"}, "content": "Sunday",
            "message_reference": {"channel_id": "700", "guild_id": "10"}}))
        .unwrap();
        assert_eq!(notice.system.as_deref(), Some("started a thread: Sunday."));
        assert_eq!(
            notice.thread.map(|thread| thread.id).as_deref(),
            Some("700")
        );
        // In the thread, its first message is the one it was started from.
        let first = parse(&json!({"id": "501", "type": 21, "channel_id": "500",
            "author": {"id": "2", "username": "bob"}, "content": "",
            "message_reference": {"channel_id": "11", "message_id": "500"},
            "referenced_message": {"id": "500", "type": 0, "channel_id": "11",
                "author": {"id": "2", "username": "bob"}, "content": "Who's in?",
                "thread": {"id": "500", "name": "Saturday"}}}))
        .unwrap();
        assert_eq!(
            (first.id.as_str(), first.channel_id.as_str()),
            ("501", "500")
        );
        assert_eq!(first.content, "Who's in?");
        assert!(first.thread.is_none() && !first.editable && first.undeletable);
        assert!(
            parse(&json!({"id": "502", "type": 21, "channel_id": "500",
            "author": {"id": "2"}, "referenced_message": null}))
            .is_none()
        );
        // A forum post's first message has the post's id, and links to no
        // thread but the one it's in.
        let post = parse(&json!({"id": "800", "type": 0, "channel_id": "800",
            "author": {"id": "2", "username": "bob"}, "content": "An idea",
            "thread": {"id": "800", "name": "Idea"}}))
        .unwrap();
        assert!(post.thread.is_none());
    }

    #[test]
    fn knows_who_may_delete_an_apps_answer_and_a_call() {
        let answer = |owners: Value| {
            parse(&json!({"id": "900", "type": 20, "channel_id": "11",
                "author": {"id": "5", "username": "app", "bot": true}, "content": "Pong",
                "interaction_metadata": {"id": "901", "type": 2,
                    "user": {"id": "1", "username": "me"},
                    "authorizing_integration_owners": owners}}))
            .unwrap()
        };
        let mine = answer(json!({"1": "1"}));
        assert_eq!(mine.invoker.as_deref(), Some("1"));
        assert_eq!(
            mine.interaction
                .map(|interaction| interaction.id)
                .as_deref(),
            Some("901")
        );
        assert!(!mine.undeletable);
        assert_eq!(
            answer(json!({"0": "10", "1": "1"})).invoker,
            None,
            "installed in the server too"
        );
        assert_eq!(answer(json!({"0": "10"})).invoker, None);
        let call = parse(&json!({"id": "902", "type": 3, "channel_id": "11",
            "author": {"id": "1"}, "call": {"participants": ["1"]}}))
        .unwrap();
        assert!(call.undeletable && call.invoker.is_none());
    }

    #[test]
    fn says_how_long_calls_lasted() {
        // Two minutes after Discord's epoch, as a snowflake.
        let id = snowflake_at(DISCORD_EPOCH_MS + 120_000).to_string();
        let call = |ended: Value| {
            parse(
                &json!({"id": id, "type": 3, "author": {"id": "1"}, "call": {
                    "participants": ["1"], "ended_timestamp": ended,
                }}),
            )
            .and_then(|message| message.system)
        };
        assert_eq!(call(Value::Null).as_deref(), Some("started a call."));
        assert_eq!(
            call(json!("2015-01-01T00:07:10+00:00")).as_deref(),
            Some("started a call that lasted 5 minutes.")
        );
        assert_eq!(lasted(10_000), "a few seconds");
        assert_eq!(lasted(50 * 60_000), "an hour");
        assert_eq!(lasted(150 * 60_000), "3 hours");
    }

    #[test]
    fn parses_stickers_and_spoilers() {
        let message = parse(&json!({
            "id": "1300000000000000000",
            "type": 0,
            "content": "look ||https://example.com/cat.gif||",
            "author": {"id": "1", "username": "me"},
            "attachments": [
                {"filename": "SPOILER_cat.png", "url": "https://cdn/c.png", "content_type": "image/png"},
                {"filename": "dog.png", "flags": 8, "url": "https://cdn/d.png", "content_type": "image/png"},
                {"filename": "plain.png", "url": "https://cdn/p.png", "content_type": "image/png"},
            ],
            "embeds": [{"type": "image", "url": "https://example.com/cat.gif",
                "thumbnail": {"url": "https://example.com/cat.gif", "proxy_url": "https://media/cat.gif", "width": 100, "height": 100}}],
            "sticker_items": [
                {"id": "7", "name": "Wave", "format_type": 1},
                {"id": "8", "name": "Dance", "format_type": 4},
                {"id": "9", "name": "Spin", "format_type": 3},
            ],
        }))
        .unwrap();
        let spoilers: Vec<bool> = message.attachments.iter().map(|a| a.spoiler).collect();
        assert_eq!(&spoilers[..3], [true, true, false]);
        assert!(spoilers[3], "a spoiled link's preview is a spoiler too");
        let stickers: Vec<(&str, &str)> = message
            .attachments
            .iter()
            .filter(|attachment| attachment.shown == Shown::Sticker)
            .map(|attachment| (attachment.name.as_str(), &*attachment.url))
            .collect();
        assert_eq!(
            stickers,
            [
                ("Wave", "https://cdn.discordapp.com/stickers/7.png?size=160"),
                (
                    "Dance",
                    "https://media.discordapp.net/stickers/8.gif?size=160"
                ),
                ("Spin", "https://cdn.discordapp.com/stickers/9.json"),
            ]
        );
        assert_eq!(message.content, "look ||https://example.com/cat.gif||");
    }

    #[test]
    fn a_message_of_components_shows_its_files_only_through_them() {
        let file = |name: &str| {
            json!({"url": format!("https://cdn/{name}"), "proxy_url": format!("https://media/{name}"),
                   "width": 10, "height": 10, "content_type": "image/png"})
        };
        let message = parse(&json!({
            "id": "1", "channel_id": "2", "author": {"id": "3", "username": "discord"},
            "content": "", "flags": 1 << 15,
            "attachments": [{"filename": "a.png", "size": 1, "url": "https://cdn/a.png",
                             "proxy_url": "https://media/a.png", "content_type": "image/png"}],
            "components": [{"type": 17, "components": [
                {"type": 10, "content": "Hi"},
                {"type": 12, "items": [{"media": file("a.png")}]},
            ]}],
        }))
        .unwrap();
        assert_eq!(message.components.len(), 1);
        let shown: Vec<_> = message.attachments.iter().map(|a| a.shown).collect();
        assert_eq!(shown, [Shown::Component(0)]);
        // An older message's buttons show under its own files.
        let message = parse(&json!({
            "id": "1", "channel_id": "2", "author": {"id": "3", "username": "bot"},
            "content": "Done",
            "attachments": [{"filename": "a.txt", "size": 1, "url": "https://cdn/a.txt"}],
            "components": [{"type": 1, "components": [
                {"type": 2, "style": 5, "label": "Open", "url": "https://example.com"}]}],
        }))
        .unwrap();
        assert_eq!(message.attachments.len(), 1);
        assert_eq!(message.components[0].rows.len(), 1);
    }

    #[test]
    fn components_v2_ignores_legacy_payload_fields() {
        let mut payload = json!({
            "id": "1", "channel_id": "2", "author": {"id": "3", "username": "Bot", "bot": true},
            "flags": components::IS_COMPONENTS_V2, "content": "Legacy message text",
            "embeds": [{"type": "rich", "title": "Legacy embed"}],
            "attachments": [{"filename": "stale.txt", "size": 8, "url": "https://cdn/stale.txt"}],
            "sticker_items": [{"id": "7", "name": "Legacy sticker", "format_type": 1}],
            "poll": {"question": {"text": "Legacy poll"}, "answers": [
                {"answer_id": 1, "poll_media": {"text": "Yes"}}
            ]},
            "interaction_metadata": {"id": "10", "type": 2, "user": {"id": "11", "username": "Member"}},
            "components": [{"type": 17, "accent_color": 0x3366aa, "components": [
                {"type": 10, "content": "Component heading"},
                {"type": 14, "divider": true, "spacing": 2},
                {"type": 12, "items": [{"media": {"url": "https://cdn/a.png",
                    "proxy_url": "https://media/a.png", "width": 12, "height": 12,
                    "content_type": "image/png"}}]},
                {"type": 1, "components": [
                    {"type": 2, "style": 1, "label": "Next", "custom_id": "next"}
                ]}
            ]}]
        });
        let current = parse(&payload).unwrap();
        assert!(current.content.is_empty() && current.embeds.is_empty());
        assert!(current.poll.is_none());
        assert_eq!(current.attachments.len(), 1);
        assert_eq!(current.attachments[0].shown, Shown::Component(0));
        assert_eq!(current.interaction.unwrap().user_id, "11");
        let card = &current.components[0];
        assert!(card.framed);
        assert_eq!(card.color, Some(0x3366aa));
        assert_eq!(card.texts().collect::<Vec<_>>(), ["Component heading"]);
        assert!(matches!(
            &card.rows[..],
            [
                components::Row::Text { .. },
                components::Row::Separator { divider: true, large: true },
                components::Row::Media(0),
                components::Row::Buttons(buttons)
            ] if buttons[0].custom_id.as_deref() == Some("next")
        ));

        payload["flags"] = json!(0);
        payload["components"] = json!([{"type": 1, "components": [
            {"type": 2, "style": 1, "label": "Next", "custom_id": "next"}
        ]}]);
        let legacy = parse(&payload).unwrap();
        assert_eq!(legacy.content, "Legacy message text");
        assert_eq!(legacy.embeds.len(), 1);
        assert_eq!(legacy.poll.unwrap().question, "Legacy poll");
        assert_eq!(legacy.attachments.len(), 2);
        assert_eq!(legacy.attachments[0].shown, Shown::Message);
        assert_eq!(legacy.attachments[1].shown, Shown::Sticker);
        assert!(!legacy.components[0].framed);
    }

    #[test]
    fn parses_replies_attachments_and_reactions() {
        let message = parse(&json!({
            "id": "1300000000000000000",
            "channel_id": "11",
            "type": 19,
            "content": "hi <@2>",
            "author": {"id": "1", "username": "me", "global_name": "Me"},
            "member": {"nick": "Captain"},
            "edited_timestamp": "2026-10-06T10:00:00.000000+00:00",
            "referenced_message": {"id": "9", "author": {"id": "2", "username": "ann"}, "content": "hello"},
            "attachments": [{"filename": "cat.png", "size": 10, "url": "https://cdn/cat.png", "content_type": "image/png",
                "proxy_url": "https://media/cat.png?ex=1", "width": 1440, "height": 540},
                {"filename": "clip.mp4", "size": 99, "url": "https://cdn/clip.mp4", "content_type": "video/mp4",
                "proxy_url": "https://media/clip.mp4", "width": 1920, "height": 1080}],
            "reactions": [
                {"emoji": {"id": null, "name": "👍"}, "count": 2, "me": true},
                {"emoji": {"id": "5", "name": "pog"}, "count": 1, "me": false},
            ],
        }))
        .unwrap();
        assert_eq!(message.author, "Captain");
        assert!(message.edited && message.editable);
        assert_eq!(
            message.reply,
            Some(Reply::Message {
                id: "9".into(),
                author_id: "2".into(),
                author: "ann".into(),
                content: "hello".into()
            })
        );
        assert!(message.attachments[0].image);
        assert_eq!(
            message.attachments[0].preview_url.as_deref(),
            Some("https://media/cat.png?ex=1&animated=true&format=webp&width=550&height=206")
        );
        assert_eq!(
            message.attachments[0].view_url.as_deref(),
            Some("https://media/cat.png?ex=1&animated=true&format=webp&width=1440&height=540"),
            "a small image isn't enlarged"
        );
        // A video plays from the file, its poster from the media proxy.
        let video = &message.attachments[1];
        assert!(!video.image);
        assert_eq!(video.video_url.as_deref(), Some("https://cdn/clip.mp4"));
        assert_eq!(
            video.preview_url.as_deref(),
            Some("https://media/clip.mp4?format=webp&width=550&height=309")
        );
        assert_eq!(video.dimensions, Some((1920, 1080)));
        assert_eq!(message.attachments[0].video_url, None);
        assert_eq!(message.reactions[1].key, ":pog:");
        assert_eq!(message.reactions[1].emoji, "pog:5");
        assert_eq!(message.timestamp(), 1_730_014_552);

        let mut message = message;
        message.react("👍", "👍", true, false);
        assert_eq!(
            (message.reactions[0].count, message.reactions[0].me),
            (1, false)
        );
        message.react("pog", "pog:5", false, false);
        message.react(":pog:", "pog:5", false, false);
        assert_eq!(message.reactions.len(), 1);

        // This account's reaction counts once, however often the gateway
        // says it was added or removed.
        message.react("👍", "👍", true, true);
        message.react("👍", "👍", true, true);
        assert_eq!(
            (message.reactions[0].count, message.reactions[0].me),
            (2, true)
        );
        message.react("👍", "👍", true, false);
        message.react("👍", "👍", true, false);
        assert_eq!(
            (message.reactions[0].count, message.reactions[0].me),
            (1, false)
        );
        // Others' still count each time.
        message.react("👍", "👍", false, true);
        assert_eq!(message.reactions[0].count, 2);

        assert!(parse(&json!({"id": "1", "type": 8, "author": {"id": "1"}})).is_none());
        let deleted = parse(
            &json!({"id": "1", "type": 19, "author": {"id": "1"}, "referenced_message": null}),
        );
        assert_eq!(deleted.unwrap().reply, Some(Reply::Deleted));
        // Without the field, Discord didn't look the original up.
        let unknown = parse(&json!({"id": "1", "type": 19, "author": {"id": "1"},
            "message_reference": {"channel_id": "11", "message_id": "500"}}));
        assert_eq!(
            unknown.unwrap().reply,
            Some(Reply::Unknown { id: "500".into() })
        );
    }

    #[test]
    fn shows_what_a_forward_carries() {
        let message = parse(&json!({
            "id": "1300000000000000000",
            "channel_id": "11",
            "type": 0,
            "content": "",
            "author": {"id": "1", "username": "me"},
            "attachments": [],
            "embeds": [],
            "message_reference": {"type": 1, "channel_id": "12", "message_id": "9", "guild_id": "10"},
            "message_snapshots": [{"message": {
                "type": 0,
                "content": "look",
                "flags": 0,
                "attachments": [{"filename": "clip.mp4", "size": 99, "url": "https://cdn/clip.mp4",
                    "content_type": "video/mp4", "proxy_url": "https://media/clip.mp4", "width": 640, "height": 360}],
                "embeds": [],
                "sticker_items": [{"id": "7", "name": "wave", "format_type": 1}],
            }}],
        }))
        .unwrap();
        assert!(message.forwarded && !message.editable);
        assert_eq!(message.content, "look");
        assert_eq!(
            message.attachments[0].video_url.as_deref(),
            Some("https://cdn/clip.mp4")
        );
        assert_eq!(message.attachments[1].shown, Shown::Sticker);

        // A reply's reference has the default type, so it shows its own content.
        let reply = parse(&json!({
            "id": "1", "type": 19, "content": "mine", "author": {"id": "1"},
            "message_reference": {"type": 0, "message_id": "9"},
            "referenced_message": {"id": "9", "author": {"id": "2"}, "content": "theirs"},
        }))
        .unwrap();
        assert!(!reply.forwarded);
        assert_eq!(reply.content, "mine");
    }

    #[test]
    fn tells_who_used_which_command_an_apps_answer_answers() {
        let answer = |kind: u64, extra: Value| {
            let mut value = json!({"id": "900", "type": kind, "channel_id": "11",
                "author": {"id": "5", "username": "app", "bot": true}, "content": "Done"});
            value
                .as_object_mut()
                .unwrap()
                .extend(extra.as_object().unwrap().clone());
            parse(&value).unwrap()
        };
        let alice = json!({"id": "1", "username": "alice", "global_name": "Alice"});
        // A slash command, with its subcommand.
        let slash = answer(
            20,
            json!({"interaction_metadata": {"id": "901", "type": 2,
            "name": "config set", "command_type": 1, "user": alice,
            "authorizing_integration_owners": {"0": "10"}}}),
        );
        let interaction = slash.interaction.unwrap();
        assert_eq!(
            (
                interaction.user_id.as_str(),
                interaction.user.as_str(),
                interaction.name.as_deref(),
                interaction.command_type
            ),
            ("1", "Alice", Some("config set"), Some(CHAT_INPUT))
        );
        assert!(slash.reply.is_none());
        // Only the deprecated object.
        let old = answer(
            20,
            json!({"interaction": {"id": "902", "type": 2, "name": "ping",
            "user": {"id": "1", "username": "alice"}}}),
        );
        let interaction = old.interaction.unwrap();
        assert_eq!(
            (interaction.id.as_str(), interaction.user.as_str()),
            ("902", "alice")
        );
        assert_eq!(interaction.name.as_deref(), Some("ping"));
        // A user command names the person it was used on.
        let user = answer(
            23,
            json!({"interaction_metadata": {"id": "903", "type": 2,
            "name": "High five", "command_type": 2, "user": alice,
            "target_user": {"id": "2", "username": "bob", "global_name": "Bob"}}}),
        );
        let interaction = user.interaction.unwrap();
        assert_eq!(interaction.command_type, Some(USER_COMMAND));
        assert_eq!(
            interaction.target_user,
            Some(("2".to_owned(), "Bob".to_owned()))
        );
        assert!(user.reply.is_none());
        // A message command's answer quotes the message.
        let quote = answer(
            23,
            json!({"interaction_metadata": {"id": "904", "type": 2,
            "name": "Quote", "command_type": 3, "user": alice, "target_message_id": "500"},
            "message_reference": {"message_id": "500", "channel_id": "11"},
            "referenced_message": {"id": "500", "author": {"id": "2", "username": "bob"},
                "content": "Wise words"}}),
        );
        assert_eq!(
            quote.interaction.unwrap().target_message_id.as_deref(),
            Some("500")
        );
        assert!(matches!(quote.reply, Some(Reply::Message { id, .. }) if id == "500"));
        // A button's follow-up quotes the message with the button, by id
        // when Discord doesn't send it.
        let button = |id: &str| {
            answer(
                0,
                json!({"id": id, "interaction_metadata": {"id": "905", "type": 3,
                "user": alice, "interacted_message_id": "600"}}),
            )
        };
        let follow_up = button("900");
        assert!(matches!(&follow_up.reply, Some(Reply::Unknown { id }) if id == "600"));
        assert_eq!(follow_up.interaction.unwrap().name, None);
        // The message the button updated quotes nothing.
        assert!(button("600").reply.is_none());
        // A form's answer names the command that opened the form.
        let form = answer(
            20,
            json!({"interaction_metadata": {"id": "906", "type": 5,
            "user": alice,
            "triggering_interaction_metadata": {"id": "907", "type": 2, "name": "feedback",
                "command_type": 1, "user": alice}}}),
        );
        let interaction = form.interaction.unwrap();
        assert_eq!(
            (interaction.id.as_str(), interaction.name.as_deref()),
            ("906", Some("feedback"))
        );
        // One a button opened quotes the button's message.
        let form = answer(
            0,
            json!({"interaction_metadata": {"id": "908", "type": 5,
            "user": alice,
            "triggering_interaction_metadata": {"id": "909", "type": 3, "user": alice,
                "interacted_message_id": "600"}}}),
        );
        assert_eq!(form.interaction.unwrap().name, None);
        assert!(matches!(&form.reply, Some(Reply::Unknown { id }) if id == "600"));
    }

    #[test]
    fn command_details_parse_modern_metadata_without_a_command_name() {
        let app_command = |wire| Interaction::of(&wire).unwrap();
        let modern = json!({
            "id": "900", "type": 2, "user": {"id": "1", "username": "alice"},
            "original_response_message_id": "80",
        });
        let nameless = app_command(json!({"type": 0, "interaction_metadata": modern}));
        assert_eq!(nameless.name, None);
        assert_eq!(nameless.command_type, Some(CHAT_INPUT));
        assert_eq!(nameless.original_response_message_id.as_deref(), Some("80"));
        let matching = app_command(json!({"type": 20, "interaction_metadata": modern,
            "interaction": {"id": "900", "type": 2, "name": "config set"}
        }));
        assert_eq!(matching.name.as_deref(), Some("config set"));
        let unrelated = app_command(json!({"type": 20, "interaction_metadata": modern,
            "interaction": {"id": "999", "type": 2, "name": "different"}
        }));
        assert_eq!(unrelated.name, None);

        let mut target = modern.clone();
        target["target_user"] = json!({"id": "8"});
        let user = app_command(json!({"type": 23, "interaction_metadata": target}));
        assert_eq!(user.command_type, Some(USER_COMMAND));
        target.as_object_mut().unwrap().remove("target_user");
        target["target_message_id"] = json!("10");
        let message = app_command(json!({"type": 23, "interaction_metadata": target}));
        assert_eq!(message.command_type, Some(MESSAGE_COMMAND));
        let unknown = app_command(json!({"type": 23, "interaction_metadata": modern}));
        assert_eq!(unknown.command_type, None);
        target["command_type"] = json!(MESSAGE_COMMAND);
        let explicit_context = app_command(json!({"type": 20, "interaction_metadata": target}));
        assert_eq!(explicit_context.command_type, Some(MESSAGE_COMMAND));

        let modal = app_command(json!({"type": 20, "interaction_metadata": {
            "id": "901", "type": 5, "user": {"id": "1"},
            "triggering_interaction_metadata": modern,
        }}));
        assert_eq!(modal.id, "901");
        assert_eq!(modal.command_type, Some(CHAT_INPUT));
        assert_eq!(modal.command_interaction_id.as_deref(), Some("900"));
        assert_eq!(modal.original_response_message_id.as_deref(), Some("80"));
        let component = app_command(json!({"type": 20, "interaction_metadata": {
            "id": "901", "type": 5, "user": {"id": "1"},
            "triggering_interaction_metadata": {"id": "902", "type": 3},
        }, "interaction": {"id": "902", "type": 2, "name": "unrelated"}}));
        assert_eq!(component.name, None);
        assert_eq!(component.command_type, None);
    }

    #[test]
    fn command_details_preserve_followup_and_modal_source_identity_without_guessing() {
        let metadata =
            |value: Value| Interaction::of(&json!({"interaction_metadata":value})).unwrap();
        let followup = metadata(
            json!({"id":"900","type":2,"name":"fetch","user":{"id":"1"},"original_response_message_id":"80"}),
        );
        assert_eq!(followup.original_response_message_id.as_deref(), Some("80"));
        assert_eq!(followup.command_interaction_id, None);
        let modal = metadata(
            json!({"id":"901","type":5,"user":{"id":"1"},"original_response_message_id":"81",
            "triggering_interaction_metadata":{"id":"900","type":2,"name":"fetch","original_response_message_id":"80"}}),
        );
        assert_eq!(modal.id, "901");
        assert_eq!(modal.command_interaction_id.as_deref(), Some("900"));
        assert_eq!(modal.original_response_message_id.as_deref(), Some("80"));
        let without_origin = metadata(
            json!({"id":"901","type":5,"user":{"id":"1"},"original_response_message_id":"81",
            "triggering_interaction_metadata":{"id":"900","type":2,"name":"fetch"}}),
        );
        assert_eq!(
            without_origin.original_response_message_id, None,
            "a modal reply's original is not its triggering command's original"
        );
        for invalid in ["0", "18446744073709551616", "../other", ""] {
            let invalid = metadata(
                json!({"id":"900","type":2,"name":"fetch","user":{"id":"1"},"original_response_message_id":invalid}),
            );
            assert_eq!(invalid.original_response_message_id, None);
        }
    }

    #[test]
    fn tells_an_answer_only_this_account_sees_and_one_still_to_come() {
        let answer = |flags: u64| {
            parse(&json!({
                "id": "5", "channel_id": "2", "type": 20, "content": "", "flags": flags,
                "author": {"id": "9", "username": "Status Bot", "bot": true},
                "interaction_metadata": {"id": "7", "type": 2, "user": {"id": "1"}},
            }))
            .unwrap()
        };
        let thinking = answer(EPHEMERAL | LOADING);
        assert!(thinking.ephemeral && thinking.loading);
        let answered = answer(EPHEMERAL);
        assert!(answered.ephemeral && !answered.loading);
        let public = answer(LOADING);
        assert!(!public.ephemeral && public.loading);
        let plain = answer(0);
        assert!(!plain.ephemeral && !plain.loading);
    }

    #[test]
    fn reads_a_voice_messages_length_and_waveform() {
        let voice = |flags: u64, recording: Value| {
            parse(&json!({
                "id": "1", "type": 0, "content": "", "author": {"id": "2"}, "flags": flags,
                "attachments": [recording],
            }))
            .unwrap()
            .voice
        };
        let recording = json!({
            "filename": "voice-message.ogg", "size": 36000, "url": "https://cdn/v.ogg",
            "content_type": "audio/ogg", "duration_secs": 5.48, "waveform": "AAh/gP8=",
        });
        assert_eq!(
            voice(1 << 13, recording.clone()),
            Some(VoiceMessage {
                duration_ms: 5480,
                waveform: [0, 8, 127, 128, 255].into(),
            })
        );
        // Without the flag, an Ogg file is a file.
        assert_eq!(voice(0, recording), None);
        // A waveform that isn't base64 shows flat; one too long is cut.
        let long = base64::Engine::encode(&base64::engine::general_purpose::STANDARD, [9; 300]);
        let odd = voice(
            1 << 13,
            json!({"filename": "a.ogg", "url": "https://cdn/a.ogg", "waveform": "!", "duration_secs": 1}),
        )
        .unwrap();
        assert_eq!((odd.duration_ms, odd.waveform.len()), (1000, 0));
        let cut = voice(
            1 << 13,
            json!({"filename": "a.ogg", "url": "https://cdn/a.ogg", "waveform": long}),
        )
        .unwrap();
        assert_eq!((cut.duration_ms, cut.waveform.len()), (0, 256));
    }

    #[test]
    fn reads_only_the_listen_message_activity_type() {
        let parse_activity = |activity: Value| {
            parse(&json!({
                "id": "123", "type": 0, "author": {"id": "456"},
                "activity": activity
            }))
            .unwrap()
        };
        let invite = parse_activity(json!({"type": 3, "party_id": "unused"}));
        assert_eq!(invite.listen_invite, Some(true));
        assert!(!invite.forwardable);
        assert_eq!(
            parse_activity(json!({"type": 1})).listen_invite,
            Some(false)
        );
        assert_eq!(parse_activity(Value::Null).listen_invite, Some(false));
        assert_eq!(
            parse(&json!({"id": "123", "author": {"id": "456"}}))
                .unwrap()
                .listen_invite,
            None,
        );
    }

    #[test]
    fn forwards_what_discord_forwards() {
        let forwardable = |extra: Value| {
            let mut value = json!({"id": "1", "type": 0, "content": "hi", "author": {"id": "1"}});
            value
                .as_object_mut()
                .unwrap()
                .extend(extra.as_object().unwrap().clone());
            parse(&value).unwrap().forwardable
        };
        assert!(forwardable(json!({})));
        assert!(forwardable(json!({"type": 19, "referenced_message": null})));
        // A forward, a voice message and an @silent one forward again.
        assert!(forwardable(
            json!({"flags": (1 << 14) | (1 << 13) | (1 << 12)})
        ));
        // An ephemeral one doesn't, nor a poll, nor a notice.
        assert!(!forwardable(json!({"flags": 1 << 6})));
        assert!(!forwardable(json!({"poll": {"question": {"text": "?"}}})));
        assert!(!forwardable(json!({"type": 6})));
    }

    #[test]
    fn reads_a_poll_and_counts_votes_on_it() {
        let mut message = parse(&json!({
            "id": "1", "type": 0, "content": "", "author": {"id": "2"},
            "poll": {
                "question": {"text": "Lunch?"},
                "answers": [
                    {"answer_id": 1, "poll_media": {"text": "Pizza", "emoji": {"id": null, "name": "🍕"}}},
                    {"answer_id": 2, "poll_media": {"text": "Soup", "emoji": {"id": "77", "name": ""}}},
                    {"answer_id": 3, "poll_media": {"text": "Salad"}},
                ],
                "expiry": "2026-10-20T12:00:00.000000+00:00",
                "allow_multiselect": true,
                "layout_type": 1,
                "results": {"is_finalized": false, "answer_counts": [
                    {"id": 1, "count": 3, "me_voted": true},
                    {"id": 3, "count": 1, "me_voted": false},
                ]},
            },
        }))
        .unwrap();
        assert!(!message.editable, "a poll stays as it was sent");
        let poll = message.poll.as_ref().unwrap();
        assert_eq!(poll.question, "Lunch?");
        assert!(poll.multiselect && poll.counted && !poll.finalized);
        let expiry = iso_ms("2026-10-20T12:00:00Z").unwrap();
        assert_eq!(poll.expiry, Some(expiry));
        assert!(!poll.closed(expiry - 1));
        assert!(poll.closed(expiry));
        let answers: Vec<_> = poll
            .answers
            .iter()
            .map(|answer| {
                (
                    answer.id,
                    answer.text.as_str(),
                    answer.emoji.clone(),
                    answer.votes,
                    answer.me,
                )
            })
            .collect();
        assert_eq!(
            answers,
            [
                (1, "Pizza", Some(("🍕".to_owned(), None)), 3, true),
                (
                    2,
                    "Soup",
                    Some((":77:".to_owned(), Some("77".to_owned()))),
                    0,
                    false
                ),
                (3, "Salad", None, 1, false),
            ]
        );
        message.vote(2, false, true);
        message.vote(1, true, false);
        message.vote(9, false, true);
        let poll = message.poll.as_ref().unwrap();
        assert_eq!((poll.answers[0].votes, poll.answers[0].me), (2, false));
        assert_eq!(poll.answers[1].votes, 1);
    }

    #[test]
    fn tells_of_a_closed_poll_and_its_winner() {
        let notice = |fields: Value| {
            parse(&json!({
                "id": "5", "type": 46, "content": "", "author": {"id": "2"},
                "message_reference": {"message_id": "1"},
                "embeds": [{"type": "poll_result", "fields": fields}],
            }))
            .unwrap()
            .system
            .unwrap()
        };
        let field =
            |name: &str, value: &str| json!({"name": name, "value": value, "inline": false});
        assert_eq!(
            notice(json!([
                field("poll_question_text", "Lunch?"),
                field("victor_answer_votes", "3"),
                field("total_votes", "4"),
                field("victor_answer_id", "1"),
                field("victor_answer_text", "Pizza"),
                field("victor_answer_emoji_name", "🍕"),
            ])),
            "'s poll \u{201c}Lunch?\u{201d} has closed. Winning answer: 🍕 Pizza, 3 votes (75%)."
        );
        assert_eq!(
            notice(json!([
                field("poll_question_text", "Lunch?"),
                field("total_votes", "0")
            ])),
            "'s poll \u{201c}Lunch?\u{201d} has closed. There was no winner."
        );
    }

    #[test]
    fn learns_the_author_a_reply_quotes() {
        let mut names = Names::default();
        names.learn_message(
            None,
            &json!({
                "id": "1", "type": 19, "author": {"id": "1", "username": "me"},
                "referenced_message": {
                    "id": "9", "author": {"id": "2", "username": "ann", "avatar": "abc"},
                    "content": "hello",
                },
            }),
        );
        assert!(
            names
                .avatar(None, "2")
                .ends_with("/avatars/2/abc.png?size=128")
        );
    }

    #[test]
    fn prefers_server_avatars() {
        let mut names = Names::default();
        names.learn_user(&json!({"id": "2", "username": "ann", "avatar": "abc"}));
        names.learn_member("10", &json!({"user_id": "2", "avatar": "def"}));
        assert!(
            names
                .avatar(None, "2")
                .ends_with("/avatars/2/abc.png?size=128")
        );
        assert!(
            names
                .avatar(Some("10"), "2")
                .ends_with("/guilds/10/users/2/avatars/def.png?size=128")
        );
        assert!(
            names
                .avatar(Some("11"), "2")
                .ends_with("/avatars/2/abc.png?size=128")
        );
        // A mention without the avatar keeps it; null removes it.
        names.learn_user(&json!({"id": "2", "username": "ann"}));
        assert!(names.avatar(None, "2").contains("/avatars/2/"));
        names.learn_user(&json!({"id": "2", "username": "ann", "avatar": null}));
        assert!(names.avatar(None, "2").contains("/embed/avatars/"));
    }

    #[test]
    fn reads_iso_times() {
        assert_eq!(iso_ms("2026-10-06T14:05:00+00:00"), Some(1_791_295_500_000));
        assert_eq!(iso_ms("2026-10-06T14:05:00.25Z"), Some(1_791_295_500_250));
        assert_eq!(
            iso_ms("2026-10-06T16:05:00.000000+02:00"),
            Some(1_791_295_500_000)
        );
        assert_eq!(iso_ms("soon"), None);
        assert_eq!(
            snowflake_ms(&snowflake_at(1_791_295_500_000).to_string()),
            1_791_295_500_000
        );
    }

    #[test]
    fn renders_mentions_emoji_and_times() {
        let mut names = Names::default();
        names.learn_message(
            Some("10"),
            &json!({
                "author": {"id": "1", "username": "me"},
                "mentions": [{"id": "2", "username": "ann", "global_name": "Ann", "member": {"nick": "Annie"}}],
            }),
        );
        let server = Server {
            id: "10".into(),
            role_names: HashMap::from([("30".into(), "Mods".into())]).into(),
            text_channels: vec![ready::Channel {
                id: "11".into(),
                name: "general".into(),
                ..Default::default()
            }],
            ..Default::default()
        };
        assert_eq!(
            names.render(
                Some(&server),
                "<@2> <@!1> <@&30> in <#11> <:pog:5> <a:dance:6> <t:1791295500:t> <@9> a < b"
            ),
            format!(
                "@Annie @me @Mods in #general :pog: :dance: {} @Discord user a < b",
                local(1_791_295_500).format("%H:%M")
            )
        );
        assert_eq!(
            custom_emoji("<:pog:5> <a:dance:6> <:pog:5> <@2> <:bad:x> `<:x:>`"),
            [
                CustomEmoji {
                    name: "pog".into(),
                    id: "5".into(),
                    animated: false
                },
                CustomEmoji {
                    name: "dance".into(),
                    id: "6".into(),
                    animated: true
                },
            ]
        );
        assert!(names.knows_member("10", "2") && !names.knows_member("10", "1"));
        let mention = |text: &str, target, at: &[usize]| Mention {
            text: text.into(),
            target,
            at: at.to_vec(),
        };
        assert_eq!(
            names.render_mentions(Some(&server), "<@2> and <@!2>, <@&30>, <#11> <@x"),
            (
                "@Annie and @Annie, @Mods, #general <@x".to_owned(),
                vec![
                    mention("@Annie", MentionTarget::User("2".into()), &[0, 11]),
                    mention("@Mods", MentionTarget::Role("30".into()), &[19]),
                    mention("#general", MentionTarget::Channel("11".into()), &[26])
                ]
            )
        );
        // A channel the server doesn't list isn't a mention of anything.
        assert_eq!(
            names.render_mentions(Some(&server), "<#99>"),
            ("#channel".to_owned(), vec![])
        );
        assert_eq!(
            names.render_mentions(None, "<#11>"),
            ("#channel".to_owned(), vec![])
        );
        assert_eq!(
            names.render_mentions(
                Some(&server),
                "@here <@2>@everyone x@everyones \\@here @heresy"
            ),
            (
                "@here @Annie@everyone x@everyones \\@here @heresy".to_owned(),
                vec![
                    mention("@here", MentionTarget::Everyone, &[0, 41]),
                    mention("@Annie", MentionTarget::User("2".into()), &[6]),
                    mention("@everyone", MentionTarget::Everyone, &[12, 23]),
                ]
            )
        );
        names.learn_member("10", &json!({"user_id": "2", "roles": ["30"]}));
        names.learn_member("10", &json!({"user_id": "3", "roles": ["31"]}));
        assert_eq!(names.members_with_role("10", "30"), ["2"]);
    }

    #[test]
    fn the_version_changes_only_with_what_names_show() {
        let mut names = Names::default();
        let ann = json!({"id": "2", "username": "ann", "avatar": "abc"});
        names.learn_user(&ann);
        let learned = names.version();
        assert_eq!(learned, 0, "someone new changes nothing shown");
        names.learn_user(&ann);
        names.learn_member("10", &json!({"user": ann, "nick": null, "roles": []}));
        let member = names.version();
        assert!(
            member > learned,
            "a server profile, though without a nickname"
        );
        names.learn_member("10", &json!({"user": ann, "nick": null, "roles": []}));
        assert_eq!(names.version(), member, "the same again");
        names.learn_member("10", &json!({"user_id": "2", "nick": "Annie", "roles": []}));
        assert!(names.version() > member, "a nickname");
    }

    #[test]
    fn learns_decorations_nameplates_and_styles_and_keeps_them_over_partial_users() {
        let mut names = Names::default();
        let ann = json!({
            "id": "2", "username": "ann",
            "avatar_decoration_data": {"asset": "a_x", "sku_id": "77", "expires_at": null},
            "collectibles": {"nameplate": {"sku_id": "88", "asset": "nameplates/x/",
                                           "label": "X", "palette": "teal"}},
            "display_name_styles": {"font_id": 3, "effect_id": 2, "colors": [16711680, 255]},
        });
        names.learn_user(&ann);
        assert!(
            names
                .decoration(None, "2")
                .unwrap()
                .ends_with("/collectibles-shop/77/static")
        );
        let plate = names.nameplate(None, "2").unwrap();
        assert_eq!(plate.colors, Some([0x086460, 0x7deed7]));
        assert!(plate.picture.ends_with("/collectibles-shop/88/static"));
        let style = names.style(None, "2").unwrap();
        assert_eq!((style.font, style.effect), (3, 2));
        assert_eq!(style.colors(), [0xff0000, 0x0000ff]);
        assert_eq!(names.decoration(None, "3"), None);
        // A partial user, such as a mention in a message, says nothing.
        names.learn_user(&json!({"id": "2", "username": "ann"}));
        assert!(names.decoration(None, "2").is_some() && names.nameplate(None, "2").is_some());
        assert!(names.style(None, "2").is_some());
        // They survive being saved and restored.
        let saved = serde_json::to_string(&names.saving()).unwrap();
        let restored = Names::restore(serde_json::from_str(&saved).unwrap());
        assert_eq!(restored.decoration(None, "2"), names.decoration(None, "2"));
        assert_eq!(restored.nameplate(None, "2"), names.nameplate(None, "2"));
        assert_eq!(restored.style(None, "2"), names.style(None, "2"));
        // Null takes them off; so does no nameplate among the collectibles.
        names.learn_user(
            &json!({"id": "2", "username": "ann", "avatar_decoration_data": null,
            "collectibles": {}, "display_name_styles": null}),
        );
        assert_eq!(names.decoration(None, "2"), None);
        assert_eq!(names.nameplate(None, "2"), None);
        assert_eq!(names.style(None, "2"), None);
    }

    #[test]
    fn what_a_member_equips_for_a_server_wins_there_alone() {
        let mut names = Names::default();
        names.learn_user(&json!({"id": "2", "username": "ann",
            "avatar_decoration_data": {"asset": "a", "sku_id": "77"},
            "display_name_styles": {"font_id": 11, "effect_id": 1, "colors": [1]}}));
        names.learn_member(
            "10",
            &json!({"user": {"id": "2", "username": "ann"}, "roles": [],
            "avatar_decoration_data": {"asset": "b", "sku_id": "78"},
            "collectibles": {"nameplate": {"sku_id": "90", "palette": "sky"}},
            "display_name_styles": {"font_id": 4, "effect_id": 3, "colors": [2]}}),
        );
        let ends = |url: Option<Arc<str>>, sku: &str| {
            url.is_some_and(|url| url.ends_with(&format!("/collectibles-shop/{sku}/static")))
        };
        assert!(
            ends(names.decoration(Some("10"), "2"), "78"),
            "the server's"
        );
        assert!(
            ends(names.decoration(Some("11"), "2"), "77"),
            "elsewhere, their own"
        );
        assert!(ends(names.decoration(None, "2"), "77"));
        assert_eq!(
            names.nameplate(Some("10"), "2").unwrap().colors,
            Some([0x0080b7, 0x56ccff])
        );
        assert_eq!(names.nameplate(Some("11"), "2"), None);
        assert_eq!(names.style(Some("10"), "2").unwrap().font, 4);
        assert_eq!(names.style(None, "2").unwrap().font, 11);
        // A member object that leaves them out changes nothing; null takes
        // the server's off, so their own show again.
        names.learn_member("10", &json!({"user_id": "2", "roles": []}));
        assert!(ends(names.decoration(Some("10"), "2"), "78"));
        let saved = serde_json::to_string(&names.saving()).unwrap();
        let restored = Names::restore(serde_json::from_str(&saved).unwrap());
        assert!(ends(restored.decoration(Some("10"), "2"), "78"));
        assert_eq!(
            restored.style(Some("10"), "2"),
            names.style(Some("10"), "2")
        );
        names.learn_member(
            "10",
            &json!({"user_id": "2", "roles": [],
            "avatar_decoration_data": null, "display_name_styles": null}),
        );
        assert!(ends(names.decoration(Some("10"), "2"), "77"));
        assert_eq!(names.style(Some("10"), "2").unwrap().font, 11);
        names.forget_member("10", "2");
        assert_eq!(names.nameplate(Some("10"), "2"), None);
    }

    #[test]
    fn forgets_those_learned_longest_ago_once_there_are_too_many() {
        let mut names = Names::default();
        let person = |n: usize| json!({"id": n.to_string(), "username": format!("p{n}")});
        names.learn_member(
            "10",
            &json!({"user": person(0), "nick": "Zero", "roles": []}),
        );
        names.learn_user(&person(1));
        for n in 2..=KEPT_PEOPLE {
            names.learn_user(&person(n));
            if n == KEPT_PEOPLE / 2 {
                // Shown, as in a member list, so kept.
                assert_eq!(names.name("10", "0"), Some("Zero"));
            }
        }
        let version = names.version();
        names.learn_user(&person(KEPT_PEOPLE + 1));
        assert_eq!(names.version(), version, "what was shown with them stays");
        assert!(names.seen.len() <= KEPT_PEOPLE * 3 / 4 + 1);
        assert_eq!(names.user_name("1"), None, "learned first");
        assert_eq!(names.name("10", "0"), Some("Zero"));
        assert!(names.knows_member("10", "0"));
        assert!(names.user_name(&KEPT_PEOPLE.to_string()).is_some());
        let saved = serde_json::to_vec(&names.saving()).unwrap();
        let restored = Names::restore(serde_json::from_slice(&saved).unwrap());
        assert_eq!(restored.users.len(), names.users.len());
    }

    #[test]
    fn knows_bots_from_any_full_user_object_and_keeps_them() {
        let mut names = Names::default();
        names.learn_user(&json!({"id": "2", "username": "helper", "bot": true}));
        names.learn_user(&json!({"id": "3", "username": "ann"}));
        // A partial user object says nothing of it.
        names.learn_member("10", &json!({"user": {"id": "2"}, "roles": []}));
        assert!(names.is_bot("2"));
        assert!(!names.is_bot("3"));
        let saved = serde_json::to_vec(&names.saving()).unwrap();
        let restored = Names::restore(serde_json::from_slice(&saved).unwrap());
        assert!(restored.is_bot("2"));
        names.learn_user(&json!({"id": "2", "username": "helper", "bot": false}));
        assert!(!names.is_bot("2"));
    }

    #[test]
    fn learns_server_tags_and_keeps_them_across_partial_objects() {
        let mut names = Names::default();
        let wears = |enabled: bool| {
            json!({"id": "2", "username": "ann", "primary_guild": {
                "identity_guild_id": "10", "identity_enabled": enabled,
                "tag": "CODE", "badge": "abc123"}})
        };
        names.learn_user(&wears(true));
        let tag = names.server_tag("2").unwrap();
        assert_eq!(&*tag.text, "CODE");
        assert!(
            tag.badge
                .as_deref()
                .unwrap()
                .ends_with("/clan-badges/10/abc123.png?size=32")
        );
        assert_eq!(names.server_tag("3"), None);

        // A partial user object, as a mention's, says nothing of it.
        names.learn_user(&json!({"id": "2"}));
        assert!(names.server_tag("2").is_some());

        // It survives a restart.
        let saved = serde_json::to_vec(&names.saving()).unwrap();
        let restored = Names::restore(serde_json::from_slice(&saved).unwrap());
        assert_eq!(restored.server_tag("2"), names.server_tag("2"));

        // Leaving it off, or taking it away, removes it, and redraws them.
        let version = names.version();
        names.learn_user(&wears(false));
        assert_eq!(names.server_tag("2"), None);
        assert!(names.version() > version);
        names.learn_user(&wears(true));
        names.learn_user(&json!({"id": "2", "primary_guild": null}));
        assert_eq!(names.server_tag("2"), None);

        // Nor does one who hasn't taken up their server's changed tag wear it.
        names.learn_user(&wears(true));
        names.learn_user(&json!({"id": "2", "primary_guild": {
            "identity_guild_id": "10", "identity_enabled": null, "tag": "OLD"}}));
        assert_eq!(names.server_tag("2"), None);

        // A server without a badge, or one with no text, shows as it can.
        names.learn_user(&json!({"id": "2", "primary_guild": {
            "identity_guild_id": "10", "identity_enabled": true, "tag": "AB", "badge": null}}));
        assert_eq!(names.server_tag("2").unwrap().badge, None);
        names.learn_user(&json!({"id": "2", "primary_guild": {
            "identity_guild_id": "10", "identity_enabled": true, "tag": " "}}));
        assert_eq!(names.server_tag("2"), None);
    }

    #[test]
    fn learns_member_join_time_only_for_the_same_guild() {
        let mut names = Names::default();
        let joined = "2026-11-09T05:00:00Z";
        names.learn_message(
            Some("10"),
            &json!({"author": {"id": "2", "username": "ann"}, "member": {"joined_at": joined}}),
        );
        assert_eq!(names.joined_at("10", "2"), iso_ms(joined));
        assert_eq!(names.joined_at("11", "2"), None);
        names.learn_member("10", &json!({"user_id": "2", "roles": []}));
        names.learn_member("10", &json!({"user_id": "2", "joined_at": null}));
        names.learn_member(
            "10",
            &json!({"user_id": "2", "joined_at": "2025-11-09T05:00:00Z"}),
        );
        assert_eq!(names.joined_at("10", "2"), iso_ms(joined));
        names.forget_member("10", "2");
        assert_eq!(names.joined_at("10", "2"), None);
    }

    #[test]
    fn learns_roles_for_name_colours() {
        let mut names = Names::default();
        names.learn_member("10", &json!({"user_id": "2", "roles": ["30", "31"]}));
        let server = Server {
            id: "10".into(),
            role_colors: HashMap::from([
                ("30".into(), (1, 0x3498db)),
                ("31".into(), (2, 0xe91e63)),
            ])
            .into(),
            ..Default::default()
        };
        assert_eq!(
            server.color(names.roles("10", "2")),
            Some(0xe91e63),
            "the highest role's"
        );
        names.learn_member("10", &json!({"user_id": "2", "nick": "Annie"}));
        assert_eq!(
            names.roles("10", "2"),
            ["30", "31"],
            "kept when a member object leaves them out"
        );
        assert!(names.roles("11", "2").is_empty());
    }

    #[test]
    fn mentions_call_on_this_account_as_discord_highlights_them() {
        let me = "1";
        let message = |extra: Value| {
            let mut value = json!({"id": "500", "channel_id": "11", "type": 0,
                "author": {"id": "2", "username": "bob"}, "content": "hi"});
            value
                .as_object_mut()
                .unwrap()
                .extend(extra.as_object().unwrap().clone());
            parse(&value).unwrap()
        };
        let server = ServerMarks {
            roles: vec!["30".into()],
            ..Default::default()
        };
        let pings = |extra: Value| message(extra).mentions_me(me, Some(&server));
        assert!(!pings(json!({})));
        assert!(pings(
            json!({"mentions": [{"id": "1", "username": "alice"}]})
        ));
        assert!(!pings(
            json!({"mentions": [{"id": "3", "username": "carol"}]})
        ));
        assert!(pings(json!({"mention_roles": ["30"]})), "Alice's role");
        assert!(!pings(json!({"mention_roles": ["31"]})));
        assert!(pings(json!({"mention_everyone": true})));
        let reply = |author: &str| {
            json!({"type": 19, "referenced_message": {"id": "400",
                "author": {"id": author, "username": "someone"}, "content": "plan"}})
        };
        assert!(pings(reply("1")), "a reply to Alice, pinging her or not");
        assert!(!pings(reply("3")));
        // A reply to her names her only when its text does: a ping lists
        // her in `mentions` all the same.
        let names = |extra: Value| message(extra).names_me(me, Some(&server));
        let ping = |content: &str| {
            let mut value = reply("1");
            value["mentions"] = json!([{"id": "1", "username": "alice"}]);
            value["content"] = json!(content);
            value
        };
        assert!(!names(reply("1")));
        assert!(!names(ping("sure")), "a ping reply");
        assert!(names(ping("sure <@1>")));
        assert!(names(ping("sure <@!1>")));
        assert!(names(
            json!({"mentions": [{"id": "1", "username": "alice"}]})
        ));
        assert!(message(ping("sure")).replies_to(me));
        assert!(!message(reply("3")).replies_to(me));

        // Her settings can quiet @everyone and roles, but not her name.
        let quiet = ServerMarks {
            suppress_everyone: true,
            suppress_roles: true,
            ..server.clone()
        };
        let quieted = |extra: Value| message(extra).mentions_me(me, Some(&quiet));
        assert!(!quieted(json!({"mention_everyone": true})));
        assert!(!quieted(json!({"mention_roles": ["30"]})));
        assert!(quieted(
            json!({"mentions": [{"id": "1", "username": "alice"}]})
        ));
        // Her own messages don't call on her.
        let own = message(json!({"author": {"id": "1", "username": "alice"},
            "mention_everyone": true}));
        assert!(!own.mentions_me(me, Some(&server)));
        // A DM has no server: @everyone means nothing there.
        assert!(!message(json!({"mention_everyone": true})).mentions_me(me, None));
    }
    #[test]
    fn discords_own_account_is_official_until_a_user_says_otherwise() {
        assert!(is_official(&json!({"id": "1", "system": true})));
        assert!(is_official(&json!({"id": "1", "public_flags": 1 << 12})));
        assert!(!is_official(&json!({"id": "1", "public_flags": 64})));
        let mut names = Names::default();
        names.learn_user(&json!({"id": "1", "username": "Discord", "system": true}));
        assert!(names.is_official("1"));
        // A partial user object says nothing of it.
        names.learn_user(&json!({"id": "1"}));
        assert!(names.is_official("1"));
        names.learn_user(&json!({"id": "1", "public_flags": 0}));
        assert!(!names.is_official("1"));
        assert!(!names.is_official("2"));
    }

    #[test]
    fn timestamps_in_plain_text_become_times() {
        let at = 1_791_295_500;
        let time = timestamp(at, Some("t"));
        assert_eq!(
            render_timestamps(&format!("My 12AM is your <t:{at}:t>!")),
            format!("My 12AM is your {time}!")
        );
        assert_eq!(render_timestamps("<t:nope> and <t:1"), "<t:nope> and <t:1");
        // As Discord's client leaves them: another style, a time past 17
        // digits, or one it can't place.
        for tag in [
            "<t:1:x>",
            "<t:1:R:x>",
            "<t:123456789012345678>",
            "<t:99999999999999999>",
            "<t:+1>",
        ] {
            assert_eq!(render_timestamps(tag), tag);
        }
        assert_ne!(render_timestamps("<t:-86400:d>"), "<t:-86400:d>");
    }

    #[test]
    fn timestamps_show_their_style() {
        let at = 1_791_295_500;
        let local = local(at);
        let day_first = TimestampFormat::DEFAULT;
        let month_first = TimestampFormat {
            twelve_hour: true,
            short_date: "%m/%d/%Y",
            long_date: "%B %-d, %Y",
        };
        let shown = |style, format| timestamp_at(at, style, at, format);
        let written = |pattern: &str| local.format(pattern).to_string();
        assert_eq!(shown(Some("t"), day_first), written("%H:%M"));
        assert_eq!(shown(Some("T"), day_first), written("%H:%M:%S"));
        assert_eq!(shown(Some("d"), day_first), written("%d/%m/%Y"));
        assert_eq!(shown(Some("D"), day_first), written("%-d %B %Y"));
        assert_eq!(shown(Some("f"), day_first), written("%-d %B %Y %H:%M"));
        assert_eq!(shown(None, day_first), shown(Some("f"), day_first));
        assert_eq!(shown(Some("F"), day_first), written("%A, %-d %B %Y %H:%M"));
        assert_eq!(shown(Some("s"), day_first), written("%d/%m/%Y %H:%M"));
        assert_eq!(shown(Some("S"), day_first), written("%d/%m/%Y %H:%M:%S"));
        // As en-US writes them: month first, on a 12-hour clock.
        assert_eq!(shown(Some("t"), month_first), written("%-I:%M %p"));
        assert_eq!(shown(Some("T"), month_first), written("%-I:%M:%S %p"));
        assert_eq!(shown(Some("d"), month_first), written("%m/%d/%Y"));
        assert_eq!(shown(Some("D"), month_first), written("%B %-d, %Y"));
        assert_eq!(
            shown(Some("f"), month_first),
            written("%B %-d, %Y %-I:%M %p")
        );
        assert_eq!(
            shown(Some("F"), month_first),
            written("%A, %B %-d, %Y %-I:%M %p")
        );
        assert_eq!(shown(Some("s"), month_first), written("%m/%d/%Y %-I:%M %p"));
    }

    #[test]
    fn relative_timestamps_use_discords_thresholds() {
        let at = 1_791_295_500;
        let ago =
            |seconds: i64| timestamp_at(at, Some("R"), at + seconds, TimestampFormat::DEFAULT);
        let (minute, hour, day) = (60, 3600, 86_400);
        assert_eq!(ago(10), "a few seconds ago");
        assert_eq!(ago(55), "a few seconds ago", "under a minute");
        assert_eq!(ago(-60), "in a minute");
        assert_eq!(ago(89), "a minute ago");
        assert_eq!(ago(5 * minute), "5 minutes ago");
        assert_eq!(ago(50 * minute), "50 minutes ago", "minutes count to 59");
        assert_eq!(ago(59 * minute), "59 minutes ago");
        assert_eq!(ago(60 * minute), "an hour ago");
        assert_eq!(ago(-3 * hour), "in 3 hours");
        assert_eq!(ago(21 * hour), "21 hours ago");
        assert_eq!(ago(22 * hour), "a day ago");
        assert_eq!(ago(10 * day), "10 days ago");
        assert_eq!(ago(25 * day), "25 days ago");
        assert_eq!(ago(26 * day), "a month ago");
        assert_eq!(ago(-90 * day), "in 3 months");
        assert_eq!(ago(320 * day), "a year ago");
        assert_eq!(ago(3 * 365 * day), "3 years ago");
    }
}
