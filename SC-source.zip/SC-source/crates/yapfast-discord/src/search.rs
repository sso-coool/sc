//! A search of messages as Discord's search box takes it: words, and
//! filters such as `from:bob`, `in:general` and `has:image`, which become
//! the query string of `GET /guilds/{id}/messages/search` or
//! `GET /channels/{id}/messages/search`.

use chrono::{Local, NaiveDate, TimeZone};

/// A selected Discord identity, or a name to resolve in the search scope.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Target {
    Id(u64),
    Name(String),
}

/// Discord's search result ordering. Relevance ignores sort direction.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Sort {
    Newest,
    Oldest,
    Relevance,
}

/// What a search's text asks for before Discord resolves any legacy names.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Query {
    /// The words to find, without the filters.
    pub content: String,
    /// `from:`, who wrote it.
    pub from: Vec<Target>,
    /// `mentions:`, whom it mentions.
    pub mentions: Vec<Target>,
    /// `in:`, the server's channels it's in, without their `#`.
    pub channels: Vec<Target>,
    /// `has:`, what it carries, as Discord's `has` names it.
    pub has: Vec<String>,
    /// `author:`, including Discord's documented exclusions.
    pub author_types: Vec<&'static str>,
    pub sort: Option<Sort>,
    /// `after:` and `before:`, or `during:`: the snowflakes it falls
    /// between, as `min_id` and `max_id`.
    pub min_id: Option<u64>,
    pub max_id: Option<u64>,
    /// `pinned:true` or `pinned:false`.
    pub pinned: Option<bool>,
}

/// What `has:` takes, as Discord's search box offers it, and the name its
/// API gives each: a forwarded message is a snapshot.
const HAS: [(&str, &str); 9] = [
    ("link", "link"),
    ("embed", "embed"),
    ("poll", "poll"),
    ("file", "file"),
    ("video", "video"),
    ("image", "image"),
    ("sound", "sound"),
    ("sticker", "sticker"),
    ("forward", "snapshot"),
];

/// When Discord's snowflakes start: 2015 began, in Unix milliseconds.
const DISCORD_EPOCH: u64 = 1_420_070_400_000;

const AUTHOR_TYPES: [&str; 6] = ["user", "bot", "webhook", "-user", "-bot", "-webhook"];

/// Discord paginates at most 10,000 results, in pages of 25.
pub const MAX_OFFSET: u32 = 9975;

impl Query {
    /// Reads a search's text: filters where a word starts with one, a
    /// value in quotes when it has spaces, and the rest as the words to
    /// find. A filter Discord doesn't know stays a word, as `http://` does.
    pub fn parse(text: &str) -> Result<Self, String> {
        let mut query = Self::default();
        let mut words = Vec::new();
        for token in tokens(text) {
            let Some((key, value)) = token.split_once(':') else {
                words.push(token);
                continue;
            };
            let value = value.trim_matches('"');
            if value.is_empty() {
                words.push(token);
                continue;
            }
            match key.to_lowercase().as_str() {
                "from" => push_unique(&mut query.from, target(value, '@')?),
                "mentions" => push_unique(&mut query.mentions, target(value, '@')?),
                "in" => push_unique(&mut query.channels, target(value, '#')?),
                "has" => {
                    let kind = value.strip_prefix('-').unwrap_or(value);
                    let has = HAS
                        .iter()
                        .find_map(|(name, api)| {
                            (name.eq_ignore_ascii_case(kind) || api.eq_ignore_ascii_case(kind))
                                .then_some(*api)
                        })
                        .ok_or_else(|| {
                            format!("has: takes {}.", HAS.map(|(name, _)| name).join(", "))
                        })?;
                    let has = if value.starts_with('-') {
                        format!("-{has}")
                    } else {
                        has.into()
                    };
                    push_unique(&mut query.has, has);
                }
                "author" | "author-type" | "author_type" => {
                    if let Some(author) = AUTHOR_TYPES
                        .iter()
                        .find(|author| author.eq_ignore_ascii_case(value))
                    {
                        push_unique(&mut query.author_types, *author);
                    } else {
                        words.push(token);
                    }
                }
                "sort" => {
                    let sort = match value.to_ascii_lowercase().as_str() {
                        "newest" => Sort::Newest,
                        "oldest" => Sort::Oldest,
                        "relevance" | "most-relevant" => Sort::Relevance,
                        _ => {
                            words.push(token);
                            continue;
                        }
                    };
                    query.sort = Some(sort);
                }
                "pinned" => {
                    query.pinned = Some(match value.to_lowercase().as_str() {
                        "true" | "yes" => true,
                        "false" | "no" => false,
                        _ => return Err("pinned: takes true or false.".into()),
                    })
                }
                day @ ("before" | "after" | "during") => {
                    let (start, end) = day_span(value)?;
                    if day != "before" {
                        let min = if day == "after" { end } else { start };
                        query.min_id = Some(query.min_id.map_or(min, |old| old.max(min)));
                    }
                    if day != "after" {
                        let max = if day == "before" { start } else { end };
                        query.max_id = Some(query.max_id.map_or(max, |old| old.min(max)));
                    }
                }
                _ => words.push(token),
            }
        }
        query.content = words.join(" ");
        if query
            .min_id
            .zip(query.max_id)
            .is_some_and(|(min, max)| min >= max)
        {
            return Err("The selected date filters don't overlap.".into());
        }
        if query.content.chars().count() > 1024 {
            return Err("Search text can have up to 1,024 characters.".into());
        }
        if query.from.len() > 100 || query.mentions.len() > 100 || query.channels.len() > 500 {
            return Err("Select up to 100 authors, 100 mentioned users or 500 channels.".into());
        }
        Ok(query)
    }

    /// Whether it asks for nothing at all.
    pub fn is_empty(&self) -> bool {
        self.content.is_empty()
            && self.from.is_empty()
            && self.mentions.is_empty()
            && self.channels.is_empty()
            && self.has.is_empty()
            && self.author_types.is_empty()
            && self.min_id.is_none()
            && self.max_id.is_none()
            && self.pinned.is_none()
    }

    /// The query string for Discord, without the people and channels,
    /// which the service adds by id.
    pub fn params(&self) -> Vec<(&'static str, String)> {
        let mut params = Vec::new();
        if !self.content.is_empty() {
            params.push(("content", self.content.clone()));
        }
        params.extend(self.has.iter().cloned().map(|has| ("has", has)));
        params.extend(
            self.author_types
                .iter()
                .map(|author| ("author_type", (*author).to_owned())),
        );
        params.extend(self.min_id.map(|id| ("min_id", id.to_string())));
        params.extend(self.max_id.map(|id| ("max_id", id.to_string())));
        params.extend(self.pinned.map(|pinned| ("pinned", pinned.to_string())));
        match self.sort {
            Some(Sort::Newest) => params.extend([
                ("sort_by", "timestamp".into()),
                ("sort_order", "desc".into()),
            ]),
            Some(Sort::Oldest) => params.extend([
                ("sort_by", "timestamp".into()),
                ("sort_order", "asc".into()),
            ]),
            Some(Sort::Relevance) => params.push(("sort_by", "relevance".into())),
            None => {}
        }
        params
    }
}

/// Splits a search draft into its free text and recognized filter tokens.
/// Quoted tokens stay whole and unknown search shortcuts remain text.
pub fn split_filters(text: &str) -> (String, Vec<String>) {
    let (filters, words): (Vec<_>, Vec<_>) = tokens(text).into_iter().partition(|token| {
        Query::parse(token).is_ok_and(|query| query.content.is_empty() && query != Query::default())
    });
    (words.join(" "), filters)
}

fn push_unique<T: PartialEq>(values: &mut Vec<T>, value: T) {
    if !values.contains(&value) {
        values.push(value);
    }
}

fn target(value: &str, symbol: char) -> Result<Target, String> {
    let id = |value: &str| {
        (!value.starts_with('0') && value.bytes().all(|byte| byte.is_ascii_digit()))
            .then(|| value.parse::<u64>().ok())
            .flatten()
    };
    let invalid = || {
        if symbol == '@' {
            "Select a user or enter a valid Discord user name or ID.".to_owned()
        } else {
            "Select a channel or enter a valid Discord channel name or ID.".to_owned()
        }
    };
    if value.starts_with("<@") || value.starts_with("<#") {
        let mut value = value
            .strip_prefix('<')
            .and_then(|value| value.strip_prefix(symbol))
            .and_then(|value| value.strip_suffix('>'))
            .ok_or_else(invalid)?;
        if symbol == '@' {
            value = value.strip_prefix('!').unwrap_or(value);
        }
        return id(value).map(Target::Id).ok_or_else(invalid);
    }
    let value = value.trim_start_matches(symbol);
    if value.bytes().all(|byte| byte.is_ascii_digit()) {
        return id(value).map(Target::Id).ok_or_else(invalid);
    }
    Ok(Target::Name(value.to_owned()))
}

/// The words of a search, a quoted part, even after a filter's colon,
/// kept whole with its quotes.
fn tokens(text: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut token = String::new();
    let mut quoted = false;
    let mut escaped = false;
    for character in text.chars() {
        match character {
            '"' if !escaped => {
                quoted = !quoted;
                token.push(character);
            }
            character if character.is_whitespace() && !quoted => {
                if !token.is_empty() {
                    tokens.push(std::mem::take(&mut token));
                }
            }
            character => token.push(character),
        }
        escaped = character == '\\' && !escaped;
    }
    if !token.is_empty() {
        tokens.push(token);
    }
    tokens
}

/// The snowflakes at the start of a day, `YYYY-MM-DD` in local time, and of
/// the next.
fn day_span(day: &str) -> Result<(u64, u64), String> {
    let date = NaiveDate::parse_from_str(day, "%Y-%m-%d")
        .map_err(|_| format!("S;C reads dates as 2026-10-13, not {day}."))?;
    let start = |date: NaiveDate| {
        let midnight = date.and_hms_opt(0, 0, 0)?;
        let at = Local.from_local_datetime(&midnight).earliest()?;
        u64::try_from(at.timestamp_millis()).ok()
    };
    let next = date.succ_opt();
    match (start(date), next.and_then(start)) {
        (Some(start), Some(end)) => Ok((snowflake(start), snowflake(end))),
        _ => Err(format!("Discord can't search around {day}.")),
    }
}

/// The smallest snowflake made at a Unix time in milliseconds.
pub fn snowflake(ms: u64) -> u64 {
    ms.saturating_sub(DISCORD_EPOCH) << 22
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_filters_and_keeps_the_rest_as_words() {
        let query =
            Query::parse(r#"trip from:@bob in:#general has:Image mentions:"Carol M" notes"#)
                .unwrap();
        assert_eq!(query.content, "trip notes");
        assert_eq!(query.from, [Target::Name("bob".into())]);
        assert_eq!(query.channels, [Target::Name("general".into())]);
        assert_eq!(query.has, ["image"]);
        assert_eq!(query.mentions, [Target::Name("Carol M".into())]);
        assert_eq!(
            query.params(),
            [("content", "trip notes".into()), ("has", "image".into())]
        );
        let forwarded = Query::parse("has:forward pinned:true").unwrap();
        assert_eq!(forwarded.has, ["snapshot"]);
        assert_eq!(forwarded.pinned, Some(true));
        assert!(forwarded.content.is_empty() && !forwarded.is_empty());
    }

    #[test]
    fn selected_search_filters_keep_exact_ids_and_repeat_wire_values() {
        let query = Query::parse(
            "from:<@123> from:456 from:<@!123> mentions:<@222> mentions:333 \
             in:<#555> in:#666 has:image has:forward has:snapshot has:-LINK \
             author:user author-type:bot author:-webhook sort:oldest",
        )
        .unwrap();
        assert_eq!(query.from, [Target::Id(123), Target::Id(456)]);
        assert_eq!(query.mentions, [Target::Id(222), Target::Id(333)]);
        assert_eq!(query.channels, [Target::Id(555), Target::Id(666)]);
        assert!(query.content.is_empty());
        assert_eq!(
            query.params(),
            [
                ("has", "image".into()),
                ("has", "snapshot".into()),
                ("has", "-link".into()),
                ("author_type", "user".into()),
                ("author_type", "bot".into()),
                ("author_type", "-webhook".into()),
                ("sort_by", "timestamp".into()),
                ("sort_order", "asc".into()),
            ]
        );
        assert!(Query::parse("from:<#123>").is_err());
        assert!(Query::parse("from:<@&123>").is_err());
        assert!(Query::parse("in:<#0>").is_err());
        assert!(Query::parse("from:<@18446744073709551616>").is_err());
    }

    #[test]
    fn split_search_filters_keeps_quoted_and_unknown_text() {
        let draft = r#"  snacks "looking for \"sort:oldest\"" from:<@123> in:#general mentions:"Carol M" sort:flavor author:chef sort:relevance "#;
        let (words, filters) = split_filters(draft);
        assert_eq!(
            words,
            r#"snacks "looking for \"sort:oldest\"" sort:flavor author:chef"#
        );
        assert_eq!(
            filters,
            [
                "from:<@123>",
                "in:#general",
                r#"mentions:"Carol M""#,
                "sort:relevance"
            ]
        );
        let query = Query::parse(draft).unwrap();
        assert_eq!(query.content, words);
        assert_eq!(query.sort, Some(Sort::Relevance));
        assert_eq!(
            query.params(),
            [("content", words), ("sort_by", "relevance".into())]
        );
        assert!(Query::parse("sort:newest").unwrap().is_empty());
    }

    #[test]
    fn unknown_filters_and_empty_values_are_words() {
        let query = Query::parse("see https://example.com at: 10:30").unwrap();
        assert_eq!(query.content, "see https://example.com at: 10:30");
        assert!(Query::parse("from:").unwrap().from.is_empty());
        assert!(Query::parse("  ").unwrap().is_empty());
    }

    #[test]
    fn refuses_what_discord_wouldnt_take() {
        assert!(Query::parse("has:pictures").unwrap_err().contains("image"));
        assert!(Query::parse("before:yesterday").is_err());
        assert!(Query::parse("pinned:maybe").is_err());
    }

    #[test]
    fn days_become_snowflakes_around_them() {
        let during = Query::parse("during:2026-10-13").unwrap();
        let (start, end) = (during.min_id.unwrap(), during.max_id.unwrap());
        // A day is 86,400,000 ms, give or take a change of clocks.
        let day = (end - start) >> 22;
        assert!((82_800_000..=90_000_000).contains(&day), "{day}");
        assert_eq!(
            Query::parse("before:2026-10-13").unwrap().max_id,
            Some(start)
        );
        assert_eq!(Query::parse("after:2026-10-13").unwrap().min_id, Some(end));
        assert_eq!(snowflake(DISCORD_EPOCH + 1), 1 << 22);
    }

    #[test]
    fn date_filters_intersect_independently_of_order() {
        let during = Query::parse("during:2026-10-13").unwrap();
        assert_eq!(
            Query::parse("before:2026-10-15 after:2026-10-11 during:2026-10-13").unwrap(),
            during,
        );
        assert_eq!(
            Query::parse("during:2026-10-13 after:2026-10-11 before:2026-10-15").unwrap(),
            during,
        );
        assert!(Query::parse("during:2026-10-13 before:2026-10-12").is_err());
    }
}
