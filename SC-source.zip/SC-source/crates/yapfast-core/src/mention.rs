//! Mentioning people, roles and channels from the composer: the `@` or `#` word
//! being typed, who or what it may mean, and the message text that mentions
//! them on its network.

use std::ops::Range;

/// Someone or something a message can mention.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Candidate {
    /// What follows the `@` in the composer.
    pub name: String,
    /// What else names them: a Discord username or a Matrix user id.
    pub username: Option<String>,
    /// How a message says it on its network, such as `<@20>` on Discord.
    pub mention: String,
    /// The address of their avatar; see [`crate::chat::DiscordCommand::Pictures`].
    pub avatar: Option<String>,
    /// The RGB colour of the name.
    pub color: Option<u32>,
    /// A role or a group such as @everyone, or a channel, rather than a person.
    pub group: bool,
    /// A channel, which `#` mentions rather than `@`.
    pub channel: bool,
    /// A voice channel.
    pub voice: bool,
}

impl Candidate {
    /// What the composer writes before the name: `#` for a channel, else `@`.
    pub fn sigil(&self) -> char {
        if self.channel { '#' } else { '@' }
    }
}

/// A mention chosen for one occurrence in an otherwise plain text field.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct Placed {
    pub range: Range<usize>,
    pub wire: String,
    pub color: Option<u32>,
}

/// Update the chosen mentions after replacing `start..old_end`.
pub(crate) fn replace(placed: &mut Vec<Placed>, start: usize, old_end: usize, new_end: usize) {
    placed.retain_mut(|mention| {
        if mention.range.end <= start {
            return true;
        }
        if mention.range.start < old_end {
            return false;
        }
        mention.range.start = new_end + (mention.range.start - old_end);
        mention.range.end = new_end + (mention.range.end - old_end);
        true
    });
}

/// Only move mentions through bytes known to be retained in a plain-text edit.
/// When a deletion could remove either of two identical tokens, neither is
/// assumed to be the token that survived.
pub(crate) fn follow_edit(placed: &mut Vec<Placed>, old: &str, new: &str) {
    if placed.is_empty() || old == new {
        return;
    }
    let common = |pairs: &mut dyn Iterator<Item = (char, char)>| {
        pairs
            .take_while(|(left, right)| left == right)
            .map(|(ch, _)| ch.len_utf8())
            .sum::<usize>()
    };
    let prefix = common(&mut old.chars().zip(new.chars()));
    let suffix = common(&mut old.chars().rev().zip(new.chars().rev()));
    let old_suffix = old.len() - suffix;
    let new_suffix = new.len() - suffix;
    placed.retain_mut(|mention| {
        let left = mention.range.end <= prefix.min(new_suffix);
        let right = mention
            .range
            .start
            .checked_sub(old_suffix)
            .map(|offset| new_suffix + offset)
            .filter(|&start| start >= prefix);
        match (left, right) {
            (true, None) => {}
            (false, Some(start)) => mention.range = start..start + mention.range.len(),
            // The edit could have changed either of two identical tokens.
            _ => return false,
        }
        new.get(mention.range.end..).is_some_and(ends_name)
    });
}

pub(crate) fn same_placements(left: &str, one: &[Placed], right: &str, two: &[Placed]) -> bool {
    let left_start = left.len() - left.trim_start().len();
    let right_start = right.len() - right.trim_start().len();
    one.len() == two.len()
        && one.iter().zip(two).all(|(one, two)| {
            one.wire == two.wire
                && one.range.len() == two.range.len()
                && one.range.start.checked_sub(left_start)
                    == two.range.start.checked_sub(right_start)
        })
}

/// Someone or something a message mentions, as the message shows it.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Mentioned {
    /// The text in the message, such as `@Bob`.
    pub text: String,
    pub target: Target,
    /// The RGB colour of the role, or of the person's name.
    pub color: Option<u32>,
    /// Where the text starts in the message's body, a byte offset each time
    /// it mentions them.
    pub at: Vec<usize>,
}

/// Who a mention points at: a user, by Discord or Matrix id, a Discord role,
/// a channel, by room id, or everyone, as Discord's `@everyone` and `@here` do.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Target {
    User(String),
    Role(String),
    Channel(String),
    Everyone,
}

const USER_LINK: &str = "yapfast:user/";
const ROLE_LINK: &str = "yapfast:role/";
const CHANNEL_LINK: &str = "yapfast:channel/";
const EVERYONE_LINK: &str = "yapfast:everyone";
const MATRIX_TO: &str = "https://matrix.to/#/";

/// The address a mention links to in a message; clicking it opens the person,
/// role or channel.
pub fn link(target: &Target) -> String {
    match target {
        Target::User(id) => format!("{USER_LINK}{id}"),
        Target::Role(id) => format!("{ROLE_LINK}{id}"),
        Target::Channel(room) => format!("{CHANNEL_LINK}{room}"),
        Target::Everyone => EVERYONE_LINK.to_owned(),
    }
}

/// Who a clicked link mentions: Yapfast's mention links, and Matrix's links to a user.
pub fn target(link: &str) -> Option<Target> {
    if let Some(id) = link.strip_prefix(USER_LINK) {
        return Some(Target::User(id.to_owned()));
    }
    if let Some(id) = link.strip_prefix(ROLE_LINK) {
        return Some(Target::Role(id.to_owned()));
    }
    if let Some(room) = link.strip_prefix(CHANNEL_LINK) {
        return Some(Target::Channel(room.to_owned()));
    }
    if link == EVERYONE_LINK {
        return Some(Target::Everyone);
    }
    let user = link.strip_prefix(MATRIX_TO)?;
    let user = user.split(['?', '/']).next()?;
    let user = user
        .replace("%40", "@")
        .replace("%3A", ":")
        .replace("%3a", ":");
    (user.starts_with('@') && user.contains(':')).then_some(Target::User(user))
}

/// Someone's Markdown with its HTML escaped, as [`crate::links::escape_html`]
/// does, and each mention outside code linked to its target and in its
/// colour, which the message draws behind it too. A mention is only where
/// the message's tag for it was, at its offsets, as Discord's client shows
/// them: `@Bobby` typed as text isn't Bob's. A mention without a colour of
/// its own takes `link_color`, `0xrrggbb`: the theme's for links.
pub fn linked(markdown: &str, mentions: &[Mentioned], link_color: u32) -> String {
    let escaped = crate::links::escape_html(markdown);
    let mut found: Vec<(usize, &Mentioned)> = mentions
        .iter()
        .filter(|mention| !mention.text.is_empty())
        .flat_map(|mention| mention.at.iter().map(move |&at| (at, mention)))
        .collect();
    if found.is_empty() {
        return escaped.into_owned();
    }
    found.sort_by_key(|(at, _)| *at);
    shift(markdown, &escaped, &mut found);
    let mut out = String::with_capacity(escaped.len() + 64 * found.len());
    let mut code = false;
    let mut last = 0;
    for (at, mention) in found {
        if at < last
            || !escaped
                .get(at..)
                .is_some_and(|rest| rest.starts_with(&mention.text))
        {
            continue;
        }
        let before = &escaped[last..at];
        code ^= before.matches('`').count() % 2 == 1;
        out.push_str(before);
        last = at;
        if code {
            continue;
        }
        // A name is shown as typed: one such as `[x](https://…)` would
        // otherwise be a link of its own. A channel's comes escaped already.
        let text = match mention.target {
            Target::Channel(_) => mention.text.clone(),
            _ => crate::links::escape_markdown(&mention.text),
        };
        let color = mention.color.unwrap_or(link_color) & 0xff_ffff;
        out.push_str(&format!(
            "<font color=\"#{color:06x}\">[{text}](<{}>)</font>",
            link(&mention.target)
        ));
        last = at + mention.text.len();
    }
    out.push_str(&escaped[last..]);
    out
}

/// A message's `body` as its author would type it again, to edit: a channel's
/// name is escaped where it shows, and would go out as text with its backslashes.
pub fn as_typed(body: &str, mentions: &[Mentioned]) -> String {
    edit_body(body, mentions, false).0
}

/// Keep the original Discord targets when opening an edit, including targets
/// that are no longer present in the autocomplete results.
pub(crate) fn edit_body(
    body: &str,
    mentions: &[Mentioned],
    discord: bool,
) -> (String, Vec<Placed>) {
    let mut places = mentions
        .iter()
        .filter(|mention| !mention.text.is_empty())
        .flat_map(|mention| mention.at.iter().map(move |&at| (at, mention)))
        .collect::<Vec<_>>();
    places.sort_unstable_by_key(|(at, _)| *at);
    let mut typed = String::with_capacity(body.len());
    let mut placed = Vec::new();
    let mut end = 0;
    for (at, mention) in places {
        if at < end
            || !body
                .get(at..)
                .is_some_and(|tail| tail.starts_with(&mention.text))
        {
            continue;
        }
        typed.push_str(&body[end..at]);
        let start = typed.len();
        match mention.target {
            Target::Channel(_) => typed.push_str(&without_escapes(&mention.text)),
            _ => typed.push_str(&mention.text),
        }
        if discord && let Some(wire) = original_wire(mention) {
            placed.push(Placed {
                range: start..typed.len(),
                wire,
                color: mention
                    .color
                    .filter(|_| matches!(mention.target, Target::Role(_))),
            });
        }
        end = at + mention.text.len();
    }
    typed.push_str(&body[end..]);
    (typed, placed)
}

fn original_wire(mention: &Mentioned) -> Option<String> {
    let valid =
        |id: &str| !id.is_empty() && id.len() <= 20 && id.bytes().all(|b| b.is_ascii_digit());
    match &mention.target {
        Target::User(id) if valid(id) => Some(format!("<@{id}>")),
        Target::Role(id) if valid(id) => Some(format!("<@&{id}>")),
        Target::Channel(room) => crate::discord::parse_room(room)
            .filter(|(_, id)| valid(id))
            .map(|(_, id)| format!("<#{id}>")),
        Target::Everyone if matches!(mention.text.as_str(), "@everyone" | "@here") => {
            Some(mention.text.clone())
        }
        _ => None,
    }
}

/// `text` without the backslashes that escape its Markdown's punctuation.
fn without_escapes(text: &str) -> String {
    let mut plain = String::with_capacity(text.len());
    let mut chars = text.chars().peekable();
    while let Some(next) = chars.next() {
        if next == '\\' && chars.peek().is_some_and(char::is_ascii_punctuation) {
            continue;
        }
        plain.push(next);
    }
    plain
}

/// Moves each offset into `original` to the same place in `escaped`, which
/// is `original` with backslashes put in before some of its `<`. The
/// offsets are in order.
fn shift(original: &str, escaped: &str, offsets: &mut [(usize, &Mentioned)]) {
    if original.len() == escaped.len() {
        return;
    }
    let (original, escaped) = (original.as_bytes(), escaped.as_bytes());
    let (mut from, mut to) = (0, 0);
    for (at, _) in offsets {
        while from < *at && from < original.len() {
            if escaped[to] == original[from] {
                from += 1;
            }
            to += 1;
        }
        *at = to;
    }
}

/// Whether a name followed by `after` ends there, rather than going on into a
/// longer word.
fn ends_name(after: &str) -> bool {
    !after.starts_with(is_name_char)
}

fn is_name_char(c: char) -> bool {
    c.is_alphanumeric() || c == '_'
}

/// Names longer than this aren't looked up while typing.
const MAX_QUERY: usize = 32;

/// The `@` or `#` word ending at `cursor`, a byte offset into `text`: where its
/// sigil is, which one, and what follows it.
pub fn query(text: &str, cursor: usize) -> Option<(usize, char, &str)> {
    let before = text.get(..cursor)?;
    let at = before.rfind(['@', '#'])?;
    let sigil = if before[at..].starts_with('#') {
        '#'
    } else {
        '@'
    };
    let query = &before[at + 1..];
    let starts_word = before[..at]
        .chars()
        .next_back()
        .is_none_or(|previous| previous.is_whitespace() || "([{\"'".contains(previous));
    (starts_word && query.len() <= MAX_QUERY && !query.contains(char::is_whitespace))
        .then_some((at, sigil, query))
}

/// Match a folded query against a full name, username, word, or substring.
pub(crate) fn match_rank(name: &str, username: Option<&str>, query: &str) -> Option<u8> {
    if query.is_empty() {
        return Some(0);
    }
    let name = name.to_lowercase();
    let username = username.map(str::to_lowercase);
    let username = username.as_deref().unwrap_or_default();
    let word = |text: &str| {
        text.split(|c: char| !c.is_alphanumeric())
            .any(|word| word.starts_with(query))
    };
    if name == query || username == query {
        Some(0)
    } else if name.starts_with(query) {
        Some(1)
    } else if username.starts_with(query) {
        Some(2)
    } else if word(&name) || word(username) {
        Some(3)
    } else if name.contains(query) || username.contains(query) {
        Some(4)
    } else {
        None
    }
}

/// The candidates `query` may mean, at most `limit`, keeping source order
/// within the exact, name prefix, username prefix, word, and substring ranks.
pub fn matching<'a, C: std::borrow::Borrow<Candidate>>(
    candidates: &'a [C],
    query: &str,
    limit: usize,
) -> Vec<&'a Candidate> {
    let query = query.to_lowercase();
    let mut found: Vec<(u8, &Candidate)> = candidates
        .iter()
        .map(std::borrow::Borrow::borrow)
        .filter_map(|candidate| {
            let rank = match_rank(&candidate.name, candidate.username.as_deref(), &query)?;
            Some((rank, candidate))
        })
        .collect();
    found.sort_by_key(|(rank, _)| *rank);
    found
        .into_iter()
        .take(limit)
        .map(|(_, candidate)| candidate)
        .collect()
}

/// `text` with each `@name` or `#channel` of a candidate, outside code, in its
/// network's form.
pub fn wire(text: &str, candidates: &[Candidate]) -> String {
    wire_placed(text, candidates, &[])
}

pub(crate) fn wire_placed(text: &str, candidates: &[Candidate], placed: &[Placed]) -> String {
    let mut out = String::with_capacity(text.len());
    let mut end = 0;
    for (range, wire, _) in found(text, candidates, placed) {
        out.push_str(&text[end..range.start]);
        out.push_str(wire);
        end = range.end;
    }
    out.push_str(&text[end..]);
    out
}

/// Where the composer highlights a mention and which role color it uses.
pub fn marks(text: &str, candidates: &[Candidate]) -> Vec<(Range<usize>, Option<u32>)> {
    placed_marks(text, candidates, &[])
}

pub(crate) fn placed_marks(
    text: &str,
    candidates: &[Candidate],
    placed: &[Placed],
) -> Vec<(Range<usize>, Option<u32>)> {
    found(text, candidates, placed)
        .into_iter()
        .map(|(range, _, color)| (range, color))
        .collect()
}

/// Chosen spans take precedence. Plain text must name a single distinct
/// target, preferring the longest name and then the exact spelling.
fn found<'a>(
    text: &str,
    candidates: &'a [Candidate],
    placed: &'a [Placed],
) -> Vec<(Range<usize>, &'a str, Option<u32>)> {
    if !text.contains(['@', '#']) {
        return Vec::new();
    }
    let mut names = candidates
        .iter()
        .flat_map(|candidate| {
            let username = candidate
                .username
                .as_deref()
                .filter(|_| !candidate.group && candidate.mention.starts_with("<@"));
            [Some(candidate.name.as_str()), username]
                .into_iter()
                .flatten()
                .filter(|name| !name.is_empty())
                .map(move |name| (name, candidate))
        })
        .collect::<Vec<_>>();
    names.sort_by_key(|(name, _)| std::cmp::Reverse(name.len()));
    let mut found = Vec::new();
    let mut placed = placed.iter().peekable();
    let mut code = false;
    let mut at = 0;
    let mut previous: Option<char> = None;
    while let Some(next) = text[at..].chars().next() {
        while placed.peek().is_some_and(|bound| bound.range.start < at) {
            placed.next();
        }
        if let Some(bound) = placed.next_if(|bound| bound.range.start == at)
            && !code
            && bound.range.end > at
            && let Some(label) = text.get(bound.range.clone())
            && label.starts_with(['@', '#'])
            && ends_name(&text[bound.range.end..])
        {
            found.push((bound.range.clone(), bound.wire.as_str(), bound.color));
            at = bound.range.end;
            previous = label.chars().next_back();
            continue;
        }
        if next == '`' {
            code = !code;
        }
        let starts_word = previous.is_none_or(|previous| !previous.is_alphanumeric());
        let native_tag = previous == Some('<');
        if (next == '@' || next == '#') && !code && starts_word && !native_tag {
            let after = &text[at + 1..];
            let limit = placed
                .peek()
                .map_or(after.len(), |bound| bound.range.start - at - 1);
            if let Some((len, candidate)) = unique_name(after, next, limit, &names) {
                let end = at + 1 + len;
                found.push((
                    at..end,
                    candidate.mention.as_str(),
                    candidate.color.filter(|_| candidate.group),
                ));
                previous = text[at..end].chars().next_back();
                at = end;
                continue;
            }
        }
        at += next.len_utf8();
        previous = Some(next);
    }
    found
}

fn unique_name<'a>(
    after: &str,
    sigil: char,
    limit: usize,
    names: &[(&str, &'a Candidate)],
) -> Option<(usize, &'a Candidate)> {
    let mut fits = names.iter().copied().filter(|&(name, candidate)| {
        candidate.sigil() == sigil
            && name.len() <= limit
            && after.get(..name.len()).is_some_and(|head| {
                head.eq_ignore_ascii_case(name) && ends_name(&after[name.len()..])
            })
    });
    let (name, mut chosen) = fits.next()?;
    let len = name.len();
    let mut exact = after.starts_with(name);
    let mut ambiguous = false;
    let everyone = |candidate: &Candidate| {
        candidate.group && matches!(candidate.mention.as_str(), "@here" | "@everyone")
    };
    if everyone(chosen) {
        return Some((len, chosen));
    }
    for (name, candidate) in fits.take_while(|(name, _)| name.len() == len) {
        if everyone(candidate) {
            return Some((len, candidate));
        }
        let exact_match = after.starts_with(name);
        if exact_match && !exact {
            chosen = candidate;
            exact = true;
            ambiguous = false;
        } else if exact_match == exact && candidate.mention != chosen.mention {
            ambiguous = true;
        }
    }
    (!ambiguous).then_some((len, chosen))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn person(name: &str, mention: &str) -> Candidate {
        Candidate {
            name: name.into(),
            username: None,
            mention: mention.into(),
            avatar: None,
            color: None,
            group: false,
            channel: false,
            voice: false,
        }
    }

    fn channel(name: &str, mention: &str) -> Candidate {
        Candidate {
            group: true,
            channel: true,
            ..person(name, mention)
        }
    }

    #[test]
    fn mentions_link_to_who_they_mention() {
        let bob = |at: &[usize]| Mentioned {
            text: "@Bob".into(),
            target: Target::User("2".into()),
            color: None,
            at: at.to_vec(),
        };
        let mods = Mentioned {
            text: "@Mods".into(),
            target: Target::Role("30".into()),
            color: Some(0x3498db),
            at: vec![13],
        };
        let pill = "<font color=\"#7cc4ff\">[\\@Bob](<yapfast:user/2>)</font>";
        assert_eq!(
            linked(
                "hi @Bob, ask @Mods but not `@Bob`",
                &[bob(&[3, 28]), mods],
                0x7cc4ff
            ),
            format!(
                "hi {pill}, ask <font color=\"#3498db\">[\\@Mods](<yapfast:role/30>)</font> \
                 but not `@Bob`"
            )
        );
        // Only where the message's tag was: `<@2>by`, not `@Bob` typed.
        assert_eq!(
            linked("@Bobby and @Bob", &[bob(&[0])], 0x7cc4ff),
            format!("{pill}by and @Bob")
        );
        assert_eq!(
            linked("<b>x</b> @Bob", &[bob(&[9])], 0x7cc4ff),
            format!("\\<b>x\\</b> {pill}"),
            "escaping the HTML moves the mention"
        );
        let named = [Mentioned {
            text: "@[Support](https://evil.example)".into(),
            target: Target::User("3".into()),
            color: None,
            at: vec![0],
        }];
        assert!(
            linked("@[Support](https://evil.example)", &named, 0)
                .contains("[\\@\\[Support\\]\\(https\\:\\/\\/evil\\.example\\)]"),
            "a name shows as typed"
        );
        assert_eq!(target("yapfast:user/2"), Some(Target::User("2".into())));
        assert_eq!(target("yapfast:role/30"), Some(Target::Role("30".into())));
        assert_eq!(target(&link(&Target::Everyone)), Some(Target::Everyone));
        assert_eq!(
            target("https://matrix.to/#/@sam:test?via=test"),
            Some(Target::User("@sam:test".into()))
        );
        assert_eq!(
            target("https://matrix.to/#/%40sam%3Atest"),
            Some(Target::User("@sam:test".into()))
        );
        assert_eq!(target("https://matrix.to/#/#games:test"), None);
        assert_eq!(target("https://example.com"), None);
    }

    #[test]
    fn finds_the_word_being_typed() {
        assert_eq!(query("hi @bo", 6), Some((3, '@', "bo")));
        assert_eq!(query("@", 1), Some((0, '@', "")));
        assert_eq!(query("(@carol", 7), Some((1, '@', "carol")));
        assert_eq!(query("mail me@home", 12), None, "not after a letter");
        assert_eq!(query("@bob is here", 12), None, "a space ends it");
        assert_eq!(
            query("hi @bo and", 6),
            Some((3, '@', "bo")),
            "the cursor ends it"
        );
        assert_eq!(query("see #gen", 8), Some((4, '#', "gen")));
        assert_eq!(query("#", 1), Some((0, '#', "")));
        assert_eq!(query("C#", 2), None, "not after a letter");
        assert_eq!(query("# Title", 7), None, "a heading's space ends it");
    }

    #[test]
    fn matches_names_and_later_words() {
        let candidates = [
            person("Bob", "<@2>"),
            person("Status Bot", "<@7>"),
            person("Carol", "<@3>"),
            person("bobby", "<@9>"),
            Candidate {
                username: Some("bob_the_builder".into()),
                ..person("Robert", "<@11>")
            },
        ];
        let names = |query| -> Vec<&str> {
            matching(&candidates, query, 8)
                .iter()
                .map(|candidate| candidate.name.as_str())
                .collect()
        };
        assert_eq!(names("bo"), ["Bob", "bobby", "Robert", "Status Bot"]);
        assert_eq!(names(""), ["Bob", "Status Bot", "Carol", "bobby", "Robert"]);
        assert!(names("x").is_empty());
        assert_eq!(matching(&candidates, "", 2).len(), 2);
    }

    #[test]
    fn matches_emoji_prefixed_channels_and_member_substrings_in_rank_order() {
        let channels = [
            channel("weekly-deposits", "<#21>"),
            channel("💰│deposit", "<#22>"),
            channel("deposit", "<#23>"),
        ];
        let matches = matching(&channels, "DEPOSIT", 8);
        assert_eq!(matches[0].mention, "<#23>");
        assert_eq!(matches[1].mention, "<#21>");
        assert_eq!(matches[2].mention, "<#22>");
        assert_eq!(matching(&channels, "posit", 8).len(), 3);
        let people = [
            person("Damasolo", "<@2>"),
            person("Trainee Chef Solo", "<@3>"),
            Candidate {
                username: Some("solo_runner".into()),
                ..person("Runner", "<@4>")
            },
        ];
        let matches = matching(&people, "solo", 8);
        assert_eq!(matches[0].mention, "<@4>");
        assert_eq!(matches[1].mention, "<@3>");
        assert_eq!(matches[2].mention, "<@2>");
    }

    #[test]
    fn mentions_go_out_in_the_network_form() {
        let candidates = [
            person("Ann", "<@1>"),
            person("Ann Lee", "<@2>"),
            person("everyone", "@everyone"),
            Candidate {
                group: true,
                ..person("Mods", "<@&20>")
            },
        ];
        assert_eq!(
            wire("@Ann Lee and @ann, ask @Mods!", &candidates),
            "<@2> and <@1>, ask <@&20>!"
        );
        assert_eq!(wire("@everyone look", &candidates), "@everyone look");
        assert_eq!(wire("@Annie stays", &candidates), "@Annie stays");
        assert_eq!(wire("me@Ann.com", &candidates), "me@Ann.com");
        assert_eq!(wire("`@Ann` but @Ann", &candidates), "`@Ann` but <@1>");
        assert_eq!(wire("café @Ann", &candidates), "café <@1>");
    }

    #[test]
    fn channels_go_out_with_hash() {
        let candidates = [
            channel("general", "<#11>"),
            channel("off-topic", "<#12>"),
            person("general", "<@3>"),
        ];
        assert_eq!(
            wire("see #general and #off-topic, ask @general", &candidates),
            "see <#11> and <#12>, ask <@3>"
        );
        assert_eq!(
            wire("C#general and #generalist", &candidates),
            "C#general and #generalist"
        );
        assert_eq!(wire("`#general`", &candidates), "`#general`");
    }

    #[test]
    fn a_name_written_alike_wins_over_one_in_another_case() {
        let text = channel("general", "<#1>");
        let voice = channel("General", "<#2>");
        assert_eq!(
            wire(
                "#General, #general, #GENERAL",
                &[text.clone(), voice.clone()]
            ),
            "<#2>, <#1>, #GENERAL"
        );
        assert_eq!(wire("#General", &[voice, text]), "<#2>");
        // The longest still wins first.
        let candidates = [person("Ann", "<@1>"), person("ann lee", "<@2>")];
        assert_eq!(wire("@Ann Lee", &candidates), "<@2>");
    }

    #[test]
    fn picked_mentions_win_at_their_own_ranges_and_merge_safely_with_edits() {
        let candidates = [
            person("Same", "<@10>"),
            person("Same", "<@20>"),
            person("Gift @Same", "<@30>"),
        ];
        let binding = |range, id| Placed {
            range,
            wire: format!("<@{id}>"),
            color: None,
        };
        assert_eq!(wire("@Same", &candidates), "@Same");
        assert_eq!(
            wire_placed("@Gift @Same", &candidates, &[binding(6..11, 20)]),
            "@Gift <@20>"
        );
        let before = "@Same @Same";
        let mut placed = vec![binding(0..5, 10), binding(6..11, 20)];
        let after = "é @Same @Same";
        follow_edit(&mut placed, before, after);
        assert_eq!(wire_placed(after, &candidates, &placed), "é <@10> <@20>");
        let mut prefixed = vec![binding(0..5, 10), binding(6..11, 20)];
        follow_edit(&mut prefixed, before, "@silent @Same @Same");
        assert_eq!(
            wire_placed("@silent @Same @Same", &candidates, &prefixed),
            "@silent <@10> <@20>"
        );
        follow_edit(&mut placed, after, "é @Same");
        assert_eq!(wire_placed("é @Same", &candidates, &placed), "é @Same");
        let mut placed = vec![binding(0..5, 20)];
        follow_edit(&mut placed, "@Same ", "@Samen ");
        assert_eq!(wire_placed("@Samen ", &candidates, &placed), "@Samen ");
    }

    #[test]
    fn a_channels_mention_opens_it_and_shows_its_escaped_name() {
        let target = Target::Channel("discord:1:2".into());
        assert_eq!(super::target(&link(&target)), Some(target.clone()));
        let mentions = [Mentioned {
            text: "#off\\-topic".into(),
            target,
            color: None,
            at: vec![4],
        }];
        assert_eq!(
            linked("see #off\\-topic", &mentions, 0x112233),
            "see <font color=\"#112233\">[#off\\-topic](<yapfast:channel/discord:1:2>)</font>"
        );
    }

    #[test]
    fn editing_writes_a_channels_name_as_typed() {
        let channel = Mentioned {
            text: "#off\\-topic".into(),
            target: Target::Channel("discord:1:2".into()),
            color: None,
            at: vec![0, 16],
        };
        let role = Mentioned {
            text: "@a\\-b".into(),
            target: Target::Role("3".into()),
            color: None,
            at: vec![28],
        };
        let body = "#off\\-topic 1\\* #off\\-topic @a\\-b";
        assert_eq!(
            as_typed(body, &[channel, role]),
            "#off-topic 1\\* #off-topic @a\\-b",
            "the rest stays as it is"
        );
    }

    #[test]
    fn marks_what_goes_out_as_a_mention() {
        let candidates = [
            person("Ann", "<@1>"),
            Candidate {
                color: Some(0x3498db),
                group: true,
                ..person("Mods", "<@&20>")
            },
        ];
        assert_eq!(
            marks("café @ann, ask @Mods but `@Ann` or @Annie", &candidates),
            [(6..10, None), (16..21, Some(0x3498db))]
        );
        assert!(marks("no one", &candidates).is_empty());
    }

    #[test]
    fn a_person_is_marked_in_the_colour_of_mentions_whatever_their_role() {
        // Ann's name is in her role's colour in the suggestions, as in
        // Discord's client, but her mention isn't.
        let candidates = [Candidate {
            color: Some(0xe91e63),
            ..person("Ann", "<@1>")
        }];
        assert_eq!(marks("hi @Ann", &candidates), [(3..7, None)]);
    }
}
