//! Apps' commands: the index of those a room offers, its server's or DM's
//! merged with the account's own. It's fetched only once the person types
//! `/` ([`DiscordCommand::CommandIndex`]); the service keeps each index
//! until Discord says it changed, so asking again for the same server
//! fetches nothing. See docs/discord/messages.md, "Apps' commands".

use super::*;

/// Carries out an app command index command, or gives back any other.
pub(super) fn command(
    command: Command,
    discord: Result<&Discord, &str>,
    events: &UnboundedSender<Event>,
) -> Option<Command> {
    let command = match command {
        Command::Discord(DiscordCommand::CommandDetails {
            room,
            item,
            original_message,
            request,
            account,
            interaction,
        }) => {
            command_details(
                room,
                item,
                original_message,
                request,
                account,
                interaction,
                discord,
                events,
            );
            return None;
        }
        command => command,
    };
    let Command::Discord(DiscordCommand::CommandIndex { room }) = command else {
        return Some(command);
    };
    let discord = match (discord, discord::parse_room(&room)) {
        (Ok(discord), Some(_)) => discord.clone(),
        (Err(why), _) => {
            let _ = events.send(Event::CommandIndex {
                room,
                index: Err(why.to_owned()),
            });
            return None;
        }
        // Only Discord's channels have commands.
        (Ok(_), None) => return None,
    };
    let events = events.clone();
    tokio::spawn(async move {
        let Some((guild, channel)) = discord::parse_room(&room) else {
            return;
        };
        let guild = (guild != discord::DM_GUILD).then_some(guild);
        let index = discord
            .command_index(guild, channel)
            .await
            .map_err(|error| {
                tracing::warn!(
                    error = format!("{error:#}"),
                    "could not fetch apps' commands"
                );
                format!("Couldn't load apps' commands: {error}")
            });
        let _ = events.send(Event::CommandIndex { room, index });
    });
    None
}

/// Reads metadata only when the application has accepted a hover on a normal
/// message. Invalid or offline requests still finish, releasing its pending slot.
fn command_details(
    room: String,
    item: String,
    original_message: Option<String>,
    request: String,
    account: String,
    interaction: String,
    discord: Result<&Discord, &str>,
    events: &UnboundedSender<Event>,
) {
    let valid_id = |id: &str| {
        id.len() <= 20
            && id.bytes().all(|byte| byte.is_ascii_digit())
            && id.parse::<u64>().is_ok_and(|id| id != 0)
    };
    let address = discord::parse_room(&room)
        .zip(item.strip_prefix("d:"))
        .filter(|((_, channel), message)| valid_id(channel) && valid_id(message));
    let (discord, channel, message) = match (discord, address) {
        (Ok(discord), Some(((_, channel), message)))
            if discord.snapshots().borrow().user_id.as_deref() == Some(account.as_str()) =>
        {
            (discord.clone(), channel.to_owned(), message.to_owned())
        }
        (discord, _) => {
            let why = discord
                .err()
                .unwrap_or("This message has no command details.");
            let _ = events.send(Event::CommandDetails {
                room,
                item,
                request,
                account,
                interaction,
                result: Err(why.to_owned()),
            });
            return;
        }
    };
    let original = original_message.filter(|id| valid_id(id) && id != &message);
    let events = events.clone();
    tokio::spawn(async move {
        let mut result = discord.command_details(&channel, &message).await;
        // Like Discord's command popout, ask for the actual visible message.
        // A follow-up can refer back to its known original if metadata is gone.
        // The reducer still requires the recorded source interaction ID.
        if command_metadata_missing(&result)
            && let Some(original) = original
        {
            result = discord.command_details(&channel, &original).await;
        }
        let result = result.map_err(|error| {
            // Numeric HTTP/API codes and canonical reasons only. A raw
            // error/body can contain command contents and must not log.
            let reason = yapfast_discord::api::interaction_failure(&error)
                .unwrap_or_else(|| "The command details request could not complete.".into());
            tracing::warn!(reason, "command details could not be loaded");
            reason
        });
        let _ = events.send(Event::CommandDetails {
            room,
            item,
            request,
            account,
            interaction,
            result,
        });
    });
}

fn command_metadata_missing(result: &anyhow::Result<serde_json::Value>) -> bool {
    result.as_ref().map_or_else(
        |error| {
            error
                .downcast_ref::<yapfast_discord::api::Refused>()
                .is_some_and(|status| status.gone())
        },
        |data| data.is_null(),
    )
}

#[cfg(test)]
#[test]
fn command_details_fallback_only_when_visible_metadata_is_gone() {
    use serde_json::{Value, json};
    use yapfast_discord::api::Refused;

    assert!(command_metadata_missing(&Ok(Value::Null)));
    assert!(!command_metadata_missing(&Ok(
        json!({"id": "123", "options": []})
    )));
    for (status, missing) in [
        (404, true),
        (410, true),
        (403, false),
        (429, false),
        (503, false),
    ] {
        let refused = Refused(status.to_string().parse().unwrap());
        assert_eq!(command_metadata_missing(&Err(refused.into())), missing);
    }
}
