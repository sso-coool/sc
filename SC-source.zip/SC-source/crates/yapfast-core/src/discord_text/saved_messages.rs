//! Reads and writes Discord's private saved-message state.

use chrono::{DateTime, Utc};
use serde_json::Value;

use super::*;
use crate::application::{
    BookmarkPage, SavedMessage, SavedMessageChange, SavedMessagesRequest, SavedMessagesResult,
    saved_message_id,
};

const INVALID_RESPONSE: &str = "Discord sent an invalid saved-message response.";

pub(super) fn command(
    command: Command,
    discord: Result<&Discord, &str>,
    events: &UnboundedSender<Event>,
) -> Option<Command> {
    let Command::Discord(DiscordCommand::SavedMessages {
        account,
        request,
        action,
    }) = command
    else {
        return Some(command);
    };
    let service = discord
        .ok()
        .filter(|discord| {
            let snapshot = discord.snapshots();
            let account_matches = snapshot.borrow().user_id.as_deref() == Some(account.as_str());
            account_matches
        })
        .cloned();
    let events = events.clone();
    tokio::spawn(async move {
        let result = match service {
            Some(discord) => carry_out(&discord, action).await,
            None => Err("The Discord account is no longer connected.".into()),
        };
        let _ = events.send(Event::SavedMessages {
            account,
            request,
            result,
        });
    });
    None
}

async fn carry_out(
    discord: &Discord,
    action: SavedMessagesRequest,
) -> Result<SavedMessagesResult, String> {
    match action {
        SavedMessagesRequest::Refresh => {
            let summary = discord
                .saved_messages()
                .await
                .map_err(|error| failure(&error))?;
            let bookmark_ids = array(&summary, "bookmark_ids")?
                .iter()
                .filter_map(Value::as_str)
                .filter(|id| saved_message_id(id))
                .map(str::to_owned)
                .collect::<HashSet<_>>();
            let reminders = array(&summary, "reminders")?
                .iter()
                .filter_map(parse_row)
                .filter(|row| row.due_at.is_some())
                .collect();
            let page = if bookmark_ids.is_empty() {
                Ok(BookmarkPage {
                    bookmarks: vec![],
                    next_before: None,
                    has_more: false,
                })
            } else {
                load_page(discord, None).await
            };
            Ok(SavedMessagesResult::Refreshed {
                bookmark_ids,
                reminders,
                page,
            })
        }
        SavedMessagesRequest::More(before) => load_page(discord, Some(before))
            .await
            .map(SavedMessagesResult::More),
        SavedMessagesRequest::Save {
            channel,
            message,
            due_at,
            from_list,
        } => {
            let value = discord
                .save_message(&channel, &message, due_at, from_list)
                .await
                .map_err(|error| failure(&error))?;
            let row = parse_row(&value)
                .filter(|row| {
                    row.channel == channel
                        && row.message == message
                        && row.due_at.is_some() == due_at.is_some()
                })
                .ok_or_else(|| INVALID_RESPONSE.to_owned())?;
            Ok(SavedMessagesResult::Changed(SavedMessageChange::Kept(row)))
        }
        SavedMessagesRequest::Remove { channel, message } => {
            discord
                .remove_saved_message(&channel, &message)
                .await
                .map_err(|error| failure(&error))?;
            Ok(SavedMessagesResult::Changed(SavedMessageChange::Removed {
                channel,
                message,
            }))
        }
    }
}

async fn load_page(
    discord: &Discord,
    before: Option<DateTime<Utc>>,
) -> Result<BookmarkPage, String> {
    let value = discord
        .message_bookmarks(before)
        .await
        .map_err(|error| failure(&error))?;
    let results = array(&value, "results")?;
    let next_before = results
        .last()
        .and_then(|row| time(&row["save_data"]["saved_at"]));
    let bookmarks = results
        .iter()
        .filter_map(parse_row)
        .filter(|row| row.due_at.is_none())
        .collect();
    let has_more = value["has_more"]
        .as_bool()
        .ok_or_else(|| INVALID_RESPONSE.to_owned())?;
    Ok(BookmarkPage {
        bookmarks,
        next_before,
        has_more,
    })
}

fn array<'a>(value: &'a Value, field: &str) -> Result<&'a [Value], String> {
    value[field]
        .as_array()
        .map(Vec::as_slice)
        .ok_or_else(|| INVALID_RESPONSE.to_owned())
}

fn time(value: &Value) -> Option<DateTime<Utc>> {
    DateTime::parse_from_rfc3339(value.as_str()?)
        .ok()
        .map(|time| time.with_timezone(&Utc))
}

fn snowflake(value: &Value) -> Option<&str> {
    value.as_str().filter(|id| saved_message_id(id))
}

fn visible_text(value: &Value, fallback: &Value, limit: usize) -> String {
    value
        .as_str()
        .filter(|text| !text.is_empty())
        .or_else(|| fallback.as_str())
        .unwrap_or_default()
        .chars()
        .take(limit)
        .collect()
}

fn parse_row(value: &Value) -> Option<SavedMessage> {
    let data = &value["save_data"];
    let message = &value["message"];
    let due_at = if data["due_at"].is_null() {
        None
    } else {
        Some(time(&data["due_at"])?)
    };
    Some(SavedMessage {
        channel: snowflake(&data["channel_id"])?.to_owned(),
        message: snowflake(&data["message_id"])?.to_owned(),
        guild: snowflake(&data["guild_id"])
            .or_else(|| snowflake(&message["guild_id"]))
            .map(str::to_owned),
        saved_at: time(&data["saved_at"])?,
        due_at,
        author: visible_text(&data["author_summary"], &message["author"]["username"], 100),
        channel_name: visible_text(&data["channel_summary"], &Value::Null, 100),
        summary: visible_text(&data["message_summary"], &message["content"], 300),
    })
}

fn failure(error: &anyhow::Error) -> String {
    use yapfast_discord::api::{Refused, code};
    let status = error
        .downcast_ref::<Refused>()
        .map(|error| error.0.as_u16());
    let why = match (code(error), status) {
        (Some(30074), _) => {
            "Discord's saved-message limit is full. Remove an existing bookmark or reminder."
        }
        (_, Some(401)) => "Discord could not authorize this saved-message action.",
        (_, Some(403)) => {
            "Discord denied this saved-message action. Saving messages requires Nitro and access to the message."
        }
        (_, Some(404)) => "Discord could not find this saved message or the saved-message service.",
        (_, Some(429)) => "Discord is limiting saved-message requests. Try again shortly.",
        _ => "Discord could not complete the saved-message request. Try again.",
    };
    why.into()
}

pub(super) fn live(event: &Live, discord: &Discord, events: &UnboundedSender<Event>) -> bool {
    let change = match event {
        Live::SavedMessageCreated(value) => parse_row(value).map(SavedMessageChange::Kept),
        Live::SavedMessageDeleted { channel, message } => Some(SavedMessageChange::Removed {
            channel: channel.clone(),
            message: message.clone(),
        }),
        _ => return false,
    };
    if let Some(change) = change
        && let Some(account) = discord.snapshots().borrow().user_id.clone()
    {
        let _ = events.send(Event::SavedMessageChanged { account, change });
    }
    true
}

#[cfg(test)]
#[test]
fn saved_message_wire_row_preserves_due_time_even_if_original_is_unavailable() {
    let mut value = serde_json::json!({
        "save_data": {
            "channel_id": "21", "message_id": "100", "guild_id": 0,
            "saved_at": "2026-11-14T23:00:00.000Z",
            "due_at": "2026-11-15T00:00:00.000Z",
            "author_summary": "Fixture", "channel_summary": "A DM",
            "message_summary": "This was bookmarked."
        },
        "message": null
    });
    let row = parse_row(&value).unwrap();
    assert_eq!(row.channel, "21");
    assert!(row.guild.is_none());
    assert_eq!(row.summary, "This was bookmarked.");
    assert_eq!(
        row.due_at.unwrap() - row.saved_at,
        chrono::TimeDelta::hours(1)
    );
    value["save_data"]["due_at"] = serde_json::json!("invalid");
    assert!(parse_row(&value).is_none());
    value["save_data"]["due_at"] = Value::Null;
    assert!(parse_row(&value).unwrap().due_at.is_none());
}
