//! Discord's messages, profiles, embeds and members as Yapfast's chat shows
//! them.

use super::{channels::SharedPreviews, *};
use yapfast_discord::message::MentionTarget;
use yapfast_discord::ready::Access;

/// A new Discord message as a notification: who wrote it, by their name in the server,
/// and what it says, or what it carries when it has no text.
pub(super) fn notification(
    discord: &Discord,
    guild: Option<&str>,
    message: &Message,
) -> Notification {
    let snapshot = discord.snapshots().borrow().clone();
    let server = guild.and_then(|guild| snapshot.servers.iter().find(|server| server.id == guild));
    let author = discord
        .name(
            guild.unwrap_or(yapfast_discord::ready::PRIVATE),
            &message.author_id,
        )
        .unwrap_or_else(|| message.author.clone());
    // A message of components says what its first text does.
    let text = match message.content.as_str() {
        "" => message
            .components
            .iter()
            .flat_map(yapfast_discord::components::Card::texts)
            .next()
            .unwrap_or_default(),
        content => content,
    };
    let mut body = crate::chat::notification_text(&crate::spoiler::hide(
        &discord.render(server.map(|server| &*server.server), text),
    ));
    if body.is_empty() {
        body = if message
            .attachments
            .iter()
            .any(|attachment| attachment.shown == Shown::Sticker)
        {
            "Sent a sticker".into()
        } else if message
            .attachments
            .iter()
            .any(|attachment| attachment.image)
        {
            "Sent a picture".into()
        } else if !message.attachments.is_empty() {
            "Sent a file".into()
        } else if message.listen_invite == Some(true) {
            "Sent a Listen Along invite".into()
        } else if let Some(poll) = &message.poll {
            // As Discord's client says it.
            format!("[poll] {}", poll.question)
        } else if let Some(title) = message.embeds.iter().find_map(|embed| embed.title.clone()) {
            title
        } else {
            "Sent a message".into()
        };
    }
    Notification {
        room: crate::discord::room_id(
            guild.unwrap_or(yapfast_discord::ready::PRIVATE),
            &message.channel_id,
        ),
        author,
        body,
        avatar: Some(discord.avatar(guild, &message.author_id)),
        mention: message.mentions_me(
            snapshot.user_id.as_deref().unwrap_or_default(),
            server.map(|server| &*server.marks),
        ),
    }
}

/// A message as a pinned message or a search result shows it: who wrote
/// it, by their name, avatar and role colour in `server`, or for a DM with
/// none, their own; when; and what it says, and the files it carries.
/// [`with_previews`] brings its pictures.
pub(super) fn found(
    discord: &Discord,
    server: Option<&yapfast_discord::ready::Server>,
    message: &Message,
) -> ChatMessage {
    let guild = server.map(|server| server.id.as_str());
    let author = discord
        .name(
            guild.unwrap_or(yapfast_discord::ready::PRIVATE),
            &message.author_id,
        )
        .unwrap_or_else(|| message.author.clone());
    let ordinary = message.system.is_none();
    let timestamp = message.timestamp();
    let (body, mentions) = rendered(discord, server, &message.content);
    let notice = chat_notice(discord, guild, server, message);
    let system = notice
        .as_ref()
        .map(|notice| notice.text.as_str())
        .or(message.system.as_deref());
    let body = match system {
        Some(system) => system_body(&author, system),
        None if body.is_empty() && message.listen_invite == Some(true) => {
            "Listen Along invite".into()
        }
        None => body,
    };
    ChatMessage {
        id: format!("d:{}", message.id),
        item: format!("d:{}", message.id),
        application_id: message.application_id.clone(),
        interaction: message
            .interaction
            .as_ref()
            .map(|interaction| interaction.id.clone()),
        command_interaction: message
            .interaction
            .as_ref()
            .and_then(|interaction| interaction.command_interaction_id.clone()),
        command_message: message
            .interaction
            .as_ref()
            .and_then(|interaction| interaction.original_response_message_id.clone()),
        command_data: message
            .interaction
            .as_ref()
            .and_then(|interaction| interaction.data.clone()),
        interaction_info: interaction_info(discord, server, message),
        flags: message.flags,
        sender: discord::sender_id(&message.author_id),
        spoilers: true,
        avatar: Some(discord.avatar(guild, &message.author_id)),
        decoration: discord.decoration(guild, &message.author_id),
        style: discord
            .styled_name(server, &message.author_id)
            .map(|style| Arc::new(style.into())),
        color: server.and_then(|server| discord.color(server, &message.author_id)),
        role_icon: server.and_then(|server| discord.role_icon(server, &message.author_id)),
        author_joined_at: guild
            .and_then(|guild| discord.member_joined_at(guild, &message.author_id)),
        bot: message.bot,
        body,
        author,
        formatted: ordinary,
        time: crate::clock::time(timestamp),
        timestamp,
        edited: message.edited,
        attachments: message
            .attachments
            .iter()
            .filter(|attachment| attachment.shown == Shown::Message)
            .map(|attachment| Attachment {
                name: attachment.name.clone(),
                size: attachment.size,
                image: attachment.image,
                dimensions: attachment.dimensions,
                preview: None,
                preview_failed: false,
                placement: Placement::Message,
                spoiler: attachment.spoiler,
                video: attachment.video_url.is_some(),
                gif: super::gifs::favorite_gif(attachment),
                url: Some(
                    attachment
                        .link_url
                        .clone()
                        .unwrap_or_else(|| attachment.url.clone()),
                ),
                description: attachment.description.clone(),
            })
            .collect(),
        mentions,
        emoji: custom_emoji(message),
        // Shown, not voted in: its author can't end it from here either.
        poll: message.poll.as_ref().map(|poll| chat_poll(poll, false)),
        voice: chat_voice(message),
        notice,
        used: used_command(discord, guild, server, message),
        ..Default::default()
    }
}

pub(super) fn interaction_info(
    discord: &Discord,
    server: Option<&yapfast_discord::ready::Server>,
    message: &Message,
) -> Option<crate::chat::InteractionInfo> {
    use crate::chat::{InteractionInfo, InteractionInstallation};

    let interaction = message.interaction.as_ref()?;
    let guild = server.map_or(yapfast_discord::ready::PRIVATE, |server| server.id.as_str());
    let user = discord
        .name(guild, &interaction.user_id)
        .unwrap_or_else(|| interaction.user.clone());
    let installation = interaction
        .installation_guild_id
        .as_deref()
        .and_then(|id| {
            discord
                .snapshots()
                .borrow()
                .servers
                .iter()
                .find(|server| server.id == id)
                .map(|server| InteractionInstallation::Guild {
                    name: server.name.clone(),
                })
        })
        .or_else(|| {
            let id = interaction.installation_user_id.as_ref()?;
            let name = if id == &interaction.user_id {
                user.clone()
            } else {
                discord.name(guild, id)?
            };
            Some(InteractionInstallation::User {
                id: id.clone(),
                name,
            })
        });
    Some(InteractionInfo {
        user_id: interaction.user_id.clone(),
        user,
        application: message.author.clone(),
        installation,
    })
}

/// The line above an app's answer: who used which command, in `guild`'s
/// names and `server`'s colours, unless it quotes a message instead, as
/// one to a message's command or a button does.
pub(super) fn used_command(
    discord: &Discord,
    guild: Option<&str>,
    server: Option<&yapfast_discord::ready::Server>,
    message: &Message,
) -> Option<crate::chat::UsedCommand> {
    let interaction = message.interaction.as_ref()?;
    if message.reply.is_some()
        && interaction.command_type != Some(yapfast_discord::message::CHAT_INPUT)
    {
        return None;
    }
    let name = interaction.name.as_deref();
    let slash = match interaction.command_type {
        Some(yapfast_discord::message::CHAT_INPUT) => true,
        Some(_) => false,
        None => {
            name.is_some()
                && interaction.target_user.is_none()
                && interaction.target_message_id.is_none()
        }
    };
    if name.is_none() && !slash {
        return None;
    }
    let user = interaction.user_id.as_str();
    let named = |user: &str, fallback: &str| {
        discord
            .name(guild.unwrap_or(yapfast_discord::ready::PRIVATE), user)
            .unwrap_or_else(|| fallback.to_owned())
    };
    Some(crate::chat::UsedCommand {
        user: named(user, &interaction.user),
        sender: discord::sender_id(user),
        avatar: (!user.is_empty()).then(|| discord.avatar(guild, user)),
        color: server.and_then(|server| discord.color(server, user)),
        name: match name {
            Some(name) if slash => format!("/{name}"),
            Some(name) => name.to_owned(),
            None => "Slash command".into(),
        },
        // An empty slash name permits a detail lookup before a command name
        // has been supplied. Only known names can be used in the composer.
        slash: slash.then(|| {
            name.and_then(|name| name.split_whitespace().next())
                .unwrap_or_default()
                .to_owned()
        }),
        target: interaction
            .target_user
            .as_ref()
            .map(|(target, fallback)| named(target, fallback)),
    })
}

/// A Discord voice message's recording, as its card shows it.
pub(super) fn chat_voice(message: &Message) -> Option<crate::chat::VoiceMessage> {
    message
        .voice
        .as_ref()
        .map(|voice| crate::chat::VoiceMessage {
            duration_ms: voice.duration_ms,
            waveform: voice.waveform.clone(),
        })
}

/// A Discord message's notice, as the timeline marks it.
pub(super) fn chat_notice(
    discord: &Discord,
    guild: Option<&str>,
    server: Option<&yapfast_discord::ready::Server>,
    message: &Message,
) -> Option<crate::chat::Notice> {
    use crate::chat::NoticeKind;
    use yapfast_discord::message::Notice;
    let mut text = message.system.clone()?;
    let kind = match message.notice.as_ref()? {
        Notice::Pinned(id) => NoticeKind::Pinned(id.as_ref().map(|id| format!("d:{id}"))),
        Notice::Joined => NoticeKind::Joined,
        Notice::RecipientChanged { added, user, name } => {
            let guild = guild.unwrap_or(yapfast_discord::ready::PRIVATE);
            let thread = guild != yapfast_discord::ready::PRIVATE;
            let name = user
                .as_deref()
                .and_then(|user| discord.name(guild, user))
                .filter(|name| !name.trim().is_empty())
                .unwrap_or_else(|| name.clone());
            let (verb, preposition) = if *added {
                ("added", "to")
            } else {
                ("removed", "from")
            };
            let place = if thread { "thread" } else { "group" };
            text = format!("{verb} {name} {preposition} the {place}.");
            NoticeKind::RecipientChanged {
                added: *added,
                user: user.clone(),
                name,
                thread,
            }
        }
        Notice::ChannelRenamed => {
            let parent = server.and_then(|server| {
                let channel = server.channel(&message.channel_id)?;
                server.channel(channel.parent.as_deref()?)
            });
            let post = parent.is_some_and(|parent| parent.forum.is_some() || parent.media);
            let name = message.content.clone();
            if post {
                text = if name.trim().is_empty() {
                    "changed the post title.".into()
                } else {
                    format!("changed the post title: {name}")
                };
            }
            NoticeKind::ChannelRenamed { name, post }
        }
        Notice::ThreadStarted => NoticeKind::ThreadStarted,
        Notice::Call => NoticeKind::Call,
        Notice::PollResult => NoticeKind::PollResult,
    };
    Some(crate::chat::Notice { kind, text })
}

/// What a notice, such as a pin or a call, says: its author's name, then
/// what they did. A closed poll's says "Ann's poll".
pub(super) fn system_body(author: &str, system: &str) -> String {
    if system.starts_with('\'') {
        format!("{author}{system}")
    } else {
        format!("{author} {system}")
    }
}

/// A Discord poll as a message shows it; `own` is this account's, which
/// may end it.
pub(super) fn chat_poll(poll: &yapfast_discord::message::Poll, own: bool) -> Poll {
    Poll {
        question: poll.question.clone(),
        answers: poll
            .answers
            .iter()
            .map(|answer| PollAnswer {
                id: answer.id,
                text: answer.text.clone(),
                emoji: answer.emoji.as_ref().map(|(key, _)| key.clone()),
                votes: answer.votes,
                mine: answer.me,
            })
            .collect(),
        expiry: poll.expiry.map(|expiry| expiry / 1000),
        finalized: poll.finalized,
        multiselect: poll.multiselect,
        can_end: own && !poll.finalized,
    }
}

/// Gives `found`, as [`found`] made them from `messages`, the previews of
/// their first [`crate::chat::FOUND_PICTURES`] pictures each, as the timeline shows
/// them: from the previews the recent channels share, or downloaded a few
/// at a time. One that can't be had is marked so.
pub(super) async fn with_previews(
    discord: &Discord,
    previews: &SharedPreviews,
    messages: &[Message],
    found: &mut [ChatMessage],
) {
    use futures_util::StreamExt;
    let mut wanted = Vec::new();
    for (at, (message, found)) in messages.iter().zip(&*found).enumerate() {
        let shown = message
            .attachments
            .iter()
            .filter(|attachment| attachment.shown == Shown::Message);
        wanted.extend(
            shown
                .zip(&found.attachments)
                .enumerate()
                .filter(|(_, (_, attachment))| attachment.image || attachment.video)
                .filter_map(|(index, (attachment, _))| {
                    Some((at, index, attachment.preview_url.clone()?))
                })
                .take(crate::chat::FOUND_PICTURES),
        );
    }
    let cached = |url: &str| {
        previews
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .get(url)
    };
    let came: Vec<_> = futures_util::stream::iter(wanted)
        .map(|(at, index, url)| async move {
            if let Some(picture) = cached(&url) {
                return (at, index, Some(picture));
            }
            let picture = preview(discord, &url).await;
            if let Some(picture) = &picture {
                previews
                    .lock()
                    .unwrap_or_else(|poisoned| poisoned.into_inner())
                    .insert(url, picture.clone());
            }
            (at, index, picture)
        })
        .buffer_unordered(4)
        .collect()
        .await;
    for (at, index, picture) in came {
        let attachment = &mut found[at].attachments[index];
        attachment.preview_failed = picture.is_none();
        attachment.preview = picture;
    }
}

/// A picture downloaded and decoded at the timeline's preview size.
pub(super) async fn preview(discord: &Discord, url: &str) -> Option<Arc<Picture>> {
    let data = discord
        .download(url, MAX_PREVIEW_DOWNLOAD_BYTES)
        .await
        .ok()?;
    let url = url.to_owned();
    // A sticker is decoded at the size a message shows it, as Discord draws
    // it, whatever the timeline's preview size is.
    let size = if yapfast_discord::ready::is_sticker(url.as_str()) {
        let side = yapfast_discord::stickers::MESSAGE_SIZE;
        (side, side)
    } else {
        (crate::chat::PREVIEW_WIDTH, crate::chat::PREVIEW_HEIGHT)
    };
    tokio::task::spawn_blocking(move || decode(&url, &data, size))
        .await
        .ok()
        .flatten()
        .map(Arc::new)
}

/// A picture downloaded from `url`, decoded to fit `width` by `height`: as
/// Lottie when `url` is a Lottie sticker's, which nothing else is.
pub(super) fn decode(url: &str, data: &[u8], (width, height): (u32, u32)) -> Option<Picture> {
    let picture = if yapfast_discord::ready::lottie_sticker(url) {
        crate::chat::decode_lottie(data, width, height)
    } else {
        crate::chat::decode_picture(data, width, height)
    };
    picture.map(|picture| crate::discord::read_kept(url, picture))
}

/// Messages found in a room, as [`found`] shows them, with the room's server.
pub(super) fn found_in(discord: &Discord, room: &str, messages: &[Message]) -> Vec<ChatMessage> {
    let snapshot = discord.snapshots().borrow().clone();
    let server = discord::parse_room(room)
        .and_then(|(guild, _)| snapshot.servers.iter().find(|server| server.id == guild))
        .map(|server| &*server.server);
    messages
        .iter()
        .map(|message| found(discord, server, message))
        .collect()
}

/// Messages a search found in a server, or with [`yapfast_discord::ready::PRIVATE`]
/// in DMs, as [`found`] shows them, each with its room.
pub(super) fn hits_in(discord: &Discord, guild: &str, messages: &[Message]) -> Vec<SearchHit> {
    let snapshot = discord.snapshots().borrow().clone();
    let server = snapshot
        .servers
        .iter()
        .find(|server| server.id == guild)
        .map(|server| &*server.server);
    messages
        .iter()
        .map(|message| SearchHit {
            room: discord::room_id(guild, &message.channel_id),
            message: found(discord, server, message),
        })
        .collect()
}

/// The custom emoji in a message's text, embeds, components and reactions.
pub(super) fn custom_emoji(message: &Message) -> Vec<CustomEmoji> {
    let mut found = emoji_in(&message.content);
    let embed_text = message.embeds.iter().flat_map(|embed| {
        [
            &embed.provider,
            &embed.author,
            &embed.title,
            &embed.description,
            &embed.footer,
        ]
        .into_iter()
        .filter_map(Option::as_deref)
        .chain(embed.fields.iter().flat_map(|field| [&*field.name, &*field.value]))
    });
    let component_text = message.components.iter().flat_map(|card| {
        card.texts().chain(card.rows.iter().flat_map(button_emoji))
    });
    for text in embed_text.chain(component_text) {
        for emoji in emoji_in(text) {
            if !found.iter().any(|known| known.id == emoji.id) {
                found.push(emoji);
            }
        }
    }
    let reactions = message.reactions.iter().filter_map(|reaction| {
        let (_, id) = reaction.emoji.split_once(':')?;
        Some((&reaction.key, id))
    });
    let answers = message
        .poll
        .iter()
        .flat_map(|poll| &poll.answers)
        .filter_map(|answer| {
            let (key, id) = answer.emoji.as_ref()?;
            Some((key, id.as_deref()?))
        });
    for (key, id) in reactions.chain(answers) {
        if !found.iter().any(|known| known.id == id) {
            found.push(CustomEmoji {
                text: key.clone(),
                id: id.to_owned(),
                animated: false,
                usable: true,
                picture: yapfast_discord::ready::custom_emoji(
                    id,
                    false,
                    crate::chat::EMOJI_PICTURE_SIZE,
                ),
            });
        }
    }
    found
}

/// The custom emoji in Discord's markup.
fn emoji_in(content: &str) -> Vec<CustomEmoji> {
    yapfast_discord::message::custom_emoji(content)
        .into_iter()
        .map(|emoji| CustomEmoji {
            text: format!(":{}:", emoji.name),
            // Its address says whether it moves, which is how its frames come:
            // Discord serves an animated emoji as a GIF and a still one as a PNG.
            picture: yapfast_discord::ready::custom_emoji(
                &emoji.id,
                emoji.animated,
                crate::chat::EMOJI_PICTURE_SIZE,
            ),
            id: emoji.id,
            animated: emoji.animated,
            usable: true,
        })
        .collect()
}

/// Sends the open server channel's topic, as [`Event::Topic`], when it
/// opens (`opened`), and after that when the topic changes, or the names
/// of people it mentions do.
pub(super) fn send_topic(
    channel: &mut OpenChannel,
    discord: &Discord,
    events: &UnboundedSender<Event>,
    opened: bool,
) {
    if channel.guild == yapfast_discord::ready::PRIVATE {
        return;
    }
    let snapshot = discord.snapshots().borrow().clone();
    let server = snapshot
        .servers
        .iter()
        .find(|server| server.id == channel.guild)
        .map(|server| &*server.server);
    let raw = server
        .and_then(|server| {
            server
                .text_channels
                .iter()
                .find(|known| known.id == channel.channel)
        })
        .and_then(|known| known.topic.clone());
    let names = raw
        .as_deref()
        .filter(|raw| raw.contains("<@"))
        .map_or(0, |_| discord.names_version());
    let sent = (raw, names);
    if !opened && channel.topic_sent.as_ref() == Some(&sent) {
        return;
    }
    let topic = sent.0.as_deref().map(|raw| topic(discord, server, raw));
    channel.topic_sent = Some(sent);
    let _ = events.send(Event::Topic {
        room: channel.room.clone(),
        topic,
    });
}

/// A channel's topic, from Discord's markup, as Yapfast shows it.
fn topic(
    discord: &Discord,
    server: Option<&yapfast_discord::ready::Server>,
    raw: &str,
) -> Arc<Topic> {
    let (body, mentions) = rendered(discord, server, raw);
    Arc::new(Topic {
        body,
        mentions,
        emoji: emoji_in(raw),
    })
}

/// A forum's topic, its post guidelines, by server and channel id.
pub(super) fn forum_topic(discord: &Discord, guild: &str, forum: &str) -> Option<Arc<Topic>> {
    let snapshot = discord.snapshots().borrow().clone();
    let server = snapshot.servers.iter().find(|server| server.id == guild)?;
    let raw = server.channel(forum)?.topic.clone()?;
    Some(topic(discord, Some(server), &raw))
}

/// A message's body as Yapfast shows it, and who and what it mentions there.
pub(super) fn rendered(
    discord: &Discord,
    server: Option<&yapfast_discord::ready::Server>,
    content: &str,
) -> (String, Vec<Mentioned>) {
    map_rendered_mentions(server, discord.render_mentions(server, content))
}

fn rendered_with_emoji(
    discord: &Discord,
    server: Option<&yapfast_discord::ready::Server>,
    content: &str,
) -> (String, Vec<Mentioned>) {
    map_rendered_mentions(server, discord.render_rich_mentions(server, content))
}

fn map_rendered_mentions(
    server: Option<&yapfast_discord::ready::Server>,
    (body, mentions): (String, Vec<yapfast_discord::message::Mention>),
) -> (String, Vec<Mentioned>) {
    let mentions = mentions
        .into_iter()
        .map(|mention| {
            // Only a role's mention has a colour of its own, as in Discord's
            // client. A member's, like @everyone's and @here's, takes the
            // colour of mentions, not that of the member's highest role.
            let (target, color) = match mention.target {
                MentionTarget::User(id) => (Target::User(id), None),
                MentionTarget::Role(id) => {
                    let color = server
                        .and_then(|server| server.role_colors.get(&id))
                        .map(|(_, color)| *color);
                    (Target::Role(id), color)
                }
                MentionTarget::Channel(id) => {
                    let guild = server.map_or("", |server| server.id.as_str());
                    (Target::Channel(discord::room_id(guild, &id)), None)
                }
                MentionTarget::Everyone => (Target::Everyone, None),
            };
            Mentioned {
                text: mention.text,
                target,
                color,
                at: mention.at,
            }
        })
        .collect();
    (body, mentions)
}

/// The roles a message in a server channel may mention, after @everyone and @here
/// for those allowed them, then the channels it may link with `#`.
pub(super) fn mention_groups(discord: &Discord, room: &str) -> Vec<MentionGroup> {
    let Some((guild, channel)) = discord::parse_room(room) else {
        return vec![];
    };
    let snapshot = discord.snapshots().borrow().clone();
    let Some(server) = snapshot.servers.iter().find(|server| server.id == guild) else {
        return vec![];
    };
    // A voice channel's chat may mention everyone too.
    let everyone = server
        .channel(channel)
        .is_some_and(|known| known.marks.mention_everyone);
    let mut groups = Vec::new();
    if everyone {
        for name in ["everyone", "here"] {
            groups.push(MentionGroup {
                name: name.into(),
                mention: format!("@{name}"),
                color: None,
                channel: false,
                voice: false,
            });
        }
    }
    groups.extend(
        server
            .mentionable(everyone)
            .into_iter()
            .map(|(id, name, color)| MentionGroup {
                name,
                mention: format!("<@&{id}>"),
                color,
                channel: false,
                voice: false,
            }),
    );
    // Its text and voice channels this account can see, in Discord's order.
    let text = server.text_channels().map(|known| (known, false));
    let voice = server.voice_channels().map(|known| (known, true));
    groups.extend(
        text.chain(voice)
            .filter(|(known, _)| known.marks.access != Access::Hidden)
            .map(|(known, voice)| MentionGroup {
                name: known.channel.name.clone(),
                mention: format!("<#{}>", known.channel.id),
                color: None,
                channel: true,
                voice,
            }),
    );
    groups
}

/// A Discord profile as Yapfast's profile card shows it, with the server's role
/// names, colours and names known now.
/// A profile's badges, as the card shows them.
pub(super) fn chat_badges(badges: Vec<yapfast_discord::profile::Badge>) -> Vec<ProfileBadge> {
    badges
        .into_iter()
        .map(|badge| ProfileBadge {
            description: badge.description,
            icon: badge.icon,
            link: badge.link,
            level: badge.level.map(|level| ProfileBadgeLevel {
                kind: level.kind,
                title: level.title,
                progress: level.progress,
                picture: level.picture,
            }),
        })
        .collect()
}

pub(super) fn chat_profile(
    discord: &Discord,
    guild: &str,
    profile: yapfast_discord::profile::Profile,
) -> Profile {
    let snapshot = discord.snapshots().borrow().clone();
    let server = snapshot
        .servers
        .iter()
        .find(|server| server.id == guild)
        .map(|server| &*server.server);
    let bio_emoji = profile.bio.as_deref().map(emoji_in).unwrap_or_default();
    Profile {
        name: profile.name,
        avatar: Some(profile.avatar),
        decoration: discord.decoration(Some(guild), &profile.user_id),
        style: discord
            .style(Some(guild), &profile.user_id)
            .map(|style| Arc::new(style.into())),
        effect: profile.effect,
        // `chat_profile`'s caller adds the frame's layers, which the shop
        // describes.
        frame: Default::default(),
        theme: profile.theme,
        banner: profile.banner,
        accent: profile.accent,
        pronouns: profile.pronouns.unwrap_or_default(),
        bio: profile
            .bio
            .map(|bio| discord.render(server, &bio))
            .unwrap_or_default(),
        roles: server
            .map(|server| server.named_roles(&profile.roles))
            .unwrap_or_default()
            .into_iter()
            .map(|(name, color)| ProfileRole { name, color })
            .collect(),
        created: Some(crate::clock::profile_day(profile.created / 1000)),
        joined: profile
            .joined
            .map(|ms| crate::clock::profile_day(ms / 1000)),
        // The server whose date `joined` is, drawn beside it.
        server_name: server
            .filter(|_| profile.joined.is_some())
            .map(|server| server.name.clone())
            .unwrap_or_default(),
        server_icon: server
            .filter(|_| profile.joined.is_some())
            .and_then(|server| server.icon.clone()),
        servers: profile
            .mutual_servers
            .into_iter()
            .filter_map(|mutual| {
                let server = snapshot
                    .servers
                    .iter()
                    .find(|server| server.id == mutual.id)?;
                Some(ProfileServer {
                    id: discord::server_id(&server.id),
                    name: server.name.clone(),
                    icon: server.icon.clone(),
                    banner: server.banner.clone(),
                    members: server.member_count,
                    channels: server.text_channels.len() + server.voice_channels.len(),
                    nick: mutual.nick,
                })
            })
            .collect(),
        friends: profile
            .mutual_friends
            .into_iter()
            .map(|friend| ProfileFriend {
                id: friend.id,
                name: friend.name,
                avatar: Some(friend.avatar),
            })
            .collect(),
        tag: discord::server_tag(profile.tag),
        badges: chat_badges(profile.badges),
        bio_emoji,
        // The note comes with its own request; see `fill_profile`.
        note: String::new(),
        connections: profile
            .connections
            .into_iter()
            .map(|connection| ProfileConnection {
                kind: connection.kind,
                name: connection.name,
                verified: connection.verified,
                url: connection.url,
                since: connection.since.map(|ms| crate::clock::day(ms / 1000)),
            })
            .collect(),
        widgets: profile
            .widgets
            .into_iter()
            .map(|widget| crate::chat::ProfileWidget {
                title: widget.title,
                application: widget.application,
                lists_games: widget.lists_games,
                games: widget
                    .games
                    .into_iter()
                    .map(|game| crate::chat::ProfileGame {
                        id: game.id,
                        name: game.name,
                        icon: game.icon,
                        comment: game.comment,
                    })
                    .collect(),
            })
            .collect(),
        wishlist_place: profile.wishlist.map(|place| crate::chat::WishlistPlace {
            id: place.id,
            private: place.private,
        }),
        // Each tab of the full profile asks for its own when it opens.
        wishlist: Default::default(),
        board_asked: false,
        board_named: false,
        recent: Vec::new(),
        recent_asked: false,
        recent_came: false,
        handle: profile.username,
        id: profile.user_id,
        // What the member list knows; the profile doesn't say.
        presence: None,
        activity: None,
        activities: Default::default(),
    }
}

/// The emoji of a row's buttons and menu options, in Discord's markup.
fn button_emoji(row: &yapfast_discord::components::Row) -> Vec<&str> {
    use yapfast_discord::components::{Beside, Row};
    if let Row::Select { options, .. } = row {
        return options
            .iter()
            .filter_map(|option| option.emoji.as_deref())
            .collect();
    }
    let buttons = match row {
        Row::Buttons(buttons) => buttons.iter().collect(),
        Row::Text {
            beside: Some(Beside::Button(button)),
            ..
        } => vec![button],
        _ => Vec::new(),
    };
    buttons
        .into_iter()
        .filter_map(|button| button.emoji.as_deref())
        .collect()
}

/// A message's components as Yapfast shows them, their mentions written as
/// names.
pub(super) fn chat_card(
    discord: &Discord,
    server: Option<&yapfast_discord::ready::Server>,
    card: &yapfast_discord::components::Card,
) -> Card {
    use yapfast_discord::components::{Beside as DiscordBeside, Row, Style};
    let button = |button: &yapfast_discord::components::Button| CardButton {
        label: match &button.emoji {
            Some(emoji) => format!("{emoji} {}", button.label)
                .trim_end()
                .to_owned(),
            None => button.label.clone(),
        },
        style: match button.style {
            Style::Primary => ButtonStyle::Primary,
            Style::Secondary => ButtonStyle::Secondary,
            Style::Success => ButtonStyle::Success,
            Style::Danger => ButtonStyle::Danger,
            Style::Link => ButtonStyle::Link,
            Style::Premium => ButtonStyle::Premium,
        },
        url: button.url.clone(),
        custom_id: button.custom_id.clone(),
        sku_id: button.sku_id.clone(),
        disabled: button.disabled,
    };
    Card {
        framed: card.framed,
        color: card.color,
        rows: card
            .rows
            .iter()
            .map(|row| match row {
                Row::Text { text, beside } => {
                    let (text, mentions) = rendered_with_emoji(discord, server, text);
                    CardRow::Text {
                        text,
                        mentions,
                        beside: beside.as_ref().map(|beside| match beside {
                            DiscordBeside::Thumbnail(slot) => Beside::Thumbnail(*slot),
                            DiscordBeside::Button(each) => Beside::Button(button(each)),
                        }),
                    }
                }
                Row::Media(slot) => CardRow::Media(*slot),
                Row::Separator { divider, large } => CardRow::Separator {
                    divider: *divider,
                    large: *large,
                },
                Row::Buttons(buttons) => CardRow::Buttons(buttons.iter().map(button).collect()),
                Row::Select {
                    text,
                    disabled,
                    kind,
                    custom_id,
                    options,
                    defaults,
                    channel_types,
                    min_values,
                    max_values,
                } => CardRow::Select {
                    text: discord.render_rich_mentions(server, text).0,
                    disabled: *disabled,
                    kind: *kind,
                    custom_id: custom_id.clone(),
                    options: options
                        .iter()
                        .map(|option| crate::chat::CardOption {
                            label: option.label.clone(),
                            value: option.value.clone(),
                            description: option.description.clone(),
                            default: option.default,
                            emoji: option.emoji.clone(),
                        })
                        .collect(),
                    defaults: defaults.clone(),
                    channel_types: channel_types.clone(),
                    min_values: *min_values,
                    max_values: *max_values,
                },
                Row::Unknown => CardRow::Unknown,
            })
            .collect(),
    }
}

/// An embed as Yapfast shows it, its mentions written as names.
pub(super) fn chat_embed(
    discord: &Discord,
    server: Option<&yapfast_discord::ready::Server>,
    embed: &yapfast_discord::embed::Embed,
) -> Embed {
    let text = |text: &Option<String>| text.clone().unwrap_or_default();
    let (description, description_mentions) = rendered_with_emoji(
        discord,
        server,
        embed.description.as_deref().unwrap_or_default(),
    );
    Embed {
        replaced_by_invite: false,
        color: embed.color,
        provider: text(&embed.provider),
        author: text(&embed.author),
        title: text(&embed.title),
        url: text(&embed.url),
        description,
        description_mentions,
        fields: embed
            .fields
            .iter()
            .map(|field| {
                let (name, name_mentions) = rendered_with_emoji(discord, server, &field.name);
                let (value, mentions) = rendered_with_emoji(discord, server, &field.value);
                EmbedField {
                    name,
                    name_mentions,
                    value,
                    mentions,
                    inline: field.inline,
                }
            })
            .collect(),
        footer: text(&embed.footer),
        video: embed.video,
    }
}

pub(super) fn chat_member(member: ListedMember) -> ChatMember {
    ChatMember {
        bot: member.bot,
        id: member.user_id,
        name: member.name,
        username: member.username,
        role: Role::Member,
        avatar: Some(member.avatar),
        decoration: member.decoration,
        nameplate: member.nameplate.map(Into::into),
        style: member.style.map(|style| Arc::new(style.into())),
        group: Some(member.group),
        group_icon: member.group_icon,
        role_icon: member.role_icon,
        presence: Some(discord::presence(member.presence)),
        color: member.color,
        activity: member.activity,
        activities: member.activities,
        roles: member.roles,
        timed_out_until: member.timed_out_until,
        tag: discord::server_tag(member.tag),
        boosting_since: member.boosting_since,
    }
}

pub(super) fn publish(
    channel: &mut OpenChannel,
    discord: &Discord,
    done: &UnboundedSender<Done>,
    events: &UnboundedSender<Event>,
) {
    // The timeline stays as it is while the messages around one jumped to
    // are on their way.
    if channel.focusing {
        return;
    }
    let messages = channel.publish(discord, done);
    let _ = events.send(Event::Timeline {
        room: channel.room.clone(),
        messages,
    });
}

/// The Discord message id of a sent message's timeline item.
pub(super) fn sent_id(item: &str) -> Option<&str> {
    item.strip_prefix("d:")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn card_mentions_keep_canonical_user_nickname_and_thread_offsets() {
        let mut names = yapfast_discord::message::Names::default();
        names.learn_user(&serde_json::json!({"id":"2", "username":"member"}));
        names.learn_member(
            "10",
            &serde_json::json!({"user":{"id":"2","username":"member"},"nick":"Member"}),
        );
        let server = yapfast_discord::ready::server(&serde_json::json!({
            "id":"10", "properties":{"name":"Test"},
            "channels":[{"id":"11","type":0,"name":"general"}],
            "threads":[{"id":"30","type":12,"name":"ticket","parent_id":"11", "thread_metadata":{"archived":false}}]
        })).unwrap();
        let raw = "## 🧭 Route\n> <@2> / <@!2> in <#30>\nLiteral @Member #ticket; unknown <#99>.";
        let (text, mentions) =
            map_rendered_mentions(Some(&server), names.render_mentions(Some(&server), raw));
        let user = mentions
            .iter()
            .find(|mention| mention.target == Target::User("2".into()))
            .unwrap();
        assert_eq!(user.at.len(), 2);
        for at in &user.at {
            assert!(text[*at..].starts_with("@Member"));
        }
        let channel = mentions
            .iter()
            .find(|mention| mention.target == Target::Channel("discord:10:30".into()))
            .unwrap();
        assert_eq!(channel.at.len(), 1);
        assert!(text[channel.at[0]..].starts_with("#ticket"));
        assert_eq!(
            mentions.len(),
            2,
            "literal names and unknown/private threads never gain guessed targets"
        );
        let linked = crate::mention::linked(&text, &mentions, 0xabcdef);
        assert_eq!(linked.matches("yapfast:user/2").count(), 2);
        assert_eq!(linked.matches("yapfast:channel/discord:10:30").count(), 1);
        assert!(linked.contains("Literal @Member #ticket; unknown #channel."));
    }

    /// Discord serves an animated emoji as a GIF and a still one as a PNG, so
    /// the address is what gives Yapfast an animation to draw at all.
    #[test]
    fn an_animated_emoji_is_asked_for_as_a_gif() {
        let moving = emoji_in("hi <a:party:7>");
        assert!(moving[0].animated);
        assert!(
            moving[0].picture.contains("/emojis/7.gif"),
            "{}",
            moving[0].picture
        );
        let still = emoji_in("hi <:talk:8>");
        assert!(!still[0].animated);
        assert!(
            still[0].picture.contains("/emojis/8.png"),
            "{}",
            still[0].picture
        );
    }

    #[test]
    fn rich_messages_collect_embed_and_application_emoji() {
        use yapfast_discord::{components, embed};
        let message = Message {
            content: "<:guild:5>".into(),
            embeds: vec![embed::Embed {
                title: Some("<:app:6>".into()),
                description: Some("<:app:6> <a:receipt:7>".into()),
                fields: vec![embed::Field {
                    name: "<:approved:8>".into(),
                    value: "<:blocked:9>".into(),
                    inline: true,
                }],
                footer: Some("<:footer:10>".into()),
                ..Default::default()
            }],
            components: components::parse(&serde_json::json!([{
                "type": 1, "components": [
                    {"type": 2, "style": 1, "label": "Confirm", "custom_id": "yes",
                     "emoji": {"id": "11"}},
                    {"type": 2, "style": 1, "label": "Decline", "custom_id": "no",
                     "emoji": {"id": "12", "animated": true}}
                ]
            }])).cards,
            ..Default::default()
        };
        let emoji = custom_emoji(&message);
        let found: Vec<_> = emoji
            .iter()
            .map(|emoji| (emoji.id.as_str(), emoji.animated))
            .collect();
        assert_eq!(
            found,
            [
                ("5", false), ("6", false), ("7", true), ("10", false),
                ("8", false), ("9", false), ("11", false), ("12", true),
            ],
        );
    }
}
