//! Thread management uses the received thread metadata and current permissions.
//! A dialog and one pending operation are bounded; gateway updates remain the
//! source of truth for names and archive/lock state.
use super::*;
use crate::chat::{Permission, ThreadChange, ThreadEdit};

pub const THREAD_ARCHIVE_MINUTES: [u16; 4] = [60, 1440, 4320, 10080];

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ThreadDialog {
    pub room: String,
    pub name: String,
    pub slowmode: u32,
    pub archive_minutes: u16,
    pub can_slowmode: bool,
    pub deleting: bool,
    pub saving: bool,
    pub error: Option<String>,
    account: String,
    original_name: String,
    original_slowmode: u32,
    original_archive_minutes: u16,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ThreadInput {
    Name(String),
    Slowmode(u32),
    ArchiveMinutes(u16),
    Save,
    Cancel,
}

pub(super) struct Pending {
    account: String,
    room: String,
    request: String,
    dialog: bool,
}

struct Known {
    account: String,
    name: String,
    slowmode: u32,
    archive_minutes: u16,
    archived: bool,
    locked: bool,
    invitable: Option<bool>,
    creator: bool,
    manages: bool,
    reopens: bool,
}

impl Known {
    fn edits(&self) -> bool {
        !self.archived && (self.manages || self.creator && !self.locked)
    }
}

impl Application {
    fn managed_thread(&self, room: &str) -> Option<Known> {
        #[cfg(feature = "discord")]
        {
            if self.state.preview || !self.state.discord_online {
                return None;
            }
            let visible = self
                .state
                .rooms
                .iter()
                .find(|known| known.id == room && !known.locked)?;
            let (server, Some(channel), account) = self.discord_place(room)? else {
                return None;
            };
            if self.state.discord_user.as_deref() != Some(account) {
                return None;
            }
            let channel = server.channel(channel)?;
            let thread = channel.thread.as_ref()?;
            let manages = self.may(room, Permission::ManageThreads);
            let creator = thread.owner.as_deref() == Some(account);
            Some(Known {
                account: account.into(),
                name: channel.name.clone(),
                slowmode: channel.slowmode,
                archive_minutes: thread.archive_after,
                archived: thread.archived,
                locked: thread.locked,
                invitable: thread.private.then_some(thread.invitable).flatten(),
                creator,
                manages,
                reopens: manages
                    || !thread.locked && !visible.read_only && (thread.joined || creator),
            })
        }
        #[cfg(not(feature = "discord"))]
        {
            let _ = room;
            None
        }
    }

    pub(super) fn thread_management_choices(&self, room: &str) -> Vec<MenuChoice> {
        let Some(known) = self.managed_thread(room) else {
            return vec![];
        };
        let mut choices = vec![];
        if known.archived && known.reopens {
            choices.push(MenuChoice::ReopenThread);
        }
        if known.edits() {
            choices.push(MenuChoice::CloseThread);
        }
        if known.manages {
            // The documented endpoint only changes other fields while active.
            // Reopen an archived thread explicitly before changing its lock.
            if !known.archived {
                choices.push(if known.locked {
                    MenuChoice::UnlockThread
                } else {
                    MenuChoice::LockThread
                });
            }
        }
        if known.edits() {
            choices.push(MenuChoice::EditThread);
            if known.invitable.is_some() {
                choices.push(MenuChoice::ThreadInvitable);
            }
        }
        if known.manages {
            choices.push(MenuChoice::DeleteThread);
        }
        choices
    }

    pub fn thread_invitable(&self, room: &str) -> Option<bool> {
        self.managed_thread(room)?.invitable
    }

    pub(super) fn open_thread_settings(&mut self, room: String, deleting: bool) -> Vec<Effect> {
        let Some(known) = self.managed_thread(&room) else {
            return vec![];
        };
        if if deleting {
            !known.manages
        } else {
            !known.edits()
        } {
            return vec![];
        }
        self.state.thread_dialog = Some(ThreadDialog {
            room,
            name: known.name.clone(),
            slowmode: known.slowmode,
            archive_minutes: known.archive_minutes,
            can_slowmode: known.manages,
            deleting,
            saving: false,
            error: None,
            account: known.account,
            original_name: known.name,
            original_slowmode: known.slowmode,
            original_archive_minutes: known.archive_minutes,
        });
        vec![]
    }

    pub(super) fn thread_settings(&mut self, input: ThreadInput) -> Vec<Effect> {
        let Some(dialog) = self.state.thread_dialog.as_mut() else {
            return vec![];
        };
        if dialog.saving {
            return vec![];
        }
        match input {
            ThreadInput::Cancel => self.state.thread_dialog = None,
            ThreadInput::Name(name) if !dialog.deleting => {
                dialog.name = name.chars().take(THREAD_NAME_LIMIT + 1).collect();
                dialog.error = None;
            }
            ThreadInput::Slowmode(seconds) if !dialog.deleting && dialog.can_slowmode => {
                dialog.slowmode = seconds;
                dialog.error = None;
            }
            ThreadInput::ArchiveMinutes(minutes) if !dialog.deleting => {
                dialog.archive_minutes = minutes;
                dialog.error = None;
            }
            ThreadInput::Save => return self.save_thread_settings(),
            _ => {}
        }
        vec![]
    }

    fn save_thread_settings(&mut self) -> Vec<Effect> {
        let Some(dialog) = self.state.thread_dialog.as_ref().cloned() else {
            return vec![];
        };
        let known = self.managed_thread(&dialog.room);
        let valid = known.as_ref().is_some_and(|known| {
            known.account == dialog.account
                && if dialog.deleting {
                    known.manages
                } else {
                    known.edits()
                }
        });
        if !valid {
            if let Some(dialog) = &mut self.state.thread_dialog {
                dialog.error = Some(
                    "This thread or your permissions changed. Close this dialog and try again."
                        .into(),
                );
            }
            return vec![];
        }
        let known = known.unwrap();
        let mut problem = None;
        let change = if dialog.deleting {
            ThreadChange::Delete
        } else {
            let name = dialog.name.trim();
            if name.is_empty() || name.chars().count() > THREAD_NAME_LIMIT {
                problem = Some("Thread names must contain 1–100 characters.");
            }
            let mut edit = ThreadEdit::default();
            if name != dialog.original_name {
                edit.name = Some(name.to_owned());
            }
            if dialog.slowmode != dialog.original_slowmode {
                if !known.manages {
                    problem = Some("You no longer have permission to change slowmode.");
                } else if dialog.slowmode > 21_600 {
                    problem = Some("Slowmode must be between 0 seconds and 6 hours.");
                } else {
                    edit.slowmode = Some(dialog.slowmode);
                }
            }
            if dialog.archive_minutes != dialog.original_archive_minutes {
                if !THREAD_ARCHIVE_MINUTES.contains(&dialog.archive_minutes) {
                    problem = Some("Choose an inactivity duration from the list.");
                } else {
                    edit.archive_minutes = Some(dialog.archive_minutes);
                }
            }
            if problem.is_none() && edit == ThreadEdit::default() {
                self.state.thread_dialog = None;
                return vec![];
            }
            ThreadChange::Edit(edit)
        };
        if let Some(problem) = problem {
            self.state.thread_dialog.as_mut().unwrap().error = Some(problem.into());
            return vec![];
        }
        let effects = self.send_thread_change(dialog.room, change, true);
        if !effects.is_empty() {
            let dialog = self.state.thread_dialog.as_mut().unwrap();
            dialog.saving = true;
            dialog.error = None;
        }
        effects
    }

    pub(super) fn archive_thread(&mut self, room: String, archived: bool) -> Vec<Effect> {
        let Some(known) = self.managed_thread(&room) else {
            return vec![];
        };
        if known.archived == archived
            || if archived {
                !known.edits()
            } else {
                !known.reopens
            }
        {
            return vec![];
        }
        self.send_thread_change(room, ThreadChange::Archive(archived), false)
    }

    pub(super) fn lock_thread(&mut self, room: String, locked: bool) -> Vec<Effect> {
        let Some(known) = self.managed_thread(&room) else {
            return vec![];
        };
        if !known.manages || known.archived || known.locked == locked {
            return vec![];
        }
        self.send_thread_change(room, ThreadChange::Lock(locked), false)
    }

    pub(super) fn set_thread_invitable(&mut self, room: String, invitable: bool) -> Vec<Effect> {
        let Some(known) = self.managed_thread(&room) else {
            return vec![];
        };
        if !known.edits() || known.invitable.is_none_or(|current| current == invitable) {
            return vec![];
        }
        self.send_thread_change(room, ThreadChange::Invitable(invitable), false)
    }

    fn send_thread_change(
        &mut self,
        room: String,
        change: ThreadChange,
        dialog: bool,
    ) -> Vec<Effect> {
        let Some(account) = self.state.discord_user.clone() else {
            return vec![];
        };
        if self
            .thread_operation
            .as_ref()
            .is_some_and(|pending| pending.account == account)
        {
            self.state.notice = Some("Wait for the current thread change to finish.".into());
            return vec![];
        }
        let request = uuid::Uuid::new_v4().simple().to_string();
        self.thread_operation = Some(Pending {
            room: room.clone(),
            account: account.clone(),
            request: request.clone(),
            dialog,
        });
        vec![Effect::Backend(Command::Discord(
            DiscordCommand::ManageThread {
                room,
                account,
                request,
                change,
            },
        ))]
    }

    pub(super) fn thread_changed(
        &mut self,
        room: String,
        account: String,
        request: String,
        result: Result<(), String>,
    ) {
        let matches = self.thread_operation.as_ref().is_some_and(|pending| {
            pending.room == room && pending.account == account && pending.request == request
        });
        if !matches {
            return;
        }
        let pending = self.thread_operation.take().unwrap();
        if self.state.discord_user.as_deref() != Some(account.as_str()) {
            return;
        }
        let current_dialog = pending.dialog
            && self.state.thread_dialog.as_ref().is_some_and(|dialog| {
                dialog.room == room && dialog.account == account && dialog.saving
            });
        if current_dialog {
            match result {
                Ok(()) => self.state.thread_dialog = None,
                Err(error) => {
                    let dialog = self.state.thread_dialog.as_mut().unwrap();
                    dialog.saving = false;
                    dialog.error = Some(error);
                }
            }
        } else if let Err(error) = result {
            self.state.notice = Some(error);
        }
    }

    pub(super) fn sync_thread_management(&mut self) {
        if self.state.thread_dialog.as_ref().is_some_and(|dialog| {
            self.state.discord_user.as_deref() != Some(dialog.account.as_str())
                || !self
                    .state
                    .rooms
                    .iter()
                    .any(|room| room.id == dialog.room && !room.locked)
        }) {
            self.state.thread_dialog = None;
        }
        if self.thread_operation.as_ref().is_some_and(|pending| {
            self.state.discord_user.as_deref() != Some(pending.account.as_str())
        }) {
            self.thread_operation = None;
        }
    }
}
