//! This Discord account's bookmarks and reminders, kept in memory.

use chrono::{DateTime, Utc};

use super::*;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SavedMessageKind {
    Bookmark,
    Reminder,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MessageSaveState {
    pub kind: Option<SavedMessageKind>,
    pub busy: bool,
    pub eligible: bool,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SavedMessage {
    pub channel: String,
    pub message: String,
    pub guild: Option<String>,
    pub saved_at: DateTime<Utc>,
    pub due_at: Option<DateTime<Utc>>,
    pub author: String,
    pub channel_name: String,
    pub summary: String,
}

#[derive(Default)]
pub struct SavedMessages {
    pub bookmarks: Vec<SavedMessage>,
    pub reminders: Vec<SavedMessage>,
    /// All bookmarked IDs and reminders came, even when more bookmark rows remain.
    pub loaded: bool,
    pub loading: bool,
    pub has_more: bool,
    pub error: Option<String>,
    bookmark_ids: HashSet<String>,
    before: Option<DateTime<Utc>>,
    premium: Option<u8>,
    pending: Option<(String, SavedMessagesRequest)>,
    incoming: Vec<SavedMessageChange>,
}

#[derive(Clone, Debug)]
pub enum SavedMessagesRequest {
    Refresh,
    More(DateTime<Utc>),
    Save {
        channel: String,
        message: String,
        due_at: Option<DateTime<Utc>>,
        from_list: bool,
    },
    Remove {
        channel: String,
        message: String,
    },
}

#[derive(Clone, Debug)]
pub struct BookmarkPage {
    pub bookmarks: Vec<SavedMessage>,
    pub next_before: Option<DateTime<Utc>>,
    pub has_more: bool,
}

#[derive(Clone, Debug)]
pub enum SavedMessagesResult {
    Refreshed {
        bookmark_ids: HashSet<String>,
        reminders: Vec<SavedMessage>,
        page: Result<BookmarkPage, String>,
    },
    More(BookmarkPage),
    Changed(SavedMessageChange),
}

#[derive(Clone, Debug)]
pub enum SavedMessageChange {
    Kept(SavedMessage),
    Removed { channel: String, message: String },
}

// Discord snowflakes are positive u64 values, transmitted as decimal strings.
pub(crate) fn saved_message_id(id: &str) -> bool {
    id.len() <= 20
        && id.bytes().all(|byte| byte.is_ascii_digit())
        && id.parse::<u64>().is_ok_and(|id| id != 0)
}

impl SavedMessages {
    fn kind(&self, channel: &str, message: &str) -> Option<SavedMessageKind> {
        if self.bookmark_ids.contains(message) {
            Some(SavedMessageKind::Bookmark)
        } else if self
            .reminders
            .iter()
            .any(|row| row.channel == channel && row.message == message)
        {
            Some(SavedMessageKind::Reminder)
        } else {
            None
        }
    }

    fn can_create(&self) -> bool {
        // The documented feature is included with full Nitro.
        self.premium == Some(2)
    }

    fn forget(&mut self, channel: &str, message: &str) {
        self.bookmark_ids.remove(message);
        self.bookmarks
            .retain(|row| row.channel != channel || row.message != message);
        self.reminders
            .retain(|row| row.channel != channel || row.message != message);
    }

    fn change(&mut self, change: SavedMessageChange) {
        match change {
            SavedMessageChange::Kept(row) => {
                self.forget(&row.channel, &row.message);
                if row.due_at.is_some() {
                    self.reminders.push(row);
                    self.reminders.sort_by_key(|row| row.due_at);
                } else {
                    self.bookmark_ids.insert(row.message.clone());
                    self.bookmarks.push(row);
                    self.bookmarks
                        .sort_by_key(|row| std::cmp::Reverse(row.saved_at));
                }
            }
            SavedMessageChange::Removed { channel, message } => self.forget(&channel, &message),
        }
    }

    fn append(&mut self, page: BookmarkPage) {
        self.has_more =
            page.has_more && page.next_before.is_some() && self.before != page.next_before;
        self.before = page.next_before;
        for row in page.bookmarks {
            if self.bookmark_ids.contains(&row.message)
                && !self
                    .bookmarks
                    .iter()
                    .any(|kept| kept.message == row.message)
            {
                self.bookmarks.push(row);
            }
        }
        self.bookmarks
            .sort_by_key(|row| std::cmp::Reverse(row.saved_at));
    }
}

impl AppState {
    pub fn saved_messages(&self) -> &SavedMessages {
        &self.saved_messages
    }

    pub fn message_save_state(&self, item: &str) -> Option<MessageSaveState> {
        let (channel, message) = self.visible_saved_address(item)?;
        Some(MessageSaveState {
            kind: self.saved_messages.kind(channel, message),
            busy: self.saved_messages.pending.is_some(),
            eligible: self.saved_messages.can_create(),
        })
    }

    fn visible_saved_address<'a, 'b>(&'a self, item: &'b str) -> Option<(&'a str, &'b str)> {
        if self.preview || !self.discord_online || self.discord_user.is_none() {
            return None;
        }
        let message = item.strip_prefix("d:").filter(|id| saved_message_id(id))?;
        let room = self.room_of(item)?;
        let (_, channel) = discord::parse_room(room)?;
        let shown = self.message(item)?;
        if !saved_message_id(channel)
            || shown.deleted
            || shown.delivery != chat::Delivery::Sent
            || shown.flags & (64 | 128) != 0
        {
            return None;
        }
        Some((channel, message))
    }
}

impl Application {
    #[cfg(feature = "discord")]
    pub(super) fn saved_messages_online(
        &mut self,
        previous_account: Option<&str>,
        was_online: bool,
        premium: Option<u8>,
    ) -> Vec<Effect> {
        if previous_account != self.state.discord_user.as_deref() {
            self.state.saved_messages = SavedMessages::default();
        } else if !self.state.discord_online {
            self.state.saved_messages.pending = None;
            self.state.saved_messages.loading = false;
            self.state.saved_messages.incoming.clear();
        }
        let was_eligible = self.state.saved_messages.can_create();
        self.state.saved_messages.premium = premium;
        if self.state.saved_messages.can_create() && (!was_eligible || !was_online) {
            self.saved_messages_request(SavedMessagesRequest::Refresh)
        } else {
            vec![]
        }
    }

    pub(super) fn load_saved_messages(&mut self) -> Vec<Effect> {
        if self.state.saved_messages.loaded && self.state.saved_messages.error.is_none() {
            return vec![];
        }
        self.saved_messages_request(SavedMessagesRequest::Refresh)
    }

    pub(super) fn more_message_bookmarks(&mut self) -> Vec<Effect> {
        if let Some(before) = self.state.saved_messages.before
            && self.state.saved_messages.has_more
        {
            return self.saved_messages_request(SavedMessagesRequest::More(before));
        }
        vec![]
    }

    pub(super) fn save_visible_message(
        &mut self,
        item: &str,
        due_at_ms: Option<u64>,
        remove: bool,
    ) -> Vec<Effect> {
        let Some((channel, message)) = self.state.visible_saved_address(item) else {
            return vec![];
        };
        self.save_message_action(
            channel.to_owned(),
            message.to_owned(),
            due_at_ms,
            remove,
            false,
        )
    }

    pub(super) fn save_listed_message(
        &mut self,
        channel: String,
        message: String,
        due_at_ms: Option<u64>,
        remove: bool,
    ) -> Vec<Effect> {
        let saved = &self.state.saved_messages;
        if !saved
            .bookmarks
            .iter()
            .chain(&saved.reminders)
            .any(|row| row.channel == channel && row.message == message)
        {
            return vec![];
        }
        self.save_message_action(channel, message, due_at_ms, remove, true)
    }

    fn save_message_action(
        &mut self,
        channel: String,
        message: String,
        due_at_ms: Option<u64>,
        remove: bool,
        from_list: bool,
    ) -> Vec<Effect> {
        let kind = self.state.saved_messages.kind(&channel, &message);
        if remove {
            return if kind.is_some() {
                self.saved_messages_request(SavedMessagesRequest::Remove { channel, message })
            } else {
                vec![]
            };
        }
        if !self.state.saved_messages.can_create() {
            self.state.notice = Some("Saving messages on Discord requires Nitro.".into());
            return vec![];
        }
        let due_at = match due_at_ms {
            None if kind == Some(SavedMessageKind::Bookmark) => return vec![],
            None => None,
            Some(ms) => {
                let due_at = i64::try_from(ms)
                    .ok()
                    .and_then(DateTime::from_timestamp_millis);
                let Some(due_at) = due_at.filter(|time| *time > Utc::now()) else {
                    self.state.notice = Some("Choose a reminder time in the future.".into());
                    return vec![];
                };
                Some(due_at)
            }
        };
        if !self.state.saved_messages.loaded {
            self.state.notice = Some("Load your saved messages before changing them.".into());
            return self.load_saved_messages();
        }
        self.saved_messages_request(SavedMessagesRequest::Save {
            channel,
            message,
            due_at,
            from_list,
        })
    }

    fn saved_messages_request(&mut self, action: SavedMessagesRequest) -> Vec<Effect> {
        let Some(account) = self.state.discord_user.clone() else {
            return vec![];
        };
        let saved = &mut self.state.saved_messages;
        if self.state.preview || !self.state.discord_online || saved.pending.is_some() {
            return vec![];
        }
        let request = uuid::Uuid::new_v4().to_string();
        saved.loading = matches!(
            action,
            SavedMessagesRequest::Refresh | SavedMessagesRequest::More(_)
        );
        if saved.loading {
            saved.error = None;
        }
        saved.pending = Some((request.clone(), action.clone()));
        vec![Effect::Backend(Command::Discord(
            DiscordCommand::SavedMessages {
                account,
                request,
                action,
            },
        ))]
    }

    pub(super) fn receive_saved_messages(
        &mut self,
        account: String,
        request: String,
        result: Result<SavedMessagesResult, String>,
    ) -> Vec<Effect> {
        let saved = &mut self.state.saved_messages;
        if self.state.discord_user.as_deref() != Some(account.as_str())
            || !saved
                .pending
                .as_ref()
                .is_some_and(|(current, _)| current == &request)
        {
            return vec![];
        }
        let (_, action) = saved.pending.take().unwrap();
        let loading = std::mem::take(&mut saved.loading);
        match result {
            Ok(SavedMessagesResult::Refreshed {
                bookmark_ids,
                reminders,
                page,
            }) => {
                saved.bookmark_ids = bookmark_ids;
                saved.reminders = reminders;
                saved.reminders.sort_by_key(|row| row.due_at);
                saved.bookmarks.clear();
                saved.before = None;
                saved.has_more = false;
                saved.loaded = true;
                match page {
                    Ok(page) => saved.append(page),
                    Err(error) => saved.error = Some(error),
                }
            }
            Ok(SavedMessagesResult::More(page)) => saved.append(page),
            Ok(SavedMessagesResult::Changed(change)) => {
                saved.change(change);
                self.state.notice = Some(
                    match action {
                        SavedMessagesRequest::Save {
                            due_at: Some(_), ..
                        } => "Reminder set.",
                        SavedMessagesRequest::Save { .. } => "Message bookmarked.",
                        SavedMessagesRequest::Remove { .. } => "Saved message removed.",
                        _ => return vec![],
                    }
                    .into(),
                );
            }
            Err(error) if loading => saved.error = Some(error),
            Err(error) => self.state.notice = Some(error),
        }
        for change in std::mem::take(&mut saved.incoming) {
            saved.change(change);
        }
        vec![]
    }

    pub(super) fn receive_saved_message_change(
        &mut self,
        account: String,
        change: SavedMessageChange,
    ) {
        let saved = &mut self.state.saved_messages;
        if self.state.discord_user.as_deref() != Some(account.as_str()) || self.state.preview {
            return;
        }
        if saved.pending.is_some() {
            // A gateway change can supersede an HTTP response already in flight.
            if saved.incoming.len() < 256 {
                saved.incoming.push(change);
            }
        } else {
            saved.change(change);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn linked() -> Application {
        let mut app = Application::default();
        app.state.discord_user = Some("1".into());
        app.state.discord_online = true;
        app.state.selected = Some("discord:20:21".into());
        app.state.saved_messages.premium = Some(2);
        app.state.messages = Arc::new(vec![Arc::new(ChatMessage {
            item: "d:100".into(),
            ..ChatMessage::default()
        })]);
        app
    }

    fn request(effects: Vec<Effect>) -> (String, SavedMessagesRequest) {
        let [
            Effect::Backend(Command::Discord(DiscordCommand::SavedMessages {
                account,
                request,
                action,
            })),
        ] = effects.as_slice()
        else {
            panic!("one request for the linked account");
        };
        assert_eq!(account, "1");
        (request.clone(), action.clone())
    }

    fn row(message: &str, due_at: Option<DateTime<Utc>>) -> SavedMessage {
        SavedMessage {
            channel: "21".into(),
            message: message.into(),
            guild: Some("20".into()),
            saved_at: Utc::now(),
            due_at,
            author: "Fixture".into(),
            channel_name: "General".into(),
            summary: "A saved message.".into(),
        }
    }

    #[test]
    fn saved_message_bookmarks_are_known_before_older_pages_load() {
        let mut app = linked();
        let (load, action) = request(app.dispatch(Action::LoadSavedMessages));
        assert!(matches!(action, SavedMessagesRequest::Refresh));
        assert!(app.dispatch(Action::LoadSavedMessages).is_empty());
        let bookmark = row("99", None);
        app.receive_saved_messages("2".into(), load.clone(), Err("Wrong account.".into()));
        assert!(app.state.saved_messages().loading);
        app.receive_saved_messages(
            "1".into(),
            load,
            Ok(SavedMessagesResult::Refreshed {
                bookmark_ids: ["99".to_owned(), "100".to_owned()].into_iter().collect(),
                reminders: vec![],
                page: Ok(BookmarkPage {
                    next_before: Some(bookmark.saved_at),
                    bookmarks: vec![bookmark],
                    has_more: true,
                }),
            }),
        );
        assert_eq!(app.state.saved_messages().bookmarks[0].message, "99");
        let state = app.state.message_save_state("d:100").unwrap();
        assert!(state.eligible);
        assert_eq!(state.kind, Some(SavedMessageKind::Bookmark));
        assert!(
            app.dispatch(Action::BookmarkMessage("d:100".into()))
                .is_empty()
        );
        let (_, action) = request(app.dispatch(Action::MoreMessageBookmarks));
        assert!(matches!(action, SavedMessagesRequest::More(_)));
    }

    #[test]
    fn saved_message_requests_require_a_visible_sent_message_and_nitro() {
        let mut app = linked();
        app.state.saved_messages.loaded = true;
        assert!(
            app.dispatch(Action::BookmarkMessage("d:101".into()))
                .is_empty()
        );
        assert!(
            app.dispatch(Action::RemindMessage {
                item: "d:100".into(),
                due_at_ms: 0,
            })
            .is_empty()
        );
        app.state.saved_messages.premium = Some(3);
        assert!(
            app.dispatch(Action::BookmarkMessage("d:100".into()))
                .is_empty()
        );
        app.state.saved_messages.premium = Some(2);
        let (write, action) = request(app.dispatch(Action::BookmarkMessage("d:100".into())));
        assert!(matches!(action, SavedMessagesRequest::Save {
            channel, message, due_at: None, from_list: false,
        } if channel == "21" && message == "100"));
        assert_eq!(app.state.message_save_state("d:100").unwrap().kind, None);
        app.receive_saved_messages("1".into(), write, Err("Server refused.".into()));
        assert_eq!(app.state.notice.as_deref(), Some("Server refused."));
        assert_eq!(app.state.message_save_state("d:100").unwrap().kind, None);
    }

    #[test]
    fn saved_message_gateway_converts_bookmark_to_reminder_after_older_read() {
        let mut app = linked();
        let (load, _) = request(app.dispatch(Action::LoadSavedMessages));
        let reminder = row("100", Some(Utc::now() + chrono::TimeDelta::hours(1)));
        app.receive_saved_message_change("1".into(), SavedMessageChange::Kept(reminder.clone()));
        app.receive_saved_messages(
            "1".into(),
            load,
            Ok(SavedMessagesResult::Refreshed {
                bookmark_ids: ["100".to_owned()].into_iter().collect(),
                reminders: vec![],
                page: Ok(BookmarkPage {
                    bookmarks: vec![row("100", None)],
                    next_before: None,
                    has_more: false,
                }),
            }),
        );
        assert_eq!(app.state.saved_messages().reminders, [reminder]);
        assert!(app.state.saved_messages().bookmarks.is_empty());
        assert_eq!(
            app.state.message_save_state("d:100").unwrap().kind,
            Some(SavedMessageKind::Reminder)
        );
        let (_, action) = request(app.dispatch(Action::RemoveListedSavedMessage {
            channel: "21".into(),
            message: "100".into(),
        }));
        assert!(matches!(action, SavedMessagesRequest::Remove { .. }));
    }
}
