//! Portable slash invocation metadata. Pasting always revalidates the current schema.

use super::command_details::{HistoricalInvocation, HistoricalOption};
use super::*;

pub const COMMAND_CLIPBOARD_LIMIT: usize = 256 * 1024;

#[derive(Clone, serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CommandClipboard {
    version: u32,
    application: String,
    command: String,
    name: String,
    text: String,
    options: Vec<HistoricalOption>,
}

impl CommandClipboard {
    pub fn encode(&self) -> Option<Vec<u8>> {
        if !self.valid() {
            return None;
        }
        let bytes = serde_json::to_vec(self).ok()?;
        (bytes.len() <= COMMAND_CLIPBOARD_LIMIT).then_some(bytes)
    }

    pub fn decode(bytes: &[u8]) -> Option<Self> {
        if bytes.len() > COMMAND_CLIPBOARD_LIMIT {
            return None;
        }
        let parsed: Self = serde_json::from_slice(bytes).ok()?;
        parsed.valid().then_some(parsed)
    }

    pub(super) fn valid(&self) -> bool {
        let snowflake = |id: &str| {
            !id.is_empty()
                && id.len() <= 20
                && id.bytes().all(|byte| byte.is_ascii_digit())
                && id.parse::<u64>().is_ok_and(|id| id > 0)
        };
        let segment = |name: &str| {
            !name.is_empty()
                && name.chars().count() <= 32
                && !name
                    .chars()
                    .any(|character| character.is_whitespace() || character.is_control())
        };
        let mut names = HashSet::new();
        self.version == 1
            && snowflake(&self.application)
            && snowflake(&self.command)
            && (1..=3).contains(&self.name.split(' ').count())
            && self.name.split(' ').all(segment)
            && self.text.len() <= COMMAND_CLIPBOARD_LIMIT
            && !self.text.contains('\0')
            && self.text.strip_prefix('/').is_some_and(|text| {
                text.strip_prefix(&self.name)
                    .is_some_and(|rest| rest.is_empty() || rest.starts_with(char::is_whitespace))
            })
            && self.options.len() <= 25
            && self.options.iter().all(|option| {
                segment(&option.name)
                    && names.insert(option.name.as_str())
                    && match option.kind {
                        3 => option
                            .value
                            .as_str()
                            .is_some_and(|value| value.len() <= 24_000 && !value.contains('\0')),
                        4 => option.value.as_i64().is_some(),
                        5 => option.value.is_boolean(),
                        6..=9 => option.value.as_str().is_some_and(snowflake),
                        10 => option.value.as_f64().is_some_and(f64::is_finite),
                        _ => false,
                    }
            })
    }

    pub(super) fn application(&self) -> &str {
        &self.application
    }

    pub fn text(&self) -> &str {
        &self.text
    }

    pub(super) fn invocation(&self) -> HistoricalInvocation {
        HistoricalInvocation {
            name: self.name.clone(),
            command_id: Some(self.command.clone()),
            options: self.options.clone(),
        }
    }
}

impl AppState {
    pub fn command_clipboard(&self, room: &str, item: &str) -> Option<CommandClipboard> {
        let invocation = self.historical_invocation(room, item)?;
        let application = self.message(item)?.application_id.clone()?;
        let command = invocation.command_id.clone()?;
        let result = CommandClipboard {
            version: 1,
            application,
            command,
            name: invocation.name.clone(),
            text: self.command_copy_text(room, item)?.to_owned(),
            options: invocation
                .options
                .iter()
                .filter(|option| option.kind != 11)
                .cloned()
                .collect(),
        };
        result.valid().then_some(result)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn copied() -> serde_json::Value {
        serde_json::json!({
            "version": 1, "application": "500", "command": "501", "name": "snap order",
            "text": "/snap order location:75081 method:CARRYOUT",
            "options": [
                {"name":"location","kind":3,"value":"75081"},
                {"name":"method","kind":3,"value":"CARRYOUT"}
            ]
        })
    }

    #[test]
    fn slash_clipboard_round_trips_typed_options_and_rejects_invalid_payloads() {
        let json = copied();
        let parsed = CommandClipboard::decode(&serde_json::to_vec(&json).unwrap()).unwrap();
        let again = CommandClipboard::decode(&parsed.encode().unwrap()).unwrap();
        assert_eq!(again.application(), "500");
        assert_eq!(again.invocation().command_id.as_deref(), Some("501"));
        assert_eq!(again.invocation().name, "snap order");
        assert_eq!(again.invocation().options[0].value, "75081");
        for corrupt in [
            serde_json::json!({"version":2}),
            serde_json::json!({"application":"+500"}),
            serde_json::json!({"text":"/other location:75081"}),
            serde_json::json!({"options":[{"name":"image","kind":11,"value":"1024"}]}),
            serde_json::json!({"options":[{"name":"user","kind":6,"value":"<@1>"}]}),
            serde_json::json!({"unexpected":"field"}),
        ] {
            let mut value = copied();
            value
                .as_object_mut()
                .unwrap()
                .extend(corrupt.as_object().unwrap().clone());
            assert!(CommandClipboard::decode(&serde_json::to_vec(&value).unwrap()).is_none());
        }
        assert!(CommandClipboard::decode(&vec![b' '; COMMAND_CLIPBOARD_LIMIT + 1]).is_none());
    }
}
