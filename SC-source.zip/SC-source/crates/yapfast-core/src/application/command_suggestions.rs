//! Local slash-command relevance and bounded usage, never option values.

use serde::{Deserialize, Serialize};

use super::SlashCommand;

const HISTORY_LIMIT: usize = 128;

/// Favorite applications retained for slash recommendations in one account.
pub const FAVORITE_COMMAND_APPS_LIMIT: usize = 64;

/// Validates, deduplicates and bounds application IDs without retaining any
/// account identity. The UI owns per-account storage and passes an empty list
/// when switching to an account without preferences.
pub fn normalize_favorite_command_apps(apps: Vec<String>) -> Vec<String> {
    let mut kept = Vec::new();
    for app in apps {
        if app.is_empty()
            || app.len() > 20
            || app.starts_with('0')
            || !app.bytes().all(|byte| byte.is_ascii_digit())
            || app.parse::<u64>().is_err()
            || kept.contains(&app)
        {
            continue;
        }
        kept.push(app);
        if kept.len() == FAVORITE_COMMAND_APPS_LIMIT {
            break;
        }
    }
    kept
}

fn valid_identity(app: &str, command: &str, path: &[String]) -> bool {
    let id =
        |id: &str| !id.is_empty() && id.len() <= 20 && id.bytes().all(|byte| byte.is_ascii_digit());
    id(app)
        && id(command)
        && path.len() <= 2
        && path.iter().all(|part| {
            !part.is_empty() && part.chars().count() <= 32 && !part.contains(char::is_whitespace)
        })
}

/// Local command identities and counts, oldest first. The UI persists this
/// separately for each Discord account; no query, option, message or token
/// belongs here. Loading through `AppState::set_command_history` validates it.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct CommandHistory {
    #[serde(default)]
    entries: Vec<CommandUse>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
struct CommandUse {
    app: String,
    command: String,
    path: Vec<String>,
    count: u32,
}

impl CommandHistory {
    /// Discards malformed/duplicate identities and keeps only the newest 128.
    pub fn normalized(mut self) -> Self {
        self.normalize();
        self
    }

    pub(super) fn normalize(&mut self) {
        let mut kept = Vec::<CommandUse>::new();
        for entry in self.entries.drain(..).rev() {
            if kept.len() == HISTORY_LIMIT {
                break;
            }
            if !valid_identity(&entry.app, &entry.command, &entry.path)
                || entry.count == 0
                || kept.iter().any(|other| {
                    other.app == entry.app
                        && other.command == entry.command
                        && other.path == entry.path
                })
            {
                continue;
            }
            kept.push(entry);
        }
        kept.reverse();
        self.entries = kept;
    }

    pub(super) fn record(&mut self, app: &str, command: &str, path: &[String]) {
        if !valid_identity(app, command, path) {
            return;
        }
        let previous = self
            .entries
            .iter()
            .position(|entry| entry.app == app && entry.command == command && entry.path == path);
        let count = previous
            .map(|at| self.entries.remove(at).count.saturating_add(1))
            .unwrap_or(1);
        if self.entries.len() == HISTORY_LIMIT {
            self.entries.remove(0);
        }
        self.entries.push(CommandUse {
            app: app.to_owned(),
            command: command.to_owned(),
            path: path.to_vec(),
            count,
        });
    }

    fn weight(&self, command: &SlashCommand) -> u32 {
        self.entries
            .iter()
            .rev()
            .enumerate()
            .find(|(_, entry)| {
                entry.app == command.app
                    && entry.command == command.command
                    && entry.path == command.path
            })
            .map(|(age, entry)| {
                // Recent use matters immediately; frequent commands keep a
                // modest advantage without permanently owning the first row.
                entry.count.min(8) * 4 + 32u32.saturating_sub(age as u32)
            })
            .unwrap_or(0)
    }

    pub(super) fn rank(
        &self,
        commands: Vec<SlashCommand>,
        query: &str,
        favorite_apps: &[String],
    ) -> Vec<SlashCommand> {
        let query = query
            .split_whitespace()
            .collect::<Vec<_>>()
            .join(" ")
            .to_lowercase();
        // A command path has at most three 32-character names. Long pasted
        // text is not a fuzzy-search workload.
        if query.chars().count() > 98 {
            return vec![];
        }
        let mut ranked: Vec<_> = commands
            .into_iter()
            .filter_map(|command| {
                relevance(&command.name.to_lowercase(), &query).map(|relevance| {
                    (
                        relevance,
                        favorite_apps.contains(&command.app),
                        self.weight(&command),
                        command,
                    )
                })
            })
            .collect();
        // Stable sorting retains the server index order for equally useful
        // commands, including a fresh account's empty picker.
        ranked.sort_by(|a, b| a.0.cmp(&b.0).then(b.1.cmp(&a.1)).then(b.2.cmp(&a.2)));
        ranked
            .into_iter()
            .map(|(_, _, _, command)| command)
            .collect()
    }
}

/// Strong name matches always precede history and fuzzy matches. Fuzzy
/// matching is deliberately unavailable for one- and two-letter queries.
fn relevance(name: &str, query: &str) -> Option<(u8, usize)> {
    if query.is_empty() || name == query {
        return Some((0, 0));
    }
    if name.starts_with(query) {
        return Some((1, 0));
    }
    let words: Vec<_> = name
        .split([' ', '-', '_'])
        .filter(|word| !word.is_empty())
        .collect();
    if words.iter().any(|word| word.starts_with(query)) {
        return Some((2, 0));
    }
    let terms: Vec<_> = query.split_whitespace().collect();
    if terms.len() > 1 {
        let mut remaining = words.iter();
        if terms
            .iter()
            .all(|term| remaining.any(|word| word.starts_with(term)))
        {
            return Some((3, 0));
        }
    }
    let typed: Vec<_> = query.chars().collect();
    if typed.len() >= 2 && name.contains(query) {
        return Some((4, 0));
    }
    if typed.len() < 3 {
        return None;
    }
    // One mistyped, omitted, extra or transposed character in a complete
    // name/word; normal partial names are covered by the stronger prefixes.
    if std::iter::once(name)
        .chain(words.iter().copied())
        .any(|word| one_typo(&typed, word))
    {
        return Some((5, 0));
    }
    // Abbreviations such as "cfg" and "png" stay useful, but very sparse
    // matches and a single letter somewhere in a long name do not appear.
    let mut next = 0;
    let mut first = None;
    for (at, letter) in name.chars().enumerate() {
        if letter == typed[next] {
            first.get_or_insert(at);
            next += 1;
            if next == typed.len() {
                let span = at - first.unwrap_or(at) + 1;
                return (span <= typed.len() * 3).then_some((6, span - typed.len()));
            }
        }
    }
    None
}

fn one_typo(typed: &[char], word: &str) -> bool {
    let word: Vec<_> = word.chars().collect();
    if typed.len().abs_diff(word.len()) > 1 {
        return false;
    }
    let first = typed.iter().zip(&word).position(|(a, b)| a != b);
    let Some(at) = first else {
        return true;
    };
    match typed.len().cmp(&word.len()) {
        std::cmp::Ordering::Less => typed[at..] == word[at + 1..],
        std::cmp::Ordering::Greater => typed[at + 1..] == word[at..],
        std::cmp::Ordering::Equal => {
            typed[at + 1..] == word[at + 1..]
                || (at + 1 < typed.len()
                    && typed[at] == word[at + 1]
                    && typed[at + 1] == word[at]
                    && typed[at + 2..] == word[at + 2..])
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn command(id: &str, name: &str) -> SlashCommand {
        SlashCommand {
            command: id.into(),
            path: name.split_whitespace().skip(1).map(str::to_owned).collect(),
            name: name.into(),
            description: String::new(),
            app: "500".into(),
            app_name: "Test app".into(),
            app_icon: None,
        }
    }

    #[test]
    fn favorite_command_apps_rank_after_text_relevance_before_usage() {
        let exact = command("1", "ping");
        let mut favorite_exact = command("2", "ping");
        favorite_exact.app = "600".into();
        let mut favorite_prefix = command("3", "ping-status");
        favorite_prefix.app = "600".into();
        let mut favorite_typo = command("4", "pin");
        favorite_typo.app = "600".into();
        let commands = vec![exact, favorite_typo, favorite_prefix, favorite_exact];
        let mut history = CommandHistory::default();
        for _ in 0..100 {
            history.record("500", "1", &[]);
        }
        let favorite = vec!["600".into()];
        let ids =
            |rows: Vec<SlashCommand>| rows.into_iter().map(|row| row.command).collect::<Vec<_>>();
        assert_eq!(
            ids(history.rank(commands.clone(), "ping", &favorite)),
            ["2", "1", "3", "4"],
            "a favorite wins equal matches, never a worse match over an exact name"
        );
        assert_eq!(
            ids(history.rank(commands.clone(), "", &favorite)),
            ["4", "3", "2", "1"],
            "favorites lead bare-slash recommendations, with stable equal-use order"
        );
        assert_eq!(history.rank(commands.clone(), "", &[])[0].command, "1");
        assert!(history.rank(commands, "unrelated", &favorite).is_empty());
    }

    #[test]
    fn favorite_command_apps_normalization_is_bounded_and_deduplicated() {
        let mut apps = [
            "",
            "0",
            "01",
            "1",
            "1",
            "-2",
            "bot",
            "18446744073709551616",
            "18446744073709551615",
        ]
        .into_iter()
        .map(str::to_owned)
        .collect::<Vec<_>>();
        apps.extend((2..200).map(|id| id.to_string()));
        let kept = normalize_favorite_command_apps(apps);
        assert_eq!(kept.len(), FAVORITE_COMMAND_APPS_LIMIT);
        assert_eq!(&kept[..2], &["1", "18446744073709551615"]);
        assert_eq!(kept.last().unwrap(), "63");
        assert_eq!(normalize_favorite_command_apps(kept.clone()), kept);
        assert!(normalize_favorite_command_apps(vec![]).is_empty());
    }

    #[test]
    fn slash_suggestions_rank_exact_and_prefix_before_history_or_fuzzy() {
        let commands = vec![
            command("1", "pin"),
            command("2", "ping-status"),
            command("3", "moderation ping"),
            command("4", "ping"),
            command("5", "shipping"),
        ];
        let mut history = CommandHistory::default();
        for _ in 0..50 {
            history.record("500", "1", &[]);
            history.record("500", "3", &["ping".into()]);
        }
        let ranked: Vec<_> = history
            .rank(commands, "ping", &[])
            .into_iter()
            .map(|row| row.name)
            .collect();
        assert_eq!(
            ranked,
            ["ping", "ping-status", "moderation ping", "shipping", "pin"]
        );
        assert_eq!(
            relevance("ping", "pnig"),
            Some((5, 0)),
            "transposed letters"
        );
        assert_eq!(relevance("ping", "png"), Some((5, 0)), "omitted letter");
        assert_eq!(
            relevance("config get", "cfg gt"),
            Some((6, 4)),
            "compact abbreviation"
        );
        assert_eq!(relevance("config get", "con g"), Some((3, 0)));
        assert_eq!(
            relevance("ping", "pg"),
            None,
            "short fuzzy queries are noisy"
        );
        assert_eq!(relevance("music play", "xyz"), None);
        assert_eq!(
            relevance("設定", "設"),
            Some((1, 0)),
            "Unicode prefixes remain supported"
        );
    }

    #[test]
    fn slash_suggestions_combine_recency_frequency_and_separate_identities() {
        let first = command("1", "config get");
        let second = command("1", "config set");
        let mut other_app = first.clone();
        other_app.app = "600".into();
        let commands = vec![first.clone(), second.clone(), other_app.clone()];
        let mut history = CommandHistory::default();
        assert_eq!(
            history.rank(commands.clone(), "", &[]),
            commands,
            "fresh index order is stable"
        );
        history.record("500", "1", &second.path);
        assert_eq!(history.rank(commands.clone(), "", &[])[0], second);
        history.record("600", "1", &first.path);
        assert_eq!(
            history.rank(commands.clone(), "", &[])[0],
            other_app,
            "most recent equal use wins"
        );
        for _ in 0..3 {
            history.record("500", "1", &second.path);
        }
        history.record("500", "1", &first.path);
        assert_eq!(
            history.rank(commands, "", &[])[0],
            second,
            "frequent use also matters"
        );
    }

    #[test]
    fn slash_suggestions_history_is_bounded_and_validates_restored_data() {
        let mut history = CommandHistory::default();
        for id in 0..200 {
            history.record("500", &id.to_string(), &[]);
        }
        assert_eq!(history.entries.len(), HISTORY_LIMIT);
        assert_eq!(history.entries[0].command, "72");
        history.record("500", "72", &[]);
        assert_eq!(history.entries.len(), HISTORY_LIMIT);
        assert_eq!(history.entries.last().unwrap().count, 2);
        let serialized = serde_json::to_value(&history).unwrap();
        let mut restored: CommandHistory = serde_json::from_value(serialized).unwrap();
        restored.entries.push(CommandUse {
            app: "not an id".into(),
            command: "1".into(),
            path: vec![],
            count: 1,
        });
        restored.entries.push(CommandUse {
            app: "500".into(),
            command: "1".into(),
            path: vec!["x".repeat(33)],
            count: 1,
        });
        restored.entries.push(restored.entries[0].clone());
        restored.normalize();
        assert_eq!(restored.entries.len(), HISTORY_LIMIT);
        assert_eq!(
            restored.entries.last().unwrap().command,
            "73",
            "duplicate keeps newest position"
        );
        assert!(
            restored
                .entries
                .iter()
                .all(|entry| entry.app == "500" && entry.path.is_empty())
        );
        assert!(
            restored
                .rank(vec![command("1", "ping")], &"p".repeat(1000), &[])
                .is_empty()
        );
    }
}
