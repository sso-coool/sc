//! On-hover command contents from Discord's read-only interaction-data
//! endpoint. This small memory-only cache is separate from recommendations
//! and from message storage, so option values never become preferences.

use super::*;
use serde_json::Value;
use std::time::{Duration, Instant};

const DETAILS_KEPT: usize = 32;
const DETAILS_PENDING: usize = 4;
const DETAIL_CHARS: usize = 16_384;
const VALUE_CHARS: usize = 6000;
const RETRY_AFTER: Duration = Duration::from_secs(30);

#[derive(Default)]
pub(super) struct CommandDetails {
    account: Option<String>,
    entries: Vec<Detail>,
}

struct Detail {
    room: String,
    item: String,
    interaction: String,
    source_interaction: String,
    original_message: Option<String>,
    request: String,
    result: DetailResult,
    retry_at: Option<Instant>,
}

enum DetailResult {
    Loading(String),
    Verified(VerifiedDetail),
    Unavailable(String),
}

struct VerifiedDetail {
    text: String,
    name_len: usize,
}

impl Detail {
    fn pending(&self) -> bool {
        matches!(self.result, DetailResult::Loading(_))
    }
}

impl AppState {
    /// Details already read for this reply; no fetch and no stored arguments
    /// in a message row. A changed/replaced interaction cannot reuse them.
    pub fn command_detail(&self, room: &str, item: &str) -> Option<&str> {
        Some(match &self.command_detail_entry(room, item)?.result {
            DetailResult::Loading(text) | DetailResult::Unavailable(text) => text,
            DetailResult::Verified(detail) => &detail.text,
        })
    }

    /// The submitted command as returned by Discord for this response, for copying.
    pub fn command_copy_text(&self, room: &str, item: &str) -> Option<&str> {
        match &self.command_detail_entry(room, item)?.result {
            DetailResult::Verified(detail) => Some(&detail.text),
            DetailResult::Loading(_) | DetailResult::Unavailable(_) => None,
        }
    }

    /// The verified slash command path, including its leading slash.
    pub fn command_verified_name(&self, room: &str, item: &str) -> Option<&str> {
        match &self.command_detail_entry(room, item)?.result {
            DetailResult::Verified(detail) => Some(&detail.text[..detail.name_len]),
            DetailResult::Loading(_) | DetailResult::Unavailable(_) => None,
        }
    }

    /// Whether this response has a command-details read in flight.
    pub fn command_detail_pending(&self, room: &str, item: &str) -> bool {
        self.command_detail_entry(room, item)
            .is_some_and(Detail::pending)
    }

    /// Whether this visible Discord response identifies a slash invocation.
    pub fn can_inspect_command(&self, room: &str, item: &str) -> bool {
        !self.preview
            && discord::parse_room(room).is_some()
            && self.room_of(item).map(String::as_str) == Some(room)
            && item.strip_prefix("d:").is_some_and(snowflake)
            && self.message(item).is_some_and(|message| {
                message
                    .used
                    .as_ref()
                    .is_some_and(|used| used.slash.is_some())
                    && message.interaction.as_deref().is_some_and(snowflake)
                    && command_interaction(message).is_some()
            })
    }

    fn command_detail_entry(&self, room: &str, item: &str) -> Option<&Detail> {
        if self.command_details.account != self.discord_user
            || !self.can_inspect_command(room, item)
        {
            return None;
        }
        let message = self.message(item)?;
        self.command_details.entries.iter().find(|entry| {
            entry.room == room
                && entry.item == item
                && message.interaction.as_deref() == Some(entry.interaction.as_str())
                && command_interaction(message) == Some(entry.source_interaction.as_str())
                && original_message(message) == entry.original_message.as_deref()
        })
    }
}

impl Application {
    pub(super) fn inspect_command(&mut self, room: String, item: String) -> Vec<Effect> {
        if !self.state.can_inspect_command(&room, &item) {
            return vec![];
        }
        let Some(message) = self.state.message(&item) else {
            return vec![];
        };
        let command_name = message
            .used
            .as_ref()
            .map(|used| used.name.clone())
            .unwrap_or_default();
        let Some(interaction) = message.interaction.clone() else {
            return vec![];
        };
        let Some(source_interaction) = command_interaction(message).map(str::to_owned) else {
            return vec![];
        };
        let original_message = original_message(message).map(str::to_owned);
        let inline = message
            .command_data
            .as_deref()
            .filter(|value| detail_matches_invocation(value, &source_interaction))
            .and_then(verified_detail);
        if inline.is_none() && !self.state.discord_online {
            return vec![];
        }
        let Some(account) = self.state.discord_user.clone() else {
            return vec![];
        };
        if self.state.command_details.account.as_ref() != Some(&account) {
            self.state.command_details = CommandDetails {
                account: Some(account.clone()),
                ..Default::default()
            };
        }
        let entries = &mut self.state.command_details.entries;
        if let Some(entry) = entries.iter_mut().find(|entry| {
            entry.room == room
                && entry.item == item
                && entry.interaction == interaction
                && entry.source_interaction == source_interaction
                && entry.original_message == original_message
        }) {
            if let Some(detail) = inline {
                entry.result = DetailResult::Verified(detail);
                entry.retry_at = None;
                return vec![];
            }
            if entry.retry_at.is_none_or(|retry| Instant::now() < retry) {
                return vec![];
            }
        }
        if inline.is_none()
            && entries.iter().filter(|entry| entry.pending()).count() >= DETAILS_PENDING
        {
            return vec![];
        }
        entries.retain(|entry| entry.room != room || entry.item != item);
        if entries.len() >= DETAILS_KEPT {
            // A pending answer retains its slot; only completed attempts leave.
            if let Some(at) = entries.iter().position(|entry| !entry.pending()) {
                entries.remove(at);
            }
        }
        let request = uuid::Uuid::new_v4().simple().to_string();
        let needs_fetch = inline.is_none();
        entries.push(Detail {
            room: room.clone(),
            item: item.clone(),
            interaction: interaction.clone(),
            source_interaction,
            original_message: original_message.clone(),
            request: request.clone(),
            result: inline.map_or_else(
                || DetailResult::Loading(format!("{command_name}\nLoading command options…")),
                DetailResult::Verified,
            ),
            retry_at: None,
        });
        if !needs_fetch {
            return vec![];
        }
        vec![Effect::Backend(Command::Discord(
            DiscordCommand::CommandDetails {
                room,
                item,
                original_message,
                request,
                account,
                interaction,
            },
        ))]
    }

    pub(super) fn receive_command_details(
        &mut self,
        room: &str,
        item: &str,
        request: &str,
        account: &str,
        interaction: &str,
        result: Result<Value, String>,
    ) {
        if self.state.discord_user.as_deref() != Some(account)
            || self.state.command_details.account.as_deref() != Some(account)
        {
            return;
        }
        let command_name = self
            .state
            .message(item)
            .and_then(|message| message.used.as_ref())
            .map(|used| used.name.clone())
            .unwrap_or_default();
        let Some(entry) = self.state.command_details.entries.iter_mut().find(|entry| {
            entry.room == room
                && entry.item == item
                && entry.request == request
                && entry.interaction == interaction
                && entry.pending()
        }) else {
            return;
        };
        // Only the matching response may supply historical options.
        // Failures use fixed descriptions: raw server prose can contain values.
        let (why, retry, status) = match result {
            Ok(value) if value.is_null() => (
                "Discord returned no command metadata for this message.",
                false,
                None,
            ),
            Ok(value) if !detail_matches_invocation(&value, &entry.source_interaction) => (
                "Discord returned missing or mismatched interaction metadata.",
                true,
                None,
            ),
            Ok(value) => {
                if let Some(detail) = verified_detail(&value) {
                    entry.result = DetailResult::Verified(detail);
                    entry.retry_at = None;
                    return;
                }
                (
                    "Discord returned incomplete or unsupported command options.",
                    true,
                    None,
                )
            }
            Err(reason) => {
                let status = safe_status(&reason);
                let terminal = status.as_deref().is_some_and(|status| {
                    matches!(
                        status.split(',').next(),
                        Some("HTTP 403" | "HTTP 404" | "HTTP 410")
                    )
                });
                (
                    if terminal {
                        "Discord did not make this message's command metadata available to this account."
                    } else {
                        "The command details request could not complete."
                    },
                    !terminal,
                    status,
                )
            }
        };
        entry.retry_at = retry.then(|| Instant::now() + RETRY_AFTER);
        let status = status
            .map(|status| format!(" ({status})"))
            .unwrap_or_default();
        let retry = if retry {
            " Hover again after 30 seconds to retry."
        } else {
            ""
        };
        entry.result = DetailResult::Unavailable(format!(
            "{command_name}\nCommand options couldn't be loaded{status}. {why}{retry}"
        ));
    }
}

fn snowflake(id: &str) -> bool {
    !id.is_empty()
        && id.len() <= 20
        && id.bytes().all(|byte| byte.is_ascii_digit())
        && id.parse::<u64>().is_ok_and(|id| id != 0)
}

fn command_interaction(message: &ChatMessage) -> Option<&str> {
    message
        .command_interaction
        .as_deref()
        .or(message.interaction.as_deref())
        .filter(|id| snowflake(id))
}

fn original_message(message: &ChatMessage) -> Option<&str> {
    message
        .command_message
        .as_deref()
        .filter(|id| snowflake(id) && Some(*id) != message.item.strip_prefix("d:"))
}

fn detail_matches_invocation(value: &Value, expected: &str) -> bool {
    if let Some(explicit) = value.get("interaction_id") {
        return explicit.as_str() == Some(expected);
    }
    let Some(id) = value["id"].as_str().filter(|id| snowflake(id)) else {
        return false;
    };
    if id == expected {
        return true;
    }
    // Discord also uses the underlying application command as the root of
    // the interaction-data envelope. That ID identifies the definition, not
    // an invocation. Only accept this form with an independently supplied
    // matching definition ID. The exact message request supplies the scope.
    value["application_command"]["id"].as_str() == Some(id)
        && value["application_command"]["type"].as_u64() == Some(1)
}

/// Display numeric status only; never free-form transport/server prose.
fn safe_status(reason: &str) -> Option<String> {
    let body = reason.split_once("(HTTP ")?.1.split_once(')')?.0;
    let (status, code) = body
        .split_once(", code ")
        .map_or((body, None), |(s, c)| (s, Some(c)));
    if status.len() != 3 || !status.bytes().all(|b| b.is_ascii_digit()) {
        return None;
    }
    let status = status
        .parse::<u16>()
        .ok()
        .filter(|status| (100..=599).contains(status))?;
    let code = match code {
        Some(code)
            if code.len() <= 20 && !code.is_empty() && code.bytes().all(|b| b.is_ascii_digit()) =>
        {
            Some(code.parse::<u64>().ok()?)
        }
        Some(_) => return None,
        None => None,
    };
    Some(match code {
        Some(code) => format!("HTTP {status}, code {code}"),
        None => format!("HTTP {status}"),
    })
}

fn plain(value: &str, limit: usize) -> String {
    value
        .chars()
        .take(limit)
        .map(|c| if c.is_control() { ' ' } else { c })
        .collect()
}

fn verified_detail(value: &Value) -> Option<VerifiedDetail> {
    // Type 2 is an application command invocation. Type 1 is the chat
    // command envelope. In particular a modal submission (5) cannot
    // provide the options of the slash command that originally opened it.
    if value["type"]
        .as_u64()
        .is_some_and(|kind| !matches!(kind, 1 | 2))
    {
        return None;
    }
    let name = value["name"]
        .as_str()
        .filter(|name| !name.is_empty())
        .or_else(|| {
            value["application_command"]["name"]
                .as_str()
                .filter(|name| !name.is_empty())
        })?;
    if value["application_command"]["type"]
        .as_u64()
        .is_some_and(|kind| kind != 1)
    {
        return None;
    }
    // An omitted options member is legitimate for a command with no supplied
    // arguments, but only its returned schema can establish that. A malformed
    // or incomplete answer must not poison this message's cache as just /name.
    let schema = value
        .get("application_command")
        .filter(|schema| schema.is_object());
    let empty = Value::Array(vec![]);
    let options = match value.get("options") {
        Some(options) if options.is_array() => options,
        None if schema
            .is_some_and(|schema| schema["name"].as_str() == name.split_whitespace().next()) =>
        {
            &empty
        }
        _ => return None,
    };
    if !valid_options(options, 0)
        || (!has_values(options)
            && schema.is_some_and(|schema| !required_options_present(schema, name, options)))
    {
        return None;
    }
    format_detail(name, options)
}

fn has_values(options: &Value) -> bool {
    options.as_array().into_iter().flatten().any(|option| {
        if matches!(option["type"].as_u64(), Some(1 | 2)) {
            has_values(&option["options"])
        } else {
            matches!(
                option["value"],
                Value::String(_) | Value::Number(_) | Value::Bool(_)
            )
        }
    })
}

fn valid_options(options: &Value, depth: usize) -> bool {
    let Some(options) = options.as_array() else {
        return false;
    };
    depth <= 2
        && options.len() <= 25
        && options.iter().all(|option| {
            option["name"].as_str().is_some_and(|name| !name.is_empty())
                && if matches!(option["type"].as_u64(), Some(1 | 2)) {
                    valid_options(&option["options"], depth + 1)
                } else {
                    matches!(
                        option["value"],
                        Value::String(_) | Value::Number(_) | Value::Bool(_)
                    )
                }
        })
}

fn required_options_present(schema: &Value, name: &str, supplied: &Value) -> bool {
    let mut definitions = schema
        .get("options")
        .and_then(Value::as_array)
        .map(Vec::as_slice)
        .unwrap_or(&[]);
    // The returned name is the complete command path. Its options may either
    // retain the nested path or already be the selected leaf's arguments.
    let mut values = supplied;
    let mut supplied_path = Vec::new();
    for _ in 0..2 {
        let Some(branch) = values
            .as_array()
            .and_then(|values| values.first())
            .filter(|branch| matches!(branch["type"].as_u64(), Some(1 | 2)))
        else {
            break;
        };
        if let Some(name) = branch["name"].as_str() {
            supplied_path.push(name);
        }
        values = &branch["options"];
    }
    let named_path: Vec<_> = name.split_whitespace().skip(1).take(2).collect();
    let path = if named_path.is_empty() {
        &supplied_path
    } else {
        &named_path
    };
    for part in path {
        let Some(branch) = definitions.iter().find(|option| {
            option["name"].as_str() == Some(*part) && matches!(option["type"].as_u64(), Some(1 | 2))
        }) else {
            return false;
        };
        definitions = branch
            .get("options")
            .and_then(Value::as_array)
            .map(Vec::as_slice)
            .unwrap_or(&[]);
    }
    if definitions
        .iter()
        .any(|option| matches!(option["type"].as_u64(), Some(1 | 2)))
    {
        return false;
    }
    let values = values.as_array().map(Vec::as_slice).unwrap_or(&[]);
    definitions
        .iter()
        .filter(|option| option["required"].as_bool() == Some(true))
        .all(|required| {
            values
                .iter()
                .any(|value| value["name"].as_str() == required["name"].as_str())
        })
}

#[cfg(test)]
fn detail_text(value: &Value) -> Option<String> {
    verified_detail(value).map(|detail| detail.text)
}

fn format_detail(name: &str, options: &Value) -> Option<VerifiedDetail> {
    if name.is_empty() {
        return None;
    }
    let mut text = format!("/{}", plain(name, 98));
    // The read endpoint names the full path and can return nested options.
    let mut branch = options;
    let mut path = Vec::new();
    for _ in 0..2 {
        let Some(option) = branch.as_array().and_then(|options| options.first()) else {
            break;
        };
        if !matches!(option["type"].as_u64(), Some(1 | 2)) {
            break;
        }
        let Some(name) = option["name"].as_str() else {
            break;
        };
        path.push(name);
        branch = &option["options"];
    }
    let named: Vec<_> = name.split_whitespace().skip(1).take(2).collect();
    if path.starts_with(&named) {
        for part in path.iter().skip(named.len()) {
            text.push(' ');
            text.push_str(&plain(part, 32));
        }
    }
    let name_len = text.len();
    let mut remaining = 25;
    fn append(options: &Value, depth: usize, remaining: &mut usize, text: &mut String) {
        if depth > 2 || *remaining == 0 {
            return;
        }
        for option in options.as_array().into_iter().flatten().take(25) {
            if *remaining == 0 || text.chars().count() > DETAIL_CHARS {
                break;
            }
            if matches!(option["type"].as_u64(), Some(1 | 2)) {
                append(&option["options"], depth + 1, remaining, text);
                continue;
            }
            let Some(name) = option["name"].as_str() else {
                continue;
            };
            let value = match &option["value"] {
                Value::String(value) => {
                    let mut shown = plain(value, VALUE_CHARS);
                    if value.chars().nth(VALUE_CHARS).is_some() {
                        shown.push('…');
                    }
                    shown
                }
                Value::Number(value) => value.to_string(),
                Value::Bool(value) => value.to_string(),
                _ => continue,
            };
            text.push_str(&format!("  {}: {}", plain(name, 32), value));
            *remaining -= 1;
        }
    }
    append(options, 0, &mut remaining, &mut text);
    if text.chars().count() > DETAIL_CHARS {
        text = text
            .chars()
            .take(DETAIL_CHARS - 1)
            .chain(std::iter::once('…'))
            .collect();
    }
    Some(VerifiedDetail { text, name_len })
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    const ROOM: &str = "discord:10:21";

    fn app() -> Application {
        let mut app = Application::default();
        app.state.discord_online = true;
        app.state.discord_user = Some("1".into());
        app.state.selected = Some(ROOM.into());
        app.state.messages = Arc::new(vec![Arc::new(ChatMessage {
            id: "d:100".into(),
            item: "d:100".into(),
            interaction: Some("900".into()),
            used: Some(chat::UsedCommand {
                user: "Alice".into(),
                sender: "discord:1".into(),
                avatar: None,
                color: None,
                name: "/fetch".into(),
                slash: Some("fetch".into()),
                target: None,
            }),
            ..Default::default()
        })]);
        app
    }

    fn inspect(app: &mut Application, item: &str) -> Vec<Effect> {
        app.dispatch(Action::InspectCommand {
            room: ROOM.into(),
            item: item.into(),
        })
    }

    fn answer(
        app: &mut Application,
        account: &str,
        interaction: &str,
        result: Result<Value, String>,
    ) {
        let request = app
            .state
            .command_details
            .entries
            .iter()
            .find(|entry| entry.item == "d:100" && entry.interaction == interaction)
            .map(|entry| entry.request.clone())
            .unwrap_or_else(|| "stale-request".into());
        app.apply(Event::CommandDetails {
            room: ROOM.into(),
            item: "d:100".into(),
            request,
            account: account.into(),
            interaction: interaction.into(),
            result,
        });
    }

    #[test]
    fn command_details_read_visible_replies_once_without_send_permission() {
        let mut app = app();
        assert!(!app.state.can_write(), "fixture has no writable channel");
        assert!(matches!(inspect(&mut app, "d:100").as_slice(),
            [Effect::Backend(Command::Discord(DiscordCommand::CommandDetails { account, interaction, .. }))] if account == "1" && interaction == "900"));
        assert!(
            inspect(&mut app, "d:100").is_empty(),
            "pending hover deduplicates"
        );
        answer(
            &mut app,
            "1",
            "900",
            Ok(
                json!({"id":"900", "name":"fetch", "options":[{"type":4,"name":"lines","value":1}]}),
            ),
        );
        assert_eq!(
            app.state.command_detail(ROOM, "d:100"),
            Some("/fetch  lines: 1")
        );
        assert!(
            inspect(&mut app, "d:100").is_empty(),
            "completed hover is cached"
        );
        assert!(app.state.command_detail("discord:10:22", "d:100").is_none());
        assert_eq!(
            app.state.command_history(),
            &CommandHistory::default(),
            "read details never enter recommendation history"
        );
        assert_eq!(
            app.state.messages[0].used.as_ref().unwrap().name,
            "/fetch",
            "options stay out of message data"
        );
    }

    #[test]
    fn command_details_use_ephemeral_inline_data_from_the_visible_message() {
        let mut app = app();
        let message = Arc::make_mut(&mut Arc::make_mut(&mut app.state.messages)[0]);
        message.command_data = Some(Arc::new(json!({
            "id": "900",
            "name": "fetch",
            "options": [{"type": 3, "name": "link", "value": "from Discord"}],
        })));
        assert!(inspect(&mut app, "d:100").is_empty(), "no HTTP request");
        assert_eq!(
            app.state.command_copy_text(ROOM, "d:100"),
            Some("/fetch  link: from Discord")
        );
        assert!(
            app.state
                .command_copy_text("discord:10:22", "d:100")
                .is_none()
        );
    }

    #[test]
    fn command_details_accept_a_scoped_command_envelope_and_reject_wrong_invocations() {
        let payload = json!({
            "id": "71",
            "type": 1,
            "application_command": {"type": 1, "id": "71", "name": "fetch"},
            "options": [{"type": 3, "name": "link", "value": "actual argument"}],
        });
        let mut app = self::app();
        assert!(matches!(
            inspect(&mut app, "d:100").as_slice(),
            [Effect::Backend(Command::Discord(DiscordCommand::CommandDetails {
                item, original_message: None, ..
            }))] if item == "d:100"
        ));
        answer(&mut app, "1", "900", Ok(payload.clone()));
        assert_eq!(
            app.state.command_copy_text(ROOM, "d:100"),
            Some("/fetch  link: actual argument")
        );

        let mut app = self::app();
        inspect(&mut app, "d:100");
        let mut wrong = payload;
        wrong["interaction_id"] = json!("901");
        answer(&mut app, "1", "900", Ok(wrong));
        assert!(app.state.command_copy_text(ROOM, "d:100").is_none());
        assert!(
            app.state
                .command_detail(ROOM, "d:100")
                .unwrap()
                .contains("mismatched")
        );
    }

    #[test]
    fn command_details_reject_unknown_messages_preview_and_stale_accounts() {
        let mut app = app();
        assert!(inspect(&mut app, "d:999").is_empty());
        assert!(
            app.dispatch(Action::InspectCommand {
                room: "discord:10:22".into(),
                item: "d:100".into()
            })
            .is_empty()
        );
        app.state.preview = true;
        assert!(inspect(&mut app, "d:100").is_empty());
        app.state.preview = false;
        inspect(&mut app, "d:100");
        app.state.discord_user = Some("2".into());
        assert!(!inspect(&mut app, "d:100").is_empty());
        answer(
            &mut app,
            "1",
            "900",
            Ok(
                json!({"id":"900","name":"fetch","options":[{"name":"text","value":"prior account"}]}),
            ),
        );
        assert!(
            app.state
                .command_detail(ROOM, "d:100")
                .unwrap()
                .contains("Loading command options")
        );
        assert!(
            app.state.command_details.entries[0].pending(),
            "stale account cannot consume current request"
        );
        answer(&mut app, "2", "900", Err("Missing Access".into()));
        assert!(
            inspect(&mut app, "d:100").is_empty(),
            "denied hover does not retry automatically"
        );
        assert!(
            app.state
                .command_detail(ROOM, "d:100")
                .unwrap()
                .contains("couldn't be loaded")
        );
    }

    #[test]
    fn command_details_changed_interaction_ignores_the_previous_answer() {
        let mut app = app();
        inspect(&mut app, "d:100");
        Arc::make_mut(&mut Arc::make_mut(&mut app.state.messages)[0]).interaction =
            Some("901".into());
        assert!(!inspect(&mut app, "d:100").is_empty());
        answer(&mut app, "1", "900", Ok(json!({"id":"900","name":"old"})));
        assert!(app.state.command_details.entries[0].pending());
        answer(
            &mut app,
            "1",
            "901",
            Ok(json!({"id":"901","name":"fetch","options":[]})),
        );
        assert_eq!(app.state.command_detail(ROOM, "d:100"), Some("/fetch"));
    }

    #[test]
    fn command_details_bound_concurrent_reads_and_memory() {
        let mut app = app();
        let message = app.state.messages[0].as_ref().clone();
        app.state.messages = Arc::new(
            (100..140)
                .map(|id| {
                    Arc::new(ChatMessage {
                        id: format!("d:{id}"),
                        item: format!("d:{id}"),
                        ..message.clone()
                    })
                })
                .collect(),
        );
        for id in 100..104 {
            assert!(!inspect(&mut app, &format!("d:{id}")).is_empty());
        }
        assert!(
            inspect(&mut app, "d:104").is_empty(),
            "at most four requests in flight"
        );
        for id in 100..140 {
            let item = format!("d:{id}");
            inspect(&mut app, &item);
            let request = app
                .state
                .command_details
                .entries
                .iter()
                .find(|entry| entry.item == item)
                .unwrap()
                .request
                .clone();
            app.receive_command_details(
                ROOM,
                &item,
                &request,
                "1",
                "900",
                Ok(json!({"id":"900","name":"fetch","options":[]})),
            );
        }
        assert_eq!(app.state.command_details.entries.len(), DETAILS_KEPT);
        assert!(
            app.state
                .command_details
                .entries
                .iter()
                .all(|entry| !entry.pending())
        );
    }

    #[test]
    fn command_details_format_nested_options_as_bounded_plain_text() {
        assert_eq!(detail_text(&json!({"name":"config set","options":[{"type":1,"name":"set","options":[
            {"type":3,"name":"text","value":"hello\nworld"}, {"type":5,"name":"on","value":true}
        ]}]})).as_deref(), Some("/config set  text: hello world  on: true"));
        assert_eq!(detail_text(&json!({"name":"config","options":[{"type":2,"name":"group","options":[{"type":1,"name":"set","options":[{"type":3,"name":"value","value":"yes"}]}]}]})).as_deref(), Some("/config group set  value: yes"));
        let value = json!({"name":"fetch", "options": (0..25).map(|id| json!({"name":format!("value{id}"),"value":"x".repeat(10000)})).collect::<Vec<_>>()});
        let text = detail_text(&value).unwrap();
        assert_eq!(text.chars().count(), DETAIL_CHARS);
        assert!(text.ends_with('…'));
        assert!(
            detail_text(&json!({"options":[]})).is_none(),
            "unknown command names are not invented"
        );
    }

    #[test]
    fn command_details_own_invocations_use_discord_before_they_can_be_copied() {
        let mut app = app();
        let message = Arc::make_mut(&mut Arc::make_mut(&mut app.state.messages)[0]);
        message.used.as_mut().unwrap().name = "/ologroup".into();
        message.used.as_mut().unwrap().slash = Some("ologroup".into());
        message.application_id = Some("42".into());
        let effects = app.start_command(
            chat::CommandRun {
                nonce: String::new(),
                room: ROOM.into(),
                application: "42".into(),
                command: Arc::new(json!({"id":"71", "type":1, "name":"ologroup"})),
                options: json!([{"name":"link", "type":3, "value":"22122"}]),
                target: None,
                files: vec![],
            },
            "Example app".into(),
            None,
        );
        let nonce = match &effects[0] {
            Effect::Backend(Command::Discord(DiscordCommand::RunCommand(run))) => run.nonce.clone(),
            _ => panic!("a validated command runs"),
        };
        app.apply(Event::InteractionCreated {
            nonce: nonce.clone(),
            id: "900".into(),
        });
        app.apply(Event::InteractionSucceeded(nonce));
        assert_eq!(app.state.command_detail(ROOM, "d:100"), None);
        assert_eq!(app.state.command_copy_text(ROOM, "d:100"), None);
        assert_eq!(inspect(&mut app, "d:100").len(), 1);
        assert_eq!(app.state.command_copy_text(ROOM, "d:100"), None);
        answer(
            &mut app,
            "1",
            "900",
            Ok(json!({
                "id": "900", "name": "ologroup",
                "options": [{"name":"link", "type":3, "value":"server-value"}]
            })),
        );
        assert_eq!(
            app.state.command_detail(ROOM, "d:100"),
            Some("/ologroup  link: server-value")
        );
        assert_eq!(
            app.state.command_copy_text(ROOM, "d:100"),
            Some("/ologroup  link: server-value")
        );
        assert_eq!(app.state.command_history(), &CommandHistory::default());
        assert_eq!(
            app.state.messages[0].used.as_ref().unwrap().name,
            "/ologroup",
            "no values in stored messages"
        );
        app.state.discord_user = Some("2".into());
        assert!(
            app.state.command_copy_text(ROOM, "d:100").is_none(),
            "must match the account"
        );
    }

    #[test]
    fn command_details_failed_read_retries_only_after_a_cooldown_and_new_hover() {
        let mut app = app();
        inspect(&mut app, "d:100");
        answer(
            &mut app,
            "1",
            "900",
            Err("raw server details never shown".into()),
        );
        let shown = app.state.command_detail(ROOM, "d:100").unwrap();
        assert!(shown.contains("couldn't be loaded"));
        assert!(!shown.contains("raw server"));
        assert_eq!(
            safe_status("private text (HTTP 403, code 50013). private suffix"),
            Some("HTTP 403, code 50013".into())
        );
        assert_eq!(safe_status("(HTTP 403, code secret-value)"), None);
        assert!(inspect(&mut app, "d:100").is_empty());
        app.state.command_details.entries[0].retry_at =
            Some(Instant::now() - Duration::from_secs(1));
        assert_eq!(inspect(&mut app, "d:100").len(), 1);
        answer(
            &mut app,
            "1",
            "900",
            Ok(json!({
                "id":"900", "type":2, "name":"ologroup",
                "application_command":{"id":"71", "application_id":"42", "type":1, "name":"ologroup"},
                "options":[{"name":"link", "type":3, "value":"22122"}]
            })),
        );
        assert_eq!(
            app.state.command_detail(ROOM, "d:100"),
            Some("/ologroup  link: 22122")
        );
        assert!(inspect(&mut app, "d:100").is_empty());
    }

    #[test]
    fn command_details_unavailable_history_does_not_offer_repeated_requests() {
        for result in [
            Err("private value (HTTP 403, code 50013). private suffix".into()),
            Err("private value (HTTP 404, code 10008). private suffix".into()),
            Ok(Value::Null),
        ] {
            let mut client = app();
            inspect(&mut client, "d:100");
            answer(&mut client, "1", "900", result);
            let shown = client.state.command_detail(ROOM, "d:100").unwrap();
            assert!(shown.contains("couldn't be loaded"));
            assert!(!shown.contains("private"));
            assert!(!shown.contains("retry"));
            assert!(client.state.command_details.entries[0].retry_at.is_none());
            assert!(inspect(&mut client, "d:100").is_empty());
            assert!(inspect(&mut client, "d:100").is_empty());
        }
    }

    #[test]
    fn command_details_invalid_remote_shapes_are_distinct_without_leaking_values() {
        for (response, expected) in [
            (
                json!({"id":"901", "name":"fetch", "options":[{"name":"link", "value":"private value"}]}),
                "missing or mismatched interaction metadata",
            ),
            (
                json!({"id":"900", "name":"fetch", "options":[{"name":"link", "value":{"secret":"private value"}}]}),
                "incomplete or unsupported command options",
            ),
        ] {
            let mut client = app();
            inspect(&mut client, "d:100");
            answer(&mut client, "1", "900", Ok(response));
            let shown = client.state.command_detail(ROOM, "d:100").unwrap();
            assert!(shown.contains(expected));
            assert!(shown.contains("30 seconds"));
            assert!(!shown.contains("private value"));
            assert!(client.state.command_details.entries[0].retry_at.is_some());
            assert!(inspect(&mut client, "d:100").is_empty());
        }
    }

    #[test]
    fn command_details_remote_history_preserves_values_for_other_invokers() {
        let mut client = app();
        Arc::make_mut(&mut Arc::make_mut(&mut client.state.messages)[0])
            .used
            .as_mut()
            .unwrap()
            .sender = "discord:2".into();
        assert_eq!(inspect(&mut client, "d:100").len(), 1);
        answer(
            &mut client,
            "1",
            "900",
            Ok(json!({
                "id":"900", "name":"fetch", "options":[
                    {"name":"link", "type":3, "value":"22122"},
                    {"name":"image", "type":11, "value":"123456789012345678"}
                ]
            })),
        );
        assert_eq!(
            client.state.command_copy_text(ROOM, "d:100"),
            Some("/fetch  link: 22122  image: 123456789012345678")
        );
        assert!(inspect(&mut client, "d:100").is_empty());
    }

    #[test]
    fn command_details_nameless_metadata_can_load_a_verified_slash_command() {
        let mut app = app();
        let message = Arc::make_mut(&mut Arc::make_mut(&mut app.state.messages)[0]);
        let used = message.used.as_mut().unwrap();
        used.name = "Slash command".into();
        used.slash = Some(String::new());
        assert!(app.state.can_inspect_command(ROOM, "d:100"));
        assert_eq!(inspect(&mut app, "d:100").len(), 1);
        answer(
            &mut app,
            "1",
            "900",
            Ok(json!({
                "id":"900", "type":2, "name":"fetch", "application_command":{"name":"fetch","type":1},
                "options":[{"name":"link","type":3,"value":"22122"}]
            })),
        );
        assert_eq!(
            app.state.command_copy_text(ROOM, "d:100"),
            Some("/fetch  link: 22122")
        );
        assert_eq!(
            detail_text(&json!({
                "id":"900", "type":2, "name":"Inspect", "application_command":{"name":"Inspect","type":2},
                "options":[]
            })),
            None
        );
    }

    #[test]
    fn command_details_loading_and_unavailable_states_are_not_copyable() {
        let mut app = app();
        assert!(!app.state.command_detail_pending(ROOM, "d:100"));
        assert_eq!(inspect(&mut app, "d:100").len(), 1);
        assert!(
            app.state
                .command_detail(ROOM, "d:100")
                .unwrap()
                .contains("Loading")
        );
        assert!(app.state.command_copy_text(ROOM, "d:100").is_none());
        assert!(app.state.command_detail_pending(ROOM, "d:100"));
        answer(
            &mut app,
            "1",
            "900",
            Err("Missing Access (HTTP 403)".into()),
        );
        assert!(
            app.state
                .command_detail(ROOM, "d:100")
                .unwrap()
                .contains("HTTP 403")
        );
        assert!(app.state.command_copy_text(ROOM, "d:100").is_none());
        assert!(!app.state.command_detail_pending(ROOM, "d:100"));
    }

    #[test]
    fn command_details_followups_keep_a_validated_original_fallback_and_match_the_source_interaction()
     {
        let mut app = app();
        let message = Arc::make_mut(&mut Arc::make_mut(&mut app.state.messages)[0]);
        message.command_message = Some("80".into());
        message.command_interaction = Some("850".into());
        assert!(matches!(inspect(&mut app, "d:100").as_slice(),
            [Effect::Backend(Command::Discord(DiscordCommand::CommandDetails { room, item, original_message, interaction, .. }))]
            if room == ROOM && item == "d:100" && original_message.as_deref() == Some("80") && interaction == "900"));
        // A response for the displayed modal's own interaction is not the
        // named command whose options the user asked to see.
        answer(
            &mut app,
            "1",
            "900",
            Ok(
                json!({"id":"900","name":"fetch","options":[{"name":"text","value":"wrong invocation"}]}),
            ),
        );
        assert!(
            app.state
                .command_detail(ROOM, "d:100")
                .unwrap()
                .contains("couldn't be loaded")
        );
        app.state.command_details.entries[0].retry_at =
            Some(Instant::now() - Duration::from_secs(1));
        inspect(&mut app, "d:100");
        answer(
            &mut app,
            "1",
            "900",
            Ok(
                json!({"id":"850","name":"fetch","options":[{"name":"link","type":3,"value":"22122"}]}),
            ),
        );
        assert_eq!(
            app.state.command_detail(ROOM, "d:100"),
            Some("/fetch  link: 22122")
        );
        Arc::make_mut(&mut Arc::make_mut(&mut app.state.messages)[0]).command_message =
            Some("81".into());
        assert!(
            app.state.command_detail(ROOM, "d:100").is_none(),
            "changed origin cannot reuse the old cache"
        );
        assert_eq!(inspect(&mut app, "d:100").len(), 1);
        Arc::make_mut(&mut Arc::make_mut(&mut app.state.messages)[0]).command_message =
            Some("../../other".into());
        assert!(
            matches!(inspect(&mut app, "d:100").as_slice(),
            [Effect::Backend(Command::Discord(DiscordCommand::CommandDetails {
                item, original_message: None, ..
            }))] if item == "d:100"),
            "an invalid fallback never replaces or prevents the visible request"
        );
    }

    #[test]
    fn command_details_modal_answers_copy_only_the_triggering_commands_verified_values() {
        assert!(
            detail_text(&json!({
                "id":"850", "type":5, "name":"fetch", "options":[]
            }))
            .is_none()
        );
        let mut app = app();
        let message = Arc::make_mut(&mut Arc::make_mut(&mut app.state.messages)[0]);
        message.command_interaction = Some("850".into());
        message.command_message = Some("80".into());
        message.application_id = Some("42".into());
        assert_eq!(inspect(&mut app, "d:100").len(), 1);
        answer(
            &mut app,
            "1",
            "900",
            Ok(json!({
                "id":"850", "name":"fetch", "options":[{"name":"link","type":3,"value":"22122"}]
            })),
        );
        assert_eq!(
            app.state.command_copy_text(ROOM, "d:100"),
            Some("/fetch  link: 22122")
        );
        assert!(inspect(&mut app, "d:100").is_empty());
        assert_eq!(
            app.state.messages[0].interaction.as_deref(),
            Some("900"),
            "response lifecycle identity is unchanged"
        );
    }

    #[test]
    fn command_details_partial_history_is_retryable_but_known_empty_commands_are_complete() {
        let required =
            json!({"id":"71","name":"fetch","options":[{"name":"link","type":3,"required":true}]});
        for options in [
            None,
            Some(Value::Null),
            Some(json!([])),
            Some(json!([{"name":"link","value":{"unexpected":"data"}}])),
        ] {
            let mut response = json!({"id":"900","name":"fetch","application_command":required});
            if let Some(options) = options {
                response["options"] = options;
            }
            assert!(detail_text(&response).is_none());
        }
        assert!(detail_text(&json!({"name":"fetch"})).is_none());
        assert!(detail_text(&json!({"name":"fetch","application_command":{}})).is_none());
        assert!(
            detail_text(
                &json!({"name":"config","application_command":{"name":"config","options":[
            {"name":"set","type":1,"options":[{"name":"key","type":3,"required":true}]}]}})
            )
            .is_none()
        );
        assert_eq!(detail_text(&json!({"name":"config","application_command":{"name":"config","options":[{"name":"list","type":1,"options":[]}]},
            "options":[{"name":"list","type":1,"options":[]}]})).as_deref(), Some("/config list"));
        assert_eq!(
            detail_text(
                &json!({"name":"ping","application_command":{"id":"71","name":"ping","type":1}})
            )
            .as_deref(),
            Some("/ping")
        );
        assert_eq!(
            detail_text(&json!({"name":"ping","options":[]})).as_deref(),
            Some("/ping")
        );
        let mut app = app();
        inspect(&mut app, "d:100");
        answer(
            &mut app,
            "1",
            "900",
            Ok(json!({"id":"900","name":"fetch","application_command":required})),
        );
        assert!(
            app.state
                .command_detail(ROOM, "d:100")
                .unwrap()
                .contains("couldn't be loaded")
        );
        assert!(
            inspect(&mut app, "d:100").is_empty(),
            "no automatic retry loop"
        );
        app.state.command_details.entries[0].retry_at =
            Some(Instant::now() - Duration::from_secs(1));
        assert_eq!(inspect(&mut app, "d:100").len(), 1);
        answer(
            &mut app,
            "1",
            "900",
            Ok(
                json!({"id":"900","name":"fetch","application_command":required,"options":[{"name":"link","type":3,"value":"22122"}]}),
            ),
        );
        assert_eq!(
            app.state.command_detail(ROOM, "d:100"),
            Some("/fetch  link: 22122")
        );
    }

    #[test]
    fn command_details_preserve_long_urls_and_full_sized_unicode_options() {
        let url = format!("https://example.test/orders?value={}", "x".repeat(700));
        let text =
            detail_text(&json!({"name":"fetch","options":[{"name":"link","type":3,"value":url}]}))
                .unwrap();
        assert_eq!(text, format!("/fetch  link: {url}"));
        let value = "界".repeat(VALUE_CHARS);
        let text = detail_text(
            &json!({"name":"fetch","options":[{"name":"text","type":3,"value":value}]}),
        )
        .unwrap();
        assert!(text.ends_with(&value));
        assert!(!text.ends_with('…'));
        // Commands can have changed since this historical invocation. Available
        // submitted values remain useful even when today's schema differs.
        assert_eq!(detail_text(&json!({"name":"fetch","application_command":{"options":[{"name":"new_option","required":true}]},
            "options":[{"name":"link","type":3,"value":"22122"}]})).as_deref(), Some("/fetch  link: 22122"));
    }

    #[test]
    fn command_details_replaced_source_keeps_its_slot_when_an_older_attempt_arrives() {
        let mut app = app();
        inspect(&mut app, "d:100");
        let old = app.state.command_details.entries[0].request.clone();
        Arc::make_mut(&mut Arc::make_mut(&mut app.state.messages)[0]).command_message =
            Some("80".into());
        inspect(&mut app, "d:100");
        let current = app.state.command_details.entries[0].request.clone();
        assert_ne!(old, current);
        app.receive_command_details(ROOM, "d:100", &old, "1", "900", Err("stale".into()));
        assert!(app.state.command_details.entries[0].pending());
        app.receive_command_details(
            ROOM,
            "d:100",
            &current,
            "1",
            "900",
            Ok(json!({"id":"900","name":"fetch","options":[{"name":"link","value":"22122"}]})),
        );
        assert_eq!(
            app.state.command_detail(ROOM, "d:100"),
            Some("/fetch  link: 22122")
        );
    }
}
