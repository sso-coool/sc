use super::*;

#[test]
fn slash_file_paste_and_drop_count_replacements_once_and_keep_the_ten_file_cap() {
    let folder = tempfile::tempdir().unwrap();
    let image = folder.path().join("image.png");
    std::fs::write(&image, b"fixture").unwrap();
    let options = serde_json::Value::Array(
        (0..11)
            .map(|n| {
                serde_json::json!({
                    "type":11,"name":format!("image{n}"),"description":"Image"
                })
            })
            .collect(),
    );
    let (mut app, _) = fixture(options);
    app.dispatch(Action::Stage(vec![image.clone(); 11]));
    assert!(app.state.staged().is_empty());
    app.dispatch(Action::Stage(vec![image.clone(); 9]));
    assert_eq!(app.state.staged().len(), 9);
    assert!(
        app.state
            .drop_refusal(&[image.clone(), image.clone()])
            .is_none()
    );
    app.dispatch(Action::Stage(vec![image.clone(); 2]));
    assert_eq!(app.state.staged().len(), 10);
    app.dispatch(Action::FocusCommandOption(10));
    assert!(!app.state.can_attach());
    app.dispatch(Action::SetCommandOption {
        index: 10,
        value: image.to_string_lossy().into_owned(),
    });
    assert!(
        app.state.command_draft().unwrap().options[10]
            .file
            .is_none()
    );
}

#[test]
fn slash_file_paste_rejects_oversized_replacement_and_new_draft_has_new_identity() {
    let folder = tempfile::tempdir().unwrap();
    let image = folder.path().join("image.png");
    let large = folder.path().join("large.png");
    std::fs::write(&image, b"ok").unwrap();
    std::fs::write(&large, b"too large").unwrap();
    let (mut app, room) = fixture(options());
    Arc::make_mut(app.state.rooms.iter_mut().find(|r| r.id == room).unwrap()).upload_limit = 3;
    app.dispatch(Action::Stage(vec![image.clone()]));
    let first_id = app.state.command_draft().unwrap().input_id();
    app.dispatch(Action::Stage(vec![large]));
    assert!(app.state.notice.is_some());
    assert_eq!(
        app.state.command_draft().unwrap().options[0].file.as_ref(),
        Some(&image)
    );
    app.dispatch(Action::CloseCommand(false));
    app.dispatch(Action::SetDraft("/scan".into()));
    app.dispatch(Action::PickCommand(0));
    assert_ne!(app.state.command_draft().unwrap().input_id(), first_id);
}

fn fixture(options: serde_json::Value) -> (Application, String) {
    let (mut app, room) = in_discord_channel();
    app.dispatch(Action::SetDraft("/".into()));
    app.apply(Event::CommandIndex {
        room: room.clone(),
        index: Ok(Arc::new(crate::chat::CommandIndex::parse(&serde_json::json!({
            "applications": [{"id":"500", "name":"Scan Bot"}],
            "application_commands": [{"id":"501", "application_id":"500", "version":"1", "type":1,
                "name":"scan", "description":"Reads images", "default_member_permissions":null, "options":options}]
        }), false))),
    });
    app.dispatch(Action::SetDraft("/scan".into()));
    app.dispatch(Action::PickCommand(0));
    assert!(app.state.command_draft().is_some());
    (app, room)
}

fn options() -> serde_json::Value {
    serde_json::json!([
        {"type":11,"name":"image","description":"Image to read","required":true},
        {"type":3,"name":"note","description":"A note"},
        {"type":11,"name":"extra","description":"Another image"}
    ])
}

#[test]
fn slash_file_paste_fills_image_option_and_only_explicit_send_uploads_it() {
    let folder = tempfile::tempdir().unwrap();
    let image = folder.path().join("image.png");
    std::fs::write(&image, b"synthetic image fixture").unwrap();
    let (mut app, room) = fixture(options());
    assert!(app.dispatch(Action::Stage(vec![image.clone()])).is_empty());
    let command = app.state.command_draft().unwrap();
    assert_eq!(command.options[0].file.as_ref(), Some(&image));
    assert_eq!(command.options[0].shown(), "image.png");
    assert_eq!(app.state.staged()[0].path, image);
    assert!(!app.state.can_mark_spoilers());
    assert!(app.state.staged.get(&room).is_none_or(Vec::is_empty));
    let effects = app.dispatch(Action::Send);
    let run = effects
        .into_iter()
        .find_map(|effect| match effect {
            Effect::Backend(Command::Discord(DiscordCommand::RunCommand(run))) => Some(run),
            _ => None,
        })
        .expect("only Enter creates the command request");
    assert_eq!(run.files, vec![image]);
    assert_eq!(
        run.options,
        serde_json::json!([{"type":11,"name":"image","value":0}])
    );
}

#[test]
fn slash_file_paste_uses_empty_attachment_when_text_option_is_focused() {
    let folder = tempfile::tempdir().unwrap();
    let image = folder.path().join("image.png");
    std::fs::write(&image, b"fixture").unwrap();
    let (mut app, _) = fixture(options());
    app.dispatch(Action::FocusCommandOption(1));
    app.dispatch(Action::SetDraft("keep this note".into()));
    app.dispatch(Action::Stage(vec![image.clone()]));
    let command = app.state.command_draft().unwrap();
    assert_eq!(command.options[0].file.as_ref(), Some(&image));
    assert_eq!(command.options[1].text, "keep this note");
    assert_eq!(app.state.draft(), "keep this note");
}

#[test]
fn slash_file_paste_is_atomic_and_preserves_other_attachment_options() {
    let folder = tempfile::tempdir().unwrap();
    let images: Vec<_> = (0..3)
        .map(|n| {
            let path = folder.path().join(format!("{n}.png"));
            std::fs::write(&path, b"fixture").unwrap();
            path
        })
        .collect();
    let (mut app, _) = fixture(options());
    app.dispatch(Action::Stage(images.clone()));
    assert!(app.state.notice.is_some());
    assert!(
        app.state
            .command_draft()
            .unwrap()
            .options
            .iter()
            .all(|o| o.file.is_none())
    );
    app.dispatch(Action::Stage(images[..2].to_vec()));
    app.dispatch(Action::FocusCommandOption(2));
    app.dispatch(Action::Stage(vec![images[2].clone()]));
    let command = app.state.command_draft().unwrap();
    assert_eq!(command.options[0].file.as_ref(), Some(&images[0]));
    assert_eq!(command.options[2].file.as_ref(), Some(&images[2]));
}

#[test]
fn slash_file_paste_rejects_invalid_file_and_commands_without_attachment_options() {
    let folder = tempfile::tempdir().unwrap();
    let image = folder.path().join("image.png");
    std::fs::write(&image, b"fixture").unwrap();
    let (mut app, room) = fixture(options());
    app.dispatch(Action::Stage(vec![
        image.clone(),
        folder.path().join("missing.png"),
    ]));
    assert!(app.state.notice.is_some());
    assert!(
        app.state
            .command_draft()
            .unwrap()
            .options
            .iter()
            .all(|o| o.file.is_none())
    );
    assert!(app.state.staged.get(&room).is_none_or(Vec::is_empty));
    let (mut app, room) = fixture(serde_json::json!([]));
    app.dispatch(Action::Stage(vec![image.clone()]));
    assert!(app.state.notice.is_some());
    assert!(app.state.staged.get(&room).is_none_or(Vec::is_empty));
    app.dispatch(Action::CloseCommand(false));
    app.dispatch(Action::Stage(vec![image]));
    assert_eq!(app.state.staged.get(&room).unwrap().len(), 1);
}

#[test]
fn slash_file_preview_remove_clears_only_its_option_even_for_duplicate_paths() {
    let folder = tempfile::tempdir().unwrap();
    let image = folder.path().join("image.png");
    std::fs::write(&image, b"fixture").unwrap();
    let (mut app, _) = fixture(options());
    app.dispatch(Action::Stage(vec![image.clone(), image.clone()]));
    assert_eq!(app.state.staged().len(), 2);
    app.dispatch(Action::Unstage(1));
    let command = app.state.command_draft().unwrap();
    assert_eq!(command.options[0].file.as_ref(), Some(&image));
    assert!(command.options[2].file.is_none());
    assert_eq!(app.state.staged().len(), 1);
    app.dispatch(Action::Unstage(0));
    assert!(app.state.staged().is_empty());
    assert!(
        app.dispatch(Action::Send).is_empty(),
        "required image was removed"
    );
}
