//! Apps' commands: the index the `/` picker reads.

use super::*;
use yapfast_discord::commands::CommandIndex;

const GENERAL: &str = "discord:10:11";

#[test]
fn slash_clipboard_restores_current_typed_options_and_keeps_attachments_empty() {
    let (mut app, room) = super::in_discord_channel();
    let mut payload = serde_json::json!({
        "version":1, "application":"500", "command":"501", "name":"snap order",
        "text":"/snap order location:75081 method:CARRYOUT count:3 quiet:true user:1",
        "options":[
            {"name":"location","kind":3,"value":"75081"},
            {"name":"method","kind":3,"value":"CARRYOUT"},
            {"name":"count","kind":4,"value":3},
            {"name":"quiet","kind":5,"value":true},
            {"name":"user","kind":6,"value":"1"}
        ]
    });
    let copied = CommandClipboard::decode(&serde_json::to_vec(&payload).unwrap()).unwrap();
    let HistoricalDraft::Waiting(requests) = app.draft_copied_command(&room, &copied, false) else {
        panic!("pasting should load the destination's current command definitions");
    };
    assert!(requests.iter().any(|effect| matches!(effect,
        Effect::Backend(Command::Discord(DiscordCommand::CommandIndex { room: requested }))
            if requested == &room
    )));
    assert!(app.state.command_draft().is_none(), "metadata does not create an unchecked editor");
    app.apply(Event::CommandIndex {
        room: room.clone(),
        index: Ok(Arc::new(CommandIndex::parse(&serde_json::json!({
            "applications":[{"id":"500","name":"Clipboard app"}],
            "application_commands":[{
                "id":"501","application_id":"500","version":"2","type":1,
                "name":"snap","description":"Snap","default_member_permissions":null,
                "options":[{"type":1,"name":"order","description":"Order","options":[
                    {"type":3,"name":"location","description":"Location","required":true},
                    {"type":3,"name":"method","description":"Method","required":true,
                     "choices":[{"name":"Carryout","value":"CARRYOUT"},{"name":"Delivery","value":"DELIVERY"}]},
                    {"type":4,"name":"count","description":"Count"},
                    {"type":5,"name":"quiet","description":"Quiet"},
                    {"type":6,"name":"user","description":"User"},
                    {"type":11,"name":"image","description":"Fresh image","required":true}
                ]}]
            }]
        }), false))),
    });
    let HistoricalDraft::Ready(effects) = app.draft_copied_command(&room, &copied, true) else {
        panic!("the current permitted command should be restored into its editor");
    };
    assert!(!effects.iter().any(|effect| matches!(effect,
        Effect::Backend(Command::Discord(DiscordCommand::RunCommand(_)))
    )), "pasting prepares the command for review");
    let draft = app.state.command_draft().unwrap();
    assert_eq!(draft.name, "snap order");
    assert_eq!(draft.options[0].text, "75081");
    assert_eq!(draft.options[1].text, "Carryout");
    assert_eq!(draft.options[2].text, "3");
    assert_eq!(draft.options[3].text, "true");
    assert!(!draft.options[4].text.is_empty());
    assert!(draft.options[5].text.is_empty() && draft.options[5].file.is_none());
    assert!(draft.staged_files().is_empty());
    app.dispatch(Action::CloseCommand(false));
    payload["application"] = serde_json::json!("999");
    let wrong_app = CommandClipboard::decode(&serde_json::to_vec(&payload).unwrap()).unwrap();
    assert!(matches!(app.draft_copied_command(&room, &wrong_app, true), HistoricalDraft::Unavailable));
    assert!(app.state.command_draft().is_none(), "another app cannot take a same-name command");
    app.state.rooms.iter_mut().find(|known| known.id == room)
        .map(Arc::make_mut).unwrap().read_only = true;
    assert!(matches!(app.draft_copied_command(&room, &copied, true), HistoricalDraft::Unavailable));
}

fn self_option_fixture(kind: u8) -> Application {
    let (mut app, room) = super::in_discord_channel();
    app.state.account_username = Some("cool_chef11".into());
    app.state.account_name = Some("Chef Cool".into());
    app.dispatch(Action::SetDraft("/".into()));
    app.apply(Event::CommandIndex {
        room,
        index: Ok(Arc::new(CommandIndex::parse(
            &serde_json::json!({
                "applications": [{"id":"500", "name":"Kitchen"}],
                "application_commands": [{"id":"501", "application_id":"500", "type":1,
                    "name":"remove", "description":"Update", "default_member_permissions":null,
                    "options":[{"type":kind,"name":"chef","description":"Who","required":true}]}]
            }),
            false,
        ))),
    });
    app.dispatch(Action::SetDraft("/remove ".into()));
    app
}

#[test]
fn slash_mention_options_find_later_names_and_emoji_prefixed_channels() {
    for kind in [6, 9] {
        let mut app = self_option_fixture(kind);
        let room = app.state.selected.clone().expect("fixture channel");
        assert!(matches!(
            app.dispatch(Action::SetDraft("@solo".into())).as_slice(),
            [Effect::Backend(Command::Discord(DiscordCommand::SearchMembers { room: requested, query }))]
                if requested == &room && query == "solo"
        ));
        app.apply(Event::MemberMatches {
            account: "2".into(),
            room: room.clone(),
            query: "solo".into(),
            members: vec![member("4", "Old Account Solo")],
        });
        assert!(app.command_rows().is_empty());
        app.apply(Event::MemberMatches {
            account: "1".into(),
            room,
            query: "solo".into(),
            members: vec![member("3", "Trainee Chef Solo")],
        });
        let rows = app.command_rows();
        assert_eq!(rows.len(), 1, "the selected room's matching member");
        assert_eq!(rows[0].name, "Trainee Chef Solo");
        app.dispatch(Action::PickCommand(0));
        assert!(app.state.option_errors(app.state.command_draft().unwrap())[0].is_none());
    }
    let mut app = self_option_fixture(7);
    let room = app.state.selected.clone().expect("fixture channel");
    app.apply(Event::MentionGroups {
        room,
        groups: vec![MentionGroup {
            name: "💰│deposit".into(),
            mention: "<#21>".into(),
            color: None,
            channel: true,
            voice: false,
        }],
    });
    app.dispatch(Action::SetDraft("#deposit".into()));
    let rows = app.command_rows();
    assert_eq!(rows.len(), 1, "the selected room's emoji-prefixed channel");
    assert_eq!(rows[0].name, "💰│deposit");
    app.dispatch(Action::PickCommand(0));
    assert!(app.state.option_errors(app.state.command_draft().unwrap())[0].is_none());
}

#[test]
fn slash_self_user_suggestions_match_handle_and_guild_nickname_without_duplicates() {
    for kind in [6, 9] {
        let mut app = self_option_fixture(kind);
        let mut own = member("discord:1", "Head Chef");
        own.username = Some("cool_chef11".into());
        app.state.members = Some(Ok(Arc::new(vec![own.clone(), member("2", "cool_chef12")])));
        app.state.found_members = vec![own];
        for query in ["cool_chef11", "Head"] {
            app.dispatch(Action::SetDraft(query.into()));
            let rows = app.command_rows();
            assert_eq!(
                rows.len(),
                1,
                "own handle or nickname matches once: {query}"
            );
            assert_eq!(rows[0].name, "Head Chef");
            assert_eq!(rows[0].description, "cool_chef11");
        }
        // The same lazy candidate set validates a fully typed display name.
        app.dispatch(Action::SetDraft("Head Chef".into()));
        assert!(app.state.option_errors(app.state.command_draft().unwrap())[0].is_none());
        app.dispatch(Action::PickCommand(0));
        let effects = app.dispatch(Action::Send);
        let run = effects
            .iter()
            .find_map(|effect| match effect {
                Effect::Backend(Command::Discord(DiscordCommand::RunCommand(run))) => Some(run),
                _ => None,
            })
            .unwrap();
        assert_eq!(run.options[0]["value"], "1");
        assert!(
            app.state
                .mention_candidates()
                .iter()
                .all(|candidate| candidate.mention != "<@1>"),
            "normal message mention behavior is unchanged"
        );
    }
    for kind in [7, 8] {
        let mut app = self_option_fixture(kind);
        app.dispatch(Action::SetDraft("cool_chef11".into()));
        assert!(
            app.command_rows().is_empty(),
            "self cannot fill a channel or role option"
        );
    }
}

#[test]
fn slash_self_user_suggestions_use_received_names_and_account_fallback() {
    let mut app = self_option_fixture(6);
    app.state.members = None;
    app.state.found_members.clear();
    app.dispatch(Action::SetDraft("cool_chef11".into()));
    assert_eq!(
        app.command_rows().len(),
        1,
        "self needs no member search response"
    );
    assert_eq!(app.command_rows()[0].description, "cool_chef11");
    let mut names = yapfast_discord::message::Names::default();
    names.learn_member("10", &serde_json::json!({
        "nick":"Server Chef", "user":{"id":"1", "username":"cool_chef11", "global_name":"Chef Cool"}
    }));
    names.learn_member(
        "20",
        &serde_json::json!({
            "nick":"Other Server Chef", "user":{"id":"1", "username":"cool_chef11"}
        }),
    );
    app.state.discord_names = Some(yapfast_discord::service::SharedNames::new(Arc::new(
        std::sync::RwLock::new(names),
    )));
    app.dispatch(Action::SetDraft("Server Chef".into()));
    assert_eq!(
        app.command_rows()[0].name,
        "Server Chef",
        "only the current guild nickname is used"
    );
    // An inaccessible room must not acquire a self candidate from account data.
    Arc::make_mut(
        app.state
            .rooms
            .iter_mut()
            .find(|room| room.id == "discord:10:21")
            .unwrap(),
    )
    .locked = true;
    assert!(app.command_rows().is_empty());
}

#[test]
fn optional_command_options_are_omitted_for_every_supported_kind() {
    let (mut app, room) = super::in_discord_channel();
    let specs = serde_json::json!([
        {"type": 3, "name": "text", "description": "Optional text", "min_length": 1},
        {"type": 4, "name": "integer", "description": "Optional integer", "required": false, "min_value": 1},
        {"type": 5, "name": "boolean", "description": "Optional boolean"},
        {"type": 6, "name": "chef", "description": "Optional member", "required": false},
        {"type": 7, "name": "channel", "description": "Optional channel"},
        {"type": 8, "name": "role", "description": "Optional role"},
        {"type": 9, "name": "mention", "description": "Optional mention"},
        {"type": 10, "name": "number", "description": "Optional number", "min_value": 1},
        {"type": 11, "name": "file", "description": "Optional attachment"},
        {"type": 3, "name": "choice", "description": "Optional choice", "choices": [{"name": "One", "value": "one"}]},
        {"type": 3, "name": "autocomplete", "description": "Optional autocomplete", "autocomplete": true}
    ]);
    let index = CommandIndex::parse(
        &serde_json::json!({
            "applications": [{"id": "500", "name": "Test app"}],
            "application_commands": [{"id": "501", "application_id": "500", "type": 1,
                "name": "done", "description": "Finish", "default_member_permissions": null,
                "options": specs}]
        }),
        false,
    );
    app.dispatch(Action::SetDraft("/".into()));
    app.apply(Event::CommandIndex {
        room: room.clone(),
        index: Ok(Arc::new(index)),
    });
    app.dispatch(Action::SetDraft("/done ".into()));
    let draft = app.state.command_draft().expect("command selected");
    assert!(draft.options.iter().all(|option| !option.required));
    assert!(app.state.option_errors(draft).iter().all(Option::is_none));
    let effects = app.dispatch(Action::Send);
    let run = effects
        .iter()
        .find_map(|effect| match effect {
            Effect::Backend(Command::Discord(DiscordCommand::RunCommand(run))) => Some(run),
            _ => None,
        })
        .expect("empty optional options do not prevent a send");
    assert_eq!(run.options, serde_json::json!([]));
    assert!(run.files.is_empty());
}

#[test]
fn autocomplete_hides_previous_answers_while_a_new_query_is_pending() {
    let (mut app, room) = super::in_discord_channel();
    let index = CommandIndex::parse(
        &serde_json::json!({
            "applications": [{"id": "500", "name": "Lookup"}],
            "application_commands": [{"id": "502", "application_id": "500", "type": 1,
                "name": "find", "description": "Find a result", "default_member_permissions": null,
                "options": [
                    {"type": 3, "name": "query", "description": "Search", "required": true, "autocomplete": true},
                    {"type": 3, "name": "color", "description": "A fixed choice",
                     "choices": [{"name": "Red", "value": "red"}, {"name": "Blue", "value": "blue"}]}
                ]}]
        }),
        false,
    );
    app.dispatch(Action::SetDraft("/".into()));
    app.apply(Event::CommandIndex {
        room,
        index: Ok(Arc::new(index)),
    });
    app.dispatch(Action::SetDraft("/find ".into()));
    let requested = |effects: &[Effect]| {
        effects.iter().find_map(|effect| match effect {
            Effect::Backend(Command::Discord(DiscordCommand::Autocomplete(run))) => {
                Some(run.nonce.clone())
            }
            _ => None,
        })
    };
    let answer = |app: &mut Application, nonce: String, name: &str| {
        app.apply(Event::AutocompleteChoices {
            nonce,
            choices: serde_json::json!([{"name": name, "value": name}]),
        });
    };
    let first = requested(&app.dispatch(Action::SetDraft("a".into()))).unwrap();
    answer(&mut app, first.clone(), "Alpha");
    assert_eq!(app.command_rows()[0].name, "Alpha");
    let second = requested(&app.dispatch(Action::SetDraft("b".into()))).unwrap();
    assert_ne!(first, second, "rapid queries must have distinct nonces");
    assert!(
        app.command_rows().is_empty(),
        "old choices disappear before the new answer arrives"
    );
    assert!(app.dispatch(Action::PickCommand(0)).is_empty());
    assert_eq!(app.state.command_draft().unwrap().options[0].text, "b");
    answer(&mut app, first, "Late Alpha");
    assert!(
        app.command_rows().is_empty(),
        "a stale answer cannot restore old choices"
    );
    answer(&mut app, second, "Beta");
    assert_eq!(app.command_rows()[0].name, "Beta");

    assert!(requested(&app.dispatch(Action::SetDraft("a".into()))).is_none());
    assert_eq!(
        app.command_rows()[0].name,
        "Alpha",
        "matching cached answers still appear immediately"
    );
    let third = requested(&app.dispatch(Action::SetDraft("c".into()))).unwrap();
    assert!(app.command_rows().is_empty());
    assert!(requested(&app.dispatch(Action::SetDraft("a".into()))).is_none());
    answer(&mut app, third, "Late Gamma");
    assert_eq!(
        app.command_rows()[0].name,
        "Alpha",
        "a late response cannot replace the cached current query"
    );

    app.dispatch(Action::FocusCommandOption(1));
    assert_eq!(
        app.command_rows().len(),
        2,
        "fixed choices remain available without a network answer"
    );
    app.dispatch(Action::SetDraft("Bl".into()));
    assert_eq!(app.command_rows()[0].name, "Blue");
    app.dispatch(Action::PickCommand(0));
    assert_eq!(app.state.command_draft().unwrap().options[1].text, "Blue");
}

#[test]
fn a_replaced_slash_draft_never_becomes_an_ordinary_message() {
    use yapfast_discord::{
        ready::{Channel, Server},
        service::{Snapshot, Status},
    };
    const FIRST: &str = "discord:10:21";
    const SECOND: &str = "discord:10:22";
    const NORMAL: &str = "discord:10:23";
    let mut app = connected();
    app.apply(discord_event(Snapshot {
        status: Status::Online,
        user_id: Some("1".into()),
        servers: vec![MarkedServer::from(Server {
            id: "10".into(),
            name: "Test".into(),
            owner_id: Some("1".into()),
            text_channels: ["21", "22", "23"]
                .into_iter()
                .map(|id| Channel {
                    id: id.into(),
                    name: id.into(),
                    ..Default::default()
                })
                .collect(),
            ..Default::default()
        })],
        ..Default::default()
    }));
    app.dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
    let open = |app: &mut Application, room: &str| {
        app.dispatch(Action::SelectRoom(room.into()));
        app.apply(Event::Timeline {
            room: room.into(),
            messages: timeline(vec![]),
        });
    };
    let pick = |app: &mut Application, room: &str| {
        app.dispatch(Action::SetDraft("/".into()));
        app.apply(Event::CommandIndex {
            room: room.into(),
            index: Ok(super::command_index()),
        });
        app.dispatch(Action::SetDraft("/echo ".into()));
        assert_eq!(app.state.command_draft().unwrap().name, "echo");
    };
    open(&mut app, NORMAL);
    app.dispatch(Action::SetDraft("Keep this normal draft".into()));
    open(&mut app, FIRST);
    pick(&mut app, FIRST);
    let editing = app.dispatch(Action::SetDraft("First command's argument".into()));
    assert!(
        !editing.iter().any(|effect| matches!(
            effect,
            Effect::Backend(Command::SaveDraft { .. }) | Effect::Backend(Command::Send { .. })
        )),
        "command arguments are neither saved nor sent as ordinary drafts"
    );
    open(&mut app, SECOND);
    // Merely visiting a second channel leaves the first command available.
    open(&mut app, FIRST);
    assert_eq!(
        app.state.command_draft().unwrap().options[0].text,
        "First command's argument"
    );
    open(&mut app, SECOND);
    pick(&mut app, SECOND);
    app.dispatch(Action::SetDraft("Second command's argument".into()));
    open(&mut app, FIRST);
    assert!(app.state.command_draft().is_none());
    assert!(app.state.draft().is_empty());
    assert!(
        app.dispatch(Action::Send).is_empty(),
        "the displaced argument must not become a message"
    );
    open(&mut app, NORMAL);
    assert_eq!(app.state.draft(), "Keep this normal draft");
    open(&mut app, SECOND);
    assert_eq!(
        app.state.command_draft().unwrap().options[0].text,
        "Second command's argument"
    );
    let sent = app.dispatch(Action::Send);
    let run = sent
        .iter()
        .find_map(|effect| match effect {
            Effect::Backend(Command::Discord(DiscordCommand::RunCommand(run))) => Some(run),
            _ => None,
        })
        .expect("the replacement command still sends normally");
    assert_eq!(run.room, SECOND);
    assert_eq!(
        run.options,
        serde_json::json!([{"type": 3, "name": "text", "value": "Second command's argument"}])
    );
}

#[test]
fn optional_command_values_can_be_cleared_without_weakening_required_validation() {
    let (mut app, room) = super::in_discord_channel();
    app.dispatch(Action::SetDraft("/".into()));
    app.apply(Event::CommandIndex {
        room,
        index: Ok(super::command_index()),
    });
    app.dispatch(Action::SetDraft("/echo ".into()));
    assert!(
        app.dispatch(Action::Send).is_empty(),
        "required text is still needed"
    );
    app.dispatch(Action::SetDraft("hello".into()));
    app.dispatch(Action::FocusCommandOption(1));
    app.dispatch(Action::SetDraft("invalid number".into()));
    assert!(
        app.dispatch(Action::Send).is_empty(),
        "an entered optional value still needs validation"
    );
    app.dispatch(Action::SetDraft(" \t ".into()));
    let effects = app.dispatch(Action::Send);
    let run = effects
        .iter()
        .find_map(|effect| match effect {
            Effect::Backend(Command::Discord(DiscordCommand::RunCommand(run))) => Some(run),
            _ => None,
        })
        .expect("whitespace-only optional value is omitted");
    assert_eq!(
        run.options,
        serde_json::json!([{"type": 3, "name": "text", "value": "hello"}])
    );
}

#[test]
fn optional_command_option_can_be_deselected_and_reopened() {
    let (mut app, room) = super::in_discord_channel();
    app.dispatch(Action::SetDraft("/".into()));
    app.apply(Event::CommandIndex {
        room,
        index: Ok(super::command_index()),
    });
    app.dispatch(Action::SetDraft("/echo ".into()));
    app.dispatch(Action::SetDraft("keep this value".into()));
    app.dispatch(Action::DeselectCommandOption(0));
    assert_eq!(app.state.draft(), "keep this value");

    app.dispatch(Action::FocusCommandOption(1));
    app.dispatch(Action::SetDraft("3".into()));
    let input_id = app.state.command_draft().unwrap().input_id();
    app.dispatch(Action::DeselectCommandOption(1));
    let command = app.state.command_draft().unwrap();
    assert_eq!(command.focused, command.options.len());
    assert_ne!(command.input_id(), input_id);
    assert_eq!(command.options[0].text, "keep this value");
    assert!(command.options[1].text.is_empty());
    assert!(app.state.draft().is_empty());
    assert!(app.command_rows().is_empty());

    app.dispatch(Action::FocusCommandOption(1));
    assert_eq!(app.state.command_draft().unwrap().focused, 1);
    assert!(app.state.draft().is_empty());
    app.dispatch(Action::DeselectCommandOption(1));
    let effects = app.dispatch(Action::Send);
    let run = effects
        .iter()
        .find_map(|effect| match effect {
            Effect::Backend(Command::Discord(DiscordCommand::RunCommand(run))) => Some(run),
            _ => None,
        })
        .expect("the command sends without the deselected argument");
    assert_eq!(
        run.options,
        serde_json::json!([
            {"type": 3, "name": "text", "value": "keep this value"}
        ])
    );
}

/// The command index asked for, if one was.
fn asked(effects: &[Effect]) -> Option<&str> {
    effects.iter().find_map(|effect| match effect {
        Effect::Backend(Command::Discord(DiscordCommand::CommandIndex { room })) => {
            Some(room.as_str())
        }
        _ => None,
    })
}

/// "Test"'s Status Bot, whose /ping takes Use Application Commands, which
/// Alice lacks there, and Notes, which she installed for herself.
fn index() -> Arc<CommandIndex> {
    let server = CommandIndex::parse(
        &serde_json::json!({
            "applications": [{"id": "7", "name": "Status Bot", "icon": "abc", "bot_id": "7", "flags": "0"}],
            "application_commands": [
                {"id": "1", "type": 1, "application_id": "7", "name": "ping", "description": "Pong",
                 "default_member_permissions": null, "version": "1"}],
        }),
        false,
    );
    let own = CommandIndex::parse(
        &serde_json::json!({
            "applications": [{"id": "8", "name": "Notes", "icon": null, "flags": "0"}],
            "application_commands": [
                {"id": "2", "type": 1, "application_id": "8", "name": "note", "description": "Keeps a note",
                 "default_member_permissions": null, "integration_types": [1], "contexts": [0, 1, 2],
                 "version": "1"},
                {"id": "3", "type": 1, "application_id": "8", "name": "notes", "description": "Lists them",
                 "default_member_permissions": null, "integration_types": [1], "contexts": [1, 2],
                 "version": "1"}],
        }),
        true,
    );
    Arc::new(own.merged(&server))
}

#[test]
fn a_slash_asks_for_the_index_once_until_discord_says_it_changed() {
    let mut app = super::discord_server();
    app.dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
    app.dispatch(Action::SelectRoom(GENERAL.into()));
    assert_eq!(app.state.selected.as_deref(), Some(GENERAL));
    assert!(
        app.slash_commands(GENERAL, "").is_empty(),
        "nothing asked yet"
    );
    let effects = app.dispatch(Action::SlashQuery(String::new()));
    assert_eq!(asked(&effects), Some(GENERAL));
    assert!(app.state.app_commands.loading(GENERAL));
    // Typing on while it comes asks nothing more.
    let effects = app.dispatch(Action::SlashQuery("no".into()));
    assert_eq!(asked(&effects), None);
    app.apply(Event::CommandIndex {
        room: GENERAL.into(),
        index: Ok(index()),
    });
    let offered: Vec<_> = app
        .slash_commands(GENERAL, "no")
        .into_iter()
        .map(|command| (command.name, command.app_name))
        .collect();
    // /ping needs Use Application Commands; /notes isn't for servers.
    assert_eq!(offered, [("note".to_owned(), "Notes".to_owned())]);
    assert!(app.slash_commands(GENERAL, "x").is_empty());
    let effects = app.dispatch(Action::SlashQuery(String::new()));
    assert_eq!(asked(&effects), None, "kept");
    // Another server's change keeps it; its own drops it.
    app.apply(Event::CommandIndexChanged {
        guild: Some("20".into()),
    });
    assert!(app.state.app_commands.index(GENERAL).is_some());
    app.apply(Event::CommandIndexChanged {
        guild: Some("10".into()),
    });
    assert!(app.state.app_commands.index(GENERAL).is_none());
    let effects = app.dispatch(Action::SlashQuery(String::new()));
    assert_eq!(asked(&effects), Some(GENERAL));
    app.apply(Event::CommandIndex {
        room: GENERAL.into(),
        index: Err("Discord said no".into()),
    });
    assert_eq!(
        app.state.app_commands.error.as_deref(),
        Some("Discord said no")
    );
}

#[test]
fn personal_command_index_partial_results_remain_usable_and_can_reload() {
    let mut app = super::discord_server();
    app.dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
    app.dispatch(Action::SelectRoom(GENERAL.into()));
    app.dispatch(Action::SlashQuery(String::new()));
    let mut partial = (*index()).clone();
    partial.partial = true;
    app.apply(Event::CommandIndex {
        room: GENERAL.into(),
        index: Ok(Arc::new(partial)),
    });
    let rows = app.command_rows();
    assert_eq!(
        rows.iter().map(|row| row.name.as_str()).collect::<Vec<_>>(),
        ["note"]
    );
    assert!(
        app.command_heading(&rows)
            .contains("Some apps couldn't load")
    );
    assert_eq!(asked(&app.dispatch(Action::AskAppCommands)), Some(GENERAL));
    assert_eq!(
        asked(&app.dispatch(Action::AskAppCommands)),
        None,
        "pending load deduplicates"
    );
    app.apply(Event::CommandIndex {
        room: GENERAL.into(),
        index: Ok(index()),
    });
    assert_eq!(
        asked(&app.dispatch(Action::AskAppCommands)),
        None,
        "complete result is retained"
    );
}

#[test]
fn personal_command_index_frequent_rows_require_exact_local_usage() {
    let mut app = super::discord_server();
    app.dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
    app.dispatch(Action::SelectRoom(GENERAL.into()));
    app.dispatch(Action::SlashQuery(String::new()));
    app.apply(Event::CommandIndex {
        room: GENERAL.into(),
        index: Ok(index()),
    });
    app.state.set_favorite_command_apps(vec!["8".into()]);
    assert!(
        !app.command_rows()[0].frequently_used,
        "favoriting does not invent usage"
    );
    for (application, expected) in [("9", false), ("8", true)] {
        app.state.set_command_history(
            serde_json::from_value(serde_json::json!({"entries":[{
                "app":application,"command":"2","path":[],"count":1
            }]}))
            .unwrap(),
        );
        assert_eq!(app.command_rows()[0].frequently_used, expected);
    }
    app.state.set_command_history(Default::default());
    assert!(
        !app.command_rows()[0].frequently_used,
        "restoring empty account history clears usage"
    );
    let mut options = self_option_fixture(6);
    options.state.members = Some(Ok(Arc::new(vec![member("2", "Chef")])));
    options.dispatch(Action::SetDraft("Chef".into()));
    assert!(
        options
            .command_rows()
            .iter()
            .all(|row| !row.frequently_used)
    );
}

#[test]
fn a_commands_name_and_a_space_picks_it_and_a_slash_waits_for_the_commands() {
    let mut app = super::discord_server();
    app.dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
    app.dispatch(Action::SelectRoom(GENERAL.into()));
    app.dispatch(Action::SetDraft("/note".into()));
    assert!(app.state.app_commands.loading(GENERAL));
    // Until the commands come, `/note` may be one: Enter sends nothing, and
    // Up is the picker's.
    assert!(app.dispatch(Action::Send).is_empty());
    assert!(app.dispatch(Action::EditLast).is_empty());
    app.apply(Event::CommandIndex {
        room: GENERAL.into(),
        index: Ok(index()),
    });
    // A whole name and a space picks it, as in Discord's client.
    app.dispatch(Action::SetDraft("/note ".into()));
    let draft = app.state.command_draft().expect("/note picked");
    assert_eq!(draft.name, "note");
    assert!(app.dispatch(Action::EditLast).is_empty());
    app.dispatch(Action::CloseCommand(false));
    // A name no command has goes as text.
    app.dispatch(Action::SetDraft("/nothing here".into()));
    assert!(app.state.command_draft().is_none());
    assert_eq!(app.state.slash_query(), None);
    // The start of a name keeps the picker.
    app.dispatch(Action::SetDraft("/no".into()));
    assert_eq!(app.state.slash_query(), Some("no"));
}

#[test]
fn favorite_command_apps_keep_permissions_context_and_pick_identity() {
    let mut denied = super::discord_server();
    denied.dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
    denied.dispatch(Action::SelectRoom(GENERAL.into()));
    denied.dispatch(Action::SlashQuery(String::new()));
    denied.apply(Event::CommandIndex {
        room: GENERAL.into(),
        index: Ok(index()),
    });
    denied.state.set_favorite_command_apps(vec![
        "7".into(),
        "8".into(),
        "7".into(),
        "invalid".into(),
    ]);
    assert_eq!(denied.state.favorite_command_apps(), &["7", "8"]);
    assert!(
        denied.slash_commands(GENERAL, "ping").is_empty(),
        "a favorite cannot bypass Use Application Commands"
    );
    assert!(
        denied
            .slash_commands(GENERAL, "notes")
            .iter()
            .all(|row| row.name != "notes"),
        "a favorite cannot offer a DM-only command in a server"
    );
    assert!(
        denied
            .command_rows()
            .iter()
            .all(|row| row.application_id.as_deref() == Some("8"))
    );

    let (mut app, room) = super::in_discord_channel();
    let index = CommandIndex::parse(
        &serde_json::json!({
            "applications": [{"id": "500", "name": "First app"}, {"id": "600", "name": "Favorite app"}],
            "application_commands": [
                {"id": "501", "application_id": "500", "type": 1, "name": "ping", "description": "First", "default_member_permissions": null},
                {"id": "601", "application_id": "600", "type": 1, "name": "ping", "description": "Favorite", "default_member_permissions": null,
                 "options": [{"type": 5, "name": "quiet", "description": "Quiet mode"}]}
            ]
        }),
        false,
    );
    app.dispatch(Action::SlashQuery("ping".into()));
    app.apply(Event::CommandIndex {
        room,
        index: Ok(Arc::new(index)),
    });
    let usage = app.state.command_history().clone();
    app.state.set_favorite_command_apps(vec!["600".into()]);
    assert_eq!(app.command_rows()[0].application_id.as_deref(), Some("600"));
    app.dispatch(Action::PickCommand(0));
    assert!(
        app.command_rows()
            .iter()
            .all(|row| row.application_id.is_none()),
        "option values have no favorite-app action"
    );
    assert_eq!(
        app.state.command_history(),
        &usage,
        "favoriting is not usage and does not alter history serialization"
    );
    let sent = app.dispatch(Action::Send);
    assert!(
        sent.iter().any(|effect| matches!(effect,
            Effect::Backend(Command::Discord(DiscordCommand::RunCommand(run)))
                if run.application == "600" && run.command["id"] == "601"
        )),
        "the selected favorite keeps its actual command/application identity"
    );
    app.state.set_favorite_command_apps(vec![]);
    assert!(app.state.favorite_command_apps().is_empty());
}

#[test]
fn slash_suggestions_preserve_permissions_context_and_ranked_pick_identity() {
    let mut app = super::discord_server();
    app.dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
    app.dispatch(Action::SelectRoom(GENERAL.into()));
    app.dispatch(Action::SlashQuery(String::new()));
    app.apply(Event::CommandIndex {
        room: GENERAL.into(),
        index: Ok(index()),
    });
    let history = serde_json::from_value(serde_json::json!({ "entries": [
        { "app": "7", "command": "1", "path": [], "count": 100 },
        { "app": "8", "command": "3", "path": [], "count": 100 }
    ] }))
    .unwrap();
    app.state.set_command_history(history);
    assert!(
        app.slash_commands(GENERAL, "png").is_empty(),
        "history cannot bypass denied server permissions"
    );
    assert!(
        app.slash_commands(GENERAL, "nts").is_empty(),
        "history cannot offer a DM-only command here"
    );
    app.dispatch(Action::SlashQuery("nte".into()));
    assert_eq!(app.command_rows()[0].name, "note");
    app.dispatch(Action::PickCommand(0));
    assert_eq!(
        app.state.command_draft().unwrap().name,
        "note",
        "picking uses the same ranked identity"
    );

    let (mut app, room) = super::in_discord_channel();
    app.dispatch(Action::SlashQuery(String::new()));
    app.apply(Event::CommandIndex {
        room,
        index: Ok(super::command_index()),
    });
    assert!(
        app.dispatch(Action::SetDraft("/con g".into()))
            .iter()
            .all(|effect| !matches!(
                effect,
                Effect::Backend(Command::Discord(DiscordCommand::CommandIndex { .. }))
            ))
    );
    assert_eq!(
        app.state.slash_query(),
        Some("con g"),
        "abbreviated subcommands keep the picker open"
    );
    assert_eq!(app.command_rows()[0].name, "config get");
    app.dispatch(Action::PickCommand(0));
    let effects = app.dispatch(Action::Send);
    let run = effects
        .iter()
        .find_map(|effect| match effect {
            Effect::Backend(Command::Discord(DiscordCommand::RunCommand(run))) => Some(run),
            _ => None,
        })
        .unwrap();
    assert_eq!(run.command["id"], "503");
    assert_eq!(
        run.options,
        serde_json::json!([{ "type": 1, "name": "get", "options": [] }])
    );
}

#[test]
fn slash_suggestions_learn_only_valid_send_without_option_data() {
    let (mut app, room) = super::in_discord_channel();
    app.dispatch(Action::SlashQuery(String::new()));
    app.apply(Event::CommandIndex {
        room: room.clone(),
        index: Ok(super::command_index()),
    });
    let empty = app.state.command_history().clone();
    app.dispatch(Action::SlashQuery("echo".into()));
    app.dispatch(Action::PickCommand(0));
    app.dispatch(Action::Send);
    assert_eq!(
        app.state.command_history(),
        &empty,
        "a missing required option is not use"
    );
    app.dispatch(Action::SetDraft("private option value".into()));
    assert_eq!(
        app.state.command_history(),
        &empty,
        "typing and picking never count"
    );
    let effects = app.dispatch(Action::Send);
    assert!(effects.iter().any(|effect| matches!(
        effect,
        Effect::Backend(Command::Discord(DiscordCommand::RunCommand(_)))
    )));
    let json = serde_json::to_value(app.state.command_history()).unwrap();
    assert_eq!(
        json,
        serde_json::json!({ "entries": [
        { "app": "500", "command": "502", "path": [], "count": 1 }
    ] }),
        "only identity/count is serializable; option values never enter history"
    );
    app.dispatch(Action::SlashQuery(String::new()));
    assert_eq!(
        app.command_rows()[0].name,
        "echo",
        "bare slash recommends the used command"
    );
    assert_eq!(
        app.slash_commands(&room, "pi")[0].name,
        "ping",
        "typed relevance still wins"
    );
    app.state.set_command_history(CommandHistory::default());
    assert_eq!(
        app.command_rows()[0].name,
        "ping",
        "changing account history resets ranking"
    );
    app.state
        .set_command_history(serde_json::from_value(json).unwrap());
    assert_eq!(
        app.command_rows()[0].name,
        "echo",
        "restored identity history preserves ranking"
    );
}

#[test]
fn slash_space_keeps_duplicate_apps_for_explicit_selection() {
    let (mut app, room) = super::in_discord_channel();
    let index = CommandIndex::parse(
        &serde_json::json!({
            "applications": [{"id": "500", "name": "First"}, {"id": "600", "name": "Recent"}],
            "application_commands": [
                {"id": "501", "application_id": "500", "type": 1, "name": "ping", "description": "First ping", "default_member_permissions": null},
                {"id": "601", "application_id": "600", "type": 1, "name": "ping", "description": "Recent ping", "default_member_permissions": null}
            ]
        }),
        false,
    );
    app.dispatch(Action::SlashQuery(String::new()));
    app.apply(Event::CommandIndex {
        room: room.clone(),
        index: Ok(Arc::new(index)),
    });
    app.state.set_command_history(
        serde_json::from_value(serde_json::json!({"entries": [
            {"app": "600", "command": "601", "path": [], "count": 2}
        ]}))
        .unwrap(),
    );
    assert_eq!(app.slash_commands(&room, "ping")[0].app, "600");
    app.dispatch(Action::SetDraft("/ping ".into()));
    assert_eq!(app.state.draft(), "/ping ");
    assert_eq!(app.state.slash_query(), Some("ping "));
    assert!(app.state.command_draft().is_none());
    assert_eq!(
        app.command_rows()
            .iter()
            .map(|row| row.application_id.as_deref().unwrap())
            .collect::<Vec<_>>(),
        ["600", "500"]
    );
    app.dispatch(Action::PickCommand(1));
    let effects = app.dispatch(Action::Send);
    assert!(effects.iter().any(|effect| matches!(effect,
        Effect::Backend(Command::Discord(DiscordCommand::RunCommand(run))) if run.application == "500" && run.command["id"] == "501"
    )));
}

#[test]
fn slash_space_keeps_subcommands_until_the_complete_path_is_unambiguous() {
    let (mut app, room) = super::in_discord_channel();
    let index = CommandIndex::parse(
        &serde_json::json!({
            "applications": [{"id": "500", "name": "First"}, {"id": "600", "name": "Second"}],
            "application_commands": [
                {"id": "501", "application_id": "500", "type": 1, "name": "add", "description": "Add",
                 "options": [{"type": 3, "name": "text", "description": "Text", "required": true}]},
                {"id": "601", "application_id": "600", "type": 1, "name": "add", "description": "Add to an order",
                 "options": [
                    {"type": 1, "name": "fee", "description": "Add a fee"},
                    {"type": 1, "name": "fees", "description": "Add multiple fees"},
                    {"type": 1, "name": "files", "description": "Add files"},
                    {"type": 1, "name": "balance", "description": "Add a balance"},
                    {"type": 1, "name": "payment", "description": "Add a payment"}
                 ]}
            ]
        }),
        false,
    );
    app.dispatch(Action::SlashQuery(String::new()));
    app.apply(Event::CommandIndex {
        room: room.clone(),
        index: Ok(Arc::new(index)),
    });

    for typed in [
        "/add ", "/add f", "/add f ", "/add fe", "/add fe ", "/add fee",
    ] {
        app.dispatch(Action::SetDraft(typed.into()));
        assert_eq!(app.state.draft(), typed);
        assert_eq!(app.state.slash_query(), typed.strip_prefix('/'));
        assert!(app.state.command_draft().is_none());
        assert!(app.command_rows().iter().any(|row| row.name == "add fee"));
    }
    app.dispatch(Action::SetDraft("/add  fee ".into()));
    let command = app.state.command_draft().expect("completed subcommand");
    assert_eq!(command.name, "add fee");
    let effects = app.dispatch(Action::Send);
    assert!(effects.iter().any(|effect| matches!(effect,
        Effect::Backend(Command::Discord(DiscordCommand::RunCommand(run))) if run.application == "600" && run.command["id"] == "601"
    )));

    app.dispatch(Action::SetDraft(String::new()));
    app.dispatch(Action::SetDraft("/ADD A  receipt".into()));
    let command = app.state.command_draft().expect("unambiguous invocation");
    assert_eq!(command.name, "add");
    assert_eq!(command.options[0].text, "A  receipt");
}
