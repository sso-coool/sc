//! Call menus retain their actual conversation even while another is selected.
use super::*;
use yapfast_discord::service::{Conversation, Friend, Snapshot, Status};

const DM: &str = "discord:@me:30";
const GROUP: &str = "discord:@me:31";
const OTHER: &str = "discord:@me:32";
const USER: &str = "2718281";

fn participant(user: &str) -> voice::Participant {
    voice::Participant {
        id: user.into(),
        user: "Annie".into(),
        person: user.into(),
        local: user == "1",
        muted: false,
        deafened: false,
        server_muted: false,
        server_deafened: false,
        speaking: false,
        connected: true,
        problem: None,
        streaming: false,
        video: None,
        avatar: None,
    }
}

fn fixture() -> Application {
    let mut app = Application::default();
    app.apply(discord_event(Snapshot {
        status: Status::Online,
        user_id: Some("1".into()),
        friends: vec![USER.into()].into(),
        friend_list: vec![Friend {
            user_id: USER.into(),
            name: "Annie".into(),
            avatar: String::new(),
            nickname: Some("Anne".into()),
            since: None,
            presence: None,
            activity: None,
            activities: Default::default(),
        }]
        .into(),
        conversations: vec![
            Arc::new(Conversation {
                id: "30".into(),
                name: "Annie".into(),
                person: Some(USER.into()),
                people: 2,
                ..Default::default()
            }),
            Arc::new(Conversation {
                id: "31".into(),
                name: "Group".into(),
                group: true,
                people: 3,
                ..Default::default()
            }),
            Arc::new(Conversation {
                id: "32".into(),
                name: "Other".into(),
                person: Some("3".into()),
                people: 2,
                ..Default::default()
            }),
        ],
        ..Default::default()
    }));
    app.state.selected = Some(OTHER.into());
    app.state.voice.phase = voice::Phase::Connected;
    app.state.voice.room = Some(DM.into());
    app.state.voice.participants = vec![participant("1"), participant(USER)];
    app
}

#[test]
fn dm_voice_menu_reuses_the_called_dms_actions_and_gates_local_controls() {
    use MenuChoice::*;
    let mut app = fixture();
    let choices = app.voice_person_choices(DM, USER);
    for expected in [
        Profile,
        Pin,
        AddNote,
        EditNickname,
        CloseDm,
        LocalMute,
        SoundboardMute,
        Unfriend,
        Ignore,
        Block,
        Mute,
        CopyId,
    ] {
        assert!(choices.contains(&expected), "missing {expected:?}");
    }
    assert_eq!(choices, app.menu_choices(DM));
    assert!(!app.menu_choices(OTHER).contains(&LocalMute));
    assert!(
        !choices
            .iter()
            .any(|choice| matches!(choice, Roles | ServerMute | Kick | Ban))
    );
    assert!(app.voice_person_choices(OTHER, USER).is_empty());
    assert!(app.voice_person_choices(DM, "3").is_empty());
    assert_eq!(app.state.selected.as_deref(), Some(OTHER));
    app.state
        .voice
        .participants
        .retain(|person| person.person != USER);
    assert!(app.voice_person_choices(DM, USER).is_empty());
    app.state.voice.participants.push(participant(USER));
    app.state.voice.phase = voice::Phase::Disconnected;
    assert!(app.voice_person_choices(DM, USER).is_empty());
    assert!(!app.menu_choices(DM).contains(&LocalMute));
}

#[test]
fn dm_voice_menu_group_participants_do_not_act_on_the_groups_conversation() {
    use MenuChoice::*;
    let mut app = fixture();
    app.state.voice.room = Some(GROUP.into());
    let choices = app.voice_person_choices(GROUP, USER);
    for expected in [
        Profile,
        Message,
        AddNote,
        EditNickname,
        LocalMute,
        SoundboardMute,
        Unfriend,
        Block,
        CopyId,
    ] {
        assert!(choices.contains(&expected), "missing {expected:?}");
    }
    assert!(
        !choices
            .iter()
            .any(|choice| matches!(choice, Pin | CloseDm | LeaveGroup | Mute | CopyLink))
    );
    assert_eq!(
        app.voice_person_choices(GROUP, "1"),
        [SelfMute, SelfDeafen, CopyId]
    );
    app.state.preview = true;
    assert!(app.voice_person_choices(GROUP, USER).is_empty());
}
