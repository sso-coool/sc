//! Thread roster results are never channel readers or another account's list.
use super::*;
use yapfast_discord::{
    ready,
    service::{Snapshot, Status},
};

const MAIN: &str = "discord:10:11";
const PRIVATE: &str = "discord:10:30";
const PUBLIC: &str = "discord:10:31";

fn app() -> Application {
    let server = ready::server(&serde_json::json!({
        "id":"10", "owner_id":"1", "properties":{"name":"Test"},
        "roles":[{"id":"10","name":"@everyone","permissions":"68608"}],
        "channels":[{"id":"11","type":0,"name":"tickets"}],
        "threads":[
            {"id":"30","type":12,"name":"Private ticket","parent_id":"11",
             "member":{"id":"30","user_id":"1","flags":1},
             "thread_metadata":{"archived":false,"locked":false}},
            {"id":"31","type":11,"name":"Public thread","parent_id":"11",
             "member":{"id":"31","user_id":"1","flags":1},
             "thread_metadata":{"archived":false,"locked":false}}
        ]
    }))
    .unwrap();
    let mut app = Application::default();
    app.apply(discord_event(Snapshot {
        status: Status::Online,
        user_id: Some("1".into()),
        servers: vec![MarkedServer::from(server)],
        viewing: vec!["30".into(), "31".into()],
        ..Default::default()
    }));
    app.dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
    app
}

fn roster(account: &str, room: &str, id: &str) -> Event {
    Event::DiscordThreadMembers {
        account: account.into(),
        room: room.into(),
        members: vec![member(id, id)],
    }
}

#[test]
fn thread_roster_private_and_public_open_empty_then_show_only_joined_members() {
    let mut app = app();
    for room in [PRIVATE, PUBLIC] {
        app.dispatch(Action::SelectRoom(room.into()));
        assert_eq!(app.state.selected.as_deref(), Some(room));
        assert!(
            app.state.members.is_none(),
            "never inherit the previous room's members"
        );
        // A late parent channel reader list cannot be projected into the thread.
        app.apply(Event::Members {
            room: MAIN.into(),
            members: Ok(vec![member("guild-member", "Other")]),
        });
        assert!(app.state.members.is_none());
        app.apply(Event::Members {
            room: room.into(),
            members: Ok(vec![member("wrong-source", "Guild reader")]),
        });
        assert!(
            app.state.members.is_none(),
            "threads never accept a generic channel readers list"
        );
        app.apply(roster("1", room, "joined"));
        let members = app.state.members.as_ref().unwrap().as_ref().unwrap();
        assert_eq!(members.len(), 1);
        assert_eq!(members[0].id, "joined");
    }
}

#[test]
fn thread_roster_rejects_other_room_account_and_no_longer_readable_thread() {
    let mut app = app();
    app.dispatch(Action::SelectRoom(PRIVATE.into()));
    app.apply(roster("2", PRIVATE, "prior-account"));
    app.apply(roster("1", PUBLIC, "other-thread"));
    assert!(app.state.members.is_none());
    app.apply(roster("1", PRIVATE, "current"));
    app.dispatch(Action::SelectRoom(PUBLIC.into()));
    assert!(app.state.members.is_none());
    app.apply(roster("1", PRIVATE, "late"));
    assert!(app.state.members.is_none());
    app.state.discord_user = Some("2".into());
    app.apply(roster("1", PUBLIC, "prior-account"));
    assert!(app.state.members.is_none());
    let room = app
        .state
        .rooms
        .iter_mut()
        .find(|room| room.id == PUBLIC)
        .unwrap();
    Arc::make_mut(room).locked = true;
    app.apply(roster("2", PUBLIC, "no-access"));
    assert!(app.state.members.is_none());
}

#[test]
fn thread_roster_beside_thread_does_not_replace_main_channel_members() {
    let mut app = app();
    app.dispatch(Action::SelectRoom(MAIN.into()));
    app.apply(Event::Members {
        room: MAIN.into(),
        members: Ok(vec![member("reader", "Channel reader")]),
    });
    app.dispatch(Action::OpenAside(PRIVATE.into()));
    assert_eq!(app.state.selected.as_deref(), Some(MAIN));
    app.apply(roster("1", PRIVATE, "thread-member"));
    let members = app.state.members.as_ref().unwrap().as_ref().unwrap();
    assert_eq!(members[0].id, "reader");
    // Opening that thread as main now gives it its own roster.
    app.dispatch(Action::SelectRoom(PRIVATE.into()));
    assert!(app.state.members.is_none());
    app.apply(roster("1", PRIVATE, "thread-member"));
    assert_eq!(
        app.state.members.as_ref().unwrap().as_ref().unwrap()[0].id,
        "thread-member"
    );
}
