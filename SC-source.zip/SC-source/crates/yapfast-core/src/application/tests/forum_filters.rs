use super::*;

fn forum_app(history: bool) -> Application {
    use yapfast_discord::{
        ready,
        ready::permission as p,
        service::{Snapshot, Status},
    };
    let server = ready::server(&serde_json::json!({
        "id":"10", "owner_id":"99", "properties":{"name":"Forum tests"},
        "roles":[{"id":"10","name":"@everyone","position":0,"permissions":
            (p::VIEW_CHANNEL | if history { p::READ_MESSAGE_HISTORY } else { 0 }).to_string()}],
        "channels":[{"id":"15","type":15,"name":"ideas","available_tags":[
            {"id":"7","name":"Bug"},{"id":"8","name":"Idea"}]}]
    }))
    .unwrap();
    let mut app = Application::default();
    app.apply(discord_event(Snapshot {
        status: Status::Online,
        user_id: Some("1".into()),
        servers: vec![MarkedServer::marked(server, ServerMarks::default(), |_| {
            ChannelMarks::default()
        })],
        ..Default::default()
    }));
    app.dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
    app.dispatch(Action::SelectRoom("discord:10:15".into()));
    app
}

fn requested(effects: &[Effect]) -> (u64, u32) {
    effects
        .iter()
        .find_map(|effect| match effect {
            Effect::Backend(Command::Discord(DiscordCommand::ForumThreads {
                request,
                offset,
                ..
            })) => Some((*request, *offset)),
            _ => None,
        })
        .expect("one server-side forum page")
}

fn page(
    app: &mut Application,
    request: u64,
    offset: u32,
    ids: impl Iterator<Item = u32>,
    more: bool,
) {
    let rows: Vec<chat::ListedThread> = ids
        .map(|id| chat::ListedThread {
            room: format!("discord:10:{id}"),
            name: format!("Post {id}"),
            archived: id % 2 == 0,
            ..Default::default()
        })
        .collect();
    let starters = rows
        .iter()
        .map(|row| {
            (
                row.room.clone(),
                Some(chat::PostStarter {
                    text: "Starter".into(),
                    ..Default::default()
                }),
            )
        })
        .collect();
    app.apply(Event::ForumThreads {
        account: Some("1".into()),
        room: "discord:10:15".into(),
        request,
        offset,
        result: Ok((rows, more)),
        starters,
    });
}

fn found(app: &Application) -> Vec<ForumPost> {
    app.forum_posts().unwrap().found.unwrap().unwrap().unwrap()
}

#[test]
fn forum_filters_are_server_side_and_reject_late_queries_accounts_and_offsets() {
    let mut app = forum_app(true);
    assert!(
        app.dispatch(Action::FilterPosts("unknown".into()))
            .is_empty()
    );
    let first = app.dispatch(Action::FilterPosts("7".into()));
    assert!(
        matches!(&first[0], Effect::Backend(Command::Discord(DiscordCommand::ForumThreads {
        tags, query, by_creation: false, offset: 0, account: Some(account), ..
    })) if tags == &["7".to_owned()] && query.is_empty() && account == "1")
    );
    let (old, _) = requested(&first);
    app.dispatch(Action::FilterPosts("7".into()));
    let (current, _) = requested(&app.dispatch(Action::FilterPosts("7".into())));
    assert_ne!(
        old, current,
        "A to B to A must not reuse a request identity"
    );
    page(&mut app, old, 0, 100..125, false);
    assert!(app.forum_posts().unwrap().found.unwrap().is_none());
    assert!(app.state.forum().unwrap().starters.is_empty());
    page(&mut app, current, 25, 100..125, false);
    assert!(app.state.forum().unwrap().loading());
    app.apply(Event::ForumThreads {
        account: Some("another account".into()),
        room: "discord:10:15".into(),
        request: current,
        offset: 0,
        result: Err("wrong account".into()),
        starters: vec![],
    });
    assert!(app.state.forum().unwrap().loading());
    page(&mut app, current, 0, 100..125, true);
    assert_eq!(found(&app).len(), 25);
    assert!(found(&app).iter().any(|post| post.thread.archived));
    assert!(found(&app).iter().any(|post| !post.thread.archived));
    let sorted = app.dispatch(Action::SortPosts(true));
    assert!(
        matches!(&sorted[0], Effect::Backend(Command::Discord(DiscordCommand::ForumThreads { tags, by_creation:true, offset:0,.. })) if tags == &["7".to_owned()])
    );
    assert!(app.state.forum().unwrap().starters.is_empty());
    let query = app.dispatch(Action::SearchPosts("  title  ".into()));
    assert!(
        matches!(&query[0], Effect::Backend(Command::Discord(DiscordCommand::ForumThreads { query, tags, by_creation:true,.. })) if query == "title" && tags == &["7".to_owned()])
    );
    let mut denied = forum_app(false);
    assert!(denied.dispatch(Action::FilterPosts("7".into())).is_empty());
    let (pending, _) = requested(&query);
    app.apply(Event::Discord(denied.discord.clone().unwrap()));
    assert!(!app.may("discord:10:15", chat::Permission::ReadHistory));
    page(&mut app, pending, 0, 900..925, false);
    assert!(
        app.forum_posts().unwrap().found.unwrap().is_none(),
        "permission withdrawal rejects the in-flight result"
    );
    assert!(app.state.forum().unwrap().starters.is_empty());
    assert!(denied.dispatch(Action::SortPosts(true)).is_empty());
    assert!(
        denied
            .dispatch(Action::SearchPosts("title".into()))
            .is_empty()
    );
}

#[test]
fn forum_filters_paginate_and_retry_without_losing_loaded_posts() {
    let mut app = forum_app(true);
    let (request, _) = requested(&app.dispatch(Action::SearchPosts("idea".into())));
    assert!(
        app.dispatch(Action::MorePosts).is_empty(),
        "only one page in flight"
    );
    page(&mut app, request, 0, 100..125, true);
    let next = app.dispatch(Action::MorePosts);
    assert_eq!(requested(&next), (request, 25));
    app.apply(Event::ForumThreads {
        account: Some("1".into()),
        room: "discord:10:15".into(),
        request,
        offset: 25,
        result: Err("Try again".into()),
        starters: vec![],
    });
    assert_eq!(found(&app).len(), 25);
    assert_eq!(app.state.forum().unwrap().result_note(), "Try again");
    assert_eq!(requested(&app.dispatch(Action::MorePosts)), (request, 25));
    page(&mut app, request, 25, 124..149, false);
    assert_eq!(found(&app).len(), 49, "duplicates across pages are merged");
    assert!(!app.state.forum().unwrap().wants_more(0));
    assert!(app.dispatch(Action::MorePosts).is_empty());
    assert!(app.state.forum().unwrap().result_note().is_empty());
}

#[test]
fn forum_filters_bound_results_and_forget_them_when_closed() {
    let mut app = forum_app(true);
    let (request, _) = requested(&app.dispatch(Action::SortPosts(false)));
    for offset in (0..500).step_by(25) {
        page(&mut app, request, offset, 100 + offset..125 + offset, true);
        if offset < 475 {
            assert_eq!(
                requested(&app.dispatch(Action::MorePosts)),
                (request, offset + 25)
            );
        }
    }
    assert_eq!(found(&app).len(), 500);
    assert_eq!(app.state.forum().unwrap().starters.len(), 500);
    assert!(app.state.forum().unwrap().result_note().contains("500"));
    assert!(app.dispatch(Action::MorePosts).is_empty());
    app.close_forum();
    app.show_forum("discord:10:15".into());
    page(&mut app, request, 0, 900..925, false);
    assert!(app.forum_posts().unwrap().found.is_none());
    assert!(app.state.forum().unwrap().starters.is_empty());
}
