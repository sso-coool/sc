use super::*;
use yapfast_discord::{
    ready,
    service::{Snapshot, Status},
};

const THREAD: &str = "discord:10:30";
const PARENT: &str = "discord:10:11";
const MANAGE: u64 = 1 << 34;
const BASE: u64 = (1 << 10) | (1 << 16) | (1 << 38);

fn snapshot(owner: &str, manages: bool, metadata: serde_json::Value) -> Snapshot {
    let server = ready::server(&serde_json::json!({
        "id":"10", "owner_id":"9", "properties":{"name":"Fixture"},
        "roles":[{"id":"10", "name":"@everyone", "permissions":(BASE | if manages {MANAGE} else {0}).to_string()}],
        "channels":[{"id":"11", "type":0, "name":"tickets"}],
        "threads":[{"id":"30", "type":12, "name":"Ticket", "parent_id":"11", "owner_id":owner,
            "rate_limit_per_user":10, "member":{"id":"30", "user_id":"1", "flags":1},
            "thread_metadata":metadata}]
    })).unwrap();
    Snapshot {
        status: Status::Online,
        user_id: Some("1".into()),
        servers: vec![MarkedServer::from(server)],
        viewing: vec!["30".into()],
        ..Default::default()
    }
}

fn metadata() -> serde_json::Value {
    serde_json::json!({"archived":false,"locked":false,"invitable":true,"auto_archive_duration":1440})
}

fn app(owner: &str, manages: bool) -> Application {
    let mut app = Application::default();
    app.apply(discord_event(snapshot(owner, manages, metadata())));
    app.dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
    app.dispatch(Action::SelectRoom(THREAD.into()));
    assert_eq!(app.state.selected.as_deref(), Some(THREAD));
    app
}

fn operation(effects: Vec<Effect>) -> (String, String, String, chat::ThreadChange) {
    let mut effects = effects.into_iter();
    let Some(Effect::Backend(Command::Discord(DiscordCommand::ManageThread {
        room,
        account,
        request,
        change,
    }))) = effects.next()
    else {
        panic!("expected one thread request")
    };
    assert!(effects.next().is_none());
    (room, account, request, change)
}

fn reply(
    app: &mut Application,
    operation: &(String, String, String, chat::ThreadChange),
    result: Result<(), String>,
) {
    app.apply(Event::ThreadChanged {
        room: operation.0.clone(),
        account: operation.1.clone(),
        request: operation.2.clone(),
        result,
    });
}

#[test]
fn thread_management_permissions_distinguish_creator_moderator_and_member() {
    let creator = app("1", false);
    let choices = creator.thread_more_choices(THREAD);
    for allowed in [
        MenuChoice::EditThread,
        MenuChoice::CloseThread,
        MenuChoice::ThreadInvitable,
    ] {
        assert!(choices.contains(&allowed));
    }
    for denied in [MenuChoice::DeleteThread, MenuChoice::LockThread] {
        assert!(!choices.contains(&denied));
    }
    assert!(
        !creator
            .thread_more_choices(PARENT)
            .contains(&MenuChoice::CloseThread)
    );
    let moderator = app("2", true);
    assert_eq!(
        moderator.thread_more_choices(THREAD),
        vec![
            MenuChoice::MarkUnread,
            MenuChoice::CloseThread,
            MenuChoice::LockThread,
            MenuChoice::EditThread,
            MenuChoice::CopyLink,
            MenuChoice::ChannelMute,
            MenuChoice::ChannelNotifications,
            MenuChoice::ThreadInvitable,
            MenuChoice::DeleteThread,
            MenuChoice::LeaveThread,
            MenuChoice::CopyId,
        ]
    );
    for allowed in [
        MenuChoice::EditThread,
        MenuChoice::CloseThread,
        MenuChoice::ThreadInvitable,
        MenuChoice::DeleteThread,
        MenuChoice::LockThread,
    ] {
        assert!(moderator.thread_more_choices(THREAD).contains(&allowed));
    }
    let mut member = app("2", false);
    for denied in [
        MenuChoice::EditThread,
        MenuChoice::CloseThread,
        MenuChoice::ThreadInvitable,
        MenuChoice::DeleteThread,
        MenuChoice::LockThread,
    ] {
        assert!(!member.thread_more_choices(THREAD).contains(&denied));
    }
    assert!(
        member
            .dispatch(Action::ArchiveThread {
                room: THREAD.into(),
                archived: true
            })
            .is_empty()
    );
    let mut closed = metadata();
    closed["archived"] = true.into();
    member.apply(discord_event(snapshot("2", false, closed.clone())));
    assert!(
        !member
            .thread_more_choices(THREAD)
            .contains(&MenuChoice::LeaveThread)
    );
    assert!(
        member
            .dispatch(Action::JoinThread {
                room: THREAD.into(),
                join: false,
                location: "Thread Context Menu"
            })
            .is_empty()
    );
    assert!(
        member
            .thread_more_choices(THREAD)
            .contains(&MenuChoice::ReopenThread)
    );
    closed["locked"] = true.into();
    member.apply(discord_event(snapshot("2", false, closed.clone())));
    assert!(
        !member
            .thread_more_choices(THREAD)
            .contains(&MenuChoice::ReopenThread)
    );
    member.apply(discord_event(snapshot("2", true, closed)));
    assert!(
        member
            .thread_more_choices(THREAD)
            .contains(&MenuChoice::ReopenThread)
    );
    assert!(
        !member
            .thread_more_choices(THREAD)
            .contains(&MenuChoice::EditThread)
    );
    let request = operation(member.dispatch(Action::ArchiveThread {
        room: THREAD.into(),
        archived: false,
    }));
    assert_eq!(request.0, THREAD);
    assert_eq!(request.3, chat::ThreadChange::Archive(false));
}

#[test]
fn thread_management_edit_patches_only_changed_fields_and_revalidates_permissions() {
    let mut app = app("1", false);
    assert!(
        app.dispatch(Action::OpenThreadSettings(THREAD.into()))
            .is_empty()
    );
    let dialog = app.state.thread_dialog.as_ref().unwrap();
    assert_eq!(dialog.name, "Ticket");
    assert!(!dialog.can_slowmode);
    assert_eq!(dialog.slowmode, 10);
    app.dispatch(Action::ThreadSettings(ThreadInput::Slowmode(60)));
    assert_eq!(app.state.thread_dialog.as_ref().unwrap().slowmode, 10);
    app.dispatch(Action::ThreadSettings(ThreadInput::Name(
        "Renamed ticket".into(),
    )));
    app.dispatch(Action::ThreadSettings(ThreadInput::ArchiveMinutes(4320)));
    let request = operation(app.dispatch(Action::ThreadSettings(ThreadInput::Save)));
    assert_eq!(request.0, THREAD);
    assert_eq!(
        request.3,
        chat::ThreadChange::Edit(chat::ThreadEdit {
            name: Some("Renamed ticket".into()),
            archive_minutes: Some(4320),
            slowmode: None
        })
    );
    reply(&mut app, &request, Err("Test refusal".into()));
    assert_eq!(
        app.state.thread_dialog.as_ref().unwrap().error.as_deref(),
        Some("Test refusal")
    );
    assert!(!app.state.thread_dialog.as_ref().unwrap().saving);
    app.dispatch(Action::ThreadSettings(ThreadInput::Name(" ".into())));
    assert!(
        app.dispatch(Action::ThreadSettings(ThreadInput::Save))
            .is_empty()
    );
    app.dispatch(Action::ThreadSettings(ThreadInput::Name("Valid".into())));
    app.dispatch(Action::ThreadSettings(ThreadInput::ArchiveMinutes(99)));
    assert!(
        app.dispatch(Action::ThreadSettings(ThreadInput::Save))
            .is_empty()
    );
    app.dispatch(Action::ThreadSettings(ThreadInput::ArchiveMinutes(1440)));
    app.apply(discord_event(snapshot("2", false, metadata())));
    assert!(
        app.dispatch(Action::ThreadSettings(ThreadInput::Save))
            .is_empty(),
        "creator permission was withdrawn"
    );
    assert!(app.state.thread_dialog.as_ref().unwrap().error.is_some());
}

#[test]
fn thread_management_delete_requires_confirmation_and_stale_results_cannot_close_dialogs() {
    let mut app = app("2", true);
    assert!(
        app.dispatch(Action::AskDeleteThread(THREAD.into()))
            .is_empty()
    );
    assert!(app.state.thread_dialog.as_ref().unwrap().deleting);
    app.dispatch(Action::ThreadSettings(ThreadInput::Cancel));
    assert!(app.state.thread_dialog.is_none());
    app.dispatch(Action::AskDeleteThread(THREAD.into()));
    app.apply(discord_event(snapshot("2", false, metadata())));
    assert!(
        app.dispatch(Action::ThreadSettings(ThreadInput::Save))
            .is_empty()
    );
    app.apply(discord_event(snapshot("2", true, metadata())));
    app.dispatch(Action::AskDeleteThread(THREAD.into()));
    let request = operation(app.dispatch(Action::ThreadSettings(ThreadInput::Save)));
    assert_eq!(request.3, chat::ThreadChange::Delete);
    app.apply(Event::ThreadChanged {
        room: THREAD.into(),
        account: "other".into(),
        request: request.2.clone(),
        result: Ok(()),
    });
    assert!(app.state.thread_dialog.as_ref().unwrap().saving);
    app.apply(Event::ThreadChanged {
        room: PARENT.into(),
        account: request.1.clone(),
        request: request.2.clone(),
        result: Ok(()),
    });
    assert!(app.state.thread_dialog.as_ref().unwrap().saving);
    reply(&mut app, &request, Ok(()));
    assert!(app.state.thread_dialog.is_none());
    // A duplicate result from a prior request cannot close a newer edit form.
    app.dispatch(Action::OpenThreadSettings(THREAD.into()));
    reply(&mut app, &request, Ok(()));
    assert!(app.state.thread_dialog.is_some());
    assert_eq!(
        app.state.selected.as_deref(),
        Some(THREAD),
        "management does not navigate to the parent"
    );
}

#[test]
fn thread_management_invite_and_lock_toggles_target_only_the_thread() {
    let mut app = app("2", true);
    assert_eq!(app.thread_invitable(THREAD), Some(true));
    let request = operation(app.dispatch(Action::SetThreadInvitable {
        room: THREAD.into(),
        invitable: false,
    }));
    assert_eq!(request.0, THREAD);
    assert_eq!(request.3, chat::ThreadChange::Invitable(false));
    assert_eq!(
        app.thread_invitable(THREAD),
        Some(true),
        "no optimistic server state"
    );
    reply(&mut app, &request, Ok(()));
    let request = operation(app.dispatch(Action::LockThread {
        room: THREAD.into(),
        locked: true,
    }));
    assert_eq!(request.3, chat::ThreadChange::Lock(true));
    reply(&mut app, &request, Ok(()));
    assert!(
        app.dispatch(Action::LockThread {
            room: PARENT.into(),
            locked: true
        })
        .is_empty()
    );
    let mut public = snapshot("2", true, metadata());
    Arc::make_mut(&mut public.servers[0].server).threads[0]
        .thread
        .as_mut()
        .unwrap()
        .private = false;
    app.apply(discord_event(public));
    assert_eq!(app.thread_invitable(THREAD), None);
    assert!(
        app.dispatch(Action::SetThreadInvitable {
            room: THREAD.into(),
            invitable: false
        })
        .is_empty()
    );
}
