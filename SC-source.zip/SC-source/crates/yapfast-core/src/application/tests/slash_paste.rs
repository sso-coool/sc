use super::*;
use crate::chat::CommandIndex;

fn app() -> Application {
    let (mut app, room) = in_discord_channel();
    app.dispatch(Action::SetDraft("/".into()));
    app.apply(Event::CommandIndex {
        room,
        index: Ok(Arc::new(CommandIndex::parse(
            &serde_json::json!({
                "applications":[{"id":"500","name":"Synthetic fixture"}],
                "application_commands":[{"id":"501","application_id":"500","version":"1","type":1,
                    "name":"doms","description":"Test a value","default_member_permissions":null,
                    "options":[{"type":3,"name":"data","description":"JSON","required":true},
                        {"type":3,"name":"note","description":"Optional note"}]}]
            }),
            false,
        ))),
    });
    app
}

const JSON: &str = "{\n  \"sample\": \"data: stays inside the JSON\", \"escaped\": \"a\\\\b\\\"c\", \"emoji\": \"🌙\"\n}";

#[test]
fn slash_paste_full_invocation_removes_one_option_label_and_preserves_json() {
    for separator in ["", " "] {
        let mut app = app();
        app.dispatch(Action::SetDraft(format!("/doms data:{separator}{JSON}")));
        let command = app.state.command_draft().unwrap();
        assert_eq!(command.name, "doms");
        assert_eq!(command.options[0].text, JSON);
        assert_eq!(app.state.draft(), JSON);
        assert!(command.options[1].text.is_empty());
    }
    let mut app = app();
    app.dispatch(Action::SetDraft(format!("/doms {JSON}")));
    assert_eq!(app.state.command_draft().unwrap().options[0].text, JSON);
    // Once editing a value, ordinary edits are literal, even with the same label.
    app.dispatch(Action::SetDraft(format!("data:{JSON}")));
    assert_eq!(
        app.state.command_draft().unwrap().options[0].text,
        format!("data:{JSON}")
    );
}

#[test]
fn slash_paste_selected_option_accepts_only_its_label_or_matching_invocation() {
    let mut app = app();
    app.dispatch(Action::SetDraft("/doms ".into()));
    for value in [
        format!("data:{JSON}"),
        format!("data: {JSON}"),
        format!("/doms data:{JSON}"),
        format!("/doms {JSON}"),
    ] {
        assert_eq!(
            app.state.normalized_command_paste(&value).as_deref(),
            Some(JSON)
        );
    }
    for value in [
        JSON,
        "database:example",
        "note:example",
        "/different data:{}",
    ] {
        assert!(
            app.state.normalized_command_paste(value).is_none(),
            "unrelated/raw values stay literal"
        );
    }
    assert_eq!(
        app.state
            .normalized_command_paste("data:data:{}")
            .as_deref(),
        Some("data:{}"),
        "strip once, not recursively"
    );
    app.dispatch(Action::FocusCommandOption(1));
    assert_eq!(
        app.state
            .normalized_command_paste("note: literal data: inside")
            .as_deref(),
        Some("literal data: inside")
    );
    assert!(
        app.state
            .normalized_command_paste("/doms data:{}")
            .is_none(),
        "another option cannot silently take the value"
    );
    app.dispatch(Action::CloseCommand(false));
    assert!(
        app.state.normalized_command_paste("data:{}").is_none(),
        "ordinary messages do not normalize labels"
    );
}
