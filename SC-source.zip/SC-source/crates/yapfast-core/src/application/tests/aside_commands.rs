//! Message-menu Apps keep the channel and its beside thread independent.

use super::*;
use yapfast_discord::{
    commands::CommandIndex,
    ready::{self, permission},
    service::{Snapshot, Status},
};

const MAIN: &str = "discord:10:11";
const THREAD: &str = "discord:10:30";

fn panes() -> Application {
    let permissions = permission::VIEW_CHANNEL
        | permission::SEND_MESSAGES
        | permission::SEND_MESSAGES_IN_THREADS
        | yapfast_discord::commands::USE_APPLICATION_COMMANDS;
    let server = ready::server(&serde_json::json!({
        "id": "10", "owner_id": "99", "properties": {"name": "Test"},
        "roles": [{"id": "10", "name": "@everyone", "permissions": permissions.to_string()}],
        "channels": [
            {"id": "11", "type": 0, "name": "general"},
            {"id": "12", "type": 0, "name": "projects"}
        ],
        "threads": [{"id": "30", "type": 11, "name": "Plans", "parent_id": "12",
                     "thread_metadata": {"archived": false, "locked": false}}]
    }))
    .unwrap();
    let mut app = Application::default();
    app.apply(discord_event(Snapshot {
        status: Status::Online,
        user_id: Some("1".into()),
        servers: vec![MarkedServer::from(server)],
        ..Default::default()
    }));
    app.dispatch(Action::Navigate(Navigation::Server("discord:10".into())));
    app.dispatch(Action::SelectRoom(MAIN.into()));
    app.apply(Event::Timeline {
        room: MAIN.into(),
        messages: timeline(vec![ChatMessage {
            item: "d:100".into(),
            ..Default::default()
        }]),
    });
    app.dispatch(Action::OpenAside(THREAD.into()));
    app.apply(Event::Timeline {
        room: THREAD.into(),
        messages: timeline(vec![
            ChatMessage {
                item: "d:200".into(),
                ..Default::default()
            },
            ChatMessage {
                item: "d:201".into(),
                flags: 1 << 6,
                ..Default::default()
            },
        ]),
    });
    assert_eq!(app.state.selected.as_deref(), Some(MAIN));
    assert_eq!(
        app.state.aside.as_ref().map(|aside| aside.room.as_str()),
        Some(THREAD)
    );
    app
}

fn index(name: &str) -> Arc<CommandIndex> {
    Arc::new(CommandIndex::parse(
        &serde_json::json!({
            "applications": [{"id": "7", "name": "Notes", "flags": "0"}],
            "application_commands": [
                {"id": "1", "type": 1, "application_id": "7", "name": "ping",
                 "description": "Pong", "version": "1"},
                {"id": "4", "type": 3, "application_id": "7", "name": name,
                 "description": "", "version": "1"},
                {"id": "6", "type": 3, "application_id": "7", "name": "Only general",
                 "description": "", "version": "1", "permissions": {"channels": {"12": false}}}
            ]
        }),
        false,
    ))
}

fn asked(effects: &[Effect]) -> Option<&str> {
    effects.iter().find_map(|effect| match effect {
        Effect::Backend(Command::Discord(DiscordCommand::CommandIndex { room })) => {
            Some(room.as_str())
        }
        _ => None,
    })
}

fn run(app: &mut Application, command: &str, target: &str) -> Option<Box<chat::CommandRun>> {
    app.dispatch(Action::RunAppCommand {
        command: command.into(),
        target: Some(target.into()),
    })
    .into_iter()
    .find_map(|effect| match effect {
        Effect::Backend(Command::Discord(DiscordCommand::RunCommand(run))) => Some(run),
        _ => None,
    })
}

fn load(app: &mut Application) {
    app.dispatch(Action::AskMessageAppCommands("d:100".into()));
    app.dispatch(Action::AskMessageAppCommands("d:200".into()));
    for (room, name) in [(THREAD, "Thread save"), (MAIN, "Main save")] {
        app.apply(Event::CommandIndex {
            room: room.into(),
            index: Ok(index(name)),
        });
    }
}

#[test]
fn aside_apps_keep_indexes_targets_and_composer_selection_independent() {
    let mut app = panes();
    assert_eq!(
        asked(&app.dispatch(Action::SetDraft("/pi".into()))),
        Some(MAIN)
    );
    assert_eq!(
        asked(&app.dispatch(Action::AskMessageAppCommands("d:200".into()))),
        Some(THREAD)
    );
    assert!(
        app.dispatch(Action::AskMessageAppCommands("d:200".into()))
            .is_empty()
    );
    // The later request can finish first, without dropping the channel's.
    app.apply(Event::CommandIndex {
        room: THREAD.into(),
        index: Ok(index("Thread save")),
    });
    assert!(app.state.app_commands.loading(MAIN));
    app.apply(Event::CommandIndex {
        room: MAIN.into(),
        index: Ok(index("Main save")),
    });
    app.dispatch(Action::PickCommand(0));
    app.dispatch(Action::SetAsideDraft("thread draft".into()));
    assert_eq!(app.state.command_draft().unwrap().name, "ping");
    let thread = run(&mut app, "4", "d:200").expect("thread message command");
    assert_eq!(
        (thread.room.as_str(), thread.target.as_deref()),
        (THREAD, Some("200"))
    );
    assert_eq!(thread.command["name"], "Thread save");
    assert!(
        app.state
            .messages
            .iter()
            .all(|message| !message.item.starts_with("c:"))
    );
    assert!(
        app.state
            .aside
            .as_ref()
            .unwrap()
            .messages
            .iter()
            .any(|message| message.item.starts_with("c:"))
    );
    assert_eq!(app.state.selected.as_deref(), Some(MAIN));
    assert_eq!(app.state.command_draft().unwrap().name, "ping");
    assert_eq!(app.state.aside_draft(), "thread draft");
    let main = run(&mut app, "4", "d:100").expect("main message command");
    assert_eq!(
        (main.room.as_str(), main.target.as_deref()),
        (MAIN, Some("100"))
    );
    assert_eq!(main.command["name"], "Main save");
    assert_eq!(app.state.command_draft().unwrap().name, "ping");
    assert!(
        app.dispatch(Action::AskAppCommands).is_empty(),
        "main index remains cached"
    );
}

#[test]
fn aside_apps_recheck_thread_parent_permissions_and_reject_stale_targets() {
    let mut app = panes();
    load(&mut app);
    let names = |app: &Application, room| {
        app.commands_for_target(room, CommandTarget::Message)
            .into_iter()
            .map(|command| command.name)
            .collect::<Vec<_>>()
    };
    assert_eq!(names(&app, MAIN), ["Main save", "Only general"]);
    assert_eq!(names(&app, THREAD), ["Thread save"]);
    assert!(
        run(&mut app, "6", "d:200").is_none(),
        "thread inherits its own parent's deny"
    );
    assert!(
        run(&mut app, "4", "d:201").is_none(),
        "ephemeral replies are not message targets"
    );
    assert!(
        run(&mut app, "4", "d:999").is_none(),
        "unknown message cannot become a user command"
    );
    app.dispatch(Action::CloseAside);
    assert!(
        run(&mut app, "4", "d:200").is_none(),
        "closed thread never falls back to main"
    );
    assert!(
        app.dispatch(Action::AskMessageAppCommands("d:200".into()))
            .is_empty()
    );
    assert!(run(&mut app, "4", "d:100").is_some());
}

#[test]
fn aside_apps_loading_errors_and_index_invalidation_stay_scoped() {
    let mut app = panes();
    app.dispatch(Action::AskAppCommands);
    app.dispatch(Action::AskMessageAppCommands("d:200".into()));
    app.apply(Event::CommandIndex {
        room: MAIN.into(),
        index: Err("Main unavailable".into()),
    });
    app.apply(Event::CommandIndex {
        room: THREAD.into(),
        index: Err("Thread unavailable".into()),
    });
    assert_eq!(
        app.state.app_commands.error.as_deref(),
        Some("Main unavailable")
    );
    load(&mut app);
    assert!(app.state.app_commands.error.is_none());
    app.apply(Event::CommandIndexChanged {
        guild: Some("20".into()),
    });
    assert!(app.state.app_commands.index(MAIN).is_some());
    assert!(app.state.app_commands.index(THREAD).is_some());
    app.apply(Event::CommandIndexChanged {
        guild: Some("10".into()),
    });
    assert!(app.state.app_commands.index(MAIN).is_none());
    assert!(app.state.app_commands.index(THREAD).is_none());
    app.dispatch(Action::AskMessageAppCommands("d:200".into()));
    app.dispatch(Action::CloseAside);
    app.apply(Event::CommandIndex {
        room: THREAD.into(),
        index: Ok(index("Late thread")),
    });
    assert!(
        app.state.app_commands.index(THREAD).is_none(),
        "closed pane's late result is discarded"
    );
    assert!(app.state.app_commands.index(MAIN).is_none());
}

#[test]
fn aside_apps_pending_failure_retry_and_cancel_stay_in_the_thread() {
    let mut app = panes();
    load(&mut app);
    let main_messages = app.state.messages.clone();
    let first = run(&mut app, "4", "d:200").unwrap();
    // A fresh history result must not erase the pending command row.
    app.apply(Event::Timeline {
        room: THREAD.into(),
        messages: timeline(vec![ChatMessage {
            item: "d:200".into(),
            ..Default::default()
        }]),
    });
    let rows = |app: &Application| {
        app.state
            .aside
            .as_ref()
            .unwrap()
            .messages
            .iter()
            .filter(|message| message.item.starts_with("c:"))
            .map(|message| {
                (
                    message.item.clone(),
                    message.body.clone(),
                    message.delivery.clone(),
                )
            })
            .collect::<Vec<_>>()
    };
    assert_eq!(rows(&app).len(), 1);
    app.apply(Event::InteractionFailed {
        nonce: first.nonce.clone(),
        reason: "Test app unavailable".into(),
    });
    let failed = rows(&app);
    assert_eq!(failed.len(), 1);
    assert_eq!(failed[0].1, "Test app unavailable");
    assert_eq!(failed[0].2, chat::Delivery::Failed);
    assert!(
        Arc::ptr_eq(&main_messages, &app.state.messages),
        "aside status leaves main timeline intact"
    );
    let retry = app
        .dispatch(Action::Retry(failed[0].0.clone()))
        .into_iter()
        .find_map(|effect| match effect {
            Effect::Backend(Command::Discord(DiscordCommand::RunCommand(run))) => Some(run),
            _ => None,
        })
        .expect("retry command effect");
    assert_eq!(
        (retry.room.as_str(), retry.target.as_deref()),
        (THREAD, Some("200"))
    );
    assert_ne!(retry.nonce, first.nonce);
    assert_eq!(rows(&app)[0].2, chat::Delivery::Sent);
    app.apply(Event::InteractionFailed {
        nonce: retry.nonce.clone(),
        reason: "Still unavailable".into(),
    });
    app.dispatch(Action::CancelSend(format!("c:{}", retry.nonce)));
    assert!(rows(&app).is_empty());
    assert!(Arc::ptr_eq(&main_messages, &app.state.messages));

    let sent = run(&mut app, "4", "d:200").unwrap();
    app.apply(Event::InteractionCreated {
        nonce: sent.nonce,
        id: "900".into(),
    });
    app.apply(Event::Timeline {
        room: THREAD.into(),
        messages: timeline(vec![ChatMessage {
            item: "d:202".into(),
            interaction: Some("900".into()),
            ..Default::default()
        }]),
    });
    assert!(
        rows(&app).is_empty(),
        "the thread's actual reply removes its pending row"
    );
    assert!(Arc::ptr_eq(&main_messages, &app.state.messages));
}
