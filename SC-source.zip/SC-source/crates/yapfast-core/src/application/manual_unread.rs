//! Explicit unread boundaries stay unread until the visible pane is left,
//! reopened, or explicitly marked read. No timer or extra history fetch.
use super::*;
use std::sync::atomic::{AtomicU64, Ordering};
static NEXT_REQUEST: AtomicU64 = AtomicU64::new(1);

pub(super) struct ManualUnread {
    pub request: u64,
    pending: bool,
    read_after: bool,
}

impl Application {
    pub(super) fn mark_unread(&mut self, target: String) -> Vec<Effect> {
        if self.state.preview || self.state.discord_user.is_none() {
            return vec![];
        }
        let (room, message) = if target.starts_with("d:") {
            let Some(message) = self.state.message(&target).filter(|message| {
                message.delivery == chat::Delivery::Sent
                    && !message.deleted
                    && message.flags & ((1 << 6) | (1 << 7)) == 0
            }) else {
                return vec![];
            };
            let Some(order) = discord::item_order(&message.item).filter(|id| *id > 0) else {
                return vec![];
            };
            let Some(room) = self.state.room_of(&target) else {
                return vec![];
            };
            (room.clone(), Some(order))
        } else {
            if !self
                .state
                .menu_choices(&target)
                .contains(&MenuChoice::MarkUnread)
            {
                return vec![];
            }
            (target, None)
        };
        let Some(place) =
            self.state.rooms.iter().find(|place| {
                place.id == room && place.network == Network::Discord && !place.locked
            })
        else {
            return vec![];
        };
        if self.manual_unread.len() >= 32 && !self.manual_unread.contains_key(&room) {
            return vec![];
        }
        let read = place
            .last_read
            .as_deref()
            .and_then(discord::item_order)
            .unwrap_or(0);
        let messages = match &self.state.aside {
            Some(aside) if aside.room == room => Some(aside.messages.as_slice()),
            _ if self.state.selected.as_deref() == Some(&room) => {
                Some(self.state.messages.as_slice())
            }
            _ => None,
        };
        let messages = messages.unwrap_or_default();
        let newest = messages
            .iter()
            .filter_map(|row| discord::item_order(&row.item))
            .max();
        let before = message
            .map(|id| id - 1)
            .unwrap_or_else(|| newest.unwrap_or(u64::MAX).saturating_sub(1).min(read));
        let mentions = |row: &&Arc<ChatMessage>| {
            !row.own
                && !row.blocked
                && row.flags & (1 << 6) == 0
                && (place.direct || row.mentions_me || row.replies_to_me)
        };
        // Advancing to a selected message subtracts only known newly-read
        // mentions; rewinding adds known newly-unread ones.
        let added = messages
            .iter()
            .filter(mentions)
            .filter(|row| {
                discord::item_order(&row.item).is_some_and(|id| id > before && id <= read)
            })
            .count() as i64;
        let removed = messages
            .iter()
            .filter(mentions)
            .filter(|row| {
                discord::item_order(&row.item).is_some_and(|id| id > read && id <= before)
            })
            .count() as i64;
        let mention_delta = added - removed;
        let complete = match &self.state.aside {
            Some(aside) if aside.room == room => aside.ready,
            _ => {
                self.state.room_ready
                    && !self.state.detached
                    && !self.focusing
                    && self.read_marker.is_none()
            }
        };
        // The service verifies the newest ID before trusting this count;
        // arrivals after this snapshot fall back to the signed adjustment.
        let known_tail = message.filter(|_| complete).zip(newest).map(|(_, newest)| {
            let count = messages
                .iter()
                .filter(mentions)
                .filter(|row| discord::item_order(&row.item).is_some_and(|id| id > before))
                .count() as u64;
            (newest, count)
        });
        let request = NEXT_REQUEST.fetch_add(1, Ordering::Relaxed);
        // One request per room; another click while it is pending must not
        // double-count newly unread mentions.
        if self
            .manual_unread
            .get(&room)
            .is_some_and(|held| held.pending)
        {
            return vec![];
        }
        self.manual_unread.insert(
            room.clone(),
            ManualUnread {
                request,
                pending: true,
                read_after: false,
            },
        );
        vec![Effect::Backend(Command::Discord(
            DiscordCommand::MarkUnread {
                room,
                message,
                mention_delta,
                known_tail,
                sync: self.state.sync_discord_reads,
                user: self.state.discord_user.clone(),
                request,
            },
        ))]
    }

    /// Reopening or explicitly reading while the rewind is in flight must
    /// enqueue its forward acknowledgement only after that rewind completes.
    pub(super) fn resume_manual_read(&mut self, room: &str) -> bool {
        if let Some(held) = self.manual_unread.get_mut(room).filter(|held| held.pending) {
            held.read_after = true;
            true
        } else {
            self.manual_unread.remove(room);
            false
        }
    }

    pub(super) fn leave_manual_room(&mut self, room: &str) {
        if self
            .manual_unread
            .get(room)
            .is_some_and(|held| !held.pending)
        {
            self.manual_unread.remove(room);
        }
    }

    pub(super) fn marked_unread(
        &mut self,
        room: String,
        user: Option<String>,
        request: u64,
        result: Result<Option<u64>, String>,
    ) -> Vec<Effect> {
        if self.state.discord_user != user
            || self
                .manual_unread
                .get(&room)
                .is_none_or(|held| held.request != request)
        {
            return vec![];
        }
        let mut held = self.manual_unread.remove(&room).unwrap();
        if held.read_after && matches!(result, Ok(Some(_))) {
            return vec![Effect::Backend(Command::MarkRead {
                room,
                sync: self.state.sync_discord_reads,
            })];
        }
        match result {
            Ok(None) => {}
            Ok(Some(boundary)) => {
                let marker = format!("d:{boundary}");
                if self.state.selected.as_ref() == Some(&room) {
                    self.state.seen = Some(marker);
                    self.state.caught_up = false;
                    self.read_marker = None;
                    self.state.first_unread = self
                        .state
                        .messages
                        .iter()
                        .find(|message| {
                            discord::item_order(&message.item).is_some_and(|id| id > boundary)
                        })
                        .map(|message| message.item.clone());
                } else if let Some(aside) =
                    self.state.aside.as_mut().filter(|aside| aside.room == room)
                {
                    aside.seen = Some(marker);
                }
                if self.state.shows_room(&room) {
                    held.pending = false;
                    self.manual_unread.insert(room, held);
                }
            }
            Err(error) => {
                self.manual_unread.remove(&room);
                self.state.notice = Some(error);
            }
        }
        vec![]
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::application::aside::Aside;
    const MAIN: &str = "discord:@me:20";
    const THREAD: &str = "discord:10:30";

    fn panes() -> Application {
        let mut app = Application::default();
        app.state.discord_user = Some("1".into());
        app.state.sync_discord_reads = true;
        let mut main = preview::preview_room(MAIN, "Main", true, 2);
        main.last_read = Some("d:100".into());
        main.unread = 1;
        let other = preview::preview_room("discord:@me:21", "Other", true, 2);
        let mut aside = preview::preview_room(THREAD, "Thread", false, 2);
        aside.last_read = Some("d:200".into());
        aside.parent = Some("discord:10:11".into());
        aside.unread = 1;
        app.state.rooms = vec![Arc::new(main), Arc::new(other), Arc::new(aside)];
        app.state.selected = Some(MAIN.into());
        app.state.room_ready = true;
        app.state.reading = true;
        app.state.messages = Arc::new(vec![
            Arc::new(ChatMessage {
                item: "d:97".into(),
                mentions_me: true,
                ..Default::default()
            }),
            Arc::new(ChatMessage {
                item: "d:100".into(),
                own: true,
                ..Default::default()
            }),
        ]);
        app.state.aside = Some(Aside {
            room: THREAD.into(),
            ready: true,
            messages: Arc::new(vec![Arc::new(ChatMessage {
                item: "d:200".into(),
                mentions_me: true,
                ..Default::default()
            })]),
            ..Default::default()
        });
        app
    }

    fn start(app: &mut Application, item: &str) -> (String, u64) {
        let effects = app.dispatch(Action::MarkUnread(item.into()));
        let [
            Effect::Backend(Command::Discord(DiscordCommand::MarkUnread {
                room,
                request,
                mention_delta,
                ..
            })),
        ] = effects.as_slice()
        else {
            panic!("expected one manual unread command")
        };
        assert_eq!(*mention_delta, 1);
        (room.clone(), *request)
    }

    fn done(
        app: &mut Application,
        room: String,
        request: u64,
        result: Result<Option<u64>, String>,
    ) -> Vec<Effect> {
        app.apply(Event::MarkedUnread {
            room,
            user: Some("1".into()),
            request,
            result,
        })
    }

    #[test]
    fn manual_unread_keeps_main_and_aside_automatic_reads_independent() {
        let mut app = panes();
        let (room, request) = start(&mut app, "d:200");
        assert_eq!(room, THREAD);
        assert!(app.mark_aside_read().is_empty());
        assert!(!app.mark_discord_read().is_empty());
        assert!(done(&mut app, room, request, Ok(Some(199))).is_empty());
        assert_eq!(
            app.state.aside.as_ref().unwrap().seen.as_deref(),
            Some("d:199")
        );
        assert_eq!(app.state.selected.as_deref(), Some(MAIN));
        assert!(app.mark_aside_read().is_empty());
        app.dispatch(Action::CloseAside);
        assert!(!app.manual_unread.contains_key(THREAD));
        let (room, request) = start(&mut app, "d:97");
        done(&mut app, room, request, Ok(Some(96)));
        assert!(app.dispatch(Action::Reading(true)).is_empty());
        assert!(!app.state.caught_up);
        assert_eq!(app.state.first_unread.as_deref(), Some("d:97"));
        app.dispatch(Action::SelectRoom("discord:@me:21".into()));
        assert!(!app.manual_unread.contains_key(MAIN));
    }

    #[test]
    fn manual_unread_explicit_read_and_reopen_wait_for_pending_rewind() {
        for reopen in [false, true] {
            let mut app = panes();
            let (room, request) = start(&mut app, "d:97");
            let effects = if reopen {
                app.dispatch(Action::SelectRoom(MAIN.into()))
            } else {
                app.dispatch(Action::MarkRead(MAIN.into()))
            };
            assert!(
                !effects
                    .iter()
                    .any(|effect| matches!(effect, Effect::Backend(Command::MarkRead { .. })))
            );
            assert!(
                matches!(done(&mut app, room, request, Ok(Some(96))).as_slice(),
                [Effect::Backend(Command::MarkRead { room, sync: true })] if room == MAIN)
            );
            assert!(!app.manual_unread.contains_key(MAIN));
        }
    }

    #[test]
    fn manual_unread_failure_stale_account_and_own_send_release_correctly() {
        let mut app = panes();
        let (room, request) = start(&mut app, "d:97");
        done(&mut app, room, request, Err("test failure".into()));
        assert!(!app.manual_unread.contains_key(MAIN));
        assert!(!app.mark_discord_read().is_empty());
        let (room, request) = start(&mut app, "d:97");
        app.state.discord_user = Some("2".into());
        done(&mut app, room.clone(), request, Ok(Some(96)));
        assert!(app.state.first_unread.is_none());
        app.state.discord_user = Some("1".into());
        done(&mut app, room, request, Ok(None));
        assert!(!app.manual_unread.contains_key(MAIN));
        assert!(app.state.first_unread.is_none());
    }

    #[test]
    fn manual_unread_rejects_unknown_ephemeral_preview_and_locked_targets() {
        let mut app = panes();
        assert!(app.dispatch(Action::MarkUnread("d:999".into())).is_empty());
        Arc::make_mut(&mut Arc::make_mut(&mut app.state.messages)[0]).flags = 1 << 6;
        assert!(app.dispatch(Action::MarkUnread("d:97".into())).is_empty());
        app.state.preview = true;
        assert!(app.dispatch(Action::MarkUnread(THREAD.into())).is_empty());
        app.state.preview = false;
        Arc::make_mut(&mut app.state.rooms[2]).locked = true;
        assert!(app.dispatch(Action::MarkUnread("d:200".into())).is_empty());
        assert!(app.manual_unread.is_empty());
    }

    #[test]
    fn manual_unread_selected_own_message_advances_boundary_and_counts_complete_tail() {
        let mut app = panes();
        Arc::make_mut(&mut app.state.rooms[0]).last_read = Some("d:90".into());
        let effects = app.dispatch(Action::MarkUnread("d:100".into()));
        let [
            Effect::Backend(Command::Discord(DiscordCommand::MarkUnread {
                room,
                message: Some(100),
                mention_delta: -1,
                known_tail: Some((100, 0)),
                request,
                ..
            })),
        ] = effects.as_slice()
        else {
            panic!(
                "selected message must subtract its newly-read mention and count the complete tail"
            )
        };
        let (room, request) = (room.clone(), *request);
        done(&mut app, room, request, Ok(Some(99)));
        assert_eq!(app.state.seen.as_deref(), Some("d:99"));
        assert_eq!(
            app.state.first_unread.as_deref(),
            Some("d:100"),
            "an explicitly selected own message is still the first unread"
        );
    }
}
