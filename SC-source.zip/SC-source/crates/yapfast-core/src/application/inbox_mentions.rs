//! The authenticated account's Inbox Mentions, kept in memory.

use super::*;
use crate::chat::SearchHit;

#[derive(Default)]
pub struct InboxMentions {
    pub messages: Vec<SearchHit>,
    pub loading: bool,
    pub error: Option<String>,
    pub has_more: bool,
    pub dismissing: HashMap<String, u64>,
    filters: Option<InboxMentionFilters>,
    pending_page: Option<(u64, Option<u64>)>,
    before: Option<u64>,
    // Covers a successful dismissal while a different filter or page is on its way.
    dismissed: HashSet<String>,
}

pub struct InboxMentionPage {
    pub messages: Vec<SearchHit>,
    pub before: Option<u64>,
}

#[derive(Clone, PartialEq, Eq)]
struct InboxMentionFilters {
    include_everyone: bool,
    include_roles: bool,
    guild: Option<String>,
}

impl AppState {
    pub fn inbox_mentions_available(&self) -> bool {
        cfg!(feature = "discord")
            && !self.preview
            && self.discord_online
            && self.discord_user.is_some()
    }

    /// Current visibility of a cached row and its exact-message jump.
    pub fn inbox_mention_visible(&self, hit: &SearchHit) -> bool {
        if !self.inbox_mentions_available() || self.room_spoiler_hidden(&hit.room) {
            return false;
        }
        let Some((guild, _)) = discord::parse_room(&hit.room) else {
            return false;
        };
        let room = self.rooms.iter().find(|room| room.id == hit.room);
        let readable = if guild == discord::DM_GUILD {
            room.is_some_and(|room| !room.locked && !room.request)
        } else {
            self.servers
                .iter()
                .any(|server| server.id == discord::server_id(guild))
                && room.is_none_or(|room| !room.locked)
        };
        #[cfg(feature = "discord")]
        let recent = hit
            .message
            .timestamp
            .saturating_add(yapfast_discord::service::RECENT_MENTION_AGE.as_secs())
            >= crate::clock::now_ms() / 1000;
        #[cfg(not(feature = "discord"))]
        let recent = false;
        readable
            && recent
            && discord::sender_user(&hit.message.sender).is_some_and(|author| {
                !self.is_blocked(author) && !self.discord_ignored.iter().any(|id| id == author)
            })
    }
}

impl Application {
    pub(super) fn load_inbox_mentions(
        &mut self,
        include_everyone: bool,
        include_roles: bool,
        guild: Option<String>,
    ) -> Vec<Effect> {
        let guild = match guild {
            Some(id) => {
                let Some(guild) = discord::parse_server(&id)
                    .filter(|guild| saved_messages::saved_message_id(guild))
                    .filter(|_| self.state.servers.iter().any(|server| server.id == id))
                else {
                    return vec![];
                };
                Some(guild.to_owned())
            }
            None => None,
        };
        let filters = InboxMentionFilters {
            include_everyone,
            include_roles,
            guild,
        };
        let inbox = &mut self.state.inbox_mentions;
        if inbox.filters.as_ref() == Some(&filters) {
            if matches!(inbox.pending_page, Some((_, None))) {
                return vec![];
            }
        } else {
            inbox.messages.clear();
        }
        inbox.filters = Some(filters);
        inbox.before = None;
        inbox.has_more = false;
        self.request_inbox_mention_page(None)
    }

    pub(super) fn more_inbox_mentions(&mut self) -> Vec<Effect> {
        let inbox = &self.state.inbox_mentions;
        if !inbox.loading
            && inbox.has_more
            && let Some(before) = inbox.before
        {
            return self.request_inbox_mention_page(Some(before));
        }
        vec![]
    }

    fn request_inbox_mention_page(&mut self, before: Option<u64>) -> Vec<Effect> {
        let available = self.state.inbox_mentions_available();
        let inbox = &mut self.state.inbox_mentions;
        let Some(filters) = inbox.filters.clone() else {
            return vec![];
        };
        if !available {
            inbox.pending_page = None;
            inbox.loading = false;
            inbox.error = Some("Connect to Discord to load recent mentions.".into());
            return vec![];
        }
        self.inbox_mention_request = self.inbox_mention_request.wrapping_add(1);
        let request = self.inbox_mention_request;
        inbox.pending_page = Some((request, before));
        inbox.loading = true;
        inbox.error = None;
        vec![Effect::Backend(Command::Discord(
            DiscordCommand::InboxMentions {
                request,
                guild: filters.guild,
                include_everyone: filters.include_everyone,
                include_roles: filters.include_roles,
                before,
            },
        ))]
    }

    pub(super) fn inbox_mentions_came(
        &mut self,
        request: u64,
        result: Result<InboxMentionPage, String>,
    ) {
        let inbox = &mut self.state.inbox_mentions;
        let Some((_, before)) = inbox.pending_page.take_if(|(id, _)| *id == request) else {
            return;
        };
        inbox.loading = false;
        match result {
            Ok(page) => {
                if before.is_none() {
                    inbox.messages.clear();
                }
                inbox.before = page
                    .before
                    .filter(|next| before.is_none_or(|old| *next < old));
                inbox.has_more = inbox.before.is_some();
                let mut seen: HashSet<_> = inbox
                    .messages
                    .iter()
                    .map(|hit| hit.message.item.clone())
                    .collect();
                inbox
                    .messages
                    .extend(page.messages.into_iter().filter(|hit| {
                        !inbox.dismissed.contains(&hit.message.item)
                            && seen.insert(hit.message.item.clone())
                    }));
            }
            Err(error) => inbox.error = Some(error),
        }
        #[cfg(feature = "discord")]
        if let Some(snapshot) = &self.discord {
            self.state.inbox_mentions.retain_readable(snapshot);
        }
    }

    pub(super) fn dismiss_inbox_mention(&mut self, item: String) -> Vec<Effect> {
        let Some(message) = item
            .strip_prefix("d:")
            .and_then(|id| id.parse::<u64>().ok())
            .filter(|id| *id > 0)
        else {
            return vec![];
        };
        let inbox = &self.state.inbox_mentions;
        if inbox.dismissing.contains_key(&item)
            || !inbox
                .messages
                .iter()
                .any(|hit| hit.message.item == item && self.state.inbox_mention_visible(hit))
        {
            return vec![];
        }
        self.inbox_mention_request = self.inbox_mention_request.wrapping_add(1);
        let request = self.inbox_mention_request;
        self.state.inbox_mentions.dismissing.insert(item, request);
        vec![Effect::Backend(Command::Discord(
            DiscordCommand::DismissInboxMention { request, message },
        ))]
    }

    pub(super) fn inbox_mention_dismissed(
        &mut self,
        request: u64,
        message: u64,
        result: Result<(), String>,
    ) {
        let item = format!("d:{message}");
        let inbox = &mut self.state.inbox_mentions;
        if inbox.dismissing.get(&item) != Some(&request) {
            return;
        }
        inbox.dismissing.remove(&item);
        match result {
            Ok(()) => {
                inbox.messages.retain(|hit| hit.message.item != item);
                inbox.dismissed.insert(item);
            }
            Err(error) => self.state.notice = Some(error),
        }
    }

    #[cfg(feature = "discord")]
    pub(super) fn sync_inbox_mentions(
        &mut self,
        snapshot: &yapfast_discord::service::Snapshot,
        previous_account: Option<&str>,
        was_online: bool,
    ) -> Vec<Effect> {
        let inbox = &mut self.state.inbox_mentions;
        if previous_account != self.state.discord_user.as_deref() {
            *inbox = InboxMentions::default();
        } else if !self.state.discord_online {
            inbox.pending_page = None;
            inbox.dismissing.clear();
            inbox.loading = false;
        } else {
            inbox.retain_readable(snapshot);
            if !was_online && inbox.filters.is_some() {
                return self.request_inbox_mention_page(None);
            }
        }
        vec![]
    }
}

#[cfg(feature = "discord")]
impl InboxMentions {
    fn retain_readable(&mut self, snapshot: &yapfast_discord::service::Snapshot) {
        self.messages.retain(|hit| {
            discord::parse_room(&hit.room)
                .is_some_and(|(guild, channel)| snapshot.may_see_recent_mention(guild, channel))
        });
    }
}

#[cfg(all(test, feature = "discord"))]
mod tests {
    use super::*;

    fn app() -> Application {
        let mut app = Application::default();
        app.state.discord_user = Some("50".into());
        app.state.discord_online = true;
        app.state.servers.push(Arc::new(ChatServer {
            id: "discord:10".into(),
            ..Default::default()
        }));
        app
    }

    fn request(app: &mut Application, guild: Option<&str>) -> u64 {
        let effects = app.dispatch(Action::LoadInboxMentions {
            include_everyone: guild.is_none(),
            include_roles: true,
            guild: guild.map(discord::server_id),
        });
        effects
            .into_iter()
            .find_map(|effect| match effect {
                Effect::Backend(Command::Discord(DiscordCommand::InboxMentions {
                    request,
                    guild: scope,
                    include_everyone,
                    include_roles,
                    before: None,
                })) => {
                    assert_eq!(scope.as_deref(), guild);
                    assert_eq!(include_everyone, guild.is_none());
                    assert!(include_roles);
                    Some(request)
                }
                _ => None,
            })
            .expect("requested a page of mentions")
    }

    fn hit(message: &str) -> SearchHit {
        SearchHit {
            room: "discord:10:11".into(),
            message: ChatMessage {
                item: format!("d:{message}"),
                id: format!("d:{message}"),
                sender: discord::sender_id("60"),
                timestamp: crate::clock::now_ms() / 1000,
                ..Default::default()
            },
        }
    }

    fn page(app: &mut Application, request: u64, hits: &[&str], before: Option<u64>) {
        app.apply(Event::InboxMentions {
            request,
            result: Ok(InboxMentionPage {
                messages: hits.iter().map(|message| hit(message)).collect(),
                before,
            }),
        });
    }

    #[test]
    fn inbox_mentions_ignore_stale_filters_and_reset_on_account_change() {
        let mut app = app();
        let first = request(&mut app, None);
        let scoped = request(&mut app, Some("10"));
        page(&mut app, first, &["100"], None);
        assert!(app.state.inbox_mentions.loading);
        assert!(app.state.inbox_mentions.messages.is_empty());
        page(&mut app, scoped, &["101"], Some(101));
        assert!(!app.state.inbox_mentions.loading);
        assert_eq!(app.state.inbox_mentions.messages[0].message.item, "d:101");

        let effects = app.dispatch(Action::MoreInboxMentions);
        let more = effects
            .into_iter()
            .find_map(|effect| match effect {
                Effect::Backend(Command::Discord(DiscordCommand::InboxMentions {
                    request,
                    before: Some(101),
                    ..
                })) => Some(request),
                _ => None,
            })
            .unwrap();
        page(&mut app, more, &["101", "100"], Some(100));
        assert_eq!(app.state.inbox_mentions.messages.len(), 2);

        let pending = request(&mut app, None);
        app.state.discord_user = Some("51".into());
        app.sync_inbox_mentions(&Default::default(), Some("50"), true);
        page(&mut app, pending, &["102"], None);
        assert!(!app.state.inbox_mentions.loading);
        assert!(app.state.inbox_mentions.messages.is_empty());

        let current = request(&mut app, None);
        app.apply(Event::InboxMentions {
            request: current,
            result: Err("Discord unavailable".into()),
        });
        assert!(!app.state.inbox_mentions.loading);
        assert_eq!(
            app.state.inbox_mentions.error.as_deref(),
            Some("Discord unavailable")
        );
    }

    #[test]
    fn inbox_mention_dismissal_does_not_reappear_from_an_in_flight_page() {
        let mut app = app();
        let initial = request(&mut app, None);
        page(&mut app, initial, &["100"], None);
        let effects = app.dispatch(Action::DismissInboxMention("d:100".into()));
        let dismissal = effects
            .into_iter()
            .find_map(|effect| match effect {
                Effect::Backend(Command::Discord(DiscordCommand::DismissInboxMention {
                    request,
                    message: 100,
                })) => Some(request),
                _ => None,
            })
            .unwrap();
        let pending = request(&mut app, Some("10"));
        app.apply(Event::InboxMentionDismissed {
            request: dismissal,
            message: 100,
            result: Ok(()),
        });
        page(&mut app, pending, &["100", "101"], None);
        assert!(app.state.inbox_mentions.dismissing.is_empty());
        let hits = &app.state.inbox_mentions.messages;
        assert_eq!(hits.len(), 1);
        assert_eq!(hits[0].message.item, "d:101");
    }
}
