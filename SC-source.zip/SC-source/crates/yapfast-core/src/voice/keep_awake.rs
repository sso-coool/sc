//! While a voice session is using the network, let Windows keep it running
//! when the display times out.

use windows::{
    Win32::{
        Foundation::HANDLE,
        System::{
            Power::{
                POWER_REQUEST_TYPE, PowerClearRequest, PowerCreateRequest,
                PowerRequestExecutionRequired, PowerRequestSystemRequired, PowerSetRequest,
            },
            Threading::{POWER_REQUEST_CONTEXT_SIMPLE_STRING, REASON_CONTEXT, REASON_CONTEXT_0},
        },
    },
    core::{Owned, PWSTR},
};

/// The request belongs to the call's worker, including when the window is
/// hidden, the microphone is muted, or the connection is recovering.
pub(super) struct CallPower {
    handle: Owned<HANDLE>,
    request: POWER_REQUEST_TYPE,
}

impl CallPower {
    pub(super) fn acquire() -> Option<Self> {
        match Self::new() {
            Ok(power) => Some(power),
            Err(error) => {
                tracing::warn!(%error, "could not keep the system awake for this call");
                None
            }
        }
    }

    fn new() -> windows::core::Result<Self> {
        let mut reason: Vec<u16> = "S;C voice call is active."
            .encode_utf16()
            .chain([0])
            .collect();
        let context = REASON_CONTEXT {
            Version: 0, // POWER_REQUEST_CONTEXT_VERSION
            Flags: POWER_REQUEST_CONTEXT_SIMPLE_STRING,
            Reason: REASON_CONTEXT_0 {
                SimpleReasonString: PWSTR(reason.as_mut_ptr()),
            },
        };
        // SAFETY: The context and its nul-terminated reason remain valid
        // through the call. Owned takes ownership of the newly opened handle.
        let handle = unsafe { Owned::new(PowerCreateRequest(&context)?) };
        // Execution keeps the process running during idle timeout on Modern
        // Standby and implies System Required on S3. Some configurations deny
        // it, so fall back to an ordinary system-idle request.
        // SAFETY: The handle is live for both attempts.
        let request = match unsafe { PowerSetRequest(*handle, PowerRequestExecutionRequired) } {
            Ok(()) => PowerRequestExecutionRequired,
            Err(error) => {
                tracing::debug!(%error, "using a system-idle request for this call");
                unsafe { PowerSetRequest(*handle, PowerRequestSystemRequired)? };
                PowerRequestSystemRequired
            }
        };
        Ok(Self { handle, request })
    }
}

impl Drop for CallPower {
    fn drop(&mut self) {
        // SAFETY: The live handle has one count for the successful request.
        // Windows can also end those requests on suspend, so closing the owned
        // handle is the final cleanup if PowerClearRequest reports an error.
        let _ = unsafe { PowerClearRequest(*self.handle, self.request) };
    }
}
