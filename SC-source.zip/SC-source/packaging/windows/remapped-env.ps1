param([Parameter(Mandatory=$true)][string]$Repo, [Parameter(Mandatory=$true)][string]$TargetDir)
$ErrorActionPreference='Stop'
$scPublicRepo=(Resolve-Path -LiteralPath $Repo).Path
$scPublicTarget=[IO.Path]::GetFullPath($TargetDir)
$scCargoHome=if($env:CARGO_HOME){[IO.Path]::GetFullPath($env:CARGO_HOME)}else{Join-Path $env:USERPROFILE '.cargo'}
New-Item -ItemType Directory -Path $scPublicTarget -Force | Out-Null
$scPathNames=New-Object -ComObject Scripting.FileSystemObject
# Broad prefixes first; the last matching Rust mapping wins. Cover both
# separator spellings because native build scripts use both on Windows.
$scRemapPairs=@(
    @($env:USERPROFILE, '/home'),
    @($scCargoHome, '/cargo'),
    @($scPublicRepo, '/sc'),
    @($scPublicTarget, '/build')
)
$scPublicMaps=@()
foreach($pair in $scRemapPairs){
    $scShortPath=$scPathNames.GetFolder($pair[0]).ShortPath
    foreach($prefix in @($pair[0],$pair[0].Replace('\','/'),$scShortPath,$scShortPath.Replace('\','/')) | Select-Object -Unique){
        $scPublicMaps += "$prefix=$($pair[1])"
    }
}
# Encoded flags avoid whitespace splitting in the host user's path. Explicitly
# preserve the repository's static MSVC CRT setting when overriding rustflags.
$env:CARGO_ENCODED_RUSTFLAGS=(@('-Ctarget-feature=+crt-static') + @($scPublicMaps | ForEach-Object {"--remap-path-prefix=$_"})) -join [char]31
$env:CC_SHELL_ESCAPED_FLAGS='1'
$scQuoteEscape=[string][char]39+[char]34+[char]39+[char]34+[char]39
$scNativeFlags=(@($scPublicMaps | ForEach-Object {"'"+("/clang:-ffile-prefix-map=$_").Replace("'",$scQuoteEscape)+"'"}) + @("'/clang:-ffile-compilation-dir=/build'")) -join ' '
foreach($scFlagName in @('CFLAGS_x86_64_pc_windows_msvc','CXXFLAGS_x86_64_pc_windows_msvc')){
    $scExistingFlags=[Environment]::GetEnvironmentVariable($scFlagName,'Process')
    [Environment]::SetEnvironmentVariable($scFlagName, (($scExistingFlags+' '+$scNativeFlags).Trim()), 'Process')
}
$env:CARGO_TARGET_DIR=$scPublicTarget
$env:CARGO_INCREMENTAL='0'
