# Launched by SC.exe from outside the package directory. No console UI is shown.
param([string]$InstallDirectory, [string]$DataDirectory, [string]$Tag, [int]$AppPid)
$ErrorActionPreference = 'Stop'
if ((Split-Path -Leaf $PSScriptRoot) -notlike 'sc-app-update-*') { throw 'Run the update from S;C.' }
$parentApp = $null
$handoff = @{ Committed = $false }
try {
    Import-Module (Join-Path $PSScriptRoot 'SC.Update.psm1') -Force -DisableNameChecking
    $target = [IO.Path]::GetFullPath($InstallDirectory).TrimEnd('\')
    $profileDir = [IO.Path]::GetFullPath($DataDirectory).TrimEnd('\')
    if ($profileDir -eq $target -or $profileDir.StartsWith($target + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'The profile is inside the app folder.'
    }
    $ownFiles = @('SC.exe','BUILD.json','SC.ico','LICENSE.txt','THIRD-PARTY.json','SOURCE.txt','README.txt','SC-INSTALL.json','licenses','vencord-companion')
    if (@(Get-ChildItem -LiteralPath $target -Force | Where-Object Name -NotIn $ownFiles).Count) { throw 'S;C needs its own directory.' }
    if (@(Get-SCCompanionProcesses $target).Count) { throw 'Close the Vencord companion before updating S;C.' }
    $parentApp = @(Get-SCInstalledProcesses $target | Where-Object Id -EQ $AppPid)
    if ($parentApp.Count -ne 1) { throw 'The requesting S;C process is no longer running.' }
    $parentApp = $parentApp[0]
    # Pin a process handle so waiting cannot accidentally follow a recycled PID.
    [void]$parentApp.Handle
    $before = {
        [Console]::Out.WriteLine('SC-UPDATE-READY')
        [Console]::Out.Flush()
        if ([Console]::In.ReadLine() -cne 'SC-UPDATE-COMMIT') { throw 'The update was cancelled.' }
        $handoff.Committed = $true
        if (!$parentApp.WaitForExit(60000)) { throw 'S;C did not shut down in time.' }
    }.GetNewClosure()
    Invoke-SCInstall -Repository 'sso-coool/sc' -Tag $Tag -InstallDirectory $target -DataDirectory $DataDirectory -Launch -BeforeInstall $before | Out-Null
} catch {
    # Never print paths or credentials to stdout. On a post-exit error, reopen
    # the original app if the helper could neither swap nor relaunch it.
    if ($handoff.Committed -and $parentApp -and $parentApp -is [Diagnostics.Process] -and $parentApp.HasExited) {
        try { Start-SCInstalled $target -DataDirectory $DataDirectory } catch { }
    }
    try { [Console]::Out.WriteLine('SC-UPDATE-FAILED') } catch { }
    exit 1
} finally {
    # Known files only, from the per-attempt directory made by the application.
    Remove-Module SC.Update -ErrorAction SilentlyContinue
    foreach ($file in @('SC.Update.psm1','Invoke-SCAppUpdate.ps1')) {
        Remove-Item -LiteralPath (Join-Path $PSScriptRoot $file) -Force -ErrorAction SilentlyContinue
    }
    try { [IO.Directory]::Delete($PSScriptRoot, $false) } catch { }
}
